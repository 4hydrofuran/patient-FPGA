"""User-operated single question, warmed prefix and retained HDMI desktop."""
import copy
import json
from pathlib import Path
import subprocess
import threading
import time

from board_case import WorkerTransport, load_native

SERVER = THREAD = APP = None


class CachedTransport(WorkerTransport):
    def __init__(self, *args):
        super().__init__(*args)
        self.binding = None
        self.answer_requested = False
        self.warm_result = None

    def warm(self, ready, request):
        self.binding = ready['prefix_cache']['binding_sha256']
        request = copy.deepcopy(request)
        request['cache_binding_sha256'] = self.binding
        self.inflight = True
        self.worker.send(request)
        while True:
            result = self.api.receive(self.worker, self.owner, self.path, timeout=180)
            if result.get('type')=='cache_created':
                self.inflight = False
                self.warm_result = result
                assert result['id']==request['id'] and result['status']=='OK'
                assert result['state_cleared_before_response'] and result['state_position_after_clear']==-1
                assert result['prefix_cache']['binding_sha256']==self.binding
                assert any(e['tokens']==70 for e in result['prefix_cache']['entries'])
                return result
            if result.get('type')=='error':
                self.inflight = False
                raise RuntimeError('Prefix preparation failed: '+str(result))

    def send(self, request):
        if self.answer_requested:
            raise RuntimeError('This manual window allows one model question')
        request = dict(request, cache_policy='TT10_REQUIRE_HIT', cache_id='neutral',
                       cache_binding_sha256=self.binding, prefill_chunk=256,
                       profile=False, diagnostic_report=False)
        self.answer_requested = True
        return super().send(request)

    def get(self, timeout):
        result = super().get(timeout)
        if result.get('type')=='result':
            cache = result['prefix_cache_request']
            assert cache['hit'] is True and cache['reused_tokens']==70
        return result


def desktop_environment():
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            if p.stat().st_uid==1000 and (p/'comm').read_text().strip()=='gsd-power':
                values=dict(x.split('=',1) for x in (p/'environ').read_bytes().decode().split('\0') if '=' in x)
                return {k:values[k] for k in ('DBUS_SESSION_BUS_ADDRESS','DISPLAY','WAYLAND_DISPLAY','XDG_RUNTIME_DIR','XAUTHORITY') if k in values}
        except (FileNotFoundError,PermissionError):
            pass
    raise RuntimeError('Logged-in desktop is required')


def run_case(worker, owner, path, *, real, api, overlay):
    global SERVER, THREAD, APP
    import uvicorn
    from patient_web.errors import GatewayError
    from web_managed import create_app
    assert real
    path, overlay = Path(path), Path(overlay)
    transport = CachedTransport(worker,owner,path,api)
    ready = api.receive(worker,owner,path,timeout=180)
    api.save(path/'ready.json',ready)
    requests=json.loads((api.BUNDLE/'control/requests.json').read_text())
    warm=next(r for r in requests if r['id']=='warm_prefix')
    transport.warm(ready,warm)
    api.save(path/'warm-result.json',transport.warm_result)
    native=load_native(overlay,'/opt/patient-qwen')(transport,ready,max_output_tokens=24)
    alive=lambda: (not owner.finished and not worker.closed and not worker.quarantined
                   and not worker.delivery_cancelled and worker.process.poll() is None)
    APP=create_app(native,is_ready=alive,remaining_seconds=lambda:(owner.expires-time.monotonic_ns())/1e9)
    coordinator=APP.state.coordinator
    original_submit=coordinator.submit
    def single_submit(sid,rid,text):
        with coordinator.lock:
            conversation=coordinator._conversation(sid)
            previous=coordinator._duplicate(conversation,rid,'turn',text)
            if previous:
                return previous
            if conversation.turns:
                raise GatewayError('SINGLE_QUESTION_COMPLETE','本次提问已完成，请点击“结束问诊”查看评价。')
            return original_submit(sid,rid,text)
    coordinator.submit=single_submit
    SERVER=uvicorn.Server(uvicorn.Config(APP,host='127.0.0.1',port=8000,workers=1,log_level='info'))
    THREAD=threading.Thread(target=SERVER.run,name='manual-web',daemon=True)
    THREAD.start()
    for _ in range(100):
        if SERVER.started and coordinator.initialized.is_set():
            break
        time.sleep(.1)
    else:
        raise RuntimeError('Web initialization failed')
    env=desktop_environment()
    command=['runuser','-u','ubuntu','--','env',*[k+'='+v for k,v in env.items()]]
    subprocess.run(command+['gsettings','set','org.gnome.desktop.a11y.applications','screen-keyboard-enabled','true'],check=True)
    profile='/home/ubuntu/snap/firefox/common/manual-pl-20261026-v1'
    subprocess.run(['runuser','-u','ubuntu','--','/usr/bin/python3','-c',
                    'from pathlib import Path;Path('+repr(profile)+').mkdir()'],check=True)
    with (path/'browser.log').open('xb') as log:
        browser=subprocess.Popen(command+['gnome-session-inhibit','--inhibit','idle','--reason','Manual-PL-consultation',
            '/snap/bin/firefox','--no-remote','--profile',profile,'--kiosk','http://127.0.0.1:8000/'],
            stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
    api.save(path/'INTERACTIVE_READY.json',dict(status='READY_WAITING_FOR_USER_INPUT',url='http://127.0.0.1:8000/',
             backend='FPGA_REAL',prefix_warmed=True,prefix_tokens=70,model_questions=0,browser_pid=browser.pid,
             maximum_questions=1,expires_monotonic_ns=owner.expires))
    while time.monotonic_ns()<owner.expires-180_000_000_000:
        with coordinator.lock:
            sid=coordinator.current_session
            conversation=coordinator.conversations.get(sid) if sid else None
            done=conversation is not None and conversation.closed and coordinator.work is None
        if done:
            break
        time.sleep(1)
    while transport.inflight:
        time.sleep(.25)
    with coordinator.lock:
        snapshot=coordinator.snapshot(sid) if sid else None
    api.save(path/'manual-session.json',snapshot)
    result=transport.last_result or transport.warm_result
    api.save(path/'native-result.json',result)
    assert worker.close(timeout=30) and worker.closed and worker.process.returncode==0
    api.save(path/'manual-compute-closed.json',dict(worker_exit=0,permission_runs=worker.runs,
             model_requests=native.count,prefix_hit=result.get('prefix_cache_request',{}).get('hit')))
    return result


def keep_result_service(seconds=1800):
    """After PS releases hardware, keep the completed session readable."""
    if SERVER is not None:
        time.sleep(seconds)
        SERVER.should_exit=True
        THREAD.join(timeout=15)
