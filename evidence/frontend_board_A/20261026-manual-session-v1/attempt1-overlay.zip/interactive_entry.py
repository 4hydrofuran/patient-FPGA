"""An explicitly graphical, single-question PL window; keeps PS display alive."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from board_entry import prepared_main

ROOT=Path(__file__).resolve().parent
BUNDLE=ROOT/'bundle'
FRONT=Path('/home/ubuntu/patient-web-demo-20261026')


def graphical_platform(original):
    class GraphicalPlatform(original):
        def service(self,action):
            if action=='stop':
                result=subprocess.run(['systemctl','is-active','gdm'],capture_output=True,text=True,timeout=5)
                if result.stdout.strip()!='active':
                    raise RuntimeError('Manual HDMI session requires the active desktop')
                self.gdm_isolated=False
                self.emit('GDM_KEPT_FOR_USER_HDMI_SESSION',reason='User requested touch-screen text input')
            else:
                return super().service(action)

        def wait_prepl_quiet(self):
            # No GDM shutdown occurred. Reuse the existing PL-holder check once,
            # rather than waiting for shutdown-related process sets to settle.
            if self.pl_mutation_started or self.worker is not None:
                raise RuntimeError('Display coexistence admission must precede PL/native activity')
            self.no_users(module_loaded=False)
    return GraphicalPlatform


def main():
    assert os.geteuid()==0 and os.uname().release=='6.8.12-a10irq2'
    assert not Path('/var/lock/kv260-a1/active').exists() and not Path('/sys/module/zocl').exists()
    for path in (FRONT/'web_gateway/src',FRONT/'.venv/lib/python3.12/site-packages',ROOT):
        sys.path.insert(0,str(path))
    import patient_web.managed,interactive_case
    assert not (BUNDLE/'run-v1').exists()
    raw=subprocess.check_output(['dmesg','--raw']).decode()
    (BUNDLE/'control/preflight.json').write_text(json.dumps(dict(boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),kernel_raw=raw)))
    manifest=json.loads((BUNDLE/'manifest.json').read_text())
    manifest['files']=[dict(path=p.relative_to(BUNDLE).as_posix(),bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(BUNDLE.rglob('*'))
        if p.is_file() and p!=BUNDLE/'manifest.json']
    (BUNDLE/'manifest.json').write_text(json.dumps(manifest,indent=2))
    source=BUNDLE/'control/resource_probe_manager.py'
    spec=importlib.util.spec_from_file_location('manual_original_manager',source)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.Platform=graphical_platform(module.Platform)
    module.run_case=lambda worker,owner,path,real:interactive_case.run_case(worker,owner,path,real=real,api=module,overlay=ROOT)
    exec(prepared_main(source.read_text()),module.__dict__)
    module.run_web_bound()
    interactive_case.keep_result_service(1800)


if __name__=='__main__':main()
