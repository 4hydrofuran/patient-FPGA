OFFLINE PRIVATE-PROMPT CPU REVIEW ONLY. NOT STANDALONE OR BOARD AUTHORIZATION.
The existing actual native/CPU adapter and original request, source, health, budget, graph-copy, END/receipt/fresh-delivery gates are exercised.
All 25 facts-only cohorts passed cap72; six representative cohorts passed cap1. Eight targeted fault windows withhold answers.
Startup stale legacy-ticket failure is retained. Lifecycle-only fresh ticket now follows durable record, with unchanged 250ms bound and fault latch.
The three-request acceptance window is not resident interactive SERVICE. New-prompt typed Board adapter remains unfinished and no ARM was executed.
No model/weights/sidecars/bitstream, install/recovery or Board execution scripts. Original ordinary probe remains first later Board baseline.
CPU timings start at native send and omit real input routing, initial model/prefix readiness and any Board performance evidence.
