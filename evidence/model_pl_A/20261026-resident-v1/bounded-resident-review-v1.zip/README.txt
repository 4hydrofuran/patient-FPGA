REVIEW ONLY. NOT STANDALONE OR A BOARD COMPUTE AUTHORIZATION.
No weights, credentials, leases or diagnostics. Requires pinned existing SDK/math/model assets.
CPU code is software-test only. Board default unbound backend remains unsupported.
Separate original Owner review, recovery, fresh release, matching kernel and ordinary baseline first.
