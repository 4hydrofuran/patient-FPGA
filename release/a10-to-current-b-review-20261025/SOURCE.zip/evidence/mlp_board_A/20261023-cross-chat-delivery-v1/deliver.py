"""Documentation delivery only; no board connection or modification."""
import datetime,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=Path(__file__).resolve().parent
source=ROOT/'docs/handoffs/A11_COMPLETE_CROSS_CHAT_HANDOFF_20261023.md'
target=Path('C:/Users/Fang/Desktop/KV260_Qwen35_A11完成_跨对话交付_20261023.md')
old_desktop=Path('C:/Users/Fang/Desktop/KV260_Qwen35_A11_跨对话交付_20261023.md')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original_hash=sha(old_desktop)
seal=ROOT/'evidence/mlp_board_A/20261023-compute-acceptance-v1/SEAL.json'
assert sha(seal)=='4e817a8add532e941c8628c2aef180f1099d4b2090f29cf7925d1723641e9a80'
entries=json.loads(seal.read_bytes())['files']
for n,e in entries.items():
    p=ROOT/n;assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],n
audit=json.loads((seal.parent/'AUDIT.json').read_bytes())
assert audit['A11']=='PASS_WITH_LIMITATIONS' and audit['all_bit_exact'] and audit['real_submissions']==23
body=source.read_bytes();text=body.decode('utf-8')
assert len(re.findall(r'^## [1-9]\. ',text,re.M))==9
assert 'A12尚未开始' in text and audit['manifest_sha256'] in text
assert 'password' not in text.lower() and 'BEGIN PRIVATE KEY' not in text
with target.open('xb') as f:f.write(body)
assert source.read_bytes()==target.read_bytes() and sha(old_desktop)==original_hash
receipt=dict(status='DELIVERED_BYTE_IDENTICAL_DOCUMENTATION_ONLY',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source=str(source),desktop=str(target),bytes=len(body),sha256=sha(source),
    old_desktop_preserved=dict(path=str(old_desktop),sha256=original_hash),
    A11='PASS_WITH_LIMITATIONS',A12='NOT_STARTED',acceptance_seal_sha256=sha(seal),
    prior_sealed_files_reverified=len(entries),new_board_connections=0,board_actions=0,git_commit=False,git_push=False)
with (E/'RECEIPT.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,ensure_ascii=False,indent=2)
files=[source,target,E/'deliver.py',E/'RECEIPT.json']
with (E/'SEAL.json').open('x',encoding='utf-8') as f:
    json.dump(dict(status='SEALED_A11_COMPLETE_CROSS_CHAT_HANDOFF',files={str(p):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}),f,ensure_ascii=False,indent=2)
print(json.dumps(receipt,ensure_ascii=False))
