import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((E/'AUDIT.json').read_bytes())
for name in a['old_seals_verified']:
 for n,e in json.loads((ROOT/name).read_bytes())['files'].items():
  p=ROOT/n;assert sha(p)==e['sha256'] and p.stat().st_size==e['bytes'],n
for n in ('contracts_final_01.json','config_final_01.json','audit_02.json'):
 assert json.loads((E/n).read_bytes())['exit_code']==0,n
for folder,names in [('governance_snapshot',['docs/PROJECT_STATUS.json','docs/DESIGN_GAP.md','docs/DECISIONS.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md','docs/status/A.md']),
                     ('source_snapshot',[p.relative_to(ROOT).as_posix() for p in (ROOT/'platform/qwen35/a11').iterdir() if p.suffix in ('.py','.ps1')])]:
 dest=E/folder;dest.mkdir(exist_ok=False)
 for n in names:
  p=dest/n;p.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(ROOT/n,p)
entries={p.relative_to(ROOT).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(E.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='SEAL.json'}
data=dict(status='SEALED_OPEN_FIX_ONLY_A11_NOT_PASSED',compute_submissions=0,files=entries)
with (E/'SEAL.json').open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
assert all(sha(ROOT/n)==v['sha256'] for n,v in entries.items())
print(json.dumps(dict(files=len(entries),status=data['status'],seal_sha256=sha(E/'SEAL.json'))))
