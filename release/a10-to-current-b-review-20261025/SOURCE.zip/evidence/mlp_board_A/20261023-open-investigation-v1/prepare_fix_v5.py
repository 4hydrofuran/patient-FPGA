import base64,hashlib,json,shutil
from pathlib import Path
E=Path(__file__).resolve().parent
src=E/'open-package-v3';out=E/'open-package-v5'
shutil.copytree(src,out)
p=out/'trial-profile-template.json';profile=json.loads(p.read_bytes())
assert profile['bo_charge_alignment']==4096
profile['bo_charge_alignment']=8192
p.write_bytes(json.dumps(profile,indent=2).encode())
m=json.loads((out/'manifest.json').read_bytes())
m['files'][p.name]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
raw=json.dumps(m,indent=2).encode();(out/'manifest.json').write_bytes(raw)
pin=hashlib.sha256(raw).hexdigest()
baseline=hashlib.sha256((E/'board-readback-v4/kernel.raw.txt').read_bytes()).hexdigest()
oldpin='1920cac8eca8e596eab93e555770c69388741f248041a183a04e88dab84792d0'
launch=(E/'launch_open_once_v4.py').read_text().replace('a11-open-20261023-v4','a11-open-20261023-v5').replace(oldpin,pin).replace('48648001dbfff6560abf123609ec77a8bf8aa1aed3da2c8a242de38961c8b0a4',baseline)
(E/'launch_open_once_v5.py').write_bytes(launch.encode())
payloads={p.name:base64.b64encode(p.read_bytes()).decode(),'manifest.json':base64.b64encode(raw).decode(),'launch_open_once.py':base64.b64encode(launch.encode()).decode()}
script='''import json,hashlib,os,base64
from pathlib import Path
old=Path('/var/lib/kv260-a11/a11-open-20261023-v4');new=Path('/var/lib/kv260-a11/a11-open-20261023-v5')
assert os.geteuid()==0 and not os.path.lexists('/var/lock/kv260-a1/active') and not Path('/sys/module/zocl').exists()
assert json.loads((old/'host-exit.json').read_text())['exit_code']==0
assert hashlib.sha256((old/'manifest.json').read_bytes()).hexdigest()==OLDPIN
before=json.loads((old/'manifest.json').read_bytes());payload=PAYLOAD
after=json.loads(base64.b64decode(payload['manifest.json']))
os.umask(0o077);new.mkdir(mode=0o700)
for name,entry in before['files'].items():
 data=(old/name).read_bytes()
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
 if name in payload:data=base64.b64decode(payload[name])
 expected=after['files'][name]
 assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
 target=new/name;target.parent.mkdir(exist_ok=True,parents=True)
 with target.open('xb') as f:f.write(data)
for name in ('manifest.json','launch_open_once.py'):
 with (new/name).open('xb') as f:f.write(base64.b64decode(payload[name]))
assert hashlib.sha256((new/'manifest.json').read_bytes()).hexdigest()==NEWPIN
print(json.dumps(dict(status='STAGED_V5_NO_COMPUTE',manifest_sha256=NEWPIN)))
'''.replace('OLDPIN',repr(oldpin)).replace('NEWPIN',repr(pin)).replace('PAYLOAD',repr(payloads))
(E/'stage_open_v5.py').write_bytes(script.encode())
(E/'start_wait_v5.py').write_bytes((E/'start_wait_v4.py').read_text().replace('a11-open-20261023-v4','a11-open-20261023-v5').encode())
print(json.dumps(dict(manifest_sha256=pin,baseline_sha256=baseline)))
