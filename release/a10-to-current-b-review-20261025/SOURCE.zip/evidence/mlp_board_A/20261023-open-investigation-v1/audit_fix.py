"""Offline audit of immutable diagnostic windows, never contacts hardware."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=Path(__file__).resolve().parent
sys.path.insert(0,str(E/'open-package-v5'))
from kernel_log_gate import diagnostics
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,msg):
 if not ok:raise RuntimeError(msg)
old=E/'board-readback-v4';new=E/'board-readback-v5'
before=read(old/'worker-result.json');after=read(new/'worker-result.json')
check(before['open_status_code']==8 and before['real_submissions']==0,'original failure lost')
check(after['open_status_code']==after['close_status_code']==after['real_submissions']==0,'fixed open/close differs')
check(after['normal_handles_closed'] is True,'normal close missing')
rows=[json.loads(s) for s in (new/'lifecycle.jsonl').read_text().splitlines()]
reaped=[r for r in rows if r['event']=='WORKER_REAPED']
check(len(reaped)==1 and reaped[0]['exit_code']==0,'worker not normally reaped')
check(read(new/'host-exit.json')['exit_code']==0,'manager exit failed')
check(read(new/'fetch_receipt.json')['exit_code']==0,'fetch failed')
releases=[r for r in rows if r['event']=='RELEASE_PRECHECK_PASSED_NOT_UNLOADED']
check(len(releases)==1 and releases[0]['module_refcount']==0,'release precheck missing')
state=read(new/'state.json');scan=state['scan']
check(scan['scan_complete'] and not scan['scan_issues'] and not scan['device_holders'] and not scan['device_mappings'],'resource scan failed')
check(not state['zocl'] and not state['active_lease_exists'] and not any(state['locks'].values()),'resources retained')
check(state['overlays']=={'k26-starter-kits_image_1':'applied'} and state['fpga']=='operating' and state['gdm']=='active','default not restored')
check(after['manager_pid'] not in [r['pid'] for r in scan['inspected_processes']] and after['worker_pid'] not in [r['pid'] for r in scan['inspected_processes']],'worker/manager still live')
gates=[r for r in rows if r['event']=='KERNEL_LOG_GATE']
check(gates and all(g['allowed'] for g in gates),'kernel gate rejected')
last=gates[-1]['raw_log'];raw=(new/'kernel.raw.txt').read_bytes().decode('utf-8')
check(raw.startswith(last) and not diagnostics(raw[len(last):]),'new post-window diagnostics')
bad=[json.loads(s) for s in (old/'worker.stderr.txt').read_text().splitlines() if 'A11_BO_VALIDATION' in s]
good=[json.loads(s) for s in (new/'worker.stderr.txt').read_text().splitlines()]
check(bad[-1]['actual_address']==34507137024 and bad[-1]['actual_size']==4096 and not bad[-1]['range_ok'],'root cause observation differs')
check([r['argument'] for r in good]==[2,3,4,5] and [r['actual_size'] for r in good]==[40960,8192,155648,8192],'fixed layout differs')
check(all(r['range_ok'] and r['size_ok'] and 0<=r['actual_address']<r['actual_address']+r['actual_size']<=2147483648 for r in good),'fixed range failed')
m0=read(E/'open-package-v3/manifest.json');m1=read(E/'open-package-v5/manifest.json')
check(m0.keys()==m1.keys() and m0['files'].keys()==m1['files'].keys(),'package membership changed')
changed=[n for n in m0['files'] if m0['files'][n]!=m1['files'][n]]
check(changed==['trial-profile-template.json'],'uncontrolled A/B variable')
for pkg in ('open-package-v3','open-package-v5','mlp-fixed-PC-candidate-v2'):
 for n,e in read(E/pkg/'manifest.json')['files'].items():
  p=E/pkg/n;check(p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],'payload changed: '+str(p))
seals=['evidence/board_platform/A10_20261023_isolated_single_v1/seal_01.json',
       'evidence/mlp_board_A/20261023-integration-v1/stopped_audit_01/SEAL.json',
       'evidence/mlp_board_A/20261023-final-closeout-v1/SEAL.json']
verified={}
for name in seals:
 entries=read(ROOT/name)['files']
 for n,e in entries.items():
  p=ROOT/n;check(sha(p)==e['sha256'] and p.stat().st_size==e['bytes'],'historical seal changed: '+n)
 verified[name]=len(entries)
for name in ('contracts_01.json','config_01.json','engine_fix_01.json','tests_v5_01.json','package_fix_02.json','bo_diagnostics_build_01.json','kernel_source_01.json','management_fix_01.json'):
 check(read(E/name)['exit_code']==0,'check failed: '+name)
result=dict(status='PASS_OPEN_ERROR_FIX_AND_NORMAL_RELEASE_ONLY',A11='NOT_PASSED',A12='NOT_ELIGIBLE',
 boot_id=state['boot_id'],kernel=state['kernel'],observed_failure=bad[-1],fixed_bo_observations=good,
 open_status=0,close_status=0,worker_exit_code=0,manager_exit_code=0,compute_submissions=0,
 explicit_io_charged_bytes=sum(r['actual_size'] for r in good),physical_peak_bytes=None,
 model_performance=None,full_mlp_board_test='NOT_TESTED',default_restored=True,gdm_active=True,
 device_FD_VMA=[0,0],zocl_absent=True,locks_held=0,active_lease_absent=True,
 post_window_new_diagnostics=0,existing_advisories_preserved=True,
 readback_delay_seconds=(state['read_monotonic_ns']-rows[-1]['monotonic_ns'])/1e9,
 peak_sample_temperature_mC=max(t for r in rows for t in r.get('temperatures_mC',[])),
 old_seals_verified=verified,manifest_sha256=sha(E/'open-package-v5/manifest.json'),
 fix='private allocation alignment 8192; exact size, 2 GiB range and 4 MiB budget remain enforced')
with (E/'AUDIT.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
