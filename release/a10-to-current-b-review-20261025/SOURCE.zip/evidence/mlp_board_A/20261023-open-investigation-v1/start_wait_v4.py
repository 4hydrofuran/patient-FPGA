import subprocess,sys;from pathlib import Path;p=Path('/var/lib/kv260-a11/a11-open-20261023-v4');assert not (p/'launch-reservation').exists();(p/'launch-reservation').touch(exist_ok=False);c=subprocess.Popen(['/usr/bin/python3','-B','-I','-c',"import subprocess,json,os\nfrom pathlib import Path\np=Path('/var/lib/kv260-a11/a11-open-20261023-v4')\nout=(p/'host.stdout.jsonl').open('xb');err=(p/'host.stderr.txt').open('xb')\nc=subprocess.Popen(['/usr/bin/python3','-B','-I',str(p/'launch_open_once.py'),'8422f92f-d01f-4849-ad19-6e66b640a9ad'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True)\nwith (p/'launcher-pid.json').open('x') as f:json.dump(dict(pid=c.pid,wrapper_pid=os.getpid()),f)\nrc=c.wait();out.close();err.close()\nwith (p/'host-exit.json').open('x') as f:json.dump(dict(exit_code=rc,pid=c.pid),f)\n"],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True,close_fds=True);print(c.pid)
import time,json
for i in range(90):
 if (p/'host-exit.json').exists() or (p/'STOP.json').exists():break
 time.sleep(.5)
names=('host-exit.json','worker-result.json','worker.stderr.txt','host.stderr.txt','STOP.json')
print(json.dumps({n:(p/n).read_text() for n in names if (p/n).exists()}))
