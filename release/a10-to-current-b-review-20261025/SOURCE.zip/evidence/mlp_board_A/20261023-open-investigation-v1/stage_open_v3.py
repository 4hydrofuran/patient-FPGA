import json,hashlib,os,subprocess
from pathlib import Path
old=Path('/var/lib/kv260-a11/a11-open-20261023-v2');new=Path('/var/lib/kv260-a11/a11-open-20261023-v3')
assert os.geteuid()==0 and not Path('/var/lock/kv260-a1/active').exists() and not Path('/sys/module/zocl').exists()
assert json.loads((old/'host-exit.json').read_text())['exit_code']==0
assert hashlib.sha256((old/'manifest.json').read_bytes()).hexdigest()=='144186dde74cb83a86e88b1948b547cff51f734170e6f51f3c873d39cb29552a'
m=json.loads((old/'manifest.json').read_text());os.umask(0o077);new.mkdir(mode=0o700)
for name,e in m['files'].items():
 data=(Path('/home/ubuntu/a11-open-upload-20261023-v1/bo-diagnostics-v1.so') if name=='libsp_linear_a11_trial.so' else old/name).read_bytes()
 if name=='libsp_linear_a11_trial.so':
  assert hashlib.sha256(data).hexdigest()=='f4ea5d55b36f2fef964b3a09e83ac0ee7dc49528bc40f42dba8fb8b1b4129881'
  e.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 else:assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
 target=new/name;target.parent.mkdir(exist_ok=True,parents=True)
 with target.open('xb') as f:f.write(data)
b=json.dumps(m,indent=2).encode();assert hashlib.sha256(b).hexdigest()=='1920cac8eca8e596eab93e555770c69388741f248041a183a04e88dab84792d0'
with (new/'manifest.json').open('xb') as f:f.write(b)
s=(old/'launch_open_once.py').read_text().replace(str(old),str(new)).replace('144186dde74cb83a86e88b1948b547cff51f734170e6f51f3c873d39cb29552a','1920cac8eca8e596eab93e555770c69388741f248041a183a04e88dab84792d0').replace('e49af99847f68f0fe30c462ca688aae05276902ddaf0d372fed509262a603c0d','48648001dbfff6560abf123609ec77a8bf8aa1aed3da2c8a242de38961c8b0a4')
assert hashlib.sha256(s.encode()).hexdigest()=='eef036705021909c36d2122f4f7ed5623e678677edffd74d82ce4640a8e38ffc'
with (new/'launch_open_once.py').open('x') as f:f.write(s)
print(json.dumps(dict(status='STAGED_V3_NO_COMPUTE',manifest_sha256='1920cac8eca8e596eab93e555770c69388741f248041a183a04e88dab84792d0')))
