import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];E=Path(__file__).resolve().parent
paths=['docs/PROJECT_STATUS.json','docs/DESIGN_GAP.md','docs/DECISIONS.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md','docs/status/A.md']
backup=E/'governance_before';backup.mkdir(exist_ok=False)
for name in paths:
 p=backup/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,p)
a=json.loads((E/'AUDIT.json').read_bytes())
entry=dict(a,report=str((E/'REPORT.md').relative_to(ROOT)).replace('\\','/'),
           audit=str((E/'AUDIT.json').relative_to(ROOT)).replace('\\','/'),
           next='Review full compute failure-release path, fresh bounded A11 window with 8192-aligned candidate; frozen 23 calls still NOT_TESTED. No replay of consumed open windows.',
           history_rule='Newest captured state supersedes lower historical current-state claims. Not live monitoring; all failures and A00-A17 preserved.')
p=ROOT/paths[0];old=json.loads(p.read_bytes());role=old.pop('role')
p.write_text(json.dumps(dict(role=role,a11_open_fix_20261023=entry,**old),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
ref='`evidence/mlp_board_A/20261023-open-investigation-v1/REPORT.md`'
common='2026-10-23 最新：A11 open错误8已定位并修复。4KiB sx BO落到34507137024高地址而被低2GiB检查拒绝；私有分配对齐改8192，同诊断库单变量板测open0/close0、四IO地址合法、worker/manager正常exit0。独立后验默认PL/GDM恢复、无ZOCL/FD/VMA/持锁/active lease；0计算，A11 NOT_PASSED、A12 NOT_ELIGIBLE。以下旧状态为历史快照。证据'+ref+'。'
entries={
 'docs/DESIGN_GAP.md':'## A11 open阻塞修复（2026-10-23）\n\nD07/D09：两页起分配避免本次单页绕过全局CMA落高DDR，保留每BO低2GiB/尺寸与4MiB预算检查；零计算正常返回及进程释放已板验。完整权重/23调用数值/含搬运计时/计算后恢复仍未测，物理峰值与收益null；P2不扩展。'+common,
 'docs/DECISIONS.md':'2026-10-23 用户授权检查并排除当前阻塞，允许串口连接板卡。限定零计算独立诊断窗口：错误返回走正常worker退出，再由完整FD/VMA/refcount与内核门禁决定普通恢复；异常/所有权不明继续隔离。相同库对照仅改8192分配，不扩大地址窗口、不改ABI数学/内核驱动、不自动重试已消费窗口。'+common,
 'docs/TEST_MATRIX.md':'## A11 open修复验证（2026-10-23）\n\nPC：契约各0；诊断31场景一致/ARM64构建0；open-only17方法、量化引擎12方法、完整管理器10方法通过；新候选manifest0。BOARD v4 open8定位sx高地址；v5 open0 close0、4IO检查通过、0提交、waitpid与manager各0；68.89秒后独立资源清零/默认恢复，最高32.438°C，已有advisories保留，后验无新诊断。旧88/523/70文件封存未变。失败候选、串口超时、Windows路径/审计换行错误均保留。'+common,
 'docs/AI_ASSISTANCE.md':'2026-10-23 用户要求检查排错并允许串口：先COM5身份/只读，执行独立open-only窗口；大证据通过已固定主机密钥SSH传输。密码仅隐藏认证、不落盘。新增诊断、正常错误返回释放、两页BO候选及回归；保留全部失败。无子代理、模型切换声明、重启/刷写/强制终止/升级/计算/提交推送；实际模型设置unknown。'+common,
 'docs/status/A.md':common
}
for name,text in entries.items():
 p=ROOT/name;s=p.read_text(encoding='utf-8');first,sep,rest=s.partition('\n')
 p.write_text(first+'\n\n'+text+'\n\n'+rest.lstrip('\n'),encoding='utf-8')
print(json.dumps(dict(status='GOVERNANCE_UPDATED_HISTORY_PRESERVED',files=paths)))
