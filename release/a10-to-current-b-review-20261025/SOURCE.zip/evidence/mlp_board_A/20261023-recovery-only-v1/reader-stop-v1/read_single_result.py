"""Read-only reconciliation of the stopped cleanup process; no signals."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import base64
import zlib

def pack(data):
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),zlib_base64=base64.b64encode(zlib.compress(data)).decode())

root=Path('/var/lib/kv260-a11/a11-mlp-20261023-v1')
assert os.geteuid()==0 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='8422f92f-d01f-4849-ad19-6e66b640a9ad'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='3b3c46700f92565839abda962e07e557018b8fd1be9e7846613ff46ecf89f11c'
log=root/'recovery-only-20261023-v1/lifecycle.jsonl'
rows=[json.loads(line) for line in log.read_text().splitlines()]
assert rows[0]['event']=='RECOVERY_RESERVED' and rows[0]['pid']==5322
assert rows[-1]['event']=='RECOVERY_STOPPED_NO_RETRY'
p=Path('/proc/5322')
assert int((p/'stat').read_text().rsplit(')',1)[1].split()[19])==rows[0]['start_ticks']
sys.path.insert(0,str(root))
from accelerator_release_gate_v2 import collect
from isolated_idle_policy import LOCKS,lock_owned
k=subprocess.run(['dmesg','--raw'],capture_output=True,timeout=3);assert k.returncode==0 and not k.stderr
g=subprocess.run(['systemctl','is-active','gdm.service'],capture_output=True,timeout=3)
active=Path('/var/lock/kv260-a1/active/lease.json')
result=dict(status='RECOVERY_STOP_READONLY',monotonic_ns=time.monotonic_ns(),pid=5322,
    process=dict(stat=(p/'stat').read_text(),status=(p/'status').read_text(),maps=(p/'maps').read_text(),
        wchan=(p/'wchan').read_text(),children=(p/'task/5322/children').read_text(),
        fds={q.name:os.readlink(q) for q in (p/'fd').iterdir()}),
    locks_owned=[lock_owned(q,5322) for q in LOCKS],
    scan=collect(allow_ps_display=True),module_refcount=Path('/sys/module/zocl/refcnt').read_text().strip(),
    worker_exists=Path('/proc/3308').exists(),manager_exists=Path('/proc/3202').exists(),
    gdm_state=g.stdout.decode().strip(),kernel_log=pack(k.stdout),active_lease=pack(active.read_bytes()),
    temperatures_mC=[int(q.read_text()) for q in Path('/sys/class/hwmon').glob('hwmon*/temp*_input')],
    files={'recovery-lifecycle.jsonl':pack(log.read_bytes())},signals_sent=0,hardware_mutations=0)
print(json.dumps(result))
