# KV260 / Qwen3.5-0.8B A11结束跨对话交付

日期：2026-10-23（北京时间）。用途：在新对话从A11完成状态接续项目。本文是状态快照、证据索引和接续建议，不是自动执行指令；实际工作范围以用户新对话的明确请求为准。

桌面副本：`C:\Users\Fang\Desktop\KV260_Qwen35_A11完成_跨对话交付_20261023.md`。

仓库原件：`C:\Patientqwen\docs\handoffs\A11_COMPLETE_CROSS_CHAT_HANDOFF_20261023.md`。两份内容逐字节相同，哈希与核验收据在`C:\Patientqwen\evidence\mlp_board_A\20261023-cross-chat-delivery-v1\`。

原桌面`KV260_Qwen35_A11_跨对话交付_20261023.md`保持原样，是“仅收口完成、A11计算0次”的历史交接；**当前进展以本文、PROJECT_STATUS最上方和新A11验收证据为准**。不覆盖旧失败、旧报告或旧封存。

## 1. 先看结论

**A11目标层实板数值、含搬运服务计时和正常计算后释放/默认恢复已完成，状态PASS_WITH_LIMITATIONS。A12尚未开始。**

| 项目 | 当前已保存证据支持的结论 |
|---|---|
| A10 | PASS_MINIMAL_WITH_LIMITATIONS；复用有效平台证据，不恢复已取消的1000次回归 |
| 原open错误8 | 已定位并修复：4096字节sx BO落入高DDR，超出低2GiB核地址窗口；8192分配对齐的独立open/close板测通过 |
| A11实际计算 | 23次有效调用：手算1、尾块/双scale1、真实gate/up/down各7；5次权重加载 |
| 实际数值 | 23份FP32原始输出取回核SHA，本机再次独立比较；全部逐字节一致，最大绝对/相对误差0；未放宽容差 |
| 非法参数 | 额外一次T=0检查返回SP_BAD_ARGUMENT=1，调用方输出哨兵不变、不可消费；不计有效硬件提交 |
| 复用与资源 | 四IO BO复用，warm期间权重handle/地址不变，无重复上传；显式BO主机创建计数14，峰值charge 2162688字节 |
| 正常生命周期 | worker、manager均exit0；waitpid、完整FD/VMA/refcount与内核门禁通过后普通卸载/恢复 |
| 最后独立后验 | 默认PL applied、FPGA operating、GDM active、ZOCL absent、FD0/VMA0、双锁无人持有、无active lease |
| 性能性质 | 单层、含量化/同步/复制的小样本服务时延；未证明CPU加速比或完整模型速度 |
| 下一步 | 先审查A12前置、实际模型图消费者、目标ARM64运行时与完整模型资源/调用预算；不再把错误8当未解决阻塞 |

最新板状态来自约北京时间**2026-10-23 21:38**的独立读回，审计在21:38:59 UTC+8开始。该快照不是持续监控。本次交接整理没有再次连接、重启或操作板卡；新对话连接前必须重新核对实际状态。

## 2. 项目目标、职责与当前通过范围

- 板卡KV260，目标`Qwen/Qwen3.5-0.8B`，文本、非思考。模型revision：`2fc06364715b967f1860aea9cf38778875588b17`；固定llama运行时commit：`81e39ad34368329b5db77620721510fd91107e80`。
- A负责当前新版完整默认系统：模型、默认计算/语音、病例评分、部署、验证与材料。已接收B核provider仍是B，A侧修订工具/派生文件单独保存，不代B签核、不另造替代核、不递归搜读B/C工程。
- A05已有成熟完整模型S1同数学CPU路径，但其验收是PC域。A11证明真实尺寸线性算子在板上计算正确，**尚未证明PL结果被完整模型计算图消费**；后者是A12。
- 当前`config\qwen35\selection.json`选择模块A、voice_A、fallback disabled。模块A的选择不等于FPGA已成为默认运行模式，必须结合manifest、实际库、配置与运行日志判断。A11维护候选没有被提升为生产默认。
- 原8B/0.5B只保留历史，不切回旧模型，不从A00重做。A00—A17历史与各分域限制保留，不因A11通过整批重标PASS。
- A11使用固定公共数学，组内整数和、组scale及activation scale、FP32跨组累加次序均不变。FP32算子容差仍为atol=1e-4、rtol=1e-5；本次实际更强，为bit-exact。

## 3. 路径与新对话必读顺序

### 实际工程位置

- **PROJECT_ROOT：`C:\Patientqwen`**；WSL为`/mnt/c/Patientqwen`。不要再套一层`project/`或从D盘历史副本开发。
- 当前分支`member-a/a11-preparation-20261023`，HEAD为`53b4666317dec5397ba49fed2e87451a1f618653`。大量既有修改和未跟踪文件保留；没有Git提交或推送。只检出HEAD不能恢复当前全部成果。
- WSL发行版`KV260-A-2204`，宿主存储在`C:\WSL\KV260-A-2204`。旧VHD是冷备份，不启动重复实例。
- 固定AMD工具2026.1，复用`/home/member-a/AMDDesignTools/2026.1`和`/home/member-a/kv260-sdk-2026.1-common`。不重装、不全局升级、不以x86的`-march=native`交叉构建A53。

### 先读这些文件

1. `C:\Patientqwen\AGENTS.md`。
2. `C:\Patientqwen\docs\PROJECT_STATUS.json`最上方`a11_acceptance_20261023`，根字段stage=A11、stage_status=PASS_WITH_LIMITATIONS；再读`docs\status\A.md`、`docs\DECISIONS.md`、`docs\DESIGN_GAP.md`、`docs\TEST_MATRIX.md`、`docs\AI_ASSISTANCE.md`的最新段落。下方A11未通过、计算0次、仍持锁等均为历史。
3. `C:\Patientqwen\evidence\mlp_board_A\20261023-compute-acceptance-v1\REPORT.md`、`AUDIT.json`、`RESOURCE_ACCOUNTING.json`、`FINAL_CHECK.json`、`SEAL.json`。
4. `C:\Patientqwen\docs\handoffs\A_A11_COMPLETE_20261023.md`；必要时读open修复报告`C:\Patientqwen\evidence\mlp_board_A\20261023-open-investigation-v1\REPORT.md`，不要从历史失败重新推断当前原因。
5. `C:\Patientqwen\contracts\qwen35\contracts.lock`及公共接口/量化定义。公共契约SHA256：`83bd402b39350710d8689d50f79296e9625e9c75ccb0ecee145f08067c4ee3b6`。
6. A05入口说明`C:\Patientqwen\runtime\qwen35_w4a8\README.md`、`C:\Patientqwen\docs\handoffs\A_A05_CLOSEOUT_20261002.md`、`C:\Patientqwen\eval\qwen35\a05\batch-fix-v1\REPORT.md`；A07说明`C:\Patientqwen\docs\handoffs\A_A07_CLOSEOUT_20261004.md`。
7. 当前唯一主任务包目录：`C:\Patientqwen\docs\plan_qwen35\KV260_Qwen35_A_详细设计增强任务包_20261002\KV260_Qwen35_A_设计增强包_20261002\`。读`03_A_系统实现与验证_阶段提示词_措辞精简版.md`中的A12及`12_A_详细设计与性能优化方案.md`的D04/D05/D06/D09。旧日历是计划，不按日期推断完成或重做已通过项。

### 关键代码、产物与证据

下列子路径统一相对于`C:\Patientqwen`。

| 子路径 | 用途/准确状态 |
|---|---|
| `platform\qwen35\a11\mlp_engine.py`、`mlp_worker.py` | 实际ABI调用、量化/原生调用/输出计时、原始Y保存、健康/父许可 |
| `platform\qwen35\a11\compute_result.py`、`manager_support.py` | 成功/已关闭失败结果验证；串行许可、abort_close、停止闩锁 |
| `platform\qwen35\a11\prepare_compute_bundle.py` | 从已封存原件派生新计算包；只排除根manifest，并真正verify_bundle |
| `platform\qwen35\a11\prepare_bundle.py` | 当前标准打包入口，已委托新完整流程；不再用旧边界配新worker |
| `platform\qwen35\a11\audit_compute.py` | 对取回原始Y、独立golden、身份链、服务时间及释放结果作离线复核 |
| `platform\qwen35\a11\test_engine.py`、`test_compute_management.py` | 引擎与Linux真实子进程/flock/许可/恢复fixture；不是BOARD数值 |
| `evidence\mlp_board_A\20261023-compute-acceptance-v1\bundle-v2\` | **实际执行的82文件包**，管理器/边界为独立派生；本地目录名v2对应板端窗口v3，不要混淆 |
| 同目录`readback-v3\` | 新鲜独立state、完整lifecycle/kernel、worker-result、原始23份Y、profile/review/退出收据 |
| 同目录`execute_v3\`、`stage_v3\` | 一次正式启动及暂存收据，远端/主机exit0 |
| 同目录`bundle-v1\`、`execute_v2\` | 新打包器首次清单遗漏失败，硬件前拒绝；保留，不作完成包 |
| 同目录`standard-entry-PC-check\` | 标准入口生成结果；manifest与正式bundle-v2完全相同，未另上板 |
| 同目录`source_snapshot\`、`governance_snapshot\`、`source_before\` | 本次结束源/治理快照与修改前件；封存后不改 |
| `evidence\mlp_board_A\20261023-preparation-v1\vectors-v2\` | 原冻结权重、真实捕获激活、独立参考，保持原字节 |
| `evidence\mlp_board_A\20261023-open-investigation-v1\` | 错误8根因、单变量8192修复与正常open/close/恢复证据 |
| `evidence\mlp_board_A\20261023-integration-v1\` | 最早open失败与原native/quant/overlay构建；历史停止现场不等于当前状态 |
| `evidence\mlp_board_A\20261023-final-closeout-v1\` | 旧异常维护的最终收口证据；不能代替本次正常计算后恢复 |
| `evidence\board_platform\A10_20261023_isolated_single_v1\` | A10最小已接受平台、N32及正常释放；不重跑 |
| `release\a07_b04_v3\`、`hw\linear_A\KERNEL_SOURCE.json` | 原链接产物和B核来源冻结；不修改公共数学或原接收核 |
| `runtime\qwen35_w4a8\`、`system_qwen35\`、`modules\linear_A\` | A12应接续的模型图、应用和模块，先审计实际入口与构建 |

## 4. 最后板卡状态与连接事实

- 已验证boot_id：`8422f92f-d01f-4849-ad19-6e66b640a9ad`，架构aarch64，内核`6.8.12-a10irq2`。板型曾实读`ZynqMP KV260 revB`，板Ubuntu 24.04.2；电脑WSL Ubuntu 22.04.5 x86_64。
- 默认启动包仍为原`6.8.0-1036-xilinx`。本次没有重启、冷启动、刷写或改默认启动；不能假定下次上电仍在irq2，更早1015/irq1也不是当前验证基线。
- 板端XRT 2.18.0；A11使用与其匹配、经实际加载及计算验证的A53派生库，不覆盖系统库。编译器/SDK沿用2026.1。
- 核build_id为`0xB3030002`，xclbin UUID为`ec6bb114-e3e0-7c8a-9194-4d75b3275325`，六个指针参数均按group3分配并检查低2GiB窗口。板机身份`/etc/machine-id`的SHA256为`ea4ea714200e50181c4375b385b1e3c4a0f6d199ccb60182d62f86bcf47b64ec`；以新鲜读回核对，不凭IP判断设备。
- 正式窗口：`/var/lib/kv260-a11/a11-mlp-20261023-v3`。原v1、前置失败v2及open诊断/收尾目录均保留。v3租约已归档到`/var/lock/kv260-a1/history/a11-mlp-20261023-v3`，无active租约。
- 历史worker17974、manager17873、wrapper17868是已结束窗口的身份，**不允许按这些固定PID发信号或重新执行旧启动脚本**。独立后验已确认worker/manager退出。
- 最后完整扫描：设备FD0/VMA0，ZOCL absent，双锁无人持有，active lease absent；默认`k26-starter-kits_image_1`为applied，FPGA operating，GDM active。锁文件保留不是占用。
- 生命周期温度最高采样31.661°C；独立读回29.158/32.376/31.163°C。约4GiB内存，CMA 819200KiB（800MiB），CMA/PSS/BO不可叠加为总物理内存。
- 串口COM5，115200/8N1/无流控；已识别FTDI PNP：`FTDIBUS\VID_0403+PID_6011+XFL1CYYPZ52YB\0000`。占用串口的终端标签应先关闭，不能通过关板来释放COM5。
- 账号`ubuntu`；本文件不保存密码、私钥或许可证。认证仅在用户已授权范围和真实隐藏提示下处理，不能放到命令、文件或日志。
- 既有直连电脑`192.168.2.1/24`、板`192.168.2.2/24`，可能为临时配置；不扫描网络、不改默认路由/DNS/VPN/防火墙或永久配置。
- 固定主机密钥文件`C:\Patientqwen\platform\qwen35\a10\board_ssh_known_hosts`，禁止跳过HostKey校验。可先串口确认，再在已核验连接上取大证据；采集卡不是输入终端，WSL不是板上shell。

## 5. A11如何完成，以及保留哪些失败

1. 最早A11 open返回8、计算0次，原工具停车留下寄存器VMA/refcount；后续专项异常收尾完成。该历史不删除，也不追认为正常MLP退出。
2. 新open-only诊断先定位`verify_bo_ranges`；细化诊断记录arg3(sx)实际4096字节、物理地址34507137024，超过允许的低2GiB窗口。大小检查正常，地址保护正确拒绝。
3. irq2对应源码说明无设备专用CMA时单页分配可能绕过全局CMA；ZOCL优先64位DMA mask。仅把私有charge对齐改8192，保留逐BO尺寸/低地址检查与4MiB预算；同诊断库单变量实板open0/close0，四IO地址合法且正常恢复。原始库/核数学未变。
4. 完整计算前发现引擎所有失败统一停车，补上严格的“已完成但数值失败”关闭协议和open明确失败正常返回；PC验证后才上板，详见第6节。
5. 新计算窗口v2因打包器按名字排除所有manifest，漏掉`vectors/manifest.json`，在任何GDM/PL/核操作前被verify_bundle拒绝。修复为只排除根manifest，并把真正的verify_bundle加入本地打包；旧失败包和exit1保留。
6. 独立新v3完成23次有效计算与T0非法参数检查。23个原始Y取回并独立重比较，全bit-exact。worker/manager正常退出，经严格释放门禁后普通恢复；约74.899秒后独立读回通过。
7. PC首轮管理测试曾因继承旧扫描事件名断言失败；改成验证真实不完整观察被保留，完整静稳观察在修改前发生。原失败日志保留。初次只读preflight的PROCESS_SET_CHANGED也保留，没有冒充完整结果。

最终PC：引擎14方法、完整恢复编排11方法、最终前置扫描断言1方法通过；旧契约/新配置、修正包/标准打包入口、独立实板审计均exit0。PC替身没有被用作BOARD输出；未追加HLS/Csim/Cosim/综合/实现或不必要长回归。

## 6. 数值、性能、内存与错误恢复边界

### 固定矩阵与实际结果

| 投影 | N×K | T1中位数 | T8中位数 | T3一次 | 冷权重总加载 |
|---|---|---:|---:|---:|---:|
| l00 gate | 3584×1024 | 5.263 ms | 16.764 ms | 8.567 ms | 56.795 ms |
| l00 up | 3584×1024 | 5.268 ms | 16.753 ms | 8.594 ms | 56.788 ms |
| l00 down | 1024×3584 | 5.109 ms | 15.257 ms | 6.935 ms | 56.720 ms |

- 每真实权重T1/T8各3次、T3一次，共21次；另2个手算/尾块/双scale小例，共23次有效调用、11种case。权重来自冻结新模型sidecar，激活为冻结S0_Q4捕获，T3取T8前3行。
- 所有FP32原始Y和golden逐字节一致；内部整数和没有导出接口，**BOARD整数探针仍NOT_TESTED**，不能用FP32一致冒充直接观察整数结果。
- 表内T1中位数包含第一个常驻调用；排除首个调用后的T1暖态中位数gate/up/down分别5.284378/5.278933/5.086416ms（各2次）。T8均在常驻后，各3次。不算小样本p95，不删失败或慢样本。
- 服务计时含激活量化、原生ABI复制/BO同步、提交/完成轮询、meta及输出同步/校验和返回复制。golden计算、诊断、许可等待、磁盘导出在计时外。完整维护约32.580秒含管理开销，不能当算子时延。
- 冷加载含文件读取、调用方复制和native load；真实gate/up/down原生load约25.209/25.034/25.057ms。细分与所有样本在AUDIT及worker-result中。
- submit-to-completion为主机侧时间，不是硬件纯核周期。weight sync约0.03ms是该API路径测量，不是PL读取DDR的有效带宽；不能拿它或标称DDR峰值喂预算脚本。CPU同板同数学加速比、AXI字节、硬件周期、有效PL DDR带宽、功耗均null/未测。

### 资源账与A12不能直接复用的限制

- 私有BO对齐8192；四IO的charge为40960/8192/155648/8192，总212992字节。逐BO低2GiB地址范围与group3检查继续执行。
- 一份IO工作区加一对常驻权重BO；显式charge峰值2162688字节（2.0625MiB），上限4194304字节（4MiB）。原冻结manifest里的proposed_allocation是旧方案，不能拿旧2154496覆盖实际值。
- 14是主机显式BO创建计数（4+5×2），不是硬件全局完成计数。每次完成由ERT状态和内核meta/build/job/状态检查构成证据；host-seeded per-call计数不冒充硬件全局计数。
- RESOURCE_ACCOUNTING保存PSS/RSS/CMA与显式BO账。XRT隐式BO、物理BO总峰值、完整模型生产内存仍null，不能将PSS+CMA+BO相加。
- **A11库是受租约、身份、预算与最多23次有效run约束的维护候选。完整模型一次token就可能涉及24层×3投影，不能直接当A12生产库用，也不能无审查地删掉23次限制。** 应另行设计新范围、调用/生命周期/内存预算和恢复路径，保留原A11基线。

### 允许恢复的错误和必须保留隔离的错误

- open明确返回错误且没有context：记录FAILED_CLOSED结果，正常退出；不能因0计算就假定此前未部分分配过资源。
- 核已确认完成、READY、job/build/meta/完成序列正确、BO范围/复用/预算和调用方保护字完整，但独立数值或量化不符：保存实际Y和失败ledger，停止后续计算，经父进程`abort_close`许可unload/close。结果明确FAILED，不记矩阵成功。
- 父进程仍要waitpid正常exit0、完整FD/VMA扫描、refcount0、内核/身份/温度/内存门禁，再普通卸载/恢复/独立读回。退出本身不是可卸载证明。
- timeout、POISONED、完成未知、job/build错、保护字破坏、关闭失败、未审查内核异常或资源残留：保留所有权和隔离，不杀worker、不强卸载、不删锁、不用租约到期强行接管。
- PC已验证上述分支；BOARD验证的是本次正常完整计算后的恢复，没有故意挂死DMA、强制复位或超时破坏性试验。两种证据域不能混称。

## 7. 新对话建议接续A12的顺序

### 第一步：只读本机审查前置

1. 读本文、最新A11审计/封存和治理。核对已有修改，确认A11通过范围；不重跑已完成的错误8定位、收口或23调用，仅因代码/平台实际变更需要时做定向回归。
2. A05完整CPU同数学入口为WSL`/home/member-a/qwen35-a05/build-v8/qwen35-s1`，固定source-v3/llama-build-v4，物理ubatch=8；这是PC入口，不能直接复制给A53，也不能假定既有A53产物包含最终v8修复。审计已有目标构建、manifest、稳定投影/attention补丁、依赖和哈希，复用实际可用项，缺项明确记未完成。
3. 从`runtime\qwen35_w4a8`和既有SP_LINEAR C接口接模型真实图回调，不另造一个离线层测试来假装模型接入。检查72个MLP张量名、真实shape/strides、T分块、gate/up同输入量化缓存及down独立量化。
4. 审查A11维护候选与A07生产候选之间的差异：8192 BO分配规则、板端XRT2.18依赖、实际group/window、身份/租约/调用上限、权重驻留与normal/poisoned释放边界。不能把cap4MiB或单层2.063MiB当完整模型预算。
5. 模型A53进程、CPU页、sidecar、当前权重BO、非目标算子、混合状态、输出头和加载峰值做不重叠资源账；先完成必要无板工作，再考虑新板窗口。

### 第二步：在新请求明确的范围内验证模型实际消费

- A12主线先一层MLP，再推进24层；其余Gated DeltaNet、attention、norm、SiLU和状态复用成熟CPU路径。
- 用固定teacher-forced输入逐层/logits比较，trace记录实际消费者、张量、执行shape、job/build/位流身份及有效输出；不能凭最终文本相似或仅有调用计数声称图已消费PL结果。
- 同数学CPU/PL差异与原模型量化差异分列，不换精度、数学、容差或输出范围来掩盖问题。正常性能模式只求必要logits，不把全词表诊断开销混入性能。
- 测prefill分块、连续decode、重置、取消、换病例和拒绝结果后的状态；不支持安全回滚时清空本会话重新prefill，防止递归/卷积/KV状态双重推进。
- 强制FPGA缺硬件/错版本必须明确失败；CPU模式不产生硬件完成；回退如果授权实现，必须记录reason和实际后端，不能静默成功。
- 性能按MLP、输出头、注意力、状态更新、量化/同步/调度分账。没有整机加速如实记录；不擅自开展输出头/P2架构搜索或长期压力。

### 第三步：新窗口和结束要求

新用户请求若明确授权A12，范围内自主完成必要工作，不逐命令重复询问；本文自身不启动A12。板端动作前重新确认boot/内核/身份、温度、内存、FD/VMA、refcount、双锁与唯一租约，使用新目录/manifest/窗口；已消费的v2/v3和固定boot/PID脚本不重放。若启动已变、出现Oops或未知在途操作，停止提交并说明实际阻塞，不自动重启/刷写来绕过。

结束仍需真实完成→正常子进程退出→严格资源门禁→普通默认恢复→独立后验。功能通过、速度收益、未测硬件观测项分列，保存所有失败与原始输出。A12完成也不自动替代后续语音/质量/长测验收。

## 8. 工具、边界与本次封存复核

- Windows Python：`D:\Python\Python314\python.exe -B`；Linux门禁、flock、Unix socket和设备号测试用现有WSL`/usr/bin/python3 -B`。不因Windows限制放松Linux检查。
- 每阶段先`C:\Patientqwen\scripts\release\check_contracts.py`，再`qwen35_config.py`与相关测试；用`C:\Patientqwen\platform\a1\record.py`记实际argv、退出码及日志。
- 标准本地打包：在工程根运行`python -B platform/qwen35/a11/prepare_bundle.py --out <全新目录>`。它只生成候选，不附带新板端授权；复制旧review/launch文件不会产生新授权。
- 预算脚本实际位置：主任务包目录下`tools\design_budget.py`。仓库根没有`tools/design_budget.py`，不要猜路径或另造重复工具；没有可信同路径有效带宽就保留null。
- 沿用55°C停止后续提交、MemAvailable至少1GiB、CmaFree至少32MiB的保守门槛。截止/超温不是破坏在途DMA资源的许可；不做旧二手板长时间高负荷、极限内存或无意义重复装卸。
- 不自动重启、复位、改启动/频率/电压、刷QSPI/SD或升级系统库；关机需用户明确要求。旧SIGUSR1收口只针对当时已核验的无资源等待者，不是通用计算取消方法。
- 保留所有用户修改；不reset/checkout覆盖、不stage-all、不自动提交/推送，不改原B/C所有权目录。当前规则不启用子代理；模型/强度按用户最新路由，不自动切设置，无法读取实际设置记unknown。
- 本次使用xilinx-suite工作流程复用工具链，没有生成替代HLS核或修改公共数学/ABI/内核/驱动。

关键哈希：

| 对象 | SHA256 |
|---|---|
| 正式82文件manifest | `64f9cc327b006f2ca12d213c159d33d404e7668679144c15e95c6290fcf0bcde` |
| A11 ARM64维护native库 | `4d30d6dfb744aa47e0ce4a3faf5a6f685a1ee88fbeb6fe5c241c2dbed7990e38` |
| A07/B核MLP xclbin | `bdcb66ca69279e0109928d7b32c3ea0325f617a267e1869636944ba3c193b5fa` |
| 冻结vectors manifest | `63d13c5bb7888eb93fbf35ca5d7d6ff70d09d370f88143640bc6e457504b1604` |
| A11最终SEAL.json本身 | `4e817a8add532e941c8628c2aef180f1099d4b2090f29cf7925d1723641e9a80` |

`C:\Patientqwen\evidence\mlp_board_A\20261023-compute-acceptance-v1\SEAL.json`封存456项证据/源/治理。结束核验同时确认历史A10 88项、原A11集成523项、最终仅收口70项、open修复626项未变。新交接另立封存，不向已封存A11目录追加或改写文件。

P2/后续仍未验收：硬件内部整数探针、周期/AXI计数、PL有效DDR带宽、长稳/压力/极限、大内存包络、功耗、故意超时BOARD恢复、完整模型PL、语音声学时序、医学/教师/最终质量审核等，按各阶段原证据接续。小样本A11不使产品目标或临床质量通过。

## 9. 可粘贴到新对话的起始请求

以下仅是供用户选择粘贴的模板，不构成本次交接整理的执行指令：

> 接续KV260/Qwen3.5-0.8B项目。先完整读取桌面《KV260_Qwen35_A11完成_跨对话交付_20261023.md》及其指向的AGENTS、PROJECT_STATUS最上方a11_acceptance_20261023和A11封存证据。实际工程根C:\Patientqwen，保留全部现有修改，不从A00重做。A11已PASS_WITH_LIMITATIONS：23次实板输出逐字节匹配独立参考，含搬运服务计时完整，正常计算后释放和默认恢复均通过；A12未开始。原错误8已定位为单页BO高地址并用8192对齐验证修复，不重新排同一旧故障，不重放旧窗口或固定PID收口工具。现在先审查A12前置、A05最终CPU图和A53构建、真实PL消费者以及完整模型内存/调用/恢复预算，完成必要的本机修复。特别核对A11维护库23次run/4MiB限制，不能直接当完整模型生产库。后续按我本轮明确授权范围自主推进；板端先重新核实实际boot/内核和资源，不自动重启、刷写、升级、强杀、压力测试或静默回退。分清单层数值通过、完整模型消费、性能收益和未测项。
