# KV260 / Qwen3.5-0.8B 跨对话交付

日期：2026-10-23（北京时间）。用途：结束过长对话，在新对话安全接续A11。本文是证据索引与工作计划，不是自动执行授权。

桌面副本：`C:\Users\Fang\Desktop\KV260_Qwen35_A11_跨对话交付_20261023.md`。

仓库原件：`C:\Patientqwen\docs\handoffs\A11_CROSS_CHAT_HANDOFF_20261023.md`。两份内容相同，SHA256见最终收口证据的`SEAL.json`。

## 1. 先看结论

**失败维护窗口的收口已完成；A11计算尚未完成，不能进入A12。**

| 项目 | 截至本次独立读回的结果 |
|---|---|
| A10 | PASS_MINIMAL_WITH_LIMITATIONS，保留用户安全精简后的有效证据；不恢复已取消的1000次回归 |
| A11电脑准备 | 冻结数据、独立参考、ARM64构建、隔离控制及诊断候选已有证据，不能替代实板通过 |
| A11板端打开 | 首次`sp_linear_open_v1`返回`SP_DEVICE_ERROR=8`；确切原生失败阶段和根因仍未知 |
| A11实际计算 | **真实MLP提交0次**，gate/up/down数值及服务时间未测 |
| 默认配置恢复 | 默认PL applied、FPGA operating、GDM active、无ZOCL；已完成，不重做 |
| 最终收口 | 完整设备扫描FD0/VMA0；双锁无人持有，原租约已归档，无active lease，已知等待进程全部退出 |
| 性能 | 没有可用板端MLP性能数据，未证明加速；不能声称完整模型已进入PL |
| 下一步 | 先PC准备新的打开诊断包及退出路径，再申请新的短时实板维护范围 |

板子本轮未关机、未重启，最后读回仍是临时irq2内核。此为约2026-10-23 20:21的已保存快照，**不是持续监控**；新对话必须核对当时实际状态。

## 2. 项目目标与职责

- 目标板卡为KV260，目标模型为`Qwen/Qwen3.5-0.8B`，文本、非思考模式。A负责完整默认系统：模型运行时、默认计算/语音、病例评分、部署与验证；FPGA优先承担真实MLP线性投影。
- 当前CPU默认实现与A07 FPGA候选是两条明确分开的产物。CPU能跑、ARM库能加载、位流能配置都不等于FPGA算子通过。禁止用CPU回退冒充FPGA结果。
- 原8B/0.5B工程只保留历史，不切回旧模型、不从A00重新开始。A00—A17按原证据保留，部分阶段/分域有各自限制，不整批重标PASS。
- B/C候选可不存在；不替B/C签核，不改其所有权目录，不递归搜读其他成员工程。默认路径为A；已接收B原始HLS等保持只读，A侧派生独立留档。
- A10已有一次N32 vector-add及安全释放/恢复的最小实际证据，不是MLP验收，也不是1000次/大内存/长期稳定验收。

## 3. 路径与必读顺序

### 实际工程位置

- **PROJECT_ROOT：`C:\Patientqwen`**；WSL对应`/mnt/c/Patientqwen`。
- 用户环境中出现的`D:\patient-qwen`本轮不存在，不据此创建第二份工程、不再套一层`project`。`D:\Patientqwen`如为历史副本，不当当前仓库。
- 本轮分支`member-a/a11-preparation-20261023`，HEAD短号`53b4666`。大量既有修改和未跟踪文件已保留，**本轮没有Git提交或推送**；不能只检出HEAD就认为拥有当前全部交付。
- WSL发行版`KV260-A-2204`，宿主发行版存储在`C:\WSL\KV260-A-2204`；不要启动重复的旧冷备份实例。

### 新对话先读

1. `C:\Patientqwen\AGENTS.md`。
2. `C:\Patientqwen\docs\PROJECT_STATUS.json`最上方`a11_final_closeout_20261023`，以及`docs\status\A.md`、`docs\DECISIONS.md`、`docs\DESIGN_GAP.md`、`docs\TEST_MATRIX.md`、`docs\AI_ASSISTANCE.md`。同一文件中的下方旧“仍持锁/默认未恢复”是历史快照。
3. `C:\Patientqwen\contracts\qwen35\`及其中`contracts.lock`。当前公共契约SHA256：`83bd402b39350710d8689d50f79296e9625e9c75ccb0ecee145f08067c4ee3b6`。不得静默修改数学、ABI、容差或浮点累加次序。
4. `C:\Patientqwen\docs\handoffs\A_A07_CLOSEOUT_20261004.md`、`A_A07_B04_20261003.md`、`A_A07_INDEPENDENT_20261003.md`，以及A10/A11下列报告。
5. 主任务包目录：`C:\Patientqwen\docs\plan_qwen35\KV260_Qwen35_A_详细设计增强任务包_20261002\KV260_Qwen35_A_设计增强包_20261002\`，读`03_A_系统实现与验证_阶段提示词_措辞精简版.md`和`12_A_详细设计与性能优化方案.md`的D07/D08/D09；本对话用户安全精简后的A11范围优先，见本文第7节。

### 关键代码、产物与证据

以下子路径均相对于明确的`C:\Patientqwen`；不要在路径前再加`project/`。

| 子路径 | 用途与状态 |
|---|---|
| `config\qwen35\selection.json` | CPU默认选择；不要把FPGA候选强行改为已验收默认 |
| `modules\linear_A\`、`modules\voice_A\` | 默认计算/语音代码；本轮未改语音 |
| `runtime\qwen35_w4a8\`、`system_qwen35\`、`design\qwen35\` | 运行时、应用及设计；设计预算不是实测 |
| `platform\qwen35\a11\` | A11编译、数据冻结、worker/manager、诊断、收尾、审计工具 |
| `platform\qwen35\a11\mlp_worker.py`、`mlp_engine.py`、`mlp_policy.py`、`mlp_manager_entry.py`、`managed_lock.hpp` | A11持久worker、分段计时、隔离与锁；后续只补具体缺口 |
| `platform\qwen35\a11\build_open_diagnostics.py`、`build_arm.sh`、`prepare_bundle.py` | PC诊断候选、ARM64构建、部署包准备 |
| `evidence\board_platform\A10_20261023_isolated_single_v1\` | A10最终最小REPORT、A10_ACCEPTANCE.json、board_profile.json、resource_ledger.json、seal_01.json |
| `docs\handoffs\A_A10_MINIMAL_COMPLETE_20261023.md` | A10限定通过范围和限制 |
| `evidence\mlp_board_A\20261023-preparation-v1\` | 冻结输入/独立参考/元数据/构建；有效数据目录`vectors-v2`，旧失败保留 |
| `evidence\mlp_board_A\20261023-integration-v1\` | 原始A11打开失败、平台/库/IRQ、原始worker日志和停止证据 |
| 上项的`stopped_audit_01\` | 已封存原始523项；报告中的现场值是历史，不是当前残留 |
| 上项的`backend-diagnostic-v2\` | 仅PC验证的诊断派生库`libsp_linear_a11_trial.so`、`derived\backend.cpp`、audit.json；尚未上板 |
| `evidence\mlp_board_A\20261023-open-failure-review-v1\` | 原/诊断库各31个PC故障/正常场景；不能证明真实资源释放 |
| `evidence\mlp_board_A\20261023-cleanup-pc-fix-v3\`、`20261023-cleanup-board-v3\` | 先前收尾修复及默认恢复证据；最后持锁问题已由本轮收口解决 |
| **`evidence\mlp_board_A\20261023-final-closeout-v1\`** | **最新REPORT.md、AUDIT.json、SEAL.json、execute_02、readback_01、旧失败execute_01** |
| `platform\local\a11-mlp-20261023-v1\` | 原始81文件暂存包，不覆盖；新诊断应独立新包 |

历史评审材料实际路径（如需用，先核对，不重复解压）：

- REVIEW_ROOT：`C:\Patientqwen\release\ABC_preboard_review_20261007`。
- AUDIT_ROOT：`C:\Patientqwen\KV260_ABC_工程审计与改进执行包_20261007\KV260_ABC_review_20261007`。
- `C:\Patientqwen\docs\REVIEW_TASK_STATUS.md`维护N/H审计任务，不能拿N01/N02的CPU证据替代A11板测。早期建议的`docs/KV260_ABC_review_20261007`不是本轮实际找到的材料目录。

## 4. 当前板卡与连接事实

- 设备树模型曾实读`ZynqMP KV260 revB`，架构`aarch64`，板上Ubuntu **24.04.2 LTS**。电脑WSL为Ubuntu **22.04.5 x86_64**，二者不同不自动代表不兼容；必须看目标架构、库依赖和ABI。
- 最新boot_id：`8422f92f-d01f-4849-ad19-6e66b640a9ad`；临时内核 **6.8.12-a10irq2**。默认启动仍保留原 **6.8.0-1036-xilinx** 系统包。不要以为断电重开后仍是irq2，更早1015也是历史。
- 板端XRT **2.18.0**。A07原构建使用2.23环境；已有符号核对及2.18派生构建、两次板上ARM64加载/量化小检查，**不代表完整打开/计算ABI已经通过**。不要凭版本不同直接归因，不覆盖板上系统库。
- 最后资源状态：默认PL/GDM恢复，ZOCL未加载、无render节点（在默认恢复状态不是新故障），设备FD/VMA均0，两把维护锁无人持有，active lease不存在。温度样本29.026/31.210/29.935°C。
- 系统约4GiB，CMA 819200KiB（800MiB）属于物理内存账的一部分，不能把CMA、PSS、BO重叠相加。实际数值以新的`/proc/meminfo`与A10资源账为准。
- 连接为Micro-USB串口COM5，115200、8数据位、1停止位、无校验、无流控。MobaXterm/PuTTY的COM5标签必须关闭后自动工具才能独占打开；不要关闭板子来“释放串口”。
- 板上用户名`ubuntu`；密码/私钥不写交付。需要认证时让用户本人输入，或仅在明确授权且真实隐藏认证提示下处理，不能放命令参数、日志、文件中。
- 网线电脑直连：电脑曾为`192.168.2.1/24`，板端授权的临时地址`192.168.2.2/24`。重启后可能消失，不能假定长期有效；不改默认路由、DNS、电脑VPN、防火墙或永久配置。
- SSH已核验known_hosts：`C:\Patientqwen\platform\qwen35\a10\board_ssh_known_hosts`；必须验证主机身份，不能关闭HostKey检查。
- 视频采集卡只提供板子视频，不代替串口输入；Moba里的WSL终端是电脑，不是板上shell。`ubuntu@kria:~$`才是已登录板端提示符之一。

板上原包`/var/lib/kv260-a11/a11-mlp-20261023-v1`、收尾v3目录`/var/lib/kv260-a11/cleanup-v3-20261023`、final-closeout-v1/v2目录均保留。原租约现在位于`/var/lock/kv260-a1/history/a11-mlp-20261023-v1-aborted-open`，原哈希`3c13e30e1747b61c4a89296273d614771410e5f06713ce8b208f1f4c20d24a4c`。

## 5. A11是怎样走到当前状态的

1. 电脑准备：复用A07/A10有效证据，冻结真实l00 gate/up/down权重与S0_Q4捕获激活；T3取T8前三行。独立参考、尾块/双scale小例、ARM64/XRT2.18派生构建、锁和进程门禁已有测试。
2. 实板维护：用户另行授权临时irq2启动；核验81文件包，完成短时动态加载/量化、MLP位流/DT/IRQ检查。
3. 第一次后端打开返回错误8，只有open许可，未发放submit许可；**0真实MLP提交**。v1没有原生异常阶段详情。原worker有64KiB寄存器VMA、ZOCL refcount1，因此当时禁止直接卸载。
4. 专项收尾分步处理：明确授权下受控退出原无计算等待者，FD/VMA和引用清零；早期收尾受全局进程/FD扫描竞争影响停住。电脑修复后，v3普通恢复默认PL/GDM成功，但最后扫描竞争又使8851硬停并保留锁/租约。
5. 本轮final-only：电脑预检与新鲜板端核对后，确认8851无设备、子进程及在途管理操作；仅一次pidfd定向SIGUSR1令其退出，新工具持原锁完成原子归档、释放锁并正常退出。没有重复卸载/配置/GDM操作，也没有计算。
6. 独立后验与离线审计通过，旧A10/集成/PC-v3/BOARD-v3封存88/523/31/103项未变。当前收口完成，失败原件不删除。

本轮也保留一次工具失败：final-closeout-v1将两份历史内核原文的哈希用错，`baseline differs`，在发信号前退出2；独立v2使用正确历史基线并新增真实冻结包policy组合测试，16方法通过，实板退出0。不能把v1失败隐藏或把v2说成首次就成功。

**重要区别：旧等待者是专项信号退出；新收口工具是正常退出。前者不能追认为A11计算worker正常退出。** 原open可能已部分分配BO，实际数量和物理峰值仍null，不能仅因0计算就填写BO=0。

## 6. 基本操作与安全规范

### 不得越过的边界

- 旧二手板，不做长时间高负荷、压力、极限内存或无意义重复装卸。A10取消的20长度/1000次不重启。
- 不自动重启、复位、循环重试，不按FWUEN/RESET，不刷QSPI/SD，不改默认启动、频率、电压或系统库。系统升级/启动配置变化必须另行确认。
- 新实板窗口要重新确认授权范围、boot/内核/温度/资源/占用，不能消费旧A10/A11窗口。当前仅收口授权已完成，不含新的打开诊断或计算。
- 保守界限沿用55°C停止后续提交，MemAvailable至少1GiB、CmaFree至少32MiB，显式计算BO cap4MiB。温度或时间截止不能成为破坏在途DMA资源的理由。
- 未知完成、超时、Oops、未审查内核错误、设备占用或扫描不完整时不提交新任务。保留日志与所有权；不要强杀worker/强卸载、删锁或以“租约过期”接管。
- 本轮SIGUSR1只针对已经严格核验无资源且另获授权的历史等待者，**不是允许终止计算进程的通用方案**。固定boot/PID的final_closeout工具已消费，禁止新对话照抄重跑。
- 完整扫描失败不能按“没看到占用”处理。明确proc暂态可有界重新只读采样，但必须获得新的完整严格结果，不忽略权限、资源或内核异常。
- 正常计算后的恢复应先确认真实完成和worker正常退出，再核FD/VMA/refcount及日志，普通卸载、恢复默认配置、独立读回。禁止与B或其他后端同时占用FPGA。
- 只有用户要求关机时才做正常关机；观察串口`Power down`后再指导拔圆头电源。此前正常软件重启曾挂起，不能把重启当默认排障工具；本轮未关机。

### 电脑与证据规范

- 保留用户修改，不reset/checkout覆盖、不stage-all、不无授权推送；独立新候选、新输出目录，失败先保留最小复现。
- 固定工具2026.1，复用WSL `/home/member-a/AMDDesignTools/2026.1`、SDK `/home/member-a/kv260-sdk-2026.1-common`；不重装，不用开发机`-march=native`构建A53。
- Windows Python：`D:\Python\Python314\python.exe -B`；Linux门禁/`flock`/Unix socket/设备号测试用WSL `/usr/bin/python3 -B`。不要因Windows不支持而修改Linux门禁。
- 每阶段先旧契约`C:\Patientqwen\scripts\release\check_contracts.py`，再新版`qwen35_config.py`及相关测试；通过`platform\a1\record.py`记录实际argv、输出与退出码。
- 代码、PC/Csim/Cosim/交叉构建/BOARD分别记账；候选≠已验收。没有硬件计数器就填null，不用软件计数冒充完成或AXI字节。
- 封存后不修改旧报告、CSV、原始输出；新增更正覆盖“当前状态”但保留旧现场。时间戳/日期不是通过证据。
- 当前规则不启用子代理。用户要求Sol/High，不用Terra/Medium/Fast/Ultra；无法读到实际设置时记unknown，不谎称已切换。

## 7. A11主要剩余任务与建议顺序

### 第一步：电脑端准备，不先动板

1. 读本文和最新收口证据，核对当前Git修改，不重做A10或已完成收尾。
2. 复用`backend-diagnostic-v2`，审查打开阶段诊断与异常退出处理，构建独立的新部署包/manifest/window；不覆盖原81文件失败包。诊断库SHA256：`2cc36ae8aecf5860f1ff49018cc61de3242addb5a8ef6db2b64aebcc144ee8c1`，执行前重新核验。
3. 继续核对ARM64依赖、板端XRT ABI、irq2/ZOCL、DT、xclbin/位流、kernel_build_id、参数与memory group。BO group取本次MLP metadata，不能沿用vector-add地址。
4. 把经过审查的退出/归档协议接入下一维护入口，PC测试open失败、正常退出、未知完成/POISONED、job_id/build_id错、错误输出不可消费、进程竞争与重放拒绝。组件测试不能替代完整链路测试。
5. 明确新窗口调用数/内存/温度/恢复边界，请用户统一授权；范围内不逐命令重复询问，范围外必须停。

### 第二步：先解决打开失败，再做计算

新鲜只读核对通过且得到新授权后，做一次有详细阶段日志的打开/关闭诊断，确认错误发生在设备、xclbin、kernel、group/BO或run对象哪个环节。不能仅凭错误8推断是XRT版本或核数学；不自动重试。

若当前不是已验收irq2，只读停止；启动切换需要另行范围确认。若诊断失败，保留原始异常和资源状态，回电脑修具体原因；若是平台错误归A10缺陷，不修改数值容差。

### 第三步：最小数值与含搬运计时

只有后端打开/关闭及释放门禁可用后，才进入以下矩阵。沿用原冻结数据，不重生成整模型，不CPU回退。

| 投影 | 真实形状 | 正确性T | 暖态追加 |
|---|---|---|---|
| l00 gate | N=3584，K=1024 | 1、8、3 | T1/T8各再2次 |
| l00 up | N=3584，K=1024 | 1、8、3 | T1/T8各再2次 |
| l00 down | N=1024，K=3584 | 1、8、3 | T1/T8各再2次 |

- 真实权重各自使用；激活来源为冻结S0_Q4捕获，T3派生来源写清。不是完整模型执行。
- 先做2个合并小例覆盖手算、N/K尾块、双scale；其余为21次真实形状调用，共**最多23次基线调用**，11个不同case，单任务串行、不追加长循环。
- 每个权重句柄只冷加载一次，在同一正常存活worker复用权重与工作区。规划显式BO峰值2,154,496字节（约2.055MiB），cap4MiB；**不是物理总峰值**，XRT内部及配置缓冲另计。
- 输出对独立同数学CPU参考，维持公共FP32容差、跨组累加顺序；检查边界、job_id/build_id和真实完成。已有整数调试接口就核验，没有则标BOARD未测，不为取调试值改位流。
- 分开记录冷权重读取/复制/上传、输入量化、BO同步、提交至完成、输出同步/复制、完整服务。完整服务含必要搬运，不含离线golden计算；主机等待不叫纯核时间。
- 看暖态是否重复上传权重/创建BO。gate/up可以复用同输入量化，down必须另量化；先验证现有实现，不重写正常代码。诊断dump与性能计时分离。
- 没硬件计数器时周期、真实AXI字节填null；短样本不称长期稳定或可靠分位数。没有同板同数学同输入可比线程CPU对照，不写加速成功。

### 第四步：正常释放、分析、交付

真实完成→worker正常退出→FD/VMA/refcount/内核门禁→普通默认恢复→独立后验，必须形成新的正常计算生命周期证据，不能借用本次异常收尾替代。

先给时间分账/瓶颈，再决定是否改重复加载、分配、复制或同步；每次只改一项、保留基线并定向回归。没有明确收益就保留原实现；不搜HLS架构、不改频率/量化/浮点顺序。只有可信同路径有效带宽才能喂给预算脚本，输出仍是理论下界；缺值null，不借DDR标称峰值。脚本实际在`C:\Patientqwen\docs\plan_qwen35\KV260_Qwen35_A_详细设计增强任务包_20261002\KV260_Qwen35_A_设计增强包_20261002\tools\design_budget.py`，**仓库根下不存在tools/design_budget.py**，不要猜路径或另造重复脚本。

A11功能通过需真实gate/up/down规定T输出正确，版本/任务/完成状态有效，含搬运计时完整，正常退出及默认恢复通过。性能结论独立，可用不等于更快。交付到`C:\Patientqwen\evidence\mlp_board_A\`并更新治理；**不要自动执行A12**。

P2与以后事项：大内存/3200MiB包络、长期稳定、压力/极限、额外硬件计数器、功耗、全模型PL接入、医学/语音产品质量均保持各自未验收状态。

## 8. 本轮证据复核入口

最新目录：`C:\Patientqwen\evidence\mlp_board_A\20261023-final-closeout-v1\`。

- `AUDIT.json`：PASS_CLOSEOUT_ONLY_NOT_A11，全部最新收口结论。
- `readback_01\state.json`、`closeout_v2\result.json`、`kernel.raw.txt`：独立读回及原始证明。
- `execute_02\stdout.jsonl`、`receipt.json`：一次成功收口，远端/主机exit0。
- `execute_01\`、`MINIMAL_FAILURE.md`：首次候选失败及修正；不删除。
- `tests_v2_01.json`及最终传输补齐后的`tests_v2_02.json`：各16方法exit0；`contracts_01.json`/`config_01.json`均exit0；`audit_01.json`审计exit0。
- `REPORT.md`列命令与分域结果；`SEAL.json`列已完成证据/源码/治理/桌面文档哈希。封存脚本自己的运行收据不自引用。

最终v2仅收口约6.03秒、峰值样本31.396°C、约45.04秒后独立复核，无新增内核诊断。两把锁文件仍保留但无人持有；旧私有socket已移除，归档租约保留。没有新MLP输出、服务时间、性能收益或正常计算退出证据。

## 9. 可粘贴到新对话的起始请求

> 接续KV260/Qwen3.5-0.8B项目，先完整读取桌面《KV260_Qwen35_A11_跨对话交付_20261023.md》及其指向的AGENTS、最新状态和必要证据。实际工程根为C:\Patientqwen，不从A00重来，保留所有修改。最终仅收口已通过，默认PL/GDM和锁/租约已恢复；A11仍在第一次后端open错误8处未通过，真实MLP提交0次。先做电脑端诊断包和正常退出/恢复链路审查，复用冻结输入及有效测试，不重做A10或执行固定旧boot/PID收口脚本。给出最小新实板诊断范围，获得本轮授权并重新核实实际板况后再上板；不自动重启/刷写/升级/强杀/重试/压力测试，不自动A12。不要把候选、CPU结果或异常收尾当MLP板测通过。
