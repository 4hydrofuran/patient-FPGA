# A11 v3仅收尾执行记录（2026-10-23）

结论：**默认PL/图形服务恢复已确认，最终锁/租约收口仍未完成。A11 NOT_PASSED，A12 NOT_ELIGIBLE。**

本轮只执行用户批准的收尾方案，不打开MLP后端、不提交计算、不分配计算BO、不加载测试包，不重启/复位/断电/刷写/升级或更改默认启动。COM5未占用，使用已固定主机指纹的SSH。认证仅真实SSH/sudo隐藏提示瞬时输入，无凭据文件。

## 实际结果与停点

- 重新只读核对同boot `8422f92f-d01f-4849-ad19-6e66b640a9ad`、irq2；首个扫描因进程消失不完整，第二次完整。原等待者6174/start_ticks383249、双锁、原日志哈希匹配，ZOCL引用0，内核基线未变。
- 新增5文件约96KB小候选于 `/var/lib/kv260-a11/cleanup-v3-20261023`，哈希与PC封存一致，未覆盖旧包。
- 监督器8851通过门禁后，pidfd向无native资源的旧等待者6174发送一次已授权SIGUSR1，确认退出并接管锁；不算正常试验退出。原3202/3308/5322没有再次发送信号。
- 普通移除MLP配置、普通卸载ZOCL、加载默认k26-starter-kits、启动GDM均退出0；每步均有STEP_COMMITTED及读回。
- `finalize`之前的扫描发现PID8959的`ValueError: PROCESS_OR_FD_TABLE_CHANGED`，同时有PROCESS_SET_CHANGED。v3只允许窄范围PID消失/集合变化重新采样，此情况触发 **HARD_STOP_RECONCILE_ONLY**。没有进入finalize动作，没有未知在途管理命令，也没有归档租约/退出监督器。
- 停止后仅只读，不发送resume、不热修改控制器、不再信号/装卸。独立读回延后56.176秒：完整扫描、加速器FD0/VMA0、ZOCL不存在、默认overlay applied、FPGA operating、GDM active、boot/启动包/XRT/默认恢复资产哈希保持；8851无native映射及子进程，仍持双锁和原租约。
- 主监督器从建立到停止18.446秒；恢复期间最高采样30.153°C，独立读回27.223～29.516°C。不是压力/长期稳定测试。
- 内核有两条原方案已审查的default-overlay属性内存警告，原文完整保留；没有新增未审查诊断。不能写成“日志完全无警告”。

## 命令与返回码

| 域 | 命令/记录 | 退出码与含义 |
| --- | --- | --- |
| PC | `python -B scripts/release/check_contracts.py` | 0，历史保护 |
| PC | `python -B scripts/release/qwen35_config.py` | 0，新契约/配置 |
| PC | `python -B platform/qwen35/a11/test_cleanup_window_v3.py` | 0；最终10方法，前8/9方法亦保留 |
| PC/WSL | `python3 -B .../test_cleanup_final_stop_v3.py` | 0，2方法，冻结实际停止并拒绝硬停resume |
| PC/WSL | `python3 -B .../audit_cleanup_window_v3.py` | 0，封存/命令/实际状态审计 |
| BOARD | stage_01固定小包暂存 | 0，五文件逐项哈希 |
| BOARD | execute_01启动前hash guard | 1，Windows路径转义错误，未exec监督器 |
| BOARD | prelaunch_readback_01 | 1，只读工具误把可选vart.conf当必需 |
| BOARD | prelaunch_readback_02 | 0，确认尚无v3状态/旧等待者仍在/资源完整 |
| BOARD | `dfx-mgr-client -listPackage` | 0，只读定位当前handle |
| BOARD | `dfx-mgr-client -remove 0` | 0，普通移除测试配置 |
| BOARD | `rmmod zocl` | 0，无force |
| BOARD | `dfx-mgr-client -load k26-starter-kits` | 0，默认配置恢复 |
| BOARD | `systemctl start gdm.service` | 0，服务读回active |
| BOARD | final_readback_01 | 0，独立完整资源/身份/日志读回 |
| BOARD | cleanup_control_v3.py --status | 0，只查询；state=HARD_STOP_RECONCILE_ONLY，next=finalize |
| BOARD/HOST | execute_02监督器8851与SSH | **null，仍在等待，不称正常退出** |
| HISTORICAL HOST | 旧6174对应host结束 | SSH4294967295/外层1，定向信号退出后的异常传输状态，不记正常退出 |

所有PC完整argv/开始时间/退出码/stdout/stderr见本目录`*_01/02/03.json`。BOARD命令及原始结果见`final_readback_01/v3/lifecycle.jsonl`。两次前置只读原始文件在同级`20261023-cleanup-board-v3-readonly-01/02`。

PC最终停止测试与审计初次误用Windows运行，因Linux `os.major`不可用退出1；未更改门禁，改在现有WSL执行后退出0。两份失败日志保留，不作BOARD失败证据。

## 代码/配置及最小失败保存

- 新增固定传输/只读采集：`platform/qwen35/a11/cleanup_window_v3_host.py`、`cleanup_window_v3_remote.py`。默认PLAN_ONLY、固定动作白名单、主机指纹、精确候选SHA、root-only新目录不覆盖；未修改冻结v3恢复候选。
- 新增测试与离线审计：`test_cleanup_window_v3.py`、`test_cleanup_final_stop_v3.py`、`audit_cleanup_window_v3.py`。
- execute_01保留原Windows错误传输源码/命令/堆栈，修为远端POSIX路径并补AST回归；prelaunch_readback_01保留可选文件错误源码/堆栈，按原A10规则缺失记null。
- 治理增量写入PROJECT_STATUS、A状态、DECISIONS、DESIGN_GAP、TEST_MATRIX、AI_ASSISTANCE；旧A00—A17/失败不清空。
- 原A10/A11/收尾/PC候选封存88/523/88/31项逐项哈希一致，无提交推送。

## 尚待解决和下一步

仅剩收尾监督器8851正常退出、双锁释放与原租约归档；**不能把“设备恢复完成”写成“整个维护窗口已关闭”**。

下一步先在PC审核“硬停止后的仅finalize收口”协议，并取得明确决定。当前v3没有这个入口，不能用resume绕过硬停、凭新完整扫描擅自终止8851、删除锁或重放任何硬件命令。已经成功的四条恢复命令不应重做。扫描变化发生在GDM启动之后，可能是系统进程活动；没有充分证据将PID8959直接归为某个图形进程，也不称板卡故障。

P2：大内存/极限BO、长期稳定、高负荷/压力、完整模型PL、性能优化全部未做。错误码8根因、真实MLP数值/服务时延继续留在后续独立A11诊断范围；本次不推进。
