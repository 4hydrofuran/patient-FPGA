# 独立只读采集器的可选文件错误

SSH退出1，完整堆栈见receipt.json：新增只读采集器把可选`/etc/vart.conf`当成必需文件。原A10/A11采集对此文件缺失一直记null，原固定候选的Trial.snapshot也如此。本次未执行任何写入/信号/卸载。

原源码已保存reader_before_optional_fix.py。修复只读工具保留缺失为null，新增缺失/存在单元测试；不修改冻结v3恢复包，不豁免内核/设备资源门禁，不称失败采集已通过。
