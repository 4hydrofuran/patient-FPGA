# 首次启动传输器路径错误（原样保留）

stage_01已成功暂存并核验5个文件，未启动收尾。execute_01 SSH退出1：Windows端Path转换为反斜线，构造远端Python字符串后`\v`变成垂直制表符，启动前lstat失败。

堆栈止于内联hash guard的Path.lstat，尚未exec cleanup_board_v3.py，没有建立控制器、信号或硬件命令。reservation.json保留确切命令，receipt.json保留错误，host_before_path_fix.py和tests_before_path_fix.py保存原源码。

修复只在PC传输器显式as_posix，原已封存的v3包不变。增加真实Windows构造命令的AST路径断言，随后先独立只读确认state不存在/旧等待者和资源未变，再决定是否启动；不把此次当远端修改结果未知而盲目重放。
