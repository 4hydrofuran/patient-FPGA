# A11 集成与首次打开停止报告 — 2026-10-23

## 结论与当前安全边界

**A11 NOT_PASSED；A12 NOT_ELIGIBLE。真实 MLP 计算提交 0 次。**

本轮在授权的维护窗口中完成 irq2 临时启动、已冻结包暂存、ARM64 加载/量化短检查、MLP 配置及 IRQ 核对。首次 `sp_linear_open_v1` 返回 `SP_DEVICE_ERROR=8`，管理器停止发放操作许可，worker 进入保留资源的等待状态。没有重试，没有计算输出或服务时间，不将库能加载或 PL 配置成功算作真实层通过。

最后一次只读观察：

- boot_id `8422f92f-d01f-4849-ad19-6e66b640a9ad`，内核 `6.8.12-a10irq2`。
- manager PID 3202/start_ticks 90192；worker PID 3308/start_ticks 91251，睡眠状态。
- worker 无设备 FD，但有 **65,536 字节 `/dev/dri/renderD128` 寄存器 VMA**；ZOCL refcount **1**。完整扫描无读取缺口。
- `a11-mlp-20261023-v1_image_1` 仍 applied；默认 PL **未恢复**，GDM inactive；双锁和租约保留。租约到期不授权其他进程接管设备。
- 最后采样温度 26.866 / 28.583 / 29.174°C；不是长期温度或实时监控保证。
- COM5/SSH 已释放。没有发送终止信号、强卸载、自动重启/复位/断电、重复装卸或后续计算。

现有授权明确禁止强杀；已部署的隔离等待流程没有正常退出通道。**不能绕过 VMA/refcount 门禁直接卸载，也不能宣称可以直接断电。** 后续需单独决定收尾范围；任何恢复都不把本次异常退出追认为 A11 功能通过。

## 分域结果与证据

| 域 | 结果 | 证据/限制 |
|---|---|---|
| PC 契约/冻结数据 | 复用有效 PASS | `../20261023-preparation-v1/`：旧/新契约、A07/A10 哈希、6 组旧独立参考及5组新 CPP 核验；未改数学/容差 |
| PC 集成 | PASS | engine 11、manager 10、boundary 19（含继承/复用）、host 6、execution-host 6 方法分别通过，不能合并为板端调用数 |
| PC 编译/打包 | PASS | overlay、native quant、资源可观测派生后端、ARM64/XRT2.18 构建和81文件包核验 |
| BOARD ARM64 加载/量化 | PASS，限定两小检查 | `native_probe_01/result.json`；两组量化字节一致，动态加载成功；未打开 FPGA 后端、不证明完整 XRT ABI/执行成功 |
| BOARD 平台/MLP 配置 | 限定通过 | 新 boot 基线、实际 DT、驱动/系统库哈希、MLP配置/32路IRQ；已知历史警告保留 |
| BOARD 后端打开 | **FAILED** | `board_execute_01.json`、`stopped_readback_01/worker.stdout.jsonl`；错误码8，确切原生异常阶段缺失 |
| BOARD 真实层/计时 | **NOT_TESTED** | 只有一次 phase=open 许可，没有权重/submit 许可；0计算，无输出/结果/服务时间 |
| BOARD 正常退出/恢复 | **未通过** | `stopped_open_diagnostics_01/state.json`：VMA/refcount 非零，默认配置未恢复 |
| PC 故障日志修订 | PASS，**未部署** | `backend-diagnostic-v2/audit.json`，30控制场景/600断言、其中6定位检查及ARM64构建通过 |

计划的 23 次上限是 21 次真实形状加2个合并小例，不是实际完成次数。gate/up/down 真实权重及捕获激活、T1/T8/T3 来源与哈希沿用冻结清单；无 CPU 回退替代硬件结果。实板整数调试、硬件周期/AXI字节、有效带宽、物理 BO 峰值及加速比均为 null/NOT_TESTED。打开过程中可能已有部分 BO 分配，因缺细粒度记录，其数量不能填写0。

## 设计差距、实际改动、测试与收益

- D07/D08：在 `platform/qwen35/a11/` 接入原生量化、持久 worker、单任务串行与独立参考、逐段计时及权重/工作区复用检查。PC 流程通过；BOARD 在首次打开前段停止，没有性能收益结论。
- D09：接入 A10 独立进程、双锁/租约、静稳占用检查、完成/退出/FD/VMA/refcount/内核日志门禁。错误后按要求隔离；新缺口是已部署隔离流程缺少受审阅的正常收尾通道，不能以“保护生效”代替恢复通过。
- 兼容性：使用 A53、实际 XRT2.18 头文件/库生成独立候选；没有复制 SDK 系统库覆盖板子。两组板端加载/量化检查通过，但真正后端打开失败原因仍 **UNKNOWN**，不能仅凭版本差异归因。
- 可观测性：v1把原生异常映射为错误码8而未保留阶段详情。`build_open_diagnostics.py` 在独立 v2 派生中补冷打开阶段及受限异常日志，不改公共 ABI、数学、浮点顺序、返回码或在途资源策略。PC测试/ARM构建通过；未覆盖v1、未部署或上板重试，底层故障尚未证实修复。
- PC DT重建首次因属性/子节点排序失败，修正后通过；初次产物及exit1保留。UART journal读取曾超时124，原记录保留，改用已完整获取且校验哈希的 raw dmesg 审查；不把超时作无错误证据。

P2 单列：大内存/3200MiB包络、长期稳定、压力/极限、硬件计数器补建、功率采集、HLS架构搜索及完整模型 PL 接入均未实施/未验收；本阶段不为补表开展压力测试或改变频率、电压、量化和公共数学。预算与理论下界不填入实测性能。

## 执行命令及退出码

完整 argv、逐条远端命令、原始 stdout/stderr 和退出码在对应 JSON；汇总索引为 `stopped_audit_01/COMMANDS.json`。以下路径以工程根 `C:/Patientqwen`（WSL `/mnt/c/Patientqwen`）为基准。命令仅用于追溯，**已消费的 BOARD 执行入口不得照抄重跑**。

| 操作 / 命令入口 | 收据 | 退出码 / 状态 |
|---|---|---|
| Python `test_engine.py --quant …liba11_quant_PC_ONLY.so` | `engine_tests_03.json` | 0，11方法 |
| Python manager / boundary 单元测试（完整argv见收据） | `manager_tests_01.json` / `boundary_tests_02.json` | 0 / 0 |
| Python `test_host_prepare.py` / `test_execution_host.py` | `host_tests_01.json` / `execution_host_tests_01.json` | 0 / 0，各6方法 |
| irq2临时冷启动捕获（用户一次断电再上电） | `cold_boot_irq2_01.json` | 0；不保存 U-Boot 环境、不改默认启动 |
| UART preflight、临时网络、上传及root暂存、native probe | `irq2_preflight_01.json` / `network_01.json` / `upload_01.json` / `root_stage_01.json` / `native_probe_01.json` | 各完成项0 |
| UART journal只读采集 | `irq2_warnings_01.json` | 其中 journalctl 子命令124；外层结束不代表该子命令成功 |
| Python `review_fresh_platform.py` | `fresh_platform_01.json` / `fresh_platform_02.json` | 首次1；修复后0，失败保留 |
| 一次MLP维护执行入口，首次open | `board_execute_01.json` | STOPPED；主机调用1，**远端退出码null**，管理器/worker未退出 |
| SSH只读停止状态/设备映射取证 | `stopped_readback_01/fetch_receipt.json` / `stopped_open_diagnostics_01/fetch_receipt.json` | 0 / 0，不执行恢复 |
| Python `build_open_diagnostics.py --out …/backend-diagnostic-v2` | `open_diagnostics_01.json` | 0；含30控制场景/6定位核验/ARM64构建 |
| Python `closeout_stopped.py`，仅PC审计/封存 | `closeout_command_01.json` | 以实际收据为准；不接触板子 |

## 产物与改动位置

- 控制/执行/编译/主机传输工具：`platform/qwen35/a11/`；该阶段完整源码快照在 `stopped_audit_01/source_snapshot/`。
- 当前治理记录：`docs/PROJECT_STATUS.json`、`docs/status/A.md`、`docs/DESIGN_GAP.md`、`docs/TEST_MATRIX.md`、`docs/DECISIONS.md`、`docs/AI_ASSISTANCE.md`；封存副本在 `stopped_audit_01/governance_snapshot/`。旧A00—A17及A10结果保留。
- BOARD原始失败最小证据：`stopped_readback_01/lifecycle.jsonl`、`worker.stdout.jsonl`、`STOP.json`（按原包实际名称）、原始内核日志；详细FD/VMA快照在 `stopped_open_diagnostics_01/`。
- 原v1暂存 manifest SHA256：`3b3c46700f92565839abda962e07e557018b8fd1be9e7846613ff46ecf89f11c`。
- 独立PC诊断v2库 SHA256：`2cc36ae8aecf5860f1ff49018cc61de3242addb5a8ef6db2b64aebcc144ee8c1`；仅电脑保存，未变更已暂存包。
- 本报告与原始证据封存：`stopped_audit_01/AUDIT.json`、`COMMANDS.json`、`SEAL.json`；外层审计命令收据单独保留，不自引用哈希。A10的88项封存文件再次逐项验证，不重做已通过板测。

没有修改模型/语音/公共契约/HLS数学/默认manifest/原系统库；没有提交或推送仓库。现有无关修改均保留。认证信息不写入包或报告。

## 下一步与未决项

1. 先取得专门的收尾决定。当前等待进程阻止普通释放，现授权不允许强制终止；不能自动升级为强杀/重启/断电。
2. 如获准新的受控收尾，先重新核对 boot、PID/start_ticks、停止锁、无计算提交和完整占用；进程退出后必须重新核验 FD/VMA、refcount 和内核日志，满足门禁才普通卸载并恢复默认 PL/GDM。异常停止，不循环重试，不强卸载。退出仍存在驱动释放风险，不能承诺零风险。
3. 恢复闭环后再审查新的故障定位包与新维护授权；定位open错误，修正已证实缺陷，再执行尚未完成的最小矩阵。不得重用已消费窗口。
4. A11仍未通过，性能/收益无结论，不能进入A12。
