# A11 打开失败路径补审 — 仅电脑，2026-10-23

## 结论

PC补测通过，**A11仍NOT_PASSED，真实错误码8的原因仍UNKNOWN**。没有连接板子、发送信号、加载配置或再次计算。当前板端状态只能引用此前只读快照，不将电脑测试记为新的板状态观察或恢复证据。

上一目标轮有具体进展：封存523项停止证据及核验88项旧A10封存文件。本轮继续完成原后端/诊断后端打开失败路径对照，不能将持续目标授权解释为批准强制终止进程。

## 新覆盖

新增 `platform/qwen35/a11/audit_open_failure_pc.py` 与 `open_failure_harness.cpp`。在独立目录派生明确标注CONTROL_ONLY的XRT替身，原A07/A11产物、板上暂存包和公共契约不改。

对封存v1后端与诊断v2后端分别运行31个场景：1个正常打开/关闭，以及30个失败。失败覆盖device/load_xclbin/kernel构造、6个group查询、4个BO分别分配失败、4个BO分别尺寸/地址不合规、run对象构造失败，以及设备名/UUID/6个group契约失配。

- 两版返回码逐项相同；所有31场景均未调用替身的计算start，失败不返回ctx，退出时替身live allocations为0。
- 诊断版30个失败场景的阶段/状态码正确；正常场景无错误诊断。诊断显式标注“不证明资源释放”。
- 这不是穷举所有可能的C++异常，不是实际XRT/驱动测试。替身资源释放不能证明真实进程寄存器映射、内核引用或物理BO释放；不以此授权强杀或卸载。
- 原523项封存文件全部哈希/大小不变。原暂存manifest哈希不变；两个后端源代码哈希不变。
- 未获得新BOARD证据，数值/服务时间/带宽/加速比均无新增；不做压力或P2优化。A12仍NOT_ELIGIBLE。

## 命令与证据

从工程根的WSL环境运行：

```text
/usr/bin/python3 -B platform/a1/record.py \
  --log evidence/mlp_board_A/20261023-open-failure-review-v1/run_01.json -- \
  /usr/bin/python3 -B platform/qwen35/a11/audit_open_failure_pc.py \
  --out evidence/mlp_board_A/20261023-open-failure-review-v1/pc-audit-v1
```

实际绝对argv、stdout/stderr及外层退出码0见 `run_01.json`。2次编译与62个PC测试子进程全部退出0，完整命令见 `pc-audit-v1/commands.json`。该次数不算实板调用。

结果 `pc-audit-v1/AUDIT.json`；派生替身/两个源副本/逐例合成配置在同目录；哈希清单 `pc-audit-v1/SEAL.json`。未覆盖上一轮报告或失败证据。

## 仍需的下一步

等待用户专项决定是否接受受控终止等待进程及驱动释放风险。未收到该决定，不自动终止、卸载、重启或重试；租约到期也不授权接管。恢复需重新核对boot/PID/所有权，退出后的完整FD/VMA、refcount及内核日志门禁通过才可普通恢复默认配置。即使恢复成功，本次打开失败仍不能记为A11通过；后续新测试需新窗口。
