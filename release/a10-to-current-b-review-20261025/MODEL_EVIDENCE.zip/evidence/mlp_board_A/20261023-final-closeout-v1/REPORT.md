# A11 最终仅收口报告 — 2026-10-23

结论：**PASS_CLOSEOUT_ONLY_NOT_A11**。本轮完成资源空闲等待者交接、原租约归档、维护锁释放及独立后验；不继续A11计算。A11仍NOT_PASSED，真实MLP提交0次；A12 NOT_ELIGIBLE。

## 执行范围与结果

- 用户本轮授权按已审查收口路径完成。先读回原boot/irq2、进程身份、无在途管理命令、严格完整设备FD/VMA扫描、默认PL/GDM、内核与热/内存门禁。
- v2仅一次pidfd定向SIGUSR1结束原无资源等待者8851，确认已退出后接管原锁inode；原租约原子归档至`/var/lock/kv260-a1/history/a11-mlp-20261023-v1-aborted-open`，哈希不变。未删除锁文件。
- 删除的仅为已确认原进程退出后的失效私有控制socket（Unix端点，不含工程/证据数据；新控制器应新建端点，不复活旧端点）。历史日志、租约内容、失败候选均保留。
- 新工具PID10888正常退出0。旧8851是专项信号退出，**不是正常A11 worker退出**，不追认此前失败。
- 本轮没有加载/卸载硬件、改服务、运行计算、分配计算BO、重启/复位/刷写或关机；默认PL/GDM恢复复用前一轮已成功操作，不重复。
- 新工具执行约6.028秒，峰值采样31.396°C；45.044秒后独立读回：默认`k26-starter-kits_image_1` applied、FPGA operating、GDM active、无ZOCL、无render节点、完整FD0/VMA0、双锁无人持有、无active lease、所有已知旧/新工具PID不存在、私有socket不存在。没有新增内核诊断。不是持续监控或长期稳定性证明。

## 失败保留与修正

`execute_01`的v1误把后续独立读回哈希作为v3 journal最后KERNEL_GATE基线，load_policy报`baseline differs`，远端exit2/主机exit1。发生在信号前，`signal_attempted=false`，不持原锁、不归档、不形成等待者。原v1源码/日志/远端STOP保留。

独立v2使用准确的历史原文哈希，并仍验证当前日志完整前缀和新增诊断；增加冻结81文件包、真实journal与实际policy加载组合测试。不同保留目录、未覆盖旧包、未放宽资源/内核安全门槛。见`MINIMAL_FAILURE.md`。

## 命令与退出码

工作目录`C:\Patientqwen`；PC Python为`D:\Python\Python314\python.exe -B`。PC命令经`platform/a1/record.py --log <收据> -- <命令>`记录，完整argv/stdout/stderr见收据。

| 命令/入口 | 收据 | 退出码与结果 |
|---|---|---|
| Python `scripts/release/check_contracts.py` | contracts_01.json | 0 |
| Python `scripts/release/qwen35_config.py` | config_01.json | 0 |
| WSL `/usr/bin/python3 -B .../test_final_closeout_v1.py` | tests_01.json / tests_02.json | 0 / 0；13、15方法，旧候选覆盖不完整 |
| WSL `/usr/bin/python3 -B /mnt/c/Patientqwen/platform/qwen35/a11/test_final_closeout_v2.py` | tests_v2_01.json / tests_v2_02.json | 各0；各16方法，第二次覆盖最终host/readback源码 |
| `cleanup_window_v3_host.py --action readback --execute-authorized --output <preflight_01>`（既有只读工具） | preflight_01/receipt.json | 0 |
| `final_closeout_host_v1.py --action launch --execute-authorized --output <execute_01>`（历史已消费） | execute_01/receipt.json | 远端2、主机1；未发信号 |
| `final_closeout_host_v2.py --action launch --execute-authorized --output <execute_02>`（历史已消费） | execute_02/receipt.json | 远端0、主机0 |
| `final_closeout_host_v2.py --action readback --execute-authorized --output <readback_01>` | readback_01/receipt.json | 远端0、主机0 |
| WSL `/usr/bin/python3 -B /mnt/c/Patientqwen/platform/qwen35/a11/audit_final_closeout_v1.py` | audit_01.json | 0；AUDIT.json通过 |

表中板端入口仅追溯，不是可重跑指令；完整参数与固定控制范围由源代码、原收据和AUTHORIZATION.md共同保存。旧v3等待SSH会话在8851退出后以非0结束，不能把该运输退出码当旧监督器正常退出。

## 文件与证据

- 本轮独立源码：`C:\Patientqwen\platform\qwen35\a11\final_closeout_v1.py`、`final_closeout_v2.py`、相应host和test、`final_closeout_readback_v1.py`、`audit_final_closeout_v1.py`、封存工具。
- 本目录`AUDIT.json`、`execute_02/stdout.jsonl`、`readback_01/state.json`、`readback_01/closeout_v2/result.json`为当前收口依据；`execute_01/`与`MINIMAL_FAILURE.md`保留新失败。
- `docs_before/`保留治理更新前状态；源码/治理完成快照及桌面交付哈希由`SEAL.json`索引。旧A10/集成/PC-v3/BOARD-v3的88/523/31/103个封存文件均逐项核对未变。
- 原A00—A17进度和旧失败保留；当前治理最新入口覆盖旧“仍持锁”快照，不修改已封存旧报告。
- 桌面与仓库跨对话交付内容一致，路径见`docs/handoffs/A11_CROSS_CHAT_HANDOFF_20261023.md`。未提交或推送Git。

## 剩余与边界

已完成的是失败维护窗口收口，不是MLP功能验收。原`sp_linear_open_v1`错误8的确切阶段/原因仍未知；PC诊断v2尚未上板。原打开可能有部分BO分配，其数量/物理峰值不能填0。

下一步先PC准备新诊断包及可正常退出的维护链路；新授权/新现场门禁后才一次打开诊断。之后仍需代表gate/up/down的T1/T8/T3真实数值、含搬运计时、复用检查和正常计算后退出/恢复。无性能数据不作优化/加速结论，不自动A12。P2大内存、长期稳定、完整模型PL接入等保持未验收。
