# v1首次收口失败与v2修正

v1 execute_01远端退出2、host退出1：`baseline differs`。v3历史日志最后KERNEL_GATE原文SHA=03a7fe81...；后续独立读回原文SHA=257979fa...。v1误把后者用于前者，故在load_policy即拒绝。signal_attempted=false，未获取原双锁、未发信号、未归档；新工具已退出，不形成新等待者。原源码/host/tests v1保留，远端v1目录与STOP原样留档。

v2独立源与独立保留目录，仅改为使用准确的已封存KERNEL_GATE基线。仍要求当前日志以前者为完整前缀且新增部分没有诊断，不把任意当前日志当已审查基线。新增实际load_policy组合测试（冻结81文件包+v3候选+真实journal），并验证两份日志连续性；不删除旧失败或降低资源门槛。
