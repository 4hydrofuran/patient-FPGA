# A11收尾流程电脑修复v3

2026-10-23：**PC_PASS / BOARD_NOT_TESTED / CANDIDATE_NOT_ACCEPTED**。

本轮只改电脑代码、测试和方案。未建立SSH/COM连接，未查询当前板状态、发送信号、加载/卸载、重启或修改网络/启动配置；没有A11计算或性能结果。上一份板状态只是历史读回。

## 根因与修复对应

| 缺口 | 实际修复 | 验证 |
| --- | --- | --- |
| 完整扫描仍因跨扫描全局PID集合变化被拒绝 | 去掉跨扫描PID集合相等条件，保留原完整扫描/设备FD/VMA/refcount/内核/锁门禁 | 原始4次扫描使旧函数报NO_TWO_COMPLETE；v3接受其中第一份完整且严格门禁通过的扫描，纯离线重放 |
| 一次proc消失使收尾永远无法续接 | 仅窄范围暂态最多4次只读采样；耗尽后PAUSED_READONLY | 不完整保留、不当通过；权限/设备/引用/内核/boot错误立即硬停止 |
| 每次停车又起新等待者 | 同一监督器提供root-only本地Unix socket查询与显式resume | 实际WSL Unix socket/身份控制、同一对象续接、真实文件锁暂停保留 |
| 续接可能重复已完成步骤 | STEP_BEGIN/STEP_COMMITTED、generation、一次性记录号、只继续未完成阶段 | 六阶段逐一暂停/续接；实际adapter组合测试中signal/remove/rmmod/load/GDM各最多一次（全为PC模拟OS） |
| 管理命令超时又无限睡眠且无法查询 | 返回可查询的HARD_STOP_RECONCILE_ONLY，保留子进程和锁，不支持直接resume | 六阶段未知结果/失败阻断、实际command路径TimeoutExpired不kill/terminate、不重复 |

“一次完整扫描”不是原子隔离证明；仍要求可信root采集、持续排他锁、已隔离其它消费者、设备/驱动零占用及内核连续检查。不能保证不合作外部程序永不打开设备，不能把静态PC测试当BOARD安全证明。

## 测试与命令

准确argv/cwd/UTC时间/退出码见各JSON收据；对外日期为Asia/Shanghai。

- `contracts_01.json`：`python -B scripts/release/check_contracts.py`，exit0。
- `config_01.json`：`python -B scripts/release/qwen35_config.py`，exit0；不是运行时模型部署通过。
- `tests_01/02/03/04.json`：WSL `python3 -B .../platform/qwen35/a11/test_cleanup_v3.py`，分别25/29/30/30方法，全部exit0；最终30方法耗时约1.2秒，不含WSL启动。
- `route_01.json`：`python -B platform/qwen35/a11/cleanup_recovery_plan_v3.py --snapshot evidence/mlp_board_A/20261023-recovery-continuation-v1/readback_01/state.json`，exit0；只输出历史现场匹配候选，`execution_authorized=false`且必须fresh_readback。
- `package_01.json`：`python -B platform/qwen35/a11/package_cleanup_v3.py`，exit0。旧A10 88项、A11 523项、两次收尾88项封存逐项不变。

测试覆盖包括模拟失败分支，不代表实际向板子注入故障。真实Linux锁/Unix socket仅在电脑WSL的独立临时目录，不是板端设备操作。

## 改动与交付

新增`platform/qwen35/a11/cleanup_controller_v3.py`、`cleanup_board_v3.py`、`cleanup_control_v3.py`、`cleanup_recovery_plan_v3.py`、`test_cleanup_v3.py`、`package_cleanup_v3.py`、`finalize_cleanup_pc_v3.py`；旧v1/v2收尾源码和封存原样保留。更新A角色治理文件，保留A00—A17及历史失败。

完整方案：`docs/A11_CLEANUP_RECOVERY_PLAN_20261023.md`。

小包：`a11-cleanup-v3-PC-CANDIDATE-NOT-BOARD-TESTED.tar.gz`，27664字节，SHA256 `07e2bef4aa87598a04518bc0801fb0b3cf08c7b8e5ae95251e44410c9722c49c`。具体manifest SHA及5文件清单在`PACKAGE.json`和`candidate/cleanup-v3-20261023/candidate.json`。不是镜像或已验收成品；依赖原板包内哈希一致的只读采集器/策略，缺失即拒绝运行。

## 下一步与限制

优先路线A：新授权后只读确认同boot/6174完整身份及资源，再一次交接给v3，普通卸载、默认PL/GDM恢复、归档与独立读回。短时维护不运行计算；异常不自动重试或重启。

路线B：如果已重启/现场变化，只读重建状态。已默认则不重放卸载/加载；新boot不沿用旧PID/授权。监督器崩溃后的未知BEGIN不得自动从journal重放，需要现场状态及新审查。工具不自动重启、刷卡或电源循环。

当前BOARD仍未恢复的历史状态不因本轮PC修复改变。open返回8的根因仍UNKNOWN，需收尾完成后单独诊断。A11 NOT_PASSED、A12 NOT_ELIGIBLE；不改模型、语音、HLS、数学/容差或性能参数，无提交推送。P2仍NOT_IMPLEMENTED/安全排除。
