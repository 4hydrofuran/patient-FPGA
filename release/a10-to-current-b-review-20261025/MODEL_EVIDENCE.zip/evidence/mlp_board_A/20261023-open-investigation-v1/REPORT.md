# A11 open 错误 8 修复与实板验证（2026-10-23）

结论：`PASS_OPEN_ERROR_FIX_AND_NORMAL_RELEASE_ONLY`。同一板卡、同一 irq2 启动、同一诊断后端下，仅将私有 BO 分配对齐从 4096 改为 8192，即从 open=8 变为 open=0、close=0；四个 IO BO 全部通过原有地址/尺寸检查。worker 与管理器均正常 exit 0。独立读回确认默认 PL/GDM 恢复，无 ZOCL、设备 FD/VMA、锁占用或活动租约。计算提交 0，A11 NOT_PASSED、A12 NOT_ELIGIBLE。

## 根因与修复

`board-readback-v4/worker.stderr.txt` 明确记录 arg3(sx) 请求/实际尺寸4096，物理地址34507137024，超出HP0允许的[0,2147483648)窗口，`size_ok=true, range_ok=false`。错误8发生在 `verify_bo_ranges`，此前x BO在合法低地址。实际页大小4096。

本机与 irq2 对应的内核源码 `dma_alloc_contiguous()` 在无设备专用CMA时跳过单页分配的全局CMA；ZOCL初始化优先64位DMA mask。该板高DDR位于0x800000000起，启动全局CMA800MiB位于0x44400000。这解释了单页sx落入高地址，而大块BO进入低地址CMA的现象。源码与配置行号/哈希见 `kernel_dma_source.json`。这不是逐调用内核追踪；因果判断同时由以下单变量实板对照支持。

| BO / 参数 | 修复前实际字节/地址 | 修复后实际字节/地址 |
|---|---|---|
| x / 2 | 40960 / 1146814464 | 40960 / 1146814464 |
| sx / 3 | 4096 / 34507137024（拒绝） | 8192 / 1146855424 |
| y / 4 | 未走到校验 | 155648 / 1146880000 |
| meta / 5 | 未走到校验 | 8192 / 1146863616 |

保留精确尺寸检查、低2GiB地址窗口、4MiB显式BO预算、失败停止、不回退。8192分配是当前已验证平台的规避方法，不保证未来每次分配都必落低区，故地址检查仍必需。IO显式charge总212992；完整23调用计划的预计显式峰值2162688，仅账面预算，不是实测物理峰值。权重BO与完整计算尚未实板验证。

`platform/qwen35/a11/prepare_bundle.py` 更新私有profile与新候选的管理器预算；`mlp_engine.py` 更新资源断言；`derive_management.py` 同步预算；`test_engine.py` 增加真实高地址及单页拒绝回归。另修复Windows打包manifest路径分隔符，使用POSIX相对路径。完整计算候选 `mlp-fixed-PC-candidate-v2/` 已本地核验，未部署、未接受为默认。原81文件包、原B核、公共ABI/数学、默认后端选择保持不变。

## 实际窗口与保留失败

COM5先确认身份并只读取证，随后进行受限零计算open诊断。大量证据通过已有固定SSH地址和主机密钥取回，无网络设置更改；凭据仅用于真实隐藏认证提示，未写文件。

- v1：fresh baseline不匹配，硬件动作之前拒绝，exit1；保留。
- v2：首次诊断定位 `verify_bo_ranges`，open8；worker正常返回，释放和默认恢复完成。
- v3：传输manifest的CRLF/LF字节不同，暂存hash检查失败；没有启动硬件，独立残留暂存目录保留。
- v4：传输改为精确原字节；细化诊断定位sx高地址，open8，正常释放恢复。
- v5：相同诊断库SHA `f4ea5d55b36f2fef964b3a09e83ac0ee7dc49528bc40f42dba8fb8b1b4129881`；payload相较v4仅profile对齐改8192。open0、close0；worker15773/manager15670退出0，0计算。
- 大串口读回超时及随后握手失败原始日志保留，未当作成功证据；改用固定SSH分文件压缩传输、逐文件hash校验。没有中断板进程以清空串口。
- 本地首次全包构建因Windows路径分隔符失败、首次审计因文本读取自动转换CR失败，均保留原日志。新候选用as_posix路径，审计用原字节UTF-8解码，未降低检查标准。

本轮没有重启、刷写、强制卸载、kill/signal、内核/驱动升级、HLS重造、模型推理、提交或推送。

## 验证与恢复

全部命令、退出码、输出见同目录record JSON与transport receipts。PC：旧/新契约检查各exit0；诊断后端31控制场景返回码保持一致；ARM64 SDK交叉构建exit0；open-only管理/真实子进程锁与释放测试17方法通过；量化与引擎12方法通过；完整管理器10方法通过；修复完整候选manifest检查exit0。测试替身输出不作为BOARD数值。

BOARD：boot `8422f92f-d01f-4849-ad19-6e66b640a9ad`、内核 `6.8.12-a10irq2`；v5 native open/close各一次，四IO BO地址检查通过；waitpid确认worker exit0、释放前完整扫描和refcount0、普通卸载/恢复、manager exit0。68.89秒后独立只读扫描完整，FD0/VMA0，默认overlay applied、FPGA operating、GDM active、ZOCL absent、双锁无人持有、active lease absent、worker/manager已不在进程表。最高采样32.438°C。已有action-scoped overlay/IRQ advisories继续保留，后验无新增诊断。

离线审计 `AUDIT.json` / `audit_02.json` exit0；历史A10 88文件、A11原集成523文件、最终收口70文件封存均未变。`SEAL.json`封存本轮源快照、治理快照、报告和证据。

## 当前剩余工作

本次已排除阻止打开的错误8，并验证该零计算路径正常释放。完整A11 23调用、权重BO、真实数值、含搬运时延和计算后释放仍未完成；A12真实模型消费PL输出尚不具备准入条件。下一阶段应从新的完整计算候选和fresh board window继续，先审查计算失败的退出/释放路径，再运行原冻结矩阵；不能重放任何已消费v1–v5授权，也不能用本次0计算成功追认原失败或A11通过。旧交接文件是历史快照，以最新 `docs/PROJECT_STATUS.json` 和本报告为准。
