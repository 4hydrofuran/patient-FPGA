# A11仅收尾续接：仍未恢复默认配置

## 结论

**PARTIAL_RECOVERY_STOPPED_DEFAULT_NOT_RESTORED。A11未通过，A12不具备条件。**

用户第二次明确授权“允许继续仅收尾”，仅覆盖重新核验并终止此前无native资源的等待者5322及普通恢复。没有重试A11、打开XRT、提交计算、强卸载、重启、刷写或修改默认启动。

原worker3308、原manager3202及第一次收尾等待者5322均已按各自专项授权退出。原64KiB设备VMA已消失、ZOCL引用从1降为0；这些是信号终止，不能算A11正常退出。

但续接脚本接管锁后未取得两次进程集合完全相同的完整扫描，已停止在卸载之前。当前等待进程6174保留双锁和原租约；MLP测试overlay和ZOCL仍在，GDM inactive，**默认PL/图形服务恢复尚未执行**。不是已关机或已可断电。

最新独立只读采集`readback_01`返回0：同boot `8422f92f-d01f-4849-ad19-6e66b640a9ad` / irq2，完整扫描无加速器FD/VMA、refcount0、温度27.083/28.630/28.878°C。新等待者无子进程、无XRT库或设备映射，仅睡眠持锁。内核文本与第一次释放后核验的原文相同；已知历史告警仍保留。

## 本次缺口与原因

原脚本对进程退出时的不完整扫描没有正常续接入口。续接增加最多4次只读观察，要求两次完整且全局PID/start_ticks集合完全一致；不完整观察不能通过，任何引用、设备占用或内核异常立即阻断。

实测接管锁后的第1/2/3次扫描均完整、无设备占用，但进程集合变化；第4次报PROCESS_SET_CHANGED。因此停在`NO_TWO_COMPLETE_STABLE_READONLY_OBSERVATIONS`。这些证据没有发现新的FPGA故障，而是暴露出收尾工具对全局进程集合稳定的额外要求及停止后无法续接的问题。消失进程的用途未完全取证，不猜名称。

没有用“之后扫描干净”绕过停止门禁，没有继续发送信号或执行配置变化。下一步应先在电脑审查该额外条件及可控续接设计，再取得确切范围授权，完成普通卸载/默认恢复和独立读回；不再重复创建同样无法续接的等待者。

## 改动、测试、命令及退出码

源文件位于`platform/qwen35/a11/`：首次4文件`recover_open_only.py`、`recovery_host.py`、`test_recover_open_only.py`、`prepare_recovery_evidence.py`；续接4文件`recover_cleanup_waiter.py`、`recovery_continuation_host.py`、`test_recover_cleanup_waiter.py`、`prepare_recovery_continuation.py`，另有离线审计`audit_cleanup_stops.py`。只读采集副本及快照在两份独立证据目录。公共契约、模型、语音、计算核及性能参数未改。

| 域/命令 | 结果 |
| --- | --- |
| PC `python -B scripts/release/check_contracts.py` | exit0 |
| PC `python -B scripts/release/qwen35_config.py` | exit0；配置校验不等于模型部署通过 |
| WSL `python3 -B .../test_recover_open_only.py` | 6方法，exit0；见第一份目录tests_01.json |
| WSL `python3 -B .../test_recover_cleanup_waiter.py` | 13方法，exit0，含真实冻结失败扫描及各阶段失败阻断 |
| PC `python -B platform/qwen35/a11/prepare_recovery_continuation.py` | exit0；A10旧88项及A11旧523项封存不变 |
| BOARD 首次host `recovery_host.py --execute-authorized-cleanup-only --output .../execute_01` | 停止后由第二次专项授权终止；原始SSH rc4294967295，不记成功 |
| BOARD 续接host `recovery_continuation_host.py --execute-authorized-cleanup-only --output .../execute_01` | STOPPED，远端6174仍睡眠持锁，退出码null |
| BOARD 只读 `reader-v1/fetch_result.py --execute-readonly --output .../readback_01` | exit0，哈希核验通过，无新增信号/硬件变化 |

准确argv/时间/退出码见JSON收据。电脑控制测试不能替代BOARD恢复；本次没有数值或服务时间结果，无性能优化收益。

## 证据与边界

`readback_01/recovery-continuation-20261023-v1/lifecycle.jsonl`保存逐次完整原始扫描与内核日志；`readback_01/state.json`保存当前现场。`AUDIT.json`保留原始行号、差异、退出码和限制；`SEAL.json`封存静态文件，明确排除仍运行的`execute_01/`日志和未完成收据。

P2仍NOT_IMPLEMENTED/安全排除；长期稳定、大内存、完整模型PL及加速均未验收。本轮不提交/推送仓库，不执行A12。板子未关机，COM5本轮未占用；续接SSH进程仍等待，不能声称全部连接已释放。
