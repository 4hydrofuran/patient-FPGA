# A11 最小MLP准备与当前停止点

状态：**A11 NOT_PASSED；PC组件已验证，完整维护入口尚未联调；BOARD仅只读。A12不具备进入条件。**

当前工程根`C:/Patientqwen`（用户环境中的`D:/patient-qwen`不存在），分支`member-a/a11-preparation-20261023`。旧修改/A00—A17/A10通过与失败证据保留，未提交推送。输入状态快照在`intake/docs_before/`。

## 实际进展

1. A07冻结源/产物6项与A10最终seal的88项复核通过。CPU默认manifest与FPGA候选未混用；原A07库/源/位流均未覆盖。
2. A07原库19个XRT未定义符号均存在于PC缓存2.18 coreutil，**仅静态覆盖**。该缓存库SHA与板端历史库不同，未视为同一二进制。另以缓存2.18头文件/库完成A53派生库交叉构建，无SDK库复制到板子，无ARM执行。
3. 冻结真实l00 gate/up/down W4A8权重和S0_Q4捕获激活。T1/T8旧Python独立参考与CPP逐位结果复用6组；T3从T8前三行派生并新CPP复核。小例2组覆盖手算、N/K尾块、跨组双scale。合计11个case、计划23次调用，golden与输入分目录；实际板输出为空。
4. 原A07自取设备锁与A10管理者双锁冲突：实现不解锁/不转移父进程锁的继承fd组件与私有派生库。真实Linux flock测试验证“同inode重新open”不能冒充继承锁，子进程关闭借用fd后父锁仍排他。
5. 私有候选采用`A11_BOUNDED_TRIAL_AUTHORIZED_NOT_ACCEPTED`、4MiB显式BO cap、23成功提交上限，增加主机copy/sync/submit-poll分段计时；未改公共数学/浮点次序/HLS/频率。原service漏最终copy的问题仍须由完整worker外层计时覆盖，不能仅用原字段作完整服务。
6. 新进程边界组件继承A10无强杀/真实waitpid/完整FD-VMA/refcount/内核门禁。完整native多调用worker、manager和MLP部署包尚未集成，不能仅凭组件测试上板。

## PC与BOARD命令结果

所有下列PC命令均由`D:/Python/Python314/python.exe -B platform/a1/record.py --log <收据> -- <实际命令>`执行。实际完整argv/cwd/输出/退出码见同名JSON；WSL为`KV260-A-2204`。

| 收据 | 实际任务 | 退出码/结果 |
|---|---|---|
| contracts_01 / config_01 | scripts/release/check_contracts.py；qwen35_config.py | 0 / 0 |
| intake_01 | WSL prepare_pc.py | 0；冻结输入及符号覆盖 |
| freeze_01 | WSL freeze_vectors.py，旧vectors目录 | 1；手算夹具FP32假设错误，保留 |
| freeze_02 | 同脚本，独立vectors-v2目录 | 0；新5个CPP对照逐位一致 |
| build_pc_01 | WSL build_pc.py，pc-build-v1 | 1；json.hpp include路径错误，保留 |
| build_pc_02 | 同脚本，pc-build-v2 | 0；30场景600断言+9单元方法 |
| build_arm_01 | WSL bash platform/qwen35/a11/build_arm.sh，pc-build-v1 | 0；2.18依赖A53交叉构建 |
| metadata_01 | audit_metadata.py | 0；17参数/6BO/HWH/xclbin核对 |
| boundary_01 | WSL test_boundary.py | 0；9进程边界方法 |
| board_preflight_01 | PowerShell collect_readonly_uart.ps1 -Phase isolated_preflight | 0；仅BOARD只读 |
| summarize_01 | summarize_preparation.py | 0；部分进度报告，不是验收 |

PC-build-v1与v2的派生backend源码SHA相同；ARM库位于v1只是产物目录命名，不表示使用失败的PC编译。`REPORT.json`记录相同源码及产物哈希。

## 本轮实板只读事实

- 新授权已收到，但明确不含重启/启动变更；约定不是irq2则只读停止。
- boot：`f4a2ac41-8010-43ee-ad8a-3b89e05034be`；内核：**6.8.0-1036-xilinx**。A10最小通过的是**6.8.12-a10irq2**，不能套用。
- 温度28.163/30.479/30.542°C；MemAvailable3315476KiB，CmaFree810604KiB。CMA包含于物理内存账，不与PSS/BO重复相加。
- 默认`k26-starter-kits_image_1` applied、FPGA operating、ZOCL absent、GDM active、无active lease；eth0 UP但未取得IP。
- 原始taint=8704，仅记录；本轮未完成内核日志分类，不宣称“干净内核”。
- 未上传、安装、加载位流/驱动、分配计算BO或运行计算；未改网络/系统/启动/电源。COM5已关闭释放。

## 拟定负载和安全界限（尚未执行）

- 21真实形状+2小例；三个真实权重各只冷加载一次，同一worker内T1/T8各3次、T3一次；单任务、单权重句柄。
- 按4096字节页计算，IO BO204800字节+单权重1949696字节=2154496字节，约2.055MiB；不是物理峰值，也不包含XRT内部/配置加载缓冲。拟设显式cap4MiB、MemAvailable至少1GiB、CmaFree至少32MiB。
- 55°C停止后续提交；不会据温度/超时强杀在途任务或释放未知DMA资源。正常窗口初步预计5–10分钟（含准备/观察/恢复，非持续负荷；不是已测性能/时限保证）。
- 正常worker退出后复核FD/VMA、refcount、日志，再普通卸载恢复默认PL/GDM。未知完成、Oops、异常日志保留进程/锁/资源，不自动复位/重启/循环重试。

## 剩余P0/P1与下一步

1. PC：完成MLP专用overlay/bit.bin及与缓存基DT合并审计；从MLP metadata取group/address，绝不复用vadd地址假设。当前metadata给六参数group3/HP0低2GiB，仅为可寻址范围，不是已验分配能力。
2. PC：将native多调用worker、量化/完整服务时间、原始输出、逐组健康观测、全流程manager与上述锁/边界组件集成并测试；未完成前不开展计算。
3. 授权：正常关机后由用户配合断电再上电，临时启动已验收irq2需独立同意；不保存U-Boot、不改默认启动、不刷QSPI，不直接在1036试装不匹配模块。
4. 新boot只读复核身份/库/内核/日志/DT/占用；ARM动态链接、实际小额BO地址/metadata/数值/计时/释放恢复全部待BOARD。
5. 瓶颈、加速、同路径有效带宽均null；没有实测依据，不执行性能优化或向预算脚本填入名义带宽。

P2单列：大内存、长期稳定、全模型PL接入、额外硬件计数器、HLS架构搜索未实现/未验收（安全排除或超出本阶段）。不自动A12。

封存说明：初次`seal_01.json`包含当时仍写入的`summarize_01.json`预留收据，因此不能作为最终完整seal；原件保留。以`seal_02.json`的完成后核验为准，记录这一PC证据封存缺陷与修正，不改历史文件。
