# A12 第06步：同板 S1 基线与资源核对

结论：**PASS_STEP06_BOARD_S1_WITH_LIMITATIONS**。01—05 既有证据保持；本轮在真实 KV260 ARM64 上验证 CPU S1，07 尚未开始，A12 整体仍在进行。PL 模型消费、实际 BO 分配、硬件数值、加速比与完整物理峰值均未测；默认设备访问开关未启用。

## 实测结果

- 固定 host key/网卡地址核对设备、machine-id 摘要、boot、irq2 内核、XRT2.18 库哈希、默认 PL、GDM、温度/内存、全进程 FD/VMA、双锁及唯一租约；基线与 A11 一致。boot `8422f92f-d01f-4849-ad19-6e66b640a9ad`，内核 `6.8.12-a10irq2`。内核日志与既有 A11 原始字节一致，没有新增诊断。
- ARM64 候选 SHA256 `dcd19038416dca75684023c18eed79bcadaa980b5ea5efb3622096157f28d20b`，模型/sidecar/模板/锁与 01—05 冻结件一致。CPU-only 包164个文件，不含 PL 后端库；私有运行目录和资产目录此前均不存在。加载72个投影权重，GPU层0，2线程/context1024/物理T8。
- 固定 teacher-forced 输入分别按 T8 与 T1 执行：10行完整词表 logits 逐位一致；抽取层0/3/4/23的12组投影输入/输出通过既定门槛，混合状态逐位一致。每次响应前状态清空，位置回到-1。
- 一个冻结合成病例自然输入（46 prompt tokens）生成“胸口疼。”，3个输出token，EOS=true。仅功能样例，不代表医学审核或统计质量验收。
- v1 259次健康采样、254次进程观察：VmHWM=770636 KiB，采样RSS峰742476 KiB/PSS峰745190 KiB；最低 MemAvailable=2885608 KiB、CmaFree=216712 KiB，最高33.604°C。RSS/PSS、CMA、假设新增BO分开记账，不求和冒充物理峰值；瞬时峰值未覆盖。
- v1/v2 worker与manager均正常exit0。独立后验默认PL operating/GDM active，无ZOCL、计算设备FD/VMA、持锁或active lease；本轮硬件提交0，全局硬件计数null。原生子程序保留继承的PC标签，由实际ARM进程/板身份包装证明物理验证域BOARD，不改写原始输出。

## 失败、定位与边界

1. prepare_01 把历史日志当文本读取，换行标准化破坏摘要；改为原始字节解码后 preflight_02/prepare_02 通过。保留原失败与两次读回。
2. 额外 PC/x86 与 ARM 整图比较 **FAIL 保留**（logits最大差约0.85—1.36，固定整图门槛0.002+0.0002|ref|）。首层 MLP 前输入微差<=3.94e-6：扁平索引3745，ARM量化归一值1.49999046→1，PC为1.50001919→2。捕获ARM和PC各自输入，独立A04标量参考的8组输出均逐位相同，误差0。说明跨架构非MLP差异可经A8边界放大；没有放宽门槛或改数学。后续S1/S2必须使用本次同板基线；不能宣称跨ISA等价。本步既定验收为同板S1，不以跨ISA失败追认PL失败或忽略失败。
3. v1 单投影/单MLP容量余量通过；全模型140591104B假设BO扣除后CMA79416 KiB，不满足额外64MiB余量加32MiB底线（98304 KiB）。**首次完整范围容量判断仍FAIL**。仅对本任务三份归档fsync与posix_fadvise(DONTNEED)，保留内容、未drop_caches。独立v2窗口同binary/参数、teacher_T8、关闭诊断文件写入：81次健康采样，最低MemAvailable2953080/CMA432612 KiB，最高32.671°C。假设完整BO后CMA295316 KiB，原64MiB余量门槛通过。v2仅是受控资源测量，不冒充完整v1场景重跑。文件缓存影响已定位；未来须在归档缓存释放前提下新鲜检查，并实际逐BO核对地址/大小/group/总限额；不能据此保证完整PL分配成功。
4. 一次SSH认证连接关闭exit255，未收到执行输出；新收据执行唯一v2窗口。Windows审计因默认GBK失败；WSL audit_04 exit0，最终工具显式UTF-8。失败收据均留存。

算子阈值仍1e-4+1e-5|ref|，整图0.002+0.0002|ref|。来源：AUDIT.json、FAILURES.json、MINIMAL_CROSS_ISA_COUNTEREXAMPLE.json、SAME_INPUT_REFERENCE.json、两份readback tar及逐命令收据。最终历史契约/新版配置检查各exit0。

## 修改范围与后续

新增本地 `platform/qwen35/a12/step06_*.py`、本目录原始证据/报告与治理更新。板上只新增 `/opt/patient-qwen` 模型资产、`/var/lib/kv260-a12/step06-20261023-v1` CPU运行/结果和任务传输归档；临时CPU-only租约归档并释放双锁。没有重启、刷写、驱动/PL装卸、服务变更、强杀、全局缓存清理、公共契约改动、远程推送或子代理。固定2026.1/依赖和模型设置unknown保持。

本次到第06步结束。下次第07步应先重核身份/无设备用户/租约/资源，在独立窗口只做l00 gate，再做l00 gate/up/down的真实图消费与同板S1配对；不能直接跳到72投影。跨ISA整图限制、首轮容量失败及实际BO未测应进入后续报告。
