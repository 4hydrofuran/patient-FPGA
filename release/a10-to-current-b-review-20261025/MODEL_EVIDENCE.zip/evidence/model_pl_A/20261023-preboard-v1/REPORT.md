# A12 01—05 无板准备报告（2026-10-23）

结论：**01—05 的 PC 实现、验证及交叉构建完成；A12 整体仍在进行，BOARD NOT_TESTED。**

## 产物与通过范围

| 步骤 | 结果与证据 |
|---|---|
| 01 起点/门槛 | A11 456 项封存核对、修改前件与差异保存；模型/契约/输入/容差冻结，见 BASELINE.json、ACCEPTANCE.json、FINAL_INPUTS.json |
| 02 ARM64 | 复用 2026.1 SDK，在新队列目录从最终 A05 源码重建 llama；最终模型、CPU 库、XRT2.18 候选及四个运行库共 7 产物通过 ELF/ABI/ISA 审计。见 ARM_BUILD_FINAL.json；没有 ARM 执行 |
| 03 预算 | 单投影/单 MLP/24 层分别冻结；T8、128 prompt/2 output 上界为 17/51/1224 次，权重加载 1/3/72 次；显式 BO charge 2162688/6062080/140591104 B。见 RESOURCE_CALL_BUDGET.json；这不是板端物理内存证明 |
| 04 接入 | 精确 72 张量真实图回调接私有 Route；未选部分仍为 S1 W4A8。CPU/PL 内部符号隔离；父许可、双锁/新租约候选、保留隔离、无 kill 关闭和应用适配器已实现 |
| 05 验证 | 8 个真实 PC 模型场景：S1、单投影、单 MLP、24 层、T1/2/4、丢弃输出反例。成功比较 logits/混合状态逐位一致，另与原 A05 v8 逐位一致；反例被拒绝。见 graph-v2/SUMMARY.json、CANONICAL_COMPARISON.json |

PC_MATH_DOUBLE 调用真实 CPU 数学来验证路由和图消费者，不冒充 FPGA_REAL。关联 trace 包含实际输入/输出 SHA、shape/stride、job、epoch/执行号与消费者节点；T8 全图 216 次、T1 720 次、T2 432 次、T4 288 次均有消费证据。硬件全局计数为 null。

31 个 XRT 控制替身场景/764 检查覆盖原故障矩阵、新调用上限、72 常驻句柄与第 73 次加载拒绝；不是数值或 BOARD 证明。Linux 真实子进程/锁/取消 7 方法、应用身份/状态 4 方法、窗口双锁/租约所有权 4 方法、嵌套清单/篡改/假 BOARD 拒绝 4 方法通过。另实际 C++ SO_PEERCRED/borrowed flock 与 Python manager 联调通过。

实际 PC native 同进程 reset、换输入/病例重放、R1 拒绝、权重不重复加载通过；首 token 后 SIGUSR1 取消得到 CANCELLED、部分输出不可交付、混合状态清空并正常退出，未 kill。见 SESSION_REGRESSION.json、CANCEL_REGRESSION.json。

## 候选与边界

候选 `release/a12_preboard_20261023_v1/` 包含 ARM 库/进程、来源、派生代码、固定 B 位流、契约与证据。主任务包实际 verify_bundle 和包内 selftest 均通过；manifest SHA256 见 PACKAGE_CHECK.json。禁用配置保留 allow_device_access=false，授权未内置，未覆盖全局默认 manifest/selection。原模型和 sidecar 仍在原处，没有复制进包。

Window/OwnedWorker 提供后续平台入口所需的所有权/许可部件；真实 PL 准备/默认恢复编排、板端启动/资源与完整模型生命周期仍须在 06 以后联调验收。本次的 PC 组件测试不代表 BOARD 释放、超时恢复或平台准备已通过。

完整模型物理峰值、XRT 隐式分配、同板 CPU 对照、ARM 执行、PL 消费/数值、整体速度和收益均未测。PSS/CMA/BO 不相加，算子 1e-4/1e-5 与整图 0.002/0.0002 阈值未放宽。没有追加 HLS 核或 P2 优化，没有改原 B 交付、公共数学、内核、系统库、默认启动或旧 A11。A11 的既有 PASS_WITH_LIMITATIONS 保留。

## 失败保留与修复

所有失败见 FAILURES.json 和对应 command receipts：缺开发头、重复收据名、原地 GLU 观察时点、误用 Python venv、旧输出缺新增诊断字段。旧源码/失败包/graph-v1/原日志均保留；各问题已定位并复核。没有通过删除样本、修改容差或假造硬件结果收口，没有超过 10 分钟仍未解决的重大阻塞继续执行。

所有实际 argv、退出码、完整输出在本目录 *_01.json/*_02.json 等收据；编译细节保存在队列工作目录 stdout/stderr，ARM_BUILD_FINAL.json 给出真实目录及产物哈希。PC 模型诊断时间不作为性能数据。

下一步仅第 06 步：新鲜板端身份/内核/资源与同板 S1 验证，满足预算后再开第 07 步。旧 boot/PID/租约/窗口不重放。本轮板端连接/写入/计算均 0；无提交/推送，实际助手设置 unknown。
