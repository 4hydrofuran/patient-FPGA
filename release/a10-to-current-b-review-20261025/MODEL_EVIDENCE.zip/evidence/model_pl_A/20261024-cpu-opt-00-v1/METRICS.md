# A12 CPU优化00：固定指标口径

日期：2026-10-24（北京时间）。验证域：本地文件、哈希与既有证据核对。新模型运行、交叉构建及BOARD均为NOT_TESTED。

## 计时边界

| 时点／指标 | 固定定义 | 当前可得性 |
|---|---|---|
| t0 请求发出 | 管理端 `begin=time.monotonic_ns()`，紧邻 `worker.send(request)` 之前；保存请求文件及提示词tokenize复核已在此前完成 | client-timing.json 的 begin_monotonic_ns |
| t1 首token事件 | 管理端收到第一个 `type=token` 消息并取时间戳；TTFT=(t1-t0) | token_events[0].received_monotonic_ns、first_token_wall_ms |
| t2 最终有效结果 | 管理端收到终结消息后立即取 ended；仅接受之后通过 type=result、status=OK、gpu_layers=0、状态清空等检查的结果。完整结果延时=(t2-t0)；这些校验本身在ended之后 | end_monotonic_ns、result_wall_ms；另检查EOS、输出与状态字段 |
| t3 应用检查完成 | 真实应用完成事实、数值、否定等内容检查的时刻；须在将来的应用整合测量中单列 | 当前A12样本未采集，值null；t2不能替代t3 |
| prefill | 原生程序围绕本轮输入 llama_decode 的外层计时；R0清空另计 | result.prefill_ms；不等于客户端TTFT |
| decode | result.decode_ms；分别记录执行步数与每步原始样本 | 不与prefill或完整结果重复相加 |
| 加载 | 管理端启动调用至ready，和进程内模型/sidecar/context加载分列 | 原startup-timing与ready；不称纯fork耗时或已证明冷缓存加载 |

来源：`frozen/health-bundle/control/health_opt_manager.py` 的 run_case；原始输入与S1/S2结果在 frozen/health-readback。

当前板测使用冻结token编号，管理端在t0之前另行复核自然提示词tokenize。应用事实选择、模板组装、现场分词、ASR、TTS、播放起点均未纳入当前TTFT；后续补采时继续单列。首token到达不代表应用内容检查完成或语音播放开始。

## 工作量与公平对照

- 主性能基线：健康优化版本的107输入token自然样本；最大输出24，历史实际6个输出token且EOS。普通模式和profile模式各保留原值。
- 9-token为teacher轨迹工作量代理，历史4个固定输出token且EOS=false；正常结束不改称自然EOS完成。
- 128/1022-token仅冻结旧任务10输入和旧性能来源。健康优化版本尚未实测，相关新版本性能为null／NOT_TESTED。
- 17条开发生成样本，以及T1/2/4/8、尾块、reset、病例A/B/A、R1/R2拒绝、完成边界取消及取消后新窗口用例，按原请求字节冻结。没有新执行。
- 公平对照继续使用同A53、同模型/sidecar/提示词token、24层72个投影、TILED双线程、物理T≤8、上下文1024、R0；不改变输入长度或输出任务来计入优化收益。
- 共享CPU修改先比较旧同板S1与新S1，再比较新S1与新S2；新S1/S2一致不足以排除共同偏差。候选先单独测，再组合测。
- 普通速度样本关闭重诊断；profile样本用于分项及观察开销比较。保留所有重复样本、慢样本、顺序与资源环境，样本不足时不报告p95或统计显著性。

## 分账与待测字段

最新natural_profile的prefill互斥分解合计52.847994252秒，见冻结的BASELINE_EXTRACT.json；外层prefill52.848003062秒，客户端TTFT52.867378826秒。父MLP区间、后端输出检查子项和非MLP默认桶不能再次叠加。整请求许可子项不能按次数平摊成prefill/decode实测。

`other_norm_activation_residual` 是含未识别矩阵与同步等待的默认桶；现有日志没有每种算子或屏障的独立耗时。提交至确认完成也是主机墙时，不能命名为纯硬件周期。

规划目标以普通107-token PL TTFT 52.623984512秒为分母，降低10%约47.361586秒、降低25%约39.467988秒。候选实际TTFT、节省秒数与加速比目前均null。硬件周期、功耗、物理总峰值、医学审核与语音端到端指标仍无本任务新证据。

## 回退与版本选择

本地回退包是 frozen/health-bundle，逐文件身份见SOURCE_INVENTORY.json；模型与sidecar以原位置154项资产哈希固定，不复制权重。candidate目录只预留独立source/build/package位置，尚无可运行候选。

回退、候选接收或板测均须新窗口、新身份/boot/内核/资源检查和唯一租约。frozen内的历史review、lease、PID、到期时间和launch材料仅供溯源，不能复用为许可。现有默认CPU选择和A12第11步PENDING保持。
