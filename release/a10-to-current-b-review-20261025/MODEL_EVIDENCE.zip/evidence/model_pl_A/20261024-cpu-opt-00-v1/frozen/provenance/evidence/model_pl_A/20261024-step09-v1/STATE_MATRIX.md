# A12 task09 状态矩阵

| 项目 | 验证域与结果 |
|---|---|
| T1/2/4/8、9-token 尾块、连续 decode | PC + 同板 CPU/PL；40 行全词表 logits、原始混合状态及抽样投影核验通过 |
| R0/reset、两份合成病例 A→B→A、R1/R2 拒绝 | 同板 CPU/PL；清空后重算及 A 重放匹配 |
| 取消、迟到输出、旧 worker 复用拒绝 | BOARD；已完成调用之后、下一次许可之前取消；无新提交，正常关闭 |
| 取消后新请求 | BOARD；完整释放恢复后使用新 worker/新窗口，结果匹配原基线 |
| 默认 1024 上下文 | 同板 CPU/PL；1022 输入 + 2 输出预算，chunk8/256 状态指纹及最终 prefill logits 匹配，进程内全词表差异0 |
| 缺必需产物、错契约版本 | 实际 ARM 程序在设备打开许可前 exit2 拒绝，模型不就绪、不回退 |
| 应用拒绝/澄清策略7条 | PC，模型/硬件调用0；不冒充 BOARD 模型生成 |
| timeout/POISONED/未知 DMA | PC 控制替身31组764项；危险 BOARD 注入 NOT_TESTED |
| 正常释放与独立后验 | 两窗口 worker/manager exit0，默认PL/GDM恢复；无ZOCL/设备用户/锁/active lease |
