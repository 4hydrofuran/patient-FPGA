# A12 CPU整体优化00：基线冻结

日期：2026-10-24（北京时间）。维护者：A。状态：**PASS_LOCAL_BASELINE_FROZEN_EXISTING_BOARD_EVIDENCE_ONLY**。

完成CPU优化计划的第一个子任务00：冻结健康优化后的实际版本、原工作树差异、输入集合、指标起止点和候选／回退位置。该完成状态只属于本地证据准备；新优化性能值null，新模型运行、交叉构建、BOARD均NOT_TESTED。A12第11步仍PENDING，默认CPU选择保持。

## 冻结内容与核验

| 内容 | 本轮结果 |
|---|---|
| 健康版实际包 | manifest及125项payload逐文件长度/SHA256匹配，独立复制 |
| 同窗口板端回读 | 71项文件逐文件匹配；回读manifest与实际包相同 |
| 模型／sidecar／既有CPU配置 | 154项资产实际重新读取并核对SHA256；权重保留原位置，不复制 |
| 历史健康专项封存 | 308项文件与原SEAL逐字节身份匹配；未修改历史报告或失败 |
| 独立冻结副本 | 476项，包括实际程序/库/管理器/窗口、回读配置、A12源码、公共契约和文档快照 |
| 工作树保护 | 初始git status、tracked worktree binary patch、index patch，以及A12相关未跟踪源码副本已保存 |
| 输入集合 | 健康性能3项、旧任务10性能6项、开发自然生成17项、短状态13项、长状态3项，共5组原请求字节 |
| 候选位置 | 01B、02、04—08各自预留source/build/package；状态RESERVED_NOT_IMPLEMENTED |

仓库初始分支 `codex/a12-preboard-20261023`，HEAD `53b4666317dec5397ba49fed2e87451a1f618653`，存在大量既有修改和未跟踪文件。未reset/clean、提交或推送。全局文档保存before-docs/after-docs，只追加CPU00条目并验证既有A13字段不变。

## 基线身份与计时

模型 `Qwen/Qwen3.5-0.8B`，revision `2fc06364715b967f1860aea9cf38778875588b17`。固定运行时commit `81e39ad34368329b5db77620721510fd91107e80` 加原A05/A12派生；完整派生/构建来源指针保存在BASELINE.json及frozen/provenance。

- ARM程序SHA256：`b32697e27b5e8bdb839df8038c88ef00a23e3325aa558272bc6bf2538c9d2cdd`。
- libggml-cpu.so SHA256：`e52214684b55472e7a46117bf1de5eb160bd13f323b8e4924522651b7d0ddc6b`。
- xclbin SHA256：`bdcb66ca69279e0109928d7b32c3ea0325f617a267e1869636944ba3c193b5fa`。
- 实际健康包manifest SHA256：`f198b680989e77d8c73f605b520cc0d15fb1c708712d874e6b51f8a67286c3c3`。
- 公共契约digest：`83bd402b39350710d8689d50f79296e9625e9c75ccb0ecee145f08067c4ee3b6`。

实际管理器、窗口和运行配置采用最终bundle/readback字节；早期DERIVATION中的中间源码hash原样保存供溯源，不代替最终部署身份。

| 已有107-token自然样本 | CPU首token／完整结果 秒 | PL首token／完整结果 秒 |
|---|---:|---:|
| natural_plain | 65.154565378／73.986618142 | 52.623984512／64.304047931 |
| natural_profile | 65.170455996／74.056070446 | 52.867378826／64.813008701 |

以上全部来自既有同板健康版回读，本轮没有重新测量。普通与profile分别保留，6个输出token、EOS和prefill logits摘要配对匹配；未新增原始逐层数值或状态诊断。9-token样本是固定teacher轨迹，EOS=false，完整结果仅代表该轨迹正常结束。健康版1022-token性能仍未复测，不从旧版本比例换算。

四个时点固定为：t0管理端发送请求之前，t1收到首token事件，t2收到有效终结消息的时间边界，t3应用内容检查完成。t3目前null；模板/现场分词/ASR/TTS/播放另列。细节见METRICS.md，包含t2后置状态校验与prefill/decode父子区间边界。

## 实际命令与退出码

所有下列命令的原始argv、cwd、完整stdout/stderr、退出码和时长均在logs，均经现有 `platform/a1/record.py` 记录：

| 命令 | 退出码 | 证据 |
|---|---:|---|
| python scripts/release/check_contracts.py | 0 | logs/contracts_01.json |
| python scripts/release/qwen35_config.py | 0 | logs/config_01.json |
| python platform/qwen35/a12/cpu_opt_baseline.py --out evidence/model_pl_A/20261024-cpu-opt-00-v1 | 0 | logs/freeze_01.json |
| python platform/qwen35/a12/cpu_opt_baseline_audit.py --out evidence/model_pl_A/20261024-cpu-opt-00-v1 | 0 | logs/audit_01.json |
| 重复freeze命令，验证已存在输出拒绝覆盖 | 1，预期 | logs/reuse_rejected_01.json，FileExistsError |
| python evidence/model_pl_A/20261024-cpu-opt-00-v1/closeout.py | 0 | logs/closeout_01.json |

独立审计重新读取冻结副本与外置资产，核对包manifest、历史封存、输入数量、客户端首token/结束时钟，以及普通/profile、EOS/清空状态和未实施声明。覆盖输出的负例在建立已有frozen目录时拒绝，原BASELINE和副本未替换。收尾契约/配置与文档保留检查见logs/contracts_final.json、logs/config_final.json及FINAL_CHECK.json。全部证据哈希索引见SEAL.json。

探索时的路径猜测和Windows默认GBK读取错误已纠正，记录在FAILURES.json；首次实际冻结和独立审计均exit0。历史A05批量舍入、跨ISA、容量、异常收口等限制不因本轮冻结而追认。

## 后续边界

用户本轮确认队友已收到优化计划。01A节点分类和03稳定投影拼接继续归队友；未收到回交候选，不标记实施或验收通过。

本机下一项是01B：在独立派生管理路径中按prefill/decode细分所有权、健康、序列化、write/fsync、IPC和余额。现有常驻kmsg和统一检查调度已实施，不重复认领；新的性能收益须独立测量。

历史bundle/review/lease/boot/PID/launch仅为证据，不能直接重放。候选／回退选择须新鲜板端门禁、唯一租约和受控窗口。共享CPU改动须旧S1／新S1、新S1／新S2比较。A13音频平台工作独立保留；本轮无板连接、安装、运行库加载、模型推理或音频动作。实际助手模型／强度unknown，子代理0。
