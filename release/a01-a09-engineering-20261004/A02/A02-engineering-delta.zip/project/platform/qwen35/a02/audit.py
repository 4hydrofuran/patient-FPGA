"""Read-only preservation, schema and dataset audit, using existing environment."""
import hashlib
import json
from pathlib import Path
import sys
import jsonschema
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from system_qwen35.app.domain import validate_case
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=ROOT/'eval/qwen35/a02'
    schema=json.loads((ROOT/'system_qwen35/cases/schema.json').read_text(encoding='utf-8'))
    jsonschema.Draft202012Validator.check_schema(schema)
    cases={}
    for p in sorted((ROOT/'system_qwen35/cases').glob('SYN*.json')):
        c=json.loads(p.read_text(encoding='utf-8'));jsonschema.validate(c,schema);validate_case(c);cases[p.name]=sha(p)
    previous=json.loads((ROOT/'eval/qwen35/design_import/files.sha256.json').read_text())
    allowed={'docs/PROJECT_STATUS.json','docs/status/A.md','docs/DESIGN_GAP.md'}
    errors=[p for p,h in previous.items() if p not in allowed and sha(ROOT/p)!=h]
    old=json.loads((out/'preflight.json').read_text())['old_app_audit']
    assert sha(ROOT/old['path'])==old['sha256'],'Original application changed'
    assert not errors,errors
    lock=json.loads((out/'dataset.lock.json').read_text())
    assert all(sha(ROOT/p)==h for p,h in lock.items()),'Frozen input changed'
    policy=json.loads((out/'split_policy.json').read_text())
    assert not set(policy['dev_sources'])&set(policy['heldout_sources'])
    assert not set(policy['train_sources'])&set(policy['heldout_sources'])
    model=ROOT/'artifacts/qwen35-0.8b/qwen35-text-Q4_K_M.gguf'
    model_sha=sha(model)
    assert model_sha=='bb9fda88db8a7ee4ae8648e71d5189ed5209151a7e6a437d18999a9c33bbac1c'
    result={'status':'PASS_PC_STRUCTURE_PRESERVATION','case_schema':'draft2020-12','cases':cases,
      'prior_evidence_files_preserved':len(previous)-len(set(previous)&allowed),'intentional_governance_updates':sorted(allowed),
      'original_application_unchanged':True,'frozen_inputs_unchanged':True,'source_labels_disjoint':True,
      'actual_author_independence':'NOT_ESTABLISHED_PLAN_ONLY','model_sha256':model_sha,
      'medical_review':'PENDING_TEACHER_REVIEW','board':'NOT_TESTED'}
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
