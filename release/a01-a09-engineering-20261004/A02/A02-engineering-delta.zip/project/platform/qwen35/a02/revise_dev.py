"""Explicit dev-label erratum, keeping v1 and the final-test allocation immutable."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'eval/qwen35/a02'
data=json.loads((out/'dev/questions.json').read_text(encoding='utf-8'))
row=next(x for x in data if x['id']=='DEV-010')
assert row['expected_intents']==['allergy','medications']
row['expected_intents']=['allergy']
with (out/'dev/questions-v2.json').open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
erratum={'version':'dev-v2','review':'PENDING_TEACHER_REVIEW','changed_question_text':False,
 'changed_id':'DEV-010','old_intents':['allergy','medications'],'new_intents':['allergy'],
 'reason':'Drug allergy question does not request current medication history; v1 draft label and lexical rule both over-routed.',
 'independent_review':False,'failed_regression':'platform/qwen35/a02/evidence/unit-dev-failure.json',
 'v1_retained':True,'thresholds_changed':False,'heldout_changed':False,
 'sha256':hashlib.sha256((out/'dev/questions-v2.json').read_bytes()).hexdigest()}
with (out/'dev/erratum-v2.json').open('x',encoding='utf-8') as f:json.dump(erratum,f,ensure_ascii=False,indent=2)
print(json.dumps(erratum,ensure_ascii=False))
