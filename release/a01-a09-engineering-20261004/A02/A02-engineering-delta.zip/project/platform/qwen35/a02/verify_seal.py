"""Verify sealed local artifacts, without board/network access."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'eval/qwen35/a02'
manifest=json.loads((out/'files.sha256.json').read_text(encoding='utf-8'))
errors=[p for p,h in manifest.items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
assert not errors,errors
r=json.loads((out/'REPORT.json').read_text(encoding='utf-8'))
assert r['domains']['BOARD']=='NOT_TESTED' and r['data']['teacher_approval'] is False
assert r['data']['heldout_authored']==0 and r['data']['heldout_planned']==300
print(json.dumps({'status':'PASS_SHA256_AND_BOUNDARIES','files':len(manifest),
                  'manifest_sha256':hashlib.sha256((out/'files.sha256.json').read_bytes()).hexdigest()}))
