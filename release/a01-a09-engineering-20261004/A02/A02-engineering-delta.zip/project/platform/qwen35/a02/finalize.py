"""Seal successful engineering evidence; cannot turn warnings into a PASS."""
import hashlib
import json
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a02'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    final=read(OUT/'model-final-v2/summary.json')
    assert final['functional_pass'] and not final['warnings'] and len(final['assertions'])==80
    assert final['source_counts']=={'MODEL':17,'TEMPLATE':7}
    source_at_test=read(OUT/'model-final-v2/source_hashes.json')
    assert all(sha(ROOT/p)==h for p,h in source_at_test.items()),'Tested sources changed after final integration'
    evidence=ROOT/'platform/qwen35/a02/evidence'
    required=['unit-input-guard-win.json','unit-input-guard-wsl.json','contracts-final.json','config-final.json',
              'preservation-final.json','cli-smoke.json','model-final-v2.json']
    for name in required:assert read(evidence/name)['exit_code']==0,name
    counts=[int(re.search(r'Ran (\d+) tests',read(evidence/name)['stderr']).group(1)) for name in required[:2]]
    assert counts==[36,36],counts
    commands=[]
    for p in sorted(evidence.glob('*.json')):
        if p.name in ('finalize.json','verify-seal.json'):continue
        x=read(p)
        commands.append(dict(log=p.relative_to(ROOT).as_posix(),sha256=sha(p),command=x.get('argv',x.get('command')),
                             cwd=x.get('cwd'),exit_code=x['exit_code'],elapsed_s=x.get('elapsed_s')))
    write(OUT/'commands.json',commands)
    variants={name:{k:read(OUT/name/'summary.json')[k] for k in ('functional_pass','source_counts','fallback_rate','warnings')}
              for name in ('model-v1','model-v2','model-v3','model-final','model-final-v2')}
    report={
      'stage':'A02','design':'A-DESIGN-1.0 D02/D03','status':'PASS_PC_ENGINEERING_DRAFTS_REVIEW_PENDING',
      'date':'2026-10-02','branch':'member-a/qwen35-a00-20261002','base_commit':'ed9df6c7152c908d512ecd1f871583182823e1eb',
      'new_commit':None,'remote_push':False,'settings_changed':False,'actual_assistant_selection':'unknown',
      'pc':{'unit_tests':36,'platforms':['Windows Python 3.14','WSL Ubuntu22.04 Python3.10'],
            'count_is_not_72_independent_tests':True,'real_model_assertions':80,'cli_requests':3,
            'latest_run':'eval/qwen35/a02/model-final-v2/summary.json','model_run_history':variants,
            'metrics':final['metrics'],'timing_scope':'PC small dev sample; not board/product metrics or causal speedup',
            'model_load_ms':read(OUT/'model-final-v2/ready.json')['model_load_ms'],
            'cpu_threads':4,'context':1024,'gpu_layers':0,'generation_max_tokens':64,'thinking':False},
      'data':{'cases':3,'case_status':'PENDING_TEACHER_REVIEW','dev':24,'dev_revision':2,
              'heldout_planned':300,'heldout_authored':0,'heldout_model_calls':0,'train_sources':[],
              'statistical_independence':'NOT_ESTABLISHED_PLAN_ONLY','teacher_approval':False},
      'model':{'revision':final['model_revision'],'sha256':final['model_hash'],'runtime_commit':final['runtime_commit'],
               'quantization':'Q4_K_M_NOT_CUSTOM_W4A8'},
      'domains':{'PC':'PASS_ENGINEERING_ONLY','Csim':'NOT_TESTED','Cosim':'NOT_TESTED','synthesis':'NOT_TESTED',
                 'implementation':'NOT_TESTED','cross_build':'NOT_TESTED','BOARD':'NOT_TESTED','ASR':'NOT_TESTED',
                 'TTS':'NOT_TESTED','clinical_quality':'NOT_TESTED','power':'NOT_TESTED'},
      'memory':{'linux_board_bytes':None,'pl_bo_budget_bytes':None},
      'preservation':json.loads(read(evidence/'preservation-final.json')['stdout']),
      'review_form':'eval/qwen35/a02/teacher_review.csv','commands':'eval/qwen35/a02/commands.json',
      'failures_retained':['model-v1 and model-v2 fallback warnings','unit-dev-failure: allergy overroute and spaces',
                           'unit-ellipsis-failure: bounded unknown/duration paraphrases',
                           'model-final: TimeoutError swallowed by OSError, fixed and fully rerun'],
      'open_items':['Teacher review of all clinical wording/case values/unknown policy/rubric',
                    'Independent final QA authoring and sealing; 300 IDs are not 300 completed questions',
                    'A03 actual speech, playback acknowledgement and asynchronous cancellation',
                    'No real medical accuracy, fairness or calibrated ASR confidence evidence'],
      'P2_not_implemented':['Broader teacher-approved natural-language grammar','Statistical intent routing','Streaming sentence generation'],
      'next':'A03 no-board voice work when requested; keep review gate, never infer approval from software PASS'
    }
    write(OUT/'REPORT.json',report)
    text='''# A02 工程验收报告

无板工程范围通过；医学审核与独立最终测试未通过（尚未执行）。

- 3份合成病例草案与Schema；AnswerPlan、规则检索、关系检查和可重算话题覆盖评分已实现。
- Windows/WSL各36项单测通过，同一组不算72个独立测试；真实Qwen3.5 CPU联调80项断言通过。
- 24题开发集：17条模型回答、7条规则拒绝/澄清。实际TIMEOUT及隔离后端error另测；没有模拟模型。
- 应答回退率64.7%→35.3%→0%，10%警戒不变；这些是开发迭代，非独立最终质量。
- 最终回归曾发现TimeoutError被OSError吞掉，失败79/80及源码保留，修复后完整重跑80/80。
- 300项最终测试仅独立编写计划，已编写0题；教师审核表空白，不代签。

全部命令、退出码与摘要见commands.json；逐轮完整候选/响应/native stderr和token日志均在model-*目录。
model-final-v2为最终源码一致的真实联调；files.sha256.json列出交付物与证据哈希，不包含其自身和正在生成的finalize/verify日志。

源码入口：system_qwen35/README_A02.md。交接：docs/handoffs/A_A02_20261002.md。
PC耗时、线程、RSS和模型加载时间见REPORT.json；无板、无语音、无功耗，不冒充KV260指标。
下一步A03无板语音实现，独立最终题目与真实教师审核保持显式未完成。
'''
    with (OUT/'REPORT.md').open('x',encoding='utf-8') as f:f.write(text)
    roots=[ROOT/'system_qwen35',ROOT/'platform/qwen35/a02',OUT]
    paths={p for root in roots for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
           and p.name not in ('files.sha256.json','finalize.json','verify-seal.json')}
    paths.update(ROOT/p for p in ('docs/PROJECT_STATUS.json','docs/status/A.md','docs/DESIGN_GAP.md','docs/handoffs/A_A02_20261002.md'))
    manifest={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}
    write(OUT/'files.sha256.json',manifest)
    print(json.dumps({'status':report['status'],'files':len(manifest),'report_sha256':sha(OUT/'REPORT.json'),
                     'manifest_sha256':sha(OUT/'files.sha256.json')},ensure_ascii=False))
if __name__=='__main__':main()
