"""Actual PC CPU integration. Does not read heldout questions or call audio/board."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import sys
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from system_qwen35.app.native import NativeCPU
from system_qwen35.app.session import Session

def write(path,obj):
    with path.open('x',encoding='utf-8') as f:json.dump(obj,f,ensure_ascii=False,indent=2)
def request(text,rid):return dict(text=text,request_id=rid,source='typed',final=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);parser.add_argument('--dev',default='eval/qwen35/a02/dev/questions.json');args=parser.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=False)
    # Lock exact sources used, before observing output; future repairs keep this run.
    sources=list((ROOT/'system_qwen35').rglob('*.py'))+list((ROOT/'system_qwen35/cases').glob('*.json'))+[Path(__file__)]
    write(out/'source_hashes.json',{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    dev=json.loads((ROOT/args.dev).read_text(encoding='utf-8'))
    thresholds=json.loads((ROOT/'eval/qwen35/a02/thresholds.json').read_text())
    records=[];assertions=[]
    def audit(name,condition):assertions.append(dict(name=name,passed=bool(condition)))
    def record(item):
        records.append(item)
        with (out/'responses.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(item,ensure_ascii=False)+'\n')
    native=NativeCPU(out/'worker')
    try:
        for item in dev:
            session=Session(item['case_id'],software_test=True)
            r=session.submit(request(item['question'],item['id']),native,30)
            p=r.get('answer_plan',{})
            match=p.get('route')==item['expected_route'] and list(p.get('intent_ids',[]))==item['expected_intents']
            record(dict(test_id=item['id'],scope='DEV',question=item['question'],expected=item,response=r,router_match=match))
            audit(item['id']+' checked-before-ready',r.get('tts_ready') and r.get('final_check',{}).get('status')=='pass')
            audit(item['id']+' no-premature-history',session.snapshot()['played']==[])
            audit(item['id']+' score-deterministic',session.recompute_score_for_host()==session.recompute_score_for_host())
            if r.get('tts_ready'):session.trusted_delivery(item['id'],session.epoch,kind='PC_TEXT_TEST_ACK')
            print(json.dumps(dict(id=item['id'],source=r.get('answer_source'),router_match=match),ensure_ascii=False),flush=True)
        # Real generation, same worker, isolated application sessions and R0 clear.
        a=Session('SYN_CP_01',software_test=True);b=Session('SYN_CP_03','exam',software_test=True)
        ra=a.submit(request('哪里痛？','a1'),native,30);record(dict(test_id='MULTI-1',scope='INTEGRATION',response=ra))
        a.trusted_delivery('a1',a.epoch,kind='PC_TEXT_TEST_ACK')
        follow=a.submit(request('那个呢？','a2'),native,30);record(dict(test_id='FOLLOWUP',scope='INTEGRATION',response=follow))
        audit('followup-grounded-in-delivered',follow['answer_plan']['required_fact_ids']==('location',) and len(follow['answer_plan']['played_history'])==1)
        a.cancel();replay=a.submit(request('那个呢？','a2'),native,30)
        audit('cancel-invalidated-replay',not replay['tts_ready'] and replay['invalidated'])
        rb=b.submit(request('哪里痛？','b1'),native,30);record(dict(test_id='CASE-ISOLATION',scope='INTEGRATION',response=rb))
        audit('different-case-not-old-value','胸前正中' in rb['text'] and '胸骨后' not in rb['text'])
        audit('different-case-no-history',not rb['answer_plan']['played_history'])
        fresh=Session('SYN_CP_01',software_test=True).submit(request('哪里痛？','fresh'),native,30)
        record(dict(test_id='FRESH-REPEAT',scope='INTEGRATION',response=fresh))
        audit('R0-repeat-text-equal',fresh['candidate']==ra['candidate'])
        try:b.training_feedback();exam_hidden=False
        except PermissionError:exam_hidden=True
        b.finish();audit('exam-feedback-gated',exam_hidden and b.training_feedback()['score']==10)
        write(out/'ready.json',native.ready)
    finally:native.close()
    # Genuine deadline after native ready, not a fake TimeoutError or simulated LLM.
    timed=NativeCPU(out/'timeout-worker')
    try:
        s=Session('SYN_CP_01',software_test=True)
        r=s.submit(request('每次持续多久？','timeout'),timed,0.000001)
        record(dict(test_id='REAL-TIMEOUT',scope='INTEGRATION',response=r))
        audit('real-timeout-labelled',r.get('answer_source')=='TIMEOUT' and timed.broken)
        s.cancel()
        failed=s.submit(request('哪里痛？','quarantined'),timed,30)
        record(dict(test_id='QUARANTINED-BACKEND',scope='INTEGRATION',response=failed))
        audit('quarantined-error-no-tts',failed.get('type')=='error' and failed.get('tts_ready') is False and failed.get('answer_source') is None)
    finally:timed.close()
    d=[x for x in records if x['scope']=='DEV'];answers=[x for x in d if x['expected']['expected_route']=='answer']
    fallbacks=sum(x['response'].get('answer_source')!='MODEL' for x in answers)
    mismatches=[x['test_id'] for x in d if not x['router_match']]
    unneeded=sum(x['response'].get('answer_plan',{}).get('route')=='clarify' for x in answers)
    rate=fallbacks/len(answers);clarify_rate=unneeded/len(answers)
    warnings=[]
    if rate>thresholds['fallback_rate_warning']:warnings.append('FALLBACK_RATE_WARNING')
    if clarify_rate>thresholds['unwarranted_clarification_rate_warning']:warnings.append('UNWARRANTED_CLARIFICATION_WARNING')
    if mismatches:warnings.append('ROUTER_MISMATCH_WARNING')
    models=[x['response']['model_result'] for x in d if x['response'].get('model_result') and 'prefill_ms' in x['response']['model_result']]
    metrics={}
    for field in ('prefill_ms','ttft_ms','decode_ms','round_wall_ms','prompt_tokens','peak_rss_kib'):
        values=[x[field] for x in models if field in x and x[field] is not None]
        metrics[field]={'n':len(values),'mean':statistics.mean(values),'max':max(values)} if values else None
    report=dict(domain='PC',actual_backend='CPU_REFERENCE',threads=4,gpu_layers=0,context=1024,dev_input=args.dev,
        model='Qwen/Qwen3.5-0.8B',model_revision='2fc06364715b967f1860aea9cf38778875588b17',
        runtime_commit='81e39ad34368329b5db77620721510fd91107e80',quantization='Q4_K_M',
        model_hash='bb9fda88db8a7ee4ae8648e71d5189ed5209151a7e6a437d18999a9c33bbac1c',
        source_counts=dict(Counter(x['response'].get('answer_source') for x in d)),
        dev_count=len(d),answer_expected_count=len(answers),fallback_count=fallbacks,fallback_rate=rate,
        router_mismatches=mismatches,unwarranted_clarification_rate=clarify_rate,warnings=warnings,
        candidate_failure_buckets=dict(Counter(x['response'].get('failure_bucket') or 'none' for x in d)),
        metrics=metrics,assertions=assertions,functional_pass=all(x['passed'] for x in assertions),
        heldout_model_calls=0,heldout_authored=0,heldout_planned=300,
        clinical_quality=None,medical_review='PENDING_TEACHER_REVIEW',audio='NOT_TESTED',board='NOT_TESTED',
        note='Dev draft labels only; constrained expression grammar, not general semantic or medical acceptance')
    write(out/'summary.json',report)
    write(out/'failures.json',[x for x in d if not x['router_match'] or x['response'].get('fallback_reason')=='checker_rejected'])
    print(json.dumps({k:report[k] for k in ('functional_pass','source_counts','fallback_rate','warnings')},ensure_ascii=False))
    return 0 if report['functional_pass'] and not warnings else 2
if __name__=='__main__':raise SystemExit(main())
