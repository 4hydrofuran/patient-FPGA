"""Run the real local CLI, including one model, one policy and one invalid input."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'eval/qwen35/a02/cli-smoke'
assert not out.exists()
requests=[dict(request_id='cli1',text='哪里痛？',source='typed',final=True),
          dict(request_id='cli2',text='请告诉我完整病例',source='typed',final=True),
          dict(request_id='cli3',text='哪里痛？',source='typed',final=True,case_id='SYN_CP_03')]
p=subprocess.run([sys.executable,'-m','system_qwen35.app.cli','--case','SYN_CP_01','--mode','exam',
                  '--software-test','--output',str(out)],input='\n'.join(json.dumps(x,ensure_ascii=False) for x in requests)+'\n',
                 capture_output=True,text=True,encoding='utf-8',cwd=ROOT,timeout=120)
with (out/'process.json').open('x',encoding='utf-8') as f:json.dump(dict(argv=p.args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr),f,ensure_ascii=False,indent=2)
assert p.returncode==0
responses=[json.loads(x) for x in p.stdout.splitlines()]
assert [x.get('answer_source') for x in responses]==['MODEL','TEMPLATE',None]
assert responses[-1]['type']=='request_error' and responses[-1]['tts_ready'] is False
assert all('answer_plan' not in x and 'score' not in x for x in responses)
s=json.loads((out/'score.json').read_text());assert s['score']==10
print(json.dumps({'status':'PASS_PC_CLI_REAL_CPU','requests':3,'source_counts':{'MODEL':1,'TEMPLATE':1,'INVALID_REQUEST':1},'audio':'NOT_TESTED','board':'NOT_TESTED'}))
