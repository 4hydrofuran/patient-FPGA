# A05 实施报告（2026-10-02）

## 结论

**完整 Qwen3.5-0.8B 的72个MLP已真实接入同数学CPU后端，文本及离线语音问诊可运行；A05不标无条件通过。** 状态：`PARTIAL_PC_S1_WORKING_PHYSICAL_T2_T4_T8_NOT_ACCEPTED`。

未通过项是完整模型较大物理微批与T1的状态/logits等价性。交付的安全路径固定`physical_ubatch=1`；外部整段/1/2/4/8提交调度的回归通过，不冒充物理T2/T4/T8全模型通过。没有放宽容差、删样例、改权重或换模型。原较大物理批实现和失败证据均保留。

## 实际改动

- `runtime/qwen35_w4a8/`：原SP_LINEAR_V1 CPU库、sidecar只读核验、真实图执行回调、持久JSONL进程、32lane整数SIMD、量化缓存、R0/取消、内存保护与测量。隔离新库，不全局替换A01。
- `modules/linear_A/`：CPU scalar/tiled配置，实际共享库/可执行文件及依赖哈希manifest。设备/xclbin/硬件计数/BO预算不编造。
- `system_qwen35/app/native_w4a8.py`：按轮IPC的S1适配器，验证锁定模型/库/配置；CLI及VoiceLoop显式选择S1。既有S0默认入口保留，无自动回退。
- `system_qwen35/app/checking.py`：两个有原始反例的完整关系表达修复，不做自由关键词放行，不修改转录/病例/评分；旧版本保存于before。
- `platform/qwen35/a05/`：构建/唯一队列、ABI/状态/数值/开发集/合成语音测试、质量分账及证据汇总。
- `eval/qwen35/a05/graph-v2.patch`：固定源码精确MLP hook及仅目标权重的CPU_REPACK规避。原固定源码目录未覆盖。

SiLU、norm、attention、残差及共享embedding/head仍为原图，不重复bias。回调仅在GGML执行阶段读取真实激活。gate/up共享A8，down门控后重新量化；缓存含epoch/层/执行号/shape/strides及一次消费失效。权重仅加载72次，无每token重导出/重载或逐矩阵Python IPC。

## 实测范围

| 域/项目 | 结果 |
|---|---|
| PC C ABI | 103项通过，含尾块T1..8/非法参数/拥有副本/report/真实BUSY/超时POISONED/安全close |
| PC SIMD整数 | 48个A04独立参考已封存真实投影，新SIMD组内INT32及FP32逐位一致，含两种真实shape和T1/T8 |
| PC 分阶段接入 | up/gate/down各自、完整第一层、全72矩阵分别真实生成“5”，不是只加载 |
| PC 全图同数学 | scalar与优化：24层72投影、23个teacher-forced全词表位置、48组混合状态数组逐位一致 |
| PC 当前状态路径 | 17项状态/常驻检查，外部1/2/4/8/256提交、真实取消/reset/病例切换/未播重算、256/1024长输入通过 |
| PC 最终v3构建 | 另11项真实模型检查，外部分块logits最大差0，72调用和保护页RSS通过 |
| PC 应用 | dev-v2固定24条：17 MODEL、7预期策略TEMPLATE；非预期回退0/17；80功能检查，真实超时单列TIMEOUT，隔离后拒绝使用 |
| PC 规则 | 36旧测试方法+3新方法及否定/值/额外事实子例通过；修复前2/17回退警戒保留 |
| PC 音频 | 两条已有合成WAV断网进程树经真实ASR→S1→检查→TTS→WSLg播放；无新录音/声学回采 |
| 完整模型物理T2/T4/T8 | **未验收**；原批量路径最大logits差3.49884，不能用独立T8算子或API分块通过替代 |
| Csim/Cosim/综合/实现/ARM/BOARD | 全NOT_TESTED；硬件误差/功耗/BO预算null |

teacher-forced token是诊断输入，不是模型自然回答；自然生成和病例另有wire。重复运行不相加为新的独立用例。

## 失败、定位与修复

1. 初构建缺OpenSSL开发头，退出1保留；确认已安装libcrypto.so.3与SHA256符号后使用其一键C ABI，没有安装/升级依赖。队列active marker按失败receipt和进程核验归档恢复，未静默删锁。
2. 上游CPU override仍选择CPU_REPACK，首次模型加载硬拒绝。仅对登记的目标MLP修复加载选择，非目标保留成熟路径。
3. `state-v1/numerics.json`：较大物理batch与T1第一层MLP输入已有偏差，后续W4A8图放大；同路径scalar/optimized却0误差，不能归为硬件误差。
4. `state-v2/numerics.json`：固定physical_ubatch=1后所有外部调度及scalar/optimized逐位一致。既定0.002+0.0002×|reference|阈值未变；更大物理微批依然未决。
5. `batch-precision-v1`独立变体仅将非MLP改为已锁定F16，MLP不变。T8与整段在该小样一致，但T1仍最大3.12185差异、45组状态数组越限，未采用为默认。
6. 应用v1/v2两条完整关系被保守检查器拒绝。v3仅增加“牵涉部位我不清楚”和“快走时出现疼痛”的关系表达，负例仍拒绝；候选、原模板和失败均保留。
7. 脚本Jinja环境选错、状态解析漏M-RoPE扩展字段、SIMD测试旧目录标签错误，首次失败与修复日志分别保留，不标成功。

未决核心工作不是等板：继续隔离非MLP批量/递归数值差异如何越过A8边界；要接纳更大物理batch，仍须在原阈值验证，不能凭最终文本相同通过。

## 量化质量分账

`quality-v1/quality.json`：同一22-token短提示、teacher序列和23个全词表位置。

| 比较 | Top-1一致位置 | 平均KL(reference‖candidate) |
|---|---:|---:|
| H0(F16)→S0(Q4_K_M) | 17/23 | 0.346134 |
| S0→S1(原始BF16导出W4A8 MLP，其他Q4) | 16/23 | 0.376569 |
| H0→S1 | 11/23 | 0.968640 |

这是非零量化/图差异，不是临床正确率、语料困惑度或硬件误差。A04同输入FP32投影对照继续有效。没有默认敏感层混合精度，72矩阵manifest不变。

原始标签勘误：v3 scope=none的历史header统一写S0_Q4_K_M；`quality-v1/H0-worker`实际argv/输入是锁定F16，质量报告按文件身份标H0，不用header认定模型。原始日志不改写。默认S1 header正确。

## 内存和PC测量

- sidecar拥有数据140,378,112字节；无第二套sidecar全量重排、无BO。
- 原GGUF目标MLP保护/丢弃页159,694,848字节，执行后进程RSS **0 KiB**。共享边界页逐张量登记，不能粗略减整个GGUF。
- 非目标CPU_REPACK约90.88 MiB仍存在。原文件页/重排/混合状态/logits/工作区计入RSS；启动有短暂旧目标页重叠，未声称峰值也完全去重。系统file cache未清理，不等同进程RSS。
- v3示例库workspace1,032,192字节、bridge capacity353,828字节；rusage峰值874,976 KiB。最大观测以REPORT.json合并status/smaps/rusage为准，不当板预算。
- 示例ready10.517秒：sidecar读取/核验7.403秒，GGUF加载2.766秒；22-token无dump prefill1.177秒、TTFT1.180秒、一次decode57.54毫秒。Ryzen 9 9955HX/WSL，GGML4线程+核4线程；部分与诊断任务并行，只是PC小样，不是严谨平台对比。
- dev17条平均107.76输入token，TTFT5.623秒、整轮6.076秒。数据保留但不冒充KV260速度。

R0在响应前清空混合状态，应用只提交确认已播内容；拒绝/取消/未播候选不污染下一轮。R1可选未验证，明确禁用。

## 交付和下一步

实际命令/退出码/日志hash：`commands.json`和`platform/qwen35/a05/evidence/`；汇总`REPORT.json`；使用方法`runtime/qwen35_w4a8/README.md`；封存`files.sha256.json`。

- sidecar manifest：`cdb2a04dbd95d426ea8967cda0adb219a769d3630107a2af72d6ddf2d5285688`
- qwen35-s1 v3：`7ae17dac265fe89ec41748818107c28b01a11f4459708a56ab215095c55c86f4`
- libsp_linear_cpu v3：`d46bd1cc785c56d718e7b2782ced73bd7b3ab9a3510177df0bb0bbeacf69ee90`

分支`member-a/qwen35-a00-20261002`，基底`ed9df6c7152c908d512ecd1f871583182823e1eb`，无新commit/push。开工核验A04的1603项；共享文档/应用修改前有before副本，模型/原库/sidecar/公共契约保留。未读取B/C工程、代签、录音或调用板端。

下一步解决较大物理batch等价性，或由用户明确接受仅canonical T1的阶段范围；不自行将失败降格后宣布A05全通过。P2：可选R1和更广吞吐优化。医学审核、300条最终集、声学计时、BOARD仍是后续各域必需门槛，不是可省略P2。
