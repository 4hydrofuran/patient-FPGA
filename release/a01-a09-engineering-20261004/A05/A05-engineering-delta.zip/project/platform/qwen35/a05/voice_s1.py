"""Existing synthetic WAV -> real ASR/S1/check/TTS/WSLg, no new recording."""
import json,os,socket,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.voice_loop import VoiceLoop
out=ROOT/sys.argv[1]
s=socket.socket();s.settimeout(1)
try:s.connect(('1.1.1.1',443));isolated=False;error=None
except OSError as e:isolated=True;error=str(e)
finally:s.close()
assert isolated,'offline namespace required'
loop=VoiceLoop(out,model_backend='s1');results=[]
try:
    fixtures=json.loads((ROOT/'eval/qwen35/a03/audio-eval-v1/fixtures.json').read_text())
    for f in [x for x in fixtures if x['id'] in ('q_location','q_duration')]:
        r=loop.turn(ROOT/f['wav'],synthetic_reference=f['text']);results.append(r)
        with (out/'turns.jsonl').open('a') as log:log.write(json.dumps(r,ensure_ascii=False)+'\n')
        print(json.dumps({'fixture':f['id'],'source':r['application']['answer_source'],'text':r['application']['text'],'playback_api':r['playback']['playback_api_completed']},ensure_ascii=False),flush=True)
    ok=all(r['application']['answer_source']=='MODEL' and r['application']['model_result']['quantization']=='S1_W4A8_MLP' and r['application']['final_check']['status']=='pass' and r['playback']['playback_api_completed'] for r in results)
    with (out/'summary.json').open('x') as log:json.dump({'passed':ok,'domain':'PC','mode':'S1_W4A8_CPU','turns':len(results),'namespace':os.readlink('/proc/self/ns/net'),'external_error':error,'acoustic_onset_ns':None,'microphone':'NOT_TESTED_NO_NEW_RECORDING','board':'NOT_TESTED','medical_review':'PENDING'},log,indent=2)
finally:loop.close()
raise SystemExit(not ok)
