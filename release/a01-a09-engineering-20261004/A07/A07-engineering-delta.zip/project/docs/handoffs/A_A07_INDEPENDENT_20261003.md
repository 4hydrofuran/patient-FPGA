# A：不等待B的A06/A07准备交接

2026-10-03。完成范围：A自有XRT候选六函数、主机安全逻辑和独立测试、完整S1及XRT库ARM64交叉构建、依赖审计、只读ZIP/XO收件工具。没有接收新B核或宣布A06/A07通过，没有BOARD调用。

报告：`evidence/A07_independent/preboard-v1/REPORT.md`、`REPORT.json`、`files.sha256.json`。
代码：`modules/linear_A/xrt/`、`platform/qwen35/a07/`。
最终本地staging：`platform/build/a07-independent-a53-v2/`；非可直接安装成套包，权重/启动链未打包。

实际PC 969断言及同一套ASan/UBSan通过，归档工具8方法通过；136编译单元，8主产物ARM64，10个SDK运行库与已下载Common rootfs字节一致。ARM执行/性能/BO/PL仍NOT_TESTED；BO预算和硬件误差null。首次缺libuuid链接失败、初版绝对RPATH和收集器目录命名问题均保留及修复。

当前默认仍A05 S1 CPU。候选`config.pending.json`在访问设备前拒绝，现有`KERNEL_SOURCE.json`保持accepted=false/frozen=false；本轮不改公共数学/接口，也不改B源码/XO。

下一步：收到B实际补交ZIP后先用inspect_delivery.py做只读inventory（永不自动accept），核对新版本源码/XO/XML、原始RTL证据并执行必要独立复测，再推进v++离线链接。无需B提供完整XRT库。到板前不生成BOARD_VERIFIED配置、不写SD/QSPI、不填物理预算。当前Common rootfs/SDK吻合仍不能解除KV260启动链/DT差异阻断。

原输入快照在报告目录before；原模型/72 sidecar和默认库不变。新commit=null，保留脏树，不合并main、不push、不代签。
