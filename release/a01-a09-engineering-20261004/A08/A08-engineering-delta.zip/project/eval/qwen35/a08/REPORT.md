# A08 电脑整机回归：当前交付与停止记录

2026-10-03。状态：`PARTIAL_PC_CORE200_COMPLETE_TARGETED_FIXES_PENDING`。

原定 **200轮断网音频任务已完成**，200条均完成受控 ASR/作答或明确模板/检查/TTS/Pulse 软件播放闭环。另9个故障/策略用例符合预期。随后追加424轮负载；用户认为重复过多，已停止，不再为凑两小时继续。总命令运行4141.916秒（约69分钟），SIGINT后退出2，不是测试自然完成。634条原始记录中最后1条未完成、保持原始RUNNING状态并另作中断注释，不计成功。

两小时条件 `NOT_COMPLETED_USER_STOPPED`，不补造通过；A08仍有下面列出的针对性收口项。

## 实际实现

- `system_qwen35/app/default_e2e/`：单命令终端界面、真实72 MLP S1 CPU、默认A语音、病例与规则评分、串行阶段调度、取消epoch、未播历史隔离、独占spool与显式worker维护。不是图形UI，不启动麦克风。
- `runtime/qwen35_w4a8/{main,bridge}.cpp`、`modules/linear_A/`：隔离A08原生入口，优化CPU算子2/3线程，与既有A05库的16个旧提示对照输出token/末位logits一致。旧可执行文件、权重和数学不改。
- `modules/voice_A/{worker,engine}.py`、应用适配器：显式ASR/TTS线程参数，公共SP_VOICE_V1不变。默认LLM/算子3、ASR1、TTS2；一轮在途，待办队列0，语音队列4；不启用三方并发。
- `config/qwen35/resources.a08.json`：有效默认值快照，真正执行参数来自CLI并写入startup；不是已接入的任意JSON配置加载器。
- `platform/qwen35/a08/`：唯一队列构建、离线网络命名空间、线程/提示对比、真实音频回归、资源采样与证据汇总。按用户最新要求默认只跑200轮及必要故障项，不追加按时长重复；旧200轮不重跑。

使用llama-cpp技能约束固定提交和隔离CPU构建，没有重装或全局替换旧运行库。没有B/C目录扫描、上板、刷写、录音或远程推送；模型设置未切换，实际设置不可核实时记unknown。

## 原定200轮结果（原始统计不追改）

| 项目 | 实测/含义 |
|---|---|
| 工程闭环 | 200/200，包含公开记录的模板和澄清，不是模型准确率100% |
| 回答来源 | MODEL 133，TEMPLATE 67 |
| 模板原因 | ASR待核40，双重否定澄清20，检查器保守拒绝7 |
| 实际调用同数学CPU | 140轮；其余60轮未调用LLM，不写成模型计算 |
| 非计划模型超时 | 0（额外故障样例的故意超时单列） |
| 输入提交→播放软件提交 | 全200样本均值3641.88ms，P95 5615.68ms；不是声学出声时间 |
| 输入提交→轮次结束 | 均值6725.28ms，P95 8438.40ms |
| 硬件/实际有效音节 | NOT_TESTED/null |

9个额外用例：四阶段取消4、损坏WAV1、故意模型deadline1、真实播放器SIGSTOP后deadline1、未知项/提示注入2。期望失败是明确记录的失败/超时/取消，不算正常回答成功。

核心证据：`core200-report/metrics.json`、`regression-v2/plan.json`、`checks.jsonl`、`default/rounds.jsonl`，以及所有voice/model wire记录。额外负载与固定200轮是不同cohort。输入为已标来源和hash的合成问句，回答由真实S1推理或显式策略模板产生，不用预录答案。此语料不是独立300条终测或真实人群质量评估。

## 资源与时序

本机AMD Ryzen 9 9955HX / x86_64 WSL。完整保留范围内同时采样PSS峰值1,096,957KiB，RSS峰值1,125,728KiB；采样间隔500ms，不能排除采样间峰值。`resources-summary.json`留下FileNotFoundError采样竞态；采样循环继续，首末跨度4140.075秒，但不宣称零缺样。进程swap观测峰值0。

sidecar CPU常驻数据140,378,112字节，原72 MLP GGUF受保护页报告RSS为0；所有完成的模型报告每次初始化权重加载72次，而非每token重导出。原GGUF非MLP文件页、重排、状态/工作区由原生allocator日志和smaps分项保留，不能把磁盘文件大小重复加到PSS。临时音频观测峰值258,614字节/2文件，结束后spool为空。更完整清单见`stopped-report/memory.json`；A53、CMA和BO预算仍null。

ASR final、原生首token接收、完整回答检查、TTS ready、播放软件提交/完成、结束均用Linux单调时钟和真实session_id关联。物理说话结束和声学第一音节没有测量，保持null。失败缺失计时不填0。R0清空重算，前缀缓存命中样本为0条，不是0ms命中；冷首轮/未命中在原始数据中分列。

## 提示、质量与未完成项

短系统提示实验减少token但质量不合格，`experiments-v1`、`dev-compare-v1/v2`的失败全部保留，未采纳。最终facts_v4保留单事实提示字节和强约束系统指令，将多事实组织为完整句；同信息要求4条多事实对照由旧版2 MODEL/2 TEMPLATE改为4 MODEL。`prompt-final-comparison/comparison.json`保留token与等待对比，不能推广为全数据质量提升。分句TTS实测约0.62–0.66秒软件请求间隔，默认不启用重叠/推测播放。

尚需**小范围针对性工作，不是再跑几百轮**：

1. 修复“我气短。”这一明确肯定句的检查器误拒绝；已有6条最小反例、修复前5/6通过，正反/未知病例与遗漏/额外事实须保持拒绝。尚未修改规则，200轮133/67不追改。
2. 普通WAV入口需要人工转录确认接线。新ReviewGate的6项控制测试通过，尚未接入Service/CLI；当前无可信置信度、无人确认时保守澄清。合成基准的原句核对不是真人确认。不能把当前WAV界面称为完整真人问诊入口。
3. 修复/复核资源采样与临时目录删除竞态，记录缺样；不能隐藏已留下的FileNotFoundError。
4. 单独`no_hardware`模式的两条实际模型任务排在长测之后，因本次提前停止尚未执行；该模式注册单测已通过。实际`fpga_required` CLI已在checks-v1/v2预期退出2且没有创建模型输出目录，不回退CPU。
5. 真人/医学词ASR错误、教师审核、独立300条终测、声学回采、物理欠载、热降频与板端性能继续开放。无新录音。本轮规则评分仅为草案覆盖统计，低置信转录仍待复核，不伪造可信成绩。

完整缺陷表`DEFECTS.md`。A06核接收、A07硬件链接和BOARD状态不因A08而升级。

## 命令与分域结果

完整argv/cwd/UTC/退出码/stdout/stderr在本目录各`*-command.json`，构建另在`build-submit.json`、`build-run.json`。

| 命令记录 | 退出码 | 结果 |
|---|---:|---|
| preflight-command、build-run | 0 | 开工校验/唯一队列隔离构建 |
| unit-v2、checks-v1/v2 | 0 | 69规则/历史测试；两个契约门禁；硬件CLI子命令预期2 |
| experiments-v1、dev-compare-v1/v2 | 2 | 真实提示质量失败，保留 |
| prompt-v4-multi、sentence-probe-v1 | 0 | 定向提示修复与实际TTS比较 |
| checker-before | 2 | 检查器反例5/6，尚未修复 |
| review-control | 0 | 6项纯控制测试，不是人类确认/模型测试 |
| regression-v2 | 2 | 用户要求停止额外负载，非自然收尾 |
| stop-extra-soak | 0 | 核对PID后仅SIGINT本测试进程 |
| stopped-report | 0 | 只读汇总已有证据，没有重跑模型 |
| final-legacy-contracts、final-qwen-config、final-script-compile | 0 | 收尾契约/配置保护和脚本语法检查，不重跑模型回归 |

PC：200轮工程闭环完成，A08全阶段仍PARTIAL。Csim/Cosim/综合/实现/A08交叉构建/BOARD：本增量全部NOT_TESTED，保留早期各域独立有效证据。未做新commit/push；基准HEAD为`ed9df6c7152c908d512ecd1f871583182823e1eb`，原有dirty文件保留。下一步仅上述收口项，不自动执行A09或重启长测。代码/报告/原始记录SHA256清单为`files.partial.sha256.json`（清单不是通过证书；不自包含自身和外层封存命令）。
