# A08：PC工程收口（2026-10-04）

结论：**PASS_A08_PC_ENGINEERING**，仅默认电脑工程闭环。不是产品质量、医学、声学或KV260验收。新普通WAV确认界面的真人操作尚未验证；不冒充用户确认。A03/A05及A07离线通过状态保留。

## 本轮实际工作

- 先归档当前A侧源码/config/锁文件，运行旧契约保护和新版配置检查；保留脏工作区，不重装、不重导权重、不构建另一套运行库。
- 核验冻结200轮计划、原始逐轮日志、checks、停止记录、指标和提示比较6项SHA256，全部与旧封存一致。原CPU源码6项与二进制6项哈希一致。
- 修复资源缺失被当作0的问题：进程内存不完整则总量null，保留已观察小计/缺失指标，spool遍历竞态保留缺失数，采样失败写ERROR行及计数；报告支持null而非丢弃异常后假装完整。
- 启动和逐轮附配置hash、模型revision、llama commit、sidecar/语音锁文件hash，所有轮含病例version/hash及worker代次。权重仍只初始化加载，不每token重哈希/重排。
- 纠正过时README：交互 `/wav` 已有单次ticket确认；`--wav`无交互确认，低置信时保守澄清。没有代用户按yes。
- 当前83项PC控制/应用/语音测试通过（原75+新增8）；之后只补两轮真实离线模型/语音推理，不重复200轮和已被用户停止的额外两小时测试。

实现路径：`system_qwen35/app/default_e2e/{resources,provenance,service,test_accounting}.py`、`system_qwen35/app/session.py`；报告工具`platform/qwen35/a08/{report,closeout}.py`，使用说明同入口README。设计差距见本目录DESIGN_GAP.md。

## 证据与结果

| 范围 | 结果 |
|---|---|
| 固定200轮（复用，hash复核） | 200完成；133 MODEL、67 TEMPLATE。40 ASR需确认、20双重否定澄清、7检查器拒绝。不是模型准确率100% |
| 故障/策略（复用） | 4阶段取消、错误WAV、LLM超时、实际播放器SIGSTOP超时、未知/注入2例，共9例 |
| 历史额外压测 | 424已检查轮次和最后未完成trace保留，用户停止；不写两小时通过 |
| 本轮真实WAV闭环 | 合成来源WAV→真实ASR→真实72 MLP S1→事实检查→真实TTS→Pulse播放完成，MODEL/CPU_REFERENCE |
| 本轮no_hardware | 真实文本→S1→检查→TTS→播放完成，MODEL/CPU_REFERENCE |
| fpga_required | 实际CLI退出2，HARDWARE_UNAVAILABLE；输出目录未创建、模型/设备未初始化，无CPU回退 |
| 网络/音频 | unshare -Urn隔离外网，保留Unix socket播放；没有新录音、预录答案或mock模型 |
| PC测试 | 83/83通过；模拟异常只限资源控制单测，不用于宣称真实推理通过 |
| Csim/Cosim/综合/实现/交叉构建 | 本轮NOT_TESTED；A06/A07已有证据不重跑、不改写 |
| BOARD/A53/CMA/BO/功耗 | NOT_TESTED/null |

两轮小样，不能代表总体或比较硬件：

| 模式 | 服务ready ms | 输入到播放提交 ms | PSS采样峰KiB | RSS采样峰KiB |
|---|---:|---:|---:|---:|
| CPU同数学WAV | 30578.910 | 4814.069 | 1065347 | 1093580 |
| no_hardware文本 | 27115.578 | 3603.685 | 1047215 | 1075776 |

ready与轮次计时分开；播放提交不是首个有效音节，声学值仍null。WAV运行真实记录1次不完整内存采样、0采样错误；no_hardware为0/0。峰值每500ms采样，可能漏短时峰值；不完整数据不补0。详细页类型、初始mapping、sidecar/工作区和受保护GGUF页见metrics.json；不能把逻辑文件字节、匿名内存和PSS相加。sidecar逻辑数据140378112字节，72个权重仅初始化加载；原GGUF目标MLP页与映射仍按原生保护策略记录。板端预算仍DEPLOYMENT_PENDING_BOARD。

## 线程、提示与质量分账

复用LLM2/3×TTS1/2四组真实小样。experiments-v1各组混有质量失败，`chosen=null`；所以不宣称默认3/2为实证最优。ASR1、LLM3/算子3、TTS2，三阶段串行；单轮在途/待办0、voice队列4，不启用全并发。

最终同信息4个多事实开发例：旧提示2 MODEL/2 TEMPLATE，facts_v4为4 MODEL；平均prompt token117→116，prefill3978.656→3953.826ms，完整原生轮等待4899.594→5028.954ms。**质量改善小样，不是整体加速**。旧失败提示和全部样本保留；单事实提示字节相同。R0禁用前缀缓存，命中无样本，不能写0ms；历史汇总已分冷首轮/miss。分句合成软件间隔约0.62–0.66秒，无证明收益，仍完整检查后整段合成播放。

A09已修的“我气短。”/“是的，我有气短。”误拒绝证据保留，未把旧200轮的7次拒绝追改成MODEL。ASR原有否定/数字/临床词问题、教师审核与独立终测仍开放；软件规则/来源可追溯不等于医学正确。

## 实际命令及退出码

外层均由 `platform/local/a1/venv/Scripts/python.exe platform/a1/record.py --log <本目录/*command.json> -- ...` 留存完整argv、stdout、stderr、用时和退出码。

| 命令（WSL KV260-A-2204，仓库根） | 退出码 |
|---|---:|
| `python3 platform/qwen35/a08/snapshot.py .../before`；`python3 scripts/release/check_contracts.py`；`python3 scripts/release/qwen35_config.py` | 0 |
| `bash platform/qwen35/a08/run.sh -m unittest ...test_a02 ...test_capture ...test_policy ...test_review ...test_accounting modules.voice_A.test_voice` | 0，83项 |
| `bash platform/qwen35/a08/run.sh platform/qwen35/a08/closeout.py audit` | 0 |
| `bash platform/qwen35/a08/run.sh platform/qwen35/a08/closeout.py smoke` | 0，两真实轮；内部FPGA拒绝2是预期 |
| `bash platform/qwen35/a08/run.sh platform/qwen35/a08/closeout.py summarize` | 0 |
| `bash platform/qwen35/a08/run.sh platform/qwen35/a08/report.py eval/qwen35/a08/regression-v2 .../reused-report` | 0；只重算汇总，不执行推理 |
| `bash platform/qwen35/a08/run.sh platform/qwen35/a08/closeout.py final` | 0；契约/配置、当前分支、200轮汇总完全一致、sidecar身份及null预算 |

最终检查/封存命令和SHA256见本目录相应JSON。当前分支`member-a/qwen35-a00-20261002`，基线HEAD `ed9df6c7152c908d512ecd1f871583182823e1eb`。**本轮无新commit/push**；保留已有未提交修改，不打包整个脏仓库。

## 未决项与下一步

- 人工体验：新确认UI真人操作NOT_TESTED。可用现有授权WAV输入，用户核对后自己确认；不需要为了本阶段再录音。
- 物理计时/声学间隙/欠载/现场说话结束仍待回采；Pulse完成只证明软件路径。
- 医学审核、独立300题、自然语音质量仍未通过。P2缓存/全并发/新GUI未实现，不掩盖质量待办。
- A09旧安装包保持原封存快照；后续若接纳本轮软件需重新封存及安装验证，不能把旧包说成已含新修复。
- 下一阶段按用户指令收口A09系统/ARM语音部署依赖；到板另行身份/启动/内存/BO/恢复验证。当前停止，不扫描B/C或执行板卡操作。

本轮llama-cpp技能仅用于核对固定CPU入口/线程测量原则，没有采用通用技能中的性能数字或升级模型/库。
