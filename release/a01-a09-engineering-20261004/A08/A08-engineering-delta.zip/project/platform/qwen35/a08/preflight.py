"""Preserve the exact pre-A08 inputs and run mandatory non-mutating gates."""
import hashlib, json, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
out = ROOT / 'eval/qwen35/a08/preflight-v1'
out.mkdir(parents=True, exist_ok=False)
files = ['AGENTS.md','docs/PROJECT_STATUS.json','docs/status/A.md',
         'system_qwen35/app/native.py','system_qwen35/app/native_w4a8.py',
         'system_qwen35/app/audio_adapter.py','modules/voice_A/engine.py',
         'modules/voice_A/worker.py','modules/voice_A/manifest.json',
         'config/qwen35/selection.json','modules/linear_A/manifest.json',
         'modules/voice_A/resources.lock.json','models/model.lock.json',
         'models/sidecar_A/qwen35-v1/manifest.json']
hashes = {}
for name in files:
    p=ROOT/name; target=out/'before'/name
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for argv in [['git','status','--short'],['git','rev-parse','HEAD'],
             [sys.executable,'scripts/release/check_contracts.py'],
             [sys.executable,'scripts/release/qwen35_config.py']]:
    r=subprocess.run(argv,cwd=ROOT,text=True,capture_output=True)
    results.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
(out/'audit.json').write_text(json.dumps(dict(files=hashes,commands=results),indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'output':str(out),'exit_codes':[r['exit_code'] for r in results]}))
sys.exit(int(any(r['exit_code'] for r in results)))
