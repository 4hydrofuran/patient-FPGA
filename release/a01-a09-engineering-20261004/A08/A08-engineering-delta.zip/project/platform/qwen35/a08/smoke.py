import json,sys
from pathlib import Path
from system_qwen35.app.default_e2e.service import Service

out=Path(sys.argv[1]);s=Service(out,llm_threads=3,tts_threads=2)
try:
    fixtures=json.loads(Path('eval/qwen35/a03/audio-eval-v1/fixtures.json').read_text())
    f=fixtures[0]
    r=s.turn(wav=f['wav'],synthetic_reference=f['text'],stream=True)
    print(json.dumps({'status':r['status'],'error':r.get('error'),'source':r['answer_source'],'text':r.get('application',{}).get('text'),'spool':r['spool_after_bytes']},ensure_ascii=False),flush=True)
    assert r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['spool_after_bytes']==0
finally:s.close()
