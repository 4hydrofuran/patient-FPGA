"""Archive scoped A08 sources/configs, never weights, licenses or other members."""
import hashlib,json,shutil,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[3];out=root/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
patterns=['system_qwen35/app/*.py','system_qwen35/app/default_e2e/*.py','modules/voice_A/*.py',
 'runtime/qwen35_w4a8/*.cpp','runtime/qwen35_w4a8/*.hpp','platform/qwen35/a08/*.py','platform/qwen35/a08/*.sh',
 'modules/linear_A/*config.json','modules/linear_A/manifest*.json','config/qwen35/*.json']
files=set()
for pattern in patterns:files.update(root.glob(pattern))
files.update(root/n for n in ['modules/voice_A/manifest.json','modules/voice_A/resources.lock.json','models/model.lock.json',
 'models/sidecar_A/qwen35-v1/manifest.json','contracts/qwen35/contracts.lock'])
manifest={}
for p in sorted(files):
    if p.is_symlink() or not p.is_file():raise RuntimeError('Unsafe snapshot file')
    name=p.relative_to(root).as_posix();dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    manifest[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
with (out/'SHA256.json').open('x') as f:json.dump({'capture_monotonic_ns':time.monotonic_ns(),'files':manifest},f,indent=2)
print(json.dumps({'files':len(files),'manifest_sha256':hashlib.sha256((out/'SHA256.json').read_bytes()).hexdigest()}))
