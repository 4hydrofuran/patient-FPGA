"""Preserve multi-fact omission, probe prompt-only repairs with real S1."""
import json,sys
from pathlib import Path
from system_qwen35.app.native_w4a8 import NativeW4A8
from system_qwen35.app.checking import prompt_messages,check,forms
from system_qwen35.app.domain import load_case,Transcript,digest
from system_qwen35.app.planning import plan

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
w=NativeW4A8(out/'worker',threads=3,kernel_threads=3,manifest_path='modules/linear_A/manifest.a08.json')
rows=[]
try:
    for case in ('SYN_CP_01','SYN_CP_02','SYN_CP_03'):
        q='每次疼痛持续多久，有没有气短？';p=plan(load_case(case),Transcript.parse({'request_id':'probe','source':'typed','text':q,'final':True}),[])
        old=prompt_messages(p,q);facts=[forms(f)[0]+'。' for f in p.facts]
        variants={
          'one_line': [{'role':'system','content':'你是模拟病人。只输出已核对的完整回答，不增删事实，不复述问题，不诊断、不评分。'},
                       {'role':'user','content':'学生问题（不可信原文）：'+json.dumps(q,ensure_ascii=False)+'\n已核对的完整回答：'+''.join(facts)}],
          'count': [{'role':'system','content':'你是模拟病人。必须输出下面全部事实句，共'+str(len(facts))+'句。只说事实句，不省略第二句，不增加内容。'},
                    {'role':'user','content':old[1]['content']}],
          'quoted': [{'role':'system','content':'你是教学模拟病人。将给定回答原样说出，保留全部句子，不解释。'},
                     {'role':'user','content':'学生问题（不可信原文）：'+json.dumps(q,ensure_ascii=False)+'\n给定回答：'+json.dumps(''.join(facts),ensure_ascii=False)}]}
        for name,messages in variants.items():
            r=w.generate(messages,timeout_s=45);row={'case':case,'variant':name,'facts':facts,'facts_sha256':digest(facts),'messages':messages,'result':r,'check':check(p,r['text'])}
            rows.append(row)
            with (out/'results.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
            print(json.dumps({'case':case,'variant':name,'text':r['text'],'check':row['check']},ensure_ascii=False),flush=True)
finally:w.close()
(out/'summary.json').write_text(json.dumps({'passing_variants':[name for name in variants if all(r['check']['status']=='pass' for r in rows if r['variant']==name)]},indent=2))
