"""Small paired, real-model development experiment; not held-out quality proof."""
import json,statistics,sys,time
from pathlib import Path
from system_qwen35.app.default_e2e.service import Service
from system_qwen35.app.native_w4a8 import NativeW4A8
from system_qwen35.app.checking import prompt_messages
from system_qwen35.app.planning import plan
from system_qwen35.app.domain import load_case,Transcript

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);rows=[];refs=[]
# Fixed old build as independent scheduling baseline; same known application questions.
questions=['疼痛在什么位置？','每次疼痛持续多久，有没有气短？']
w=NativeW4A8(out/'preserved-a05',threads=4)
try:
    for q in questions:
        p=plan(load_case('SYN_CP_01'),Transcript.parse({'request_id':'ref','text':q,'source':'typed','final':True}),[])
        r=w.generate(prompt_messages(p,q),timeout_s=45);refs.append({'text':r['text'],'tokens':r['output_tokens'],'logits':r['last_prompt_logits_fnv64']})
finally:w.close()
(out/'old-build-reference.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2))
for llm,tts in [(2,1),(3,1),(2,2),(3,2)]:
    s=Service(out/f'llm{llm}-tts{tts}',llm_threads=llm,tts_threads=tts)
    try:
        for repeat in range(2):
            for style in ('old','short'):
                s.model.prompt_style=style
                for n,q in enumerate(questions):
                    s.switch_case('SYN_CP_01');r=s.turn(text=q,timeout_s=45)
                    model=r.get('application',{}).get('model_result') or {};ts=r['timestamps']
                    row={'llm':llm,'kernel':llm,'tts':tts,'repeat':repeat,'style':style,'question_index':n,
                         'status':r['status'],'answer_source':r['answer_source'],'trace':str(s.output/'rounds.jsonl'),'request_id':r['request_id'],
                         'text':r.get('application',{}).get('text'),'prefill_ms':model.get('prefill_ms'),'ttft_ms':model.get('ttft_ms'),
                         'prompt_tokens':model.get('prompt_tokens'),'payload_sha256':r.get('prompt',{}).get('payload_sha256'),
                         'tts_ms':r.get('tts',{}).get('compute_ms'),'input_to_submit_ms':(ts['playback_submit_ns']-ts['input_submitted_ns'])/1e6 if ts['playback_submit_ns'] else None,
                         'preserved_a05_bitwise_match':None if style=='short' else (model.get('output_tokens')==refs[n]['tokens'] and model.get('last_prompt_logits_fnv64')==refs[n]['logits'])}
                    rows.append(row)
                    with (out/'results.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
                    print(json.dumps(row,ensure_ascii=False),flush=True)
    finally:s.close()
summary=[]
for llm,tts in [(2,1),(3,1),(2,2),(3,2)]:
    for style in ('old','short'):
        rs=[r for r in rows if (r['llm'],r['tts'],r['style'])==(llm,tts,style)]
        valid=all(r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['preserved_a05_bitwise_match'] is not False for r in rs)
        summary.append({'llm':llm,'tts':tts,'style':style,'count':len(rs),'valid':valid,
            'mean_submit_ms':statistics.mean(r['input_to_submit_ms'] for r in rs if r['input_to_submit_ms'] is not None),
            'mean_prompt_tokens':statistics.mean(r['prompt_tokens'] for r in rs if r['prompt_tokens'] is not None)})
valid=[r for r in summary if r['valid']]
chosen=min(valid,key=lambda r:r['mean_submit_ms']) if valid else None
result={'domain':'PC','paired_results':summary,'chosen':chosen,'old_build_equivalence':all(r['preserved_a05_bitwise_match'] for r in rows if r['style']=='old'),
        'scope':'Two development questions only; no clinical/heldout claim','board':'NOT_TESTED'}
(out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
if not chosen or not result['old_build_equivalence']:raise SystemExit(2)
