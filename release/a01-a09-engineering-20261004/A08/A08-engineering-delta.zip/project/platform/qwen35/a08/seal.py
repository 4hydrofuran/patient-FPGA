"""Seal existing A08 code/reports, with no model or audio regeneration."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[3];dest=root/sys.argv[1]
if dest.exists():raise RuntimeError('Evidence seal already exists')
files=set()
for base in ('eval/qwen35/a08','platform/qwen35/a08','system_qwen35/app/default_e2e'):
    files.update(p for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ('docs/PROJECT_STATUS.json','docs/status/A.md','docs/DESIGN_GAP.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md','docs/handoffs/A_A08_20261003.md',
             'system_qwen35/app/native.py','system_qwen35/app/native_w4a8.py','system_qwen35/app/audio_adapter.py',
             'modules/voice_A/engine.py','modules/voice_A/worker.py','modules/linear_A/manifest.a08.json',
             'modules/linear_A/cpu_threads2_config.json','modules/linear_A/cpu_threads3_config.json',
             'config/qwen35/resources.a08.json','runtime/qwen35_w4a8/main.cpp','runtime/qwen35_w4a8/bridge.cpp'):
    files.add(root/name)
manifest={}
for p in sorted(files):
    if p.is_symlink():raise RuntimeError('Symlink evidence refused: '+str(p))
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    manifest[p.relative_to(root).as_posix()]={'sha256':h.hexdigest(),'bytes':p.stat().st_size}
dest.parent.mkdir(parents=True,exist_ok=True)
with dest.open('x',encoding='utf-8') as f:json.dump({'scope':'A08 partial handoff after user stopped extra repetition; seal is not acceptance',
  'exclusions':['No weights or credentials recopied','This seal and its enclosing command record are not self-hashed'],'files':manifest},f,ensure_ascii=False,indent=2)
print(json.dumps({'files':len(manifest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'path':str(dest)}))
