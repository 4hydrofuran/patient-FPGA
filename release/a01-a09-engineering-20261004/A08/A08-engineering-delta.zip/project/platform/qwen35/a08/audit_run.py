"""Read-only integrity audit of the finished real A08 run, not a rerun."""
import argparse, collections, hashlib, json
from pathlib import Path
from system_qwen35.app.default_e2e.policy import validate_trace

def lines(p):
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('run');ap.add_argument('output');a=ap.parse_args()
    root=Path.cwd();run=Path(a.run);out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    result={'domain':'PC_EVIDENCE_AUDIT','errors':[],'checks':0,'services':{}}
    def verify(ok,description,**context):
        result['checks']+=1
        if not ok:result['errors'].append(dict(description=description,**context))
    summary=json.loads((run/'summary.json').read_text())
    verify(summary['two_hour_duration'] and summary['elapsed_s']>=7200,'two-hour actual run')
    frozen=json.loads((run/'plan.json').read_text())
    checks=lines(run/'checks.jsonl');core=[x for x in checks if x['cohort']=='CORE_200_WAV']
    verify(len(core)==len(frozen['normal'])==200,'all 200 frozen rounds retained')
    verify(all(x['pass'] for x in checks),'all recorded expected-behavior checks',failed=[x for x in checks if not x['pass']])
    for c,p in zip(core,frozen['normal']):
        verify(c['index']==p['index'] and c['fixture']==p['fixture'],'frozen plan order',request_id=c['request_id'])
    for name in ('default','no-hardware'):
        folder=run/name;rounds=lines(folder/'rounds.jsonl');vrequests={};mrequests={};mresults={}
        for p in folder.glob('voice-*/wire.jsonl'):
            for x in lines(p):
                if 'request' in x:
                    q=x['request'];key=(q['request_id'],q['op'])
                    verify(key not in vrequests,'unique voice request/op',request_id=q['request_id'])
                    vrequests[key]=x
        for p in folder.glob('model-*/wire.jsonl'):
            for x in lines(p):
                if 'request' in x:mrequests[x['request']['id']]=x['request']
                if x.get('type')=='result':mresults[x['id']]=x
        sources=collections.Counter();completed=0;model_count=0
        for r in rounds:
            rid=r['request_id'];sid=r['session_id'];ts=r['timestamps'];sources[str(r['answer_source'])]+=1
            try:validate_trace(r)
            except Exception as e:verify(False,'trace integrity',request_id=rid,error=repr(e))
            else:verify(True,'trace integrity')
            for key in ('asr','tts','voice_reset'):
                response=r.get(key)
                if response is None:continue
                entry=vrequests.get((response['request_id'],response['op']))
                verify(entry is not None,'voice wire request exists',request_id=rid,kind=key)
                if entry:
                    verify(entry['request'].get('session_id')==sid,'voice actual session identity',request_id=rid,kind=key)
                    verify(ts['input_submitted_ns']<=entry['submitted_ns']<=ts['end_ns'],'voice clock within round',request_id=rid,kind=key)
            if ts['llm_start_ns'] is not None:
                q=mrequests.get(sid+':'+rid)
                verify(q is not None and q.get('session_id')==sid and q.get('session_epoch')==r['epoch'],'native request/epoch identity',request_id=rid)
            app=r.get('application',{});m=app.get('model_result') or {}
            if m.get('quantization')=='S1_W4A8_MLP' and m.get('status')=='OK':
                b=m['bridge'];model_count+=1
                verify(m['id']==sid+':'+rid and m['id'] in mresults,'native raw result provenance',request_id=rid)
                verify(len(b['weights'])==72 and all(v['calls']>0 for v in b['weights'].values()),'all72 CPU nodes computed',request_id=rid)
                verify(b['weight_load_count']==72 and b['owned_weight_bytes']==140378112,'resident weight lifecycle',request_id=rid)
                verify(b['hardware_done_count'] is None and b['kernel_ms'] is None,'no hardware measurements invented',request_id=rid)
                verify(m['state_cleared_before_response'] and m['state_position_after_clear']==-1,'R0 state cleared',request_id=rid)
            if r['status']=='COMPLETED':
                completed+=1
                verify(r['session_after']['pending'] is None,'no pending delivery after completion',request_id=rid)
            if name=='no-hardware':
                verify(r['mode']=='no_hardware' and r['status']=='COMPLETED' and r['actual_backend']=='CPU_REFERENCE' and r['answer_source']=='MODEL','separate actual no-hardware CPU round',request_id=rid)
        resources=json.loads((folder/'resources-summary.json').read_text())
        verify(resources['sampler_error'] is None,'resource sampler no error',service=name)
        verify(not any(p.is_file() for p in (folder/'spool').rglob('*')),'owned spool empty after shutdown',service=name)
        result['services'][name]={'rounds':len(rounds),'completed':completed,'model_results':model_count,'sources':dict(sources),'voice_requests':len(vrequests),'native_requests':len(mrequests)}
    initial=json.loads((run/'initial-resource.json').read_text());final=json.loads((run/'final-resource.json').read_text())
    verify(initial['network']['isolated'] and final['network']['isolated'],'external network unavailable at start and end')
    verify(initial['network']['net_namespace']==final['network']['net_namespace'],'same disconnected network namespace')
    result['network']={'start':initial['network'],'end':final['network']}
    rejected=json.loads((run/'fpga-required.json').read_text())
    verify(len(rejected)==3 and all(x['pass'] and x['actual_backend'] is None for x in rejected),'all required-FPGA registry calls rejected')
    snap=json.loads((run/'source-snapshot/SHA256.json').read_text());changed=[]
    for name,v in snap['files'].items():
        if name.startswith(('system_qwen35/app/','modules/voice_A/','runtime/qwen35_w4a8/','modules/linear_A/','config/qwen35/')):
            if hashlib.sha256((root/name).read_bytes()).hexdigest()!=v['sha256']:changed.append(name)
    result['runtime_source_changes_since_snapshot']=changed
    verify(not changed,'runtime source unchanged during frozen long run',changed=changed)
    result['pass']=not result['errors'];result['BOARD']='NOT_TESTED';result['medical_review']='PENDING_TEACHER_REVIEW'
    (out/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'pass':result['pass'],'checks':result['checks'],'errors':len(result['errors']),'services':result['services']}))
    return 0 if result['pass'] else 2
if __name__=='__main__':raise SystemExit(main())
