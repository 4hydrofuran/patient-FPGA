"""Real post-repair regression; does not overwrite frozen 200-round metrics."""
import json,sys
from pathlib import Path
from system_qwen35.app.default_e2e.service import Service
from system_qwen35.app.default_e2e.policy import validate_trace

out=Path(sys.argv[1]);s=Service(out,llm_threads=3,tts_threads=2);checks=[]
fixtures={f['id']:f for f in json.loads(Path('eval/qwen35/a03/audio-eval-v1/fixtures.json').read_text())}
try:
    for case in ('SYN_CP_01','SYN_CP_02','SYN_CP_03'):
        s.switch_case(case);f=fixtures['q_dyspnea']
        r=s.turn(wav=f['wav'],synthetic_reference=f['text']);validate_trace(r)
        checks.append({'request_id':r['request_id'],'case_id':case,'task':'real ASR dyspnea','source':r['answer_source'],'candidate':r['application']['candidate'],
                       'pass':r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['application']['final_check']['status']=='pass'})
        r=s.turn(text='每次疼痛持续多久，有没有气短？');validate_trace(r)
        checks.append({'request_id':r['request_id'],'case_id':case,'task':'real two-fact S1 TTS','source':r['answer_source'],'candidate':r['application']['candidate'],
                       'pass':r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['application']['final_check']['status']=='pass'})
finally:s.close()
(out/'increment.json').write_text(json.dumps({'domain':'PC_REAL_MODEL_ASR_TTS_PULSE','checks':checks,'BOARD':'NOT_TESTED','acoustic_onset_ns':None,'medical_review':'PENDING_TEACHER_REVIEW'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':sum(c['pass'] for c in checks),'total':len(checks)}));raise SystemExit(0 if all(c['pass'] for c in checks) else 2)
