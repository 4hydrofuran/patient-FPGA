import hashlib,json
from pathlib import Path
root=Path('/mnt/c/Patientqwen');old=json.loads((root/'modules/linear_A/manifest.json').read_text())
new=dict(old);new['native_entry']='/home/member-a/qwen35-a08/native-v1/qwen35-s1'
new['shared_library']='/home/member-a/qwen35-a08/native-v1/libsp_linear_cpu.so'
new['files']={p:v for p,v in old['files'].items() if p not in (old['native_entry'],old['shared_library'])}
for p in [new['native_entry'],new['shared_library']]:
    data=Path(p).read_bytes();new['files'][p]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
new['status']='A08_BUILD_PENDING_REAL_REGRESSION';new['change']='Same CPU math and pinned llama libraries; explicit optimized 2/3-thread kernel configurations'
new['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in [
    'runtime/qwen35_w4a8/main.cpp','runtime/qwen35_w4a8/bridge.cpp','runtime/qwen35_w4a8/cpu_backend.cpp',
    'quant/reference/w4a8.cpp','modules/linear_A/cpu_threads2_config.json','modules/linear_A/cpu_threads3_config.json']}
with (root/'modules/linear_A/manifest.a08.json').open('x') as f:json.dump(new,f,indent=2)
print(json.dumps({'native_entry':new['native_entry'],'files':new['files']}))
