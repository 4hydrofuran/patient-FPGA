"""Bounded A08 refresh; historical 200 remain immutable. No board or recording."""
import collections,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a08/closeout-20261004-v1'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def lines(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(name,x):
    with (OUT/name).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def audit():
    base=ROOT/'eval/qwen35/a08';seal=read(base/'files.partial.sha256.json')['files']
    names=['regression-v2/plan.json','regression-v2/checks.jsonl','regression-v2/default/rounds.jsonl',
           'regression-v2/STOPPED_BY_USER.json','core200-report/metrics.json',
           'prompt-final-comparison/comparison.json']
    evidence={}
    for name in names:
        p=base/name;rel=p.relative_to(ROOT).as_posix();old=seal.get(rel)
        evidence[rel]={'sha256':sha(p),'bytes':p.stat().st_size,'sealed_sha256':old['sha256'] if old else None,
                       'matches_old_seal':sha(p)==old['sha256'] if old else None}
    checks=lines(base/'regression-v2/checks.jsonl');rows=lines(base/'regression-v2/default/rounds.jsonl')
    index={r['request_id']:r for r in rows};core=[c for c in checks if c['cohort']=='CORE_200_WAV'];selected=[index[c['request_id']] for c in core]
    failures=[c for c in core if not c['pass']]
    m=read(ROOT/'modules/linear_A/manifest.a08.json')
    native={n:sha(ROOT/n)==s for n,s in m['source_sha256'].items()}
    binaries={n:sha(Path(n))==s['sha256'] for n,s in m['files'].items()}
    result={'domain':'PC_EVIDENCE_AUDIT','evidence':evidence,'core_count':len(core),'core_check_failures':failures,
       'core_sources':dict(collections.Counter(r['answer_source'] for r in selected)),
       'core_statuses':dict(collections.Counter(r['status'] for r in selected)),
       'cohorts':dict(collections.Counter(c['cohort'] for c in checks)),
       'all_recorded_rounds_including_extra':len(rows),'native_source_continuity':native,'native_binary_hashes':binaries,
       'not_replayed':True,'BOARD':'NOT_TESTED','prior_failures':'Retained; old cohort not relabelled using newer checker.'}
    save('reuse-audit.json',result)
    assert len(core)==200 and not failures and all(native.values()) and all(binaries.values())
    assert all(x['matches_old_seal'] is not False for x in evidence.values())
    print(json.dumps({'audit':'PASS','core':200,'sources':result['core_sources']}))
def smoke():
    from system_qwen35.app.default_e2e.service import Service
    from system_qwen35.app.default_e2e.policy import validate_trace
    fixture=read(ROOT/'eval/qwen35/a03/audio-eval-v1/fixtures.json')[0]
    result=[]
    for mode in ('cpu_same_math','no_hardware'):
        s=Service(OUT/mode,mode=mode)
        try:
            r=s.turn(wav=fixture['wav'],synthetic_reference=fixture['text'],stream=True) if mode=='cpu_same_math' else s.turn(text='有没有气短？')
            validate_trace(r)
            result.append({'mode':mode,'status':r['status'],'answer_source':r['answer_source'],'actual_backend':r['actual_backend'],
               'answer':r.get('application',{}).get('text'),'error':r.get('error'),'provenance':r['provenance'],
               'case_identity':r['case_identity'],'spool_bytes':r['spool_after_bytes']})
        finally:s.close()
    # Exercise the actual CLI refusal, no directory/model/hardware opened.
    argv=[sys.executable,'-m','system_qwen35.app.default_e2e','--output',str(OUT/'must-not-exist'),'--mode','fpga_required']
    p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
    save('hardware-refusal.json',{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,
        'output_created':(OUT/'must-not-exist').exists()})
    save('smoke-summary.json',{'domain':'PC_REAL_MODELS_OFFLINE_NETNS','rounds':result,'network_namespace':os.readlink('/proc/self/ns/net'),
        'network_interfaces':os.listdir('/sys/class/net'),'new_recordings':False,'human_confirmation_UI':'NOT_TESTED',
        'BOARD':'NOT_TESTED','acoustic_first_sound_ns':None})
    assert p.returncode==2 and not (OUT/'must-not-exist').exists()
    assert all(r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['actual_backend']=='CPU_REFERENCE' and r['spool_bytes']==0 for r in result)
    print(json.dumps({'smoke':'PASS','real_rounds':len(result),'fpga_required_exit':p.returncode}))
def summarize():
    from system_qwen35.app.default_e2e.policy import validate_trace
    metrics={}
    for mode in ('cpu_same_math','no_hardware'):
        directory=OUT/mode;r=lines(directory/'rounds.jsonl')[0];validate_trace(r)
        start=read(directory/'startup.json');ts=r['timestamps'];model=r['application']['model_result'];bridge=model['bridge']
        resource=read(directory/'resources-summary.json');samples=lines(directory/'resources.jsonl')
        assert not resource['failed_samples'] and resource['sampler_error'] is None
        metrics[mode]={'status':r['status'],'answer_source':r['answer_source'],'actual_backend':r['actual_backend'],
           'software_input_to_submit_ms':(ts['playback_submit_ns']-ts['input_submitted_ns'])/1e6,
           'software_round_ms':(ts['end_ns']-ts['input_submitted_ns'])/1e6,
           'service_ready_ms':(start['ready_ns']-start['start_ns'])/1e6,
           'native_prefill_ms':model['prefill_ms'],'native_ttft_ms':model['ttft_ms'],
           'resource_summary':resource,'initial_model_mapping':start['model_mapping'],
           'sidecar_owned_bytes':bridge['owned_weight_bytes'],'weight_load_count':bridge['weight_load_count'],
           'workspace_capacity_bytes':bridge['workspace_capacity_bytes'],'runtime_buffer_capacity_bytes':bridge['runtime_buffer_capacity_bytes'],
           'protected_gguf_mlp_rss_kib':bridge['protected_gguf_rss_kib'],
           'trace_case_identity':r['case_identity'],'trace_provenance':r['provenance'],
           'incomplete_sample_examples':[s for s in samples if s.get('sample_status')!='COMPLETE' or s.get('spool_disappeared_during_sample')],
           'state_policy':'R0_CLEAR_ALL_REPLAY; context1024, physical ubatch8; cache_hit=false',
           'first_effective_sound_ms':None,'acoustic_underruns':None}
    save('metrics.json',{'domain':'PC','bounded_samples':metrics,'memory_accounting':'Logical disk/allocation bytes overlap RSS/PSS; do not sum. 500ms sampled peaks can miss transient maxima.',
         'A53_memory_bytes':None,'CMA_bytes':None,'BO_budget_bytes':None,'BOARD':'NOT_TESTED'})
    print(json.dumps({k:{'submit_ms':v['software_input_to_submit_ms'],'ready_ms':v['service_ready_ms'],'pss_kib':v['resource_summary']['peak_simultaneous_sampled']['pss_kib']} for k,v in metrics.items()}))
def seal():
    names=['system_qwen35/app/default_e2e/resources.py','system_qwen35/app/default_e2e/provenance.py',
       'system_qwen35/app/default_e2e/service.py','system_qwen35/app/default_e2e/test_accounting.py','system_qwen35/app/default_e2e/README.md',
       'system_qwen35/app/session.py','platform/qwen35/a08/report.py','platform/qwen35/a08/closeout.py',
       'docs/PROJECT_STATUS.json','docs/status/A.md','docs/handoffs/A_A08_CLOSEOUT_20261004.md']
    files=[ROOT/n for n in names]+[p for p in OUT.rglob('*') if p.is_file() and p.name not in ('files.sha256.json','seal-command.json')]
    save('files.sha256.json',{'scope':'A08 incremental software evidence; not BOARD/medical acceptance',
        'files':{p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(set(files))}})
    print(json.dumps({'files':len(set(files)),'seal_sha256':sha(OUT/'files.sha256.json')}))
def final_checks():
    commands=[]
    for argv in ([sys.executable,'scripts/release/check_contracts.py'],[sys.executable,'scripts/release/qwen35_config.py'],
                 ['git','rev-parse','HEAD'],['git','branch','--show-current']):
        p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
        commands.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    new=read(OUT/'reused-report/metrics.json');old=read(ROOT/'eval/qwen35/a08/core200-report/metrics.json')
    cohort_unchanged=new['cohorts']['CORE_200_WAV']==old['cohorts']['CORE_200_WAV']
    metrics=read(OUT/'metrics.json');identity_ok=all(v['trace_provenance']['identity_files_sha256']['models/sidecar_A/qwen35-v1/manifest.json']=='cdb2a04dbd95d426ea8967cda0adb219a769d3630107a2af72d6ddf2d5285688' for v in metrics['bounded_samples'].values())
    status=read(ROOT/'docs/PROJECT_STATUS.json')
    save('final-checks.json',{'commands':commands,'recomputed_core200_cohort_identical':cohort_unchanged,
         'same_sidecar_identity':identity_ok,'board_budget_still_null':status['linux_memory_bytes'] is None and status['pl_bo_budget_bytes'] is None,
         'public_protocol':'UNCHANGED','BOARD':'NOT_TESTED'})
    assert all(x['exit_code']==0 for x in commands) and cohort_unchanged and identity_ok
    assert status['linux_memory_bytes'] is None and status['pl_bo_budget_bytes'] is None
    print(json.dumps({'final_checks':'PASS','core200_metrics_unchanged':True}))
if __name__=='__main__':
    {'audit':audit,'smoke':smoke,'summarize':summarize,'seal':seal,'final':final_checks}[sys.argv[1]]()
