#!/usr/bin/env bash
set -euo pipefail
cmake -S /mnt/c/Patientqwen/runtime/qwen35_w4a8 -B /home/member-a/qwen35-a08/native-v1 -DCMAKE_BUILD_TYPE=Release
cmake --build /home/member-a/qwen35-a08/native-v1 -j 3
cd /mnt/c/Patientqwen
python3 platform/qwen35/a08/seal_native.py
