@echo off
REM Interactive user launch only. No recording, no installation, no disk flashing.
if "%~1"=="" (
  echo Usage: launch.cmd UNIQUE_OUTPUT_NAME
  exit /b 2
)
wsl.exe -d KV260-A-2204 --cd /mnt/c/Patientqwen -- bash platform/qwen35/a08/run.sh -m system_qwen35.app.default_e2e --output "eval/qwen35/a08/%~1"
exit /b %errorlevel%
