"""Paired prompt-quality comparison using the same trusted facts, no TTS shortcut."""
import json,sys
from pathlib import Path
from system_qwen35.app.default_e2e.service import TimedNative
from system_qwen35.app.default_e2e.policy import THREAD_ENV,new_trace
from system_qwen35.app.session import Session

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
candidate=sys.argv[2] if len(sys.argv)>2 else 'facts_v2'
dev=json.loads(Path('eval/qwen35/a02/dev/questions-v2.json').read_text())
for i in range(1,4):dev.append({'id':f'A08-MULTI-{i}','case_id':f'SYN_CP_{i:02d}','question':'每次疼痛持续多久，有没有气短？'})
if '--multi-only' in sys.argv:dev=[d for d in dev if d['id']=='DEV-012' or d['id'].startswith('A08-MULTI-')]
worker=TimedNative(out/'native',threads=3,kernel_threads=3,manifest_path='modules/linear_A/manifest.a08.json',thread_env=THREAD_ENV)
rows=[]
try:
    for d in dev:
        for style in ('old',candidate):
            worker.prompt_style=style;session=Session(d['case_id'],software_test=True)
            tr=new_trace(session.snapshot()['session_id'],0,d['id'],'cpu_same_math',not rows);worker.trace=tr
            r=session.submit({'request_id':d['id'],'text':d['question'],'source':'typed','final':True},worker,timeout_s=45)
            row={'id':d['id'],'style':style,'question':d['question'],'case_id':d['case_id'],'trace':tr,'response':r};rows.append(row)
            with (out/'results.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
            print(json.dumps({'id':d['id'],'style':style,'source':r.get('answer_source'),'text':r.get('text'),'reason':r.get('fallback_reason')},ensure_ascii=False),flush=True)
finally:worker.trace=None;worker.close()
summary={}
for style in ('old',candidate):
    rs=[r['response'] for r in rows if r['style']==style]
    summary[style]={'count':len(rs),'model':sum(r.get('answer_source')=='MODEL' for r in rs),'templates':sum(r.get('answer_source')=='TEMPLATE' for r in rs),
        'unexpected_fallback':sum(r.get('fallback_reason')=='checker_rejected' for r in rs),'timeouts':sum(r.get('answer_source')=='TIMEOUT' for r in rs),
        'all_checks_pass':all(r.get('final_check',{}).get('status')=='pass' for r in rs)}
summary['identical_fact_and_question_requirements']=all(a['trace'].get('prompt',{}).get('fact_requirement_sha256')==b['trace'].get('prompt',{}).get('fact_requirement_sha256') and
    a['trace'].get('prompt',{}).get('question_payload_sha256')==b['trace'].get('prompt',{}).get('question_payload_sha256') for a,b in zip(rows[::2],rows[1::2]))
summary['quality_gate']=summary[candidate]['unexpected_fallback']==0 and summary[candidate]['timeouts']==0 and summary[candidate]['all_checks_pass'] and summary['identical_fact_and_question_requirements']
(out/'summary.json').write_text(json.dumps(summary,indent=2))
raise SystemExit(0 if summary['quality_gate'] else 2)
