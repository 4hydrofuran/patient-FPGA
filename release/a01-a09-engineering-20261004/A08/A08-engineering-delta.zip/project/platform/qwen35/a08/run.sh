#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Patientqwen
export PYTHONPATH=/mnt/c/Patientqwen
audio_prefix=/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu
export LD_LIBRARY_PATH="$audio_prefix:$audio_prefix/pulseaudio${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
# New network namespace only; host networking is not changed. Pulse uses a Unix socket.
exec unshare -Urn python3 "$@"
