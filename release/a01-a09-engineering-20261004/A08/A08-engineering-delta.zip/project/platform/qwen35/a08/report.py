"""Summarize recorded real attempts; never replace missing metrics with zero."""
import argparse,collections,hashlib,json,math,statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
def read_lines(p):
    if not p.exists():return []
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def stats(xs):
    xs=[x for x in xs if x is not None]
    if not xs:return {'n':0,'mean':None,'p50':None,'p95':None,'max':None}
    v=sorted(xs);return {'n':len(v),'mean':statistics.mean(v),'p50':statistics.median(v),'p95':v[math.ceil(.95*len(v))-1],'max':v[-1]}
def delta(r,end,begin):
    t=r['timestamps'];return None if t.get(end) is None or t.get(begin) is None else (t[end]-t[begin])/1e6

def observed_max(values):return max((v for v in values if v is not None),default=None)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('run');ap.add_argument('output');a=ap.parse_args()
    run=ROOT/a.run;out=ROOT/a.output;out.mkdir(parents=True,exist_ok=False)
    complete=json.loads((run/'summary.json').read_text()) if (run/'summary.json').exists() else None
    stopped=json.loads((run/'STOPPED_BY_USER.json').read_text()) if (run/'STOPPED_BY_USER.json').exists() else None
    rows=read_lines(run/'default/rounds.jsonl');checks=read_lines(run/'checks.jsonl');index={r['request_id']:r for r in rows}
    cohorts={}
    for cohort in sorted({c['cohort'] for c in checks}):
        cs=[c for c in checks if c['cohort']==cohort];rs=[index[c['request_id']] for c in cs]
        cohorts[cohort]={'attempts':len(cs),'expected_behavior_pass':sum(c['pass'] for c in cs),'statuses':dict(collections.Counter(r['status'] for r in rs)),
          'answer_sources':dict(collections.Counter(str(r['answer_source']) for r in rs)),
          'actual_backends':dict(collections.Counter(str(r['actual_backend']) for r in rs)),
          'fallback_reasons':dict(collections.Counter(str(r.get('application',{}).get('fallback_reason')) for r in rs)),
          'unexpected_checker_fallbacks':sum(r.get('application',{}).get('fallback_reason')=='checker_rejected' for r in rs),
          'timeouts':sum(r['status']=='TIMEOUT' or r['answer_source']=='TIMEOUT' for r in rs),
          'input_to_play_submit_ms':stats(delta(r,'playback_submit_ns','input_submitted_ns') for r in rs),
          'round_end_ms':stats(delta(r,'end_ns','input_submitted_ns') for r in rs),
          'acoustic_first_sound_ms':None,'missing_submit_count':sum(r['timestamps']['playback_submit_ns'] is None for r in rs)}
    cache_groups={}
    for kind in ('cold_first_round','miss','hit'):
        rs=[r for r in rows if r['cache']['category']==kind and r['timestamps']['llm_start_ns'] is not None]
        cache_groups[kind]={'attempts':len(rs),'time_ms':stats(delta(r,'playback_submit_ns','input_submitted_ns') for r in rs)}
    cache_groups['note']='Prefix cache disabled R0; zero hit samples, not zero-ms hits. Native gate/up reuse is separate.'
    cache_groups['llm_not_called']=sum(r['timestamps']['llm_start_ns'] is None for r in rows)
    source_latency={}
    for source in sorted({str(r['answer_source']) for r in rows}):
        rs=[r for r in rows if str(r['answer_source'])==source]
        source_latency[source]={'all_attempts':len(rs),'input_to_submit_ms':stats(delta(r,'playback_submit_ns','input_submitted_ns') for r in rs),
                               'missing_submit_count':sum(r['timestamps']['playback_submit_ns'] is None for r in rs)}
    stage_latency={name:stats(delta(r,end,begin) for r in rows) for name,begin,end in (
        ('input_to_asr_final_ms','input_submitted_ns','asr_final_ns'),
        ('llm_to_first_token_receive_ms','llm_start_ns','llm_first_token_received_ns'),
        ('llm_to_complete_sentence_checked_ms','llm_start_ns','sentence_checked_ns'),
        ('checked_to_tts_ready_ms','sentence_checked_ns','tts_ready_ns'),
        ('tts_ready_to_play_submit_ms','tts_ready_ns','playback_submit_ns'),
        ('playback_submit_to_api_complete_ms','playback_submit_ns','playback_complete_ns'))}
    startup=json.loads((run/'default/startup.json').read_text())
    maintenance=read_lines(run/'default/maintenance.jsonl')
    startup_metrics={'service_ready_ms':(startup['ready_ns']-startup['start_ns'])/1e6,
       'first_native_model_load_ms':startup['model_ready'].get('model_load_ms'),
       'first_voice_load_ms':startup['voice_hello'].get('load_ms'),
       'native_loads_ms':[e['native_ready']['model_load_ms'] for e in maintenance if e['event']=='workers_started'],
       'voice_loads_ms':[e['load_ms'] for e in maintenance if e['event']=='voice_started'],
       'startup_and_maintenance_are_not_omitted_from_wall_clock_duration':True}
    resources=read_lines(run/'default/resources.jsonl');process_peaks={};phases={}
    for name in ('app','voice','model','player'):
        samples=[r['processes'][name] for r in resources if name in r['processes']]
        process_peaks[name]={'rss_kib':observed_max(x['rollup'].get('Rss') for x in samples),
          'pss_kib':observed_max(x['rollup'].get('Pss') for x in samples),
          'os_hwm_kib':observed_max(x['status'].get('VmHWM') for x in samples),
          'thread_objects':observed_max(x['status'].get('Threads') for x in samples),
          'swap_kib':observed_max(x['status'].get('VmSwap') for x in samples)}
    for phase in sorted({r['phase'] for r in resources}):
        rs=[r for r in resources if r['phase']==phase]
        phases[phase]={'samples':len(rs),'aggregate_pss_peak_kib':observed_max(r['pss_kib'] for r in rs)}
    voices={};failure_buckets=collections.Counter();models=[]
    for r in rows:
        app=r.get('application',{});m=app.get('model_result')
        if m and m.get('quantization')=='S1_W4A8_MLP':models.append(m)
        if app.get('failure_bucket'):failure_buckets[app['failure_bucket']]+=1
        if r.get('asr_exact_fixture_match') is False:failure_buckets['ASR_NORMALIZED_TRANSCRIPT_MISMATCH']+=1
        if r.get('input',{}).get('kind')=='WAV':
            ref=r['input'].get('synthetic_reference');v=voices.setdefault(str(ref),{'attempts':0,'asr_final':0,'exact_normalized':0,'raw_hypotheses':collections.Counter()})
            v['attempts']+=1
            if r.get('asr'):
                v['asr_final']+=1;v['exact_normalized']+=int(r.get('asr_exact_fixture_match') is True);v['raw_hypotheses'][r['asr']['text']]+=1
    per_pid={}
    for sample in resources:
        for name,proc in sample['processes'].items():
            key=f'{name}:{proc["pid"]}'
            entry=per_pid.setdefault(key,{'first_ns':sample['monotonic_ns'],'first_pss_kib':proc['rollup'].get('Pss'),
                                         'first_rss_kib':proc['rollup'].get('Rss'),'pss_peak_kib':None,'rss_peak_kib':None,'samples':0})
            entry.update(last_ns=sample['monotonic_ns'],last_pss_kib=proc['rollup'].get('Pss'),last_rss_kib=proc['rollup'].get('Rss'))
            for metric,field in [('Pss','pss_peak_kib'),('Rss','rss_peak_kib')]:
                value=proc['rollup'].get(metric)
                if value is not None:entry[field]=value if entry[field] is None else max(entry[field],value)
            entry['samples']+=1
    memory={'sampling_ms':500,'process_peaks_not_additive':process_peaks,'phase_aggregate':phases,
       'simultaneous_aggregate_pss_peak_kib':observed_max(r['pss_kib'] for r in resources),
       'simultaneous_aggregate_rss_peak_kib':observed_max(r['rss_kib'] for r in resources),
       'spool_peak_bytes':observed_max(r['spool_bytes'] for r in resources),
       'spool_max_files':observed_max(r['spool_files'] for r in resources),
       'post_turn_spool_nonzero':sum(r.get('spool_after_bytes')!=0 for r in rows),
       'process_swap_peak_kib':observed_max(r.get('process_swap_kib') for r in resources),
       'vm_swap_delta':{key:resources[-1]['vm_swap_counters'][key]-resources[0]['vm_swap_counters'][key] for key in ('pswpin','pswpout')} if resources and all(key in resources[i].get('vm_swap_counters',{}) for i in (0,-1) for key in ('pswpin','pswpout')) else None,
       'incomplete_or_error_samples':sum(r.get('sample_status') in ('INCOMPLETE','ERROR') or bool(r.get('spool_disappeared_during_sample')) for r in resources),
       'sidecar_owned_bytes':max((m['bridge']['owned_weight_bytes'] for m in models),default=None),
       'native_workspace_peak_capacity_bytes':max((m['bridge']['workspace_capacity_bytes'] for m in models),default=None),
       'bridge_scratch_peak_capacity_bytes':max((m['bridge']['runtime_buffer_capacity_bytes'] for m in models),default=None),
       'protected_original_mlp_gguf_rss_peak_kib':max((m['bridge']['protected_gguf_rss_kib'] for m in models),default=None),
       'native_weight_load_counts':sorted({m['bridge']['weight_load_count'] for m in models}),
       'per_process_lifetimes':per_pid,
       'a53_memory_bytes':None,'cma_bytes':None,'pl_bo_budget_bytes':None,'deployment_status':'DEPLOYMENT_PENDING_BOARD',
       'thermal_throttling':None,'physical_audio_underruns':None,
       'notes':['RSS and file/anonymous pages overlap; do not add logical disk bytes to PSS.',
                'Sidecar input arrays are transient and CPU owns one packed copy; original MLP full pages protected/discarded.',
                'Smaps initial/final details and allocation logs preserve GGUF, non-MLP repack, state/cache, anonymous heaps.',
                '500ms sampling can miss sub-interval peaks; VmHWM per process is separately reported.',
                'WSL telemetry is not a physical A53 memory/thermal result.']}
    result={'stage':'A08','domain':'PC','run_summary':complete,'stop_annotation':stopped,'cohorts':cohorts,'all_attempts_in_raw_trace':len(rows),
       'checked_attempts':len(checks),'unclassified_attempts':[r['request_id'] for r in rows if r['request_id'] not in {c['request_id'] for c in checks}],
       'all_statuses':dict(collections.Counter(r['status'] for r in rows)),
       'all_sources':dict(collections.Counter(str(r['answer_source']) for r in rows)),
       'all_input_to_submit_ms':stats(delta(r,'playback_submit_ns','input_submitted_ns') for r in rows),
       'missing_input_to_submit':sum(r['timestamps']['playback_submit_ns'] is None for r in rows),
       'model_prefill_ms':stats(m['prefill_ms'] for m in models),'model_ttft_ms':stats(m['ttft_ms'] for m in models),
       'model_decode_ms':stats(m['decode_ms'] for m in models),'startup':startup_metrics,'stage_latency':stage_latency,
       'cache_groups':cache_groups,'latency_by_answer_source':source_latency,'asr_by_reference':voices,'quality_failure_buckets':dict(failure_buckets),'memory':memory,
       'independent_quality_categories':{'ASR':'SYNTHETIC_NORMALIZED_TRANSCRIPT_MEASURED','intent':'DEVELOPMENT_ROUTING_ONLY_NOT_INDEPENDENT_HUMAN_LABELS',
           'retrieval':'CASE_HASH_AND_REQUIRED_FACTS_CONSISTENCY','omission':'CHECKER_REJECTIONS_RECORDED',
           'extra_facts':'CHECKER_REJECTIONS_RECORDED','role':'POLICY_INJECTION_TESTED_NO_MEDICAL_SIGNOFF',
           'checker_false_negative':'NOT_TESTED_INDEPENDENT_MEDICAL_REVIEW','checker_false_positive':'OBSERVED_我气短。_COUNTEREXAMPLE_RETAINED'},
       'no_hardware_rounds':len(read_lines(run/'no-hardware/rounds.jsonl')),
       'hardware_required':json.loads((run/'fpga-required.json').read_text()) if (run/'fpga-required.json').exists() else None,
       'claims_excluded':['Independent heldout quality','Medical review','Physical speech end/onset','A53/FPGA speed','Board memory/energy/thermal','HLS or implementation acceptance'],
       'domains':{'PC':'COMPLETE_RAW_RUN' if complete else 'EXTRA_SOAK_STOPPED_BY_USER_CORE200_COMPLETE' if stopped else 'IN_PROGRESS','Csim':'NOT_TESTED','Cosim':'NOT_TESTED','synthesis':'NOT_TESTED','implementation':'NOT_TESTED','A08_cross_build':'NOT_TESTED','BOARD':'NOT_TESTED'}}
    (out/'metrics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'memory.json').write_text(json.dumps(memory,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(out),'attempts':len(rows),'complete':complete is not None,'cohorts':{k:v['attempts'] for k,v in cohorts.items()}}))
if __name__=='__main__':main()
