"""Recheck retained real candidates, without changing original source/metrics."""
import argparse,hashlib,json
from pathlib import Path
from system_qwen35.app.domain import Fact
from system_qwen35.app.planning import AnswerPlan
from system_qwen35.app.checking import check

def main():
    ap=argparse.ArgumentParser();ap.add_argument('run');ap.add_argument('output');a=ap.parse_args()
    run=Path(a.run);out=Path(a.output);out.mkdir(parents=True,exist_ok=False);rows=[]
    for line in (run/'default/rounds.jsonl').read_text(encoding='utf-8').splitlines():
        raw=json.loads(line);app=raw.get('application',{});candidate=app.get('candidate')
        if candidate is None or not app.get('answer_plan'):continue
        pd=dict(app['answer_plan']);pd['facts']=tuple(Fact(**f) for f in pd['facts']);p=AnswerPlan(**pd)
        before=app.get('candidate_check');after=check(p,candidate)
        changed=before!=after
        allowed=(not changed) or (before['status']!='pass' and after['status']=='pass' and candidate.replace(' ','')=='我气短。' and len(p.facts)==1 and p.facts[0].slot=='dyspnea' and p.facts[0].status=='known' and p.facts[0].value is True)
        rows.append({'request_id':raw['request_id'],'case_id':app['case_id'],'candidate':candidate,'before':before,'after':after,'changed':changed,'expected_difference':allowed})
    result={'domain':'PC_POSTHOC_CHECKER_ONLY','source':str(run/'default/rounds.jsonl'),
       'source_sha256':hashlib.sha256((run/'default/rounds.jsonl').read_bytes()).hexdigest(),
       'checker_sha256':hashlib.sha256(Path('system_qwen35/app/checking.py').read_bytes()).hexdigest(),
       'candidates':len(rows),'changed':sum(r['changed'] for r in rows),'unexpected_differences':[r for r in rows if not r['expected_difference']],
       'rows':rows,'original_run_answer_sources_and_timings_unchanged':True,'medical_review':'PENDING_TEACHER_REVIEW'}
    (out/'replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','unexpected_differences')},ensure_ascii=False))
    return 2 if result['unexpected_differences'] else 0
if __name__=='__main__':raise SystemExit(main())
