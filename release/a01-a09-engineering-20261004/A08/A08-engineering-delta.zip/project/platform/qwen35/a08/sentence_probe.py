"""Real TTS/playback schedule comparison, no speculative unvalidated sentence."""
import hashlib,json,signal,sys,threading,time,uuid
from pathlib import Path
from system_qwen35.app.default_e2e.service import Service
from system_qwen35.app.checking import check,fallback
from system_qwen35.app.planning import plan
from system_qwen35.app.domain import Transcript,load_case
from system_qwen35.app.default_e2e.policy import new_trace

out=Path(sys.argv[1]);s=Service(out,llm_threads=3,tts_threads=2,prompt_style='facts_v4');rows=[]
try:
    for case in ('SYN_CP_01','SYN_CP_02','SYN_CP_03'):
        s.switch_case(case);q='每次疼痛持续多久，有没有气短？';full=s.turn(text=q);rows.append({'kind':'WHOLE_WAV','trace':full})
        app=full.get('application',{});p=plan(load_case(case),Transcript.parse({'request_id':'probe','source':'typed','text':q,'final':True}),[])
        if full['status']!='COMPLETED' or app.get('answer_source')!='MODEL' or check(p,app['text'])['status']!='pass':raise RuntimeError('Model complete-answer precondition')
        benchmark_text=fallback(p)
        if check(p,benchmark_text)['status']!='pass':raise RuntimeError('Unsafe scheduling benchmark text')
        sentences=[x+'。' for x in benchmark_text.split('。') if x]
        if len(sentences)!=2:raise RuntimeError('Expected two full checked sentences')
        trace=new_trace(s.session.snapshot()['session_id'],s.epoch,uuid.uuid4().hex,'tts_schedule_experiment',False)
        trace['full_text_sha256']=hashlib.sha256(benchmark_text.encode()).hexdigest();parts=[];last_complete=None
        whole_begin=time.monotonic_ns();whole_tts=s.call_voice('synthesize',text=benchmark_text,output_dir=s.sid+'/out')
        whole_play=s.play(s.spool/whole_tts['wav_path'],uuid.uuid4().hex,s.epoch,trace)
        rows.append({'kind':'WHOLE_TEMPLATE_BENCHMARK','case_id':case,'text':benchmark_text,'answer_source':'TEMPLATE_BENCHMARK_NOT_MODEL_OUTPUT',
                     'begin_ns':whole_begin,'tts':whole_tts,'playback':whole_play})
        for sentence in sentences:
            begin=time.monotonic_ns();tts=s.call_voice('synthesize',text=sentence,output_dir=s.sid+'/out')
            receipt=s.play(s.spool/tts['wav_path'],uuid.uuid4().hex,s.epoch,trace)
            parts.append({'text':sentence,'synthesis_begin_ns':begin,'tts':tts,'playback':receipt,
                          'software_gap_ms':None if last_complete is None else (receipt['playback_submit_ns']-last_complete)/1e6,
                          'acoustic_gap_ms':None})
            last_complete=receipt['playback_api_complete_ns']
        row={'kind':'SEQUENTIAL_SENTENCE_WAV','case_id':case,'full_answer_checked_before_any_tts':True,'parts':parts,
             'same_full_text':''.join(sentences)==benchmark_text,'answer_source':'TEMPLATE_BENCHMARK_NOT_MODEL_OUTPUT',
             'adopted':False,'reason':'Whole WAV remains default; no concurrent/speculative playback or measured acoustic benefit'}
        rows.append(row);s.voice.call('reset',session_id=s.sid)
    with (out/'sentence-comparison.json').open('x') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
finally:s.close()
