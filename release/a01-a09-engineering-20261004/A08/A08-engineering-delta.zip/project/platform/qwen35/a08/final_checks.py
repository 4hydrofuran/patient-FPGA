"""Logged commands, including expected fail-closed CLI exit. No board calls."""
import json,subprocess,sys
from pathlib import Path

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);rows=[]
commands=[([sys.executable,'scripts/release/check_contracts.py'],0),
          ([sys.executable,'scripts/release/qwen35_config.py'],0),
          ([sys.executable,'-m','unittest','system_qwen35.app.default_e2e.test_policy','system_qwen35.app.test_a02','system_qwen35.app.test_capture','modules.voice_A.test_voice','-v'],0),
          ([sys.executable,'-m','system_qwen35.app.default_e2e','--output',str(out/'must-not-be-created'),'--mode','fpga_required'],2)]
for argv,expected in commands:
    r=subprocess.run(argv,capture_output=True,text=True);rows.append({'argv':argv,'exit_code':r.returncode,'expected_exit_code':expected,'stdout':r.stdout,'stderr':r.stderr})
with (out/'commands.json').open('x') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
passed=all(r['exit_code']==r['expected_exit_code'] for r in rows) and not (out/'must-not-be-created').exists()
print(json.dumps({'passed':passed,'commands':len(rows),'domain':'PC','board':'NOT_TESTED'}))
raise SystemExit(0 if passed else 2)
