"""Separate rejected prompt experiments from the final equal-facts comparison."""
import hashlib,json,statistics,sys
from pathlib import Path

def mean(items,key):
    values=[r[key] for r in items if r.get(key) is not None]
    return {'n':len(values),'mean':statistics.mean(values) if values else None}

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
source=Path('eval/qwen35/a08/prompt-v4-multi/results.jsonl')
rows=[json.loads(x) for x in source.read_text(encoding='utf-8').splitlines()]
result={'domain':'PC_DEVELOPMENT_ONLY','comparison':'same 4 multi-fact questions, same typed facts, same real S1 native',
        'raw_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'styles':{},'single_fact_prompts':'byte-identical: existing dev evidence reused; no new speed claim',
        'rejected_experiments':['experiments-v1','dev-compare-v1','dev-compare-v2'],'BOARD':'NOT_TESTED'}
for style in ('old','facts_v4'):
    selected=[r['response'] for r in rows if r['style']==style];models=[r['model_result'] for r in selected]
    result['styles'][style]={'n':len(selected),'MODEL':sum(r['answer_source']=='MODEL' for r in selected),'TEMPLATE':sum(r['answer_source']=='TEMPLATE' for r in selected),
        'prompt_tokens':mean(models,'prompt_tokens'),'prefill_ms':mean(models,'prefill_ms'),'native_ttft_ms':mean(models,'ttft_ms'),
        'native_round_wall_ms':mean(models,'round_wall_ms'),'output_tokens':{'n':len(models),'mean':statistics.mean(len(m['output_tokens']) for m in models)},
        'note':'Includes rejected candidates and template fallbacks, not only model successes. LLM wait only; no acoustic timing.'}
(out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
