"""A08 observed real candidate: full affirmative clause, not keyword matching.

Run before and after the narrowly scoped language-rule repair. No LLM mock.
"""
import json,sys
from pathlib import Path
from system_qwen35.app.domain import load_case,Transcript
from system_qwen35.app.planning import plan
from system_qwen35.app.checking import check

out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False);rows=[]
for case,question,text,expected in [
 ('SYN_CP_01','有没有气短','我气短。','pass'),
 ('SYN_CP_02','有没有气短','我气短。','not_pass'),
 ('SYN_CP_03','有没有气短','我气短。','not_pass'),
 ('SYN_CP_01','有没有气短','我没有气短。','not_pass'),
 ('SYN_CP_01','有没有气短','我气短，而且我有药物过敏。','not_pass'),
 ('SYN_CP_01','每次疼痛持续多久，有没有气短','我气短。','not_pass')]:
    p=plan(load_case(case),Transcript.parse({'request_id':'counterexample','text':question,'source':'typed','final':True}),[])
    r=check(p,text);passed=(r['status']=='pass') if expected=='pass' else (r['status']!='pass')
    rows.append({'case':case,'question':question,'candidate':text,'expected':expected,'actual':r,'pass':passed})
(out/'results.json').write_text(json.dumps({'domain':'PC_LANGUAGE_RULE','source':'regression-v2 actual model candidate 我气短。; counterfactuals explicitly authored, not model outputs',
    'medical_review':'PENDING_TEACHER_REVIEW','checks':rows},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':sum(r['pass'] for r in rows),'total':len(rows)}));raise SystemExit(0 if all(r['pass'] for r in rows) else 2)
