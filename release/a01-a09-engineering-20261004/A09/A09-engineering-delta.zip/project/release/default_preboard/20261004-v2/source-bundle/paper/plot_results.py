"""Render actual supplied data only. Missing measurements never become zero."""
import argparse,csv,math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path(__file__).with_name('results.csv'));p.add_argument('--output',type=Path,required=True);a=p.parse_args()
rows=list(csv.DictReader(a.input.open()));a.output.mkdir(parents=True,exist_ok=False)
for domain in ('PC','BOARD'):
    selected=[r for r in rows if r['domain']==domain];fig,ax=plt.subplots(figsize=(3.5,2.6))
    for i,r in enumerate(selected):
        if not r['value']:
            ax.text(i,.08,'NA',ha='center',transform=ax.get_xaxis_transform());continue
        if r['status']!='MEASURED' or not r['evidence']:raise ValueError('Value requires measured status and evidence')
        v=float(r['value'])
        if not math.isfinite(v) or v<0:raise ValueError('Metric value')
        ax.bar(i,v,color='#0072B2')
    ax.set_xticks(range(len(selected)),[r['variant'] for r in selected]);ax.set_ylabel('Decode (token/s)');ax.set_title(domain+' — unmeasured fields are NA',fontsize=9)
    ax.set_ylim(bottom=0);ax.spines[['top','right']].set_visible(False);fig.tight_layout()
    fig.savefig(a.output/(domain+'.pdf'));fig.savefig(a.output/(domain+'.png'),dpi=300);plt.close(fig)
