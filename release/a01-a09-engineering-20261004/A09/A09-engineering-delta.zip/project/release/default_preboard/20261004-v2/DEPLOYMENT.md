# 部署演练和安全恢复 v2

电脑示例沿用原`deploy.py validate/health/start/stop/rollback/logs`。配置为`config/qwen35/deploy.pc.json`，输出目录/state必须全新。health的`CONFIG_VALID_NOT_APPLICATION_READY`不是推理就绪；看真实startup/逐轮trace。start记录PID+boot_id+start_ticks，stop只作用于匹配进程；回滚仅停止后按已知配置hash生成选择receipt，不改固件/权重。日志可能含授权转录，只私下审阅，不自动上传。

```sh
python platform/qwen35/a09/deploy.py validate --config config/qwen35/deploy.pc.json
python platform/qwen35/a09/deploy.py start --config config/qwen35/deploy.pc.json --state /private/NEW.state.json --output /private/NEW.run --text '疼痛在什么位置？'
python platform/qwen35/a09/deploy.py stop --state /private/NEW.state.json
python platform/qwen35/a09/deploy.py rollback --config config/qwen35/deploy.pc.json --state /private/NEW.state.json --expected-config-sha256 <实际hash> --output /private/NEW.rollback.json
python platform/qwen35/a09/deploy.py logs --state /private/NEW.state.json --output /private/NEW.logs.tar.gz
```

BOARD配置在启动自检阶段拒绝；fpga_required不得CPU成功。设备路径默认空，flash_allowed=false。无SD/QSPI写入函数。旧v1部署说明里“A06未收到XO/A07未链接”仅为历史；实际A07新核离线链接已有独立证据，但**实际启动组合仍待板验证**。

## 到板只读先行

kv260_base 2026.1/XPFM/XSA与BOOT、WIC、DT、内核、zocl、XRT必须是可核验组合；Common rootfs/SDK不能视作可直接启动KV260，也不能混Versal EDF路径。参考原`platform/build/ra02-platform-20261001-v1/platform_manifest.candidate.json`与A07实际封存。版本对应或启动介质缺失时列阻断，继续PC工作；不拼DT、不切PYNQ。

用户先物理确认并获专项授权，登记身份/SSH指纹后：

```sh
python platform/qwen35/a09/deploy.py collect-board --registry <已核实登记> --output <全新证据目录>
```

内部必须经中央板卡租约与部署锁。到板读DT memory/reserved-memory/CMA、MemTotal、XRT拓扑、内核/固件/设备身份；PS DDR表项2GB不等于物理容量，也不等于Linux或PL可分配预算。实际值仍null。

## 测量入口（本阶段不执行）

- BO同步：`platform/qwen35/a09/board_probe.py --profile config/qwen35/bo_probe.pending.json`默认退出2。核实真实board_profile、拓扑、恢复方法和小额安全预算后才可生成启用profile；所有输入hash检查通过，再用`--execute --registry ... --output ...`进入中央租约。候选工具只允许4KiB到16MiB、1到100次，不能探尽内存。
- BO探针记录分配和双向同步耗时及逻辑payload。SoC一致性缓存行为可能影响sync；**不称AXI实测带宽、不证明PL访问或计算正确**。`measured_axi_bytes=null`。核执行/PL回环由A10/A11独立验证。同步异常无法证明停止时保留进程/BO，不自动超时杀死或重载。
- 逐层：沿用A05原生层捕获/logits诊断入口；性能模式关闭全logits。S2必须同时有实际FPGA执行证据，不能把CPU trace改名。
- 声学：`measurements.py acoustic`校验授权回采文件hash和同采样时钟人工标注；播放器提交不等于首音。
- 功率：`measurements.py power`接收校准仪表原始CSV，同一DC边界含风扇/音频。没有仪表/校准时不计算板端结论；准备入口不自动连接未知仪表。
- 故障恢复：应用停止、保存日志、隔离POISONED上下文。真实硬件静止未验证不得释放BO或CPU回退；软复位/重加载/换SD/电源循环须按已验证恢复计划获授权。当前全部BOARD NOT_TESTED。

物理连接清单在PREBOARD_CHECKLIST；依赖安装限制在DEPENDENCIES。PC演练成功不开放板端profile，不代表已可部署。
