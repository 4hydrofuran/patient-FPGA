# 依赖、许可和目标准备

## 版本及禁止混用

电脑：Ubuntu22.04/WSL、CPython3.10、x86_64；已有隔离venv的9固定wheel安装、pip check和真实推理证据。板端候选：2026.1 SDK实际头文件为CPython3.12.12、AArch64，**到板必须再次读取实际Python ABI**，不能照搬开发机路径/库。

语音候选9包与PC保持版本：Jinja2 3.0.3、MarkupSafe 2.0.1、cffi 2.1.1、numpy 1.26.4、pycparser 3.0、scipy 1.15.3、sherpa-onnx/core 1.12.40、soundfile 0.13.1。下载来自PyPI对应固定版本，SHA256逐项校验。MarkupSafe无匹配cp312 wheel，未升级：由原始源码与SDK头文件实际构建cp312-linux_aarch64 wheel。未更改模型数学/语音模型。

146个ELF均经readelf确认AArch64，直接NEEDED库名全部能在wheel或SDK中找到。**这是静态依赖检查，不是动态符号版本/ISA/目标导入成功**。实际rootfs须具备libc、libstdc++、libgomp、libcrypto、libffi、libsndfile及Pulse client/server音频栈等；SDK存在不证明rootfs安装。到板以动态加载器检查、pip check、import及hello/真实WAV验证闭环，不自动安装另一发行版deb。

到板环境核验完成后，仅在新venv执行（此处未执行）：

```sh
python3.12 -m venv /opt/patient-qwen-venv-NEW
/opt/patient-qwen-venv-NEW/bin/python -m pip install --no-index --no-deps /approved/arm312-wheels/*.whl
/opt/patient-qwen-venv-NEW/bin/python -m pip check
/opt/patient-qwen-venv-NEW/bin/python -c 'import sherpa_onnx, numpy, scipy, soundfile, jinja2, markupsafe; print("imports complete")'
```

不能在不兼容系统上直接执行以上示意命令。推荐使用`platform/qwen35/a09/install_target.py --wheels <arm312-wheels> --receipt <新文件>`先验9包hash；显式`--install --target <全新venv>`只允许中央租约下的Linux/AArch64/Python3.12并先检查系统库。本轮只执行PC输入检查和错误架构拒绝，未创建目标venv。没有venv/pip或系统库时，使用已确认同发行版/同版本包源或BSP配方补齐，再离线封存；不全局替换旧环境。硬件启动链未验证前，目标部署入口仍拒绝。

## 许可清单

Qwen3.5-0.8B原LICENSE Apache-2.0，llama.cpp MIT，sherpa-onnx Apache-2.0。语音权重的具体归档/来源/许可已锁于`modules/voice_A/resources.lock.json`；代码许可不替代权重/语料许可。Matcha/Baker非商业约束保持，Vocos权重与代码许可分开。依赖各wheel的LICENSE/NOTICE及METADATA原文保留，不能把顶层许可证替代所有第三方通知。当前不自动公开权重或声称已获比赛/商业再分发许可。

实际wheel/源码哈希、目标ELF和系统路径：`target-dependencies.json`、`markupsafe-build.json`、`arm-inputs.json`。未做ARM导入、声学或医疗审核；空值不填0。
