# 默认版无板交付候选 v2（2026-10-04）

本目录保留在原`release/default_preboard`下，**不覆盖旧封存包**。源码包含A08最新资源缺失null/逐轮身份修复，以及A09受保护BO同步测量准备。不是板端已验收产品。

- `source-bundle/project/`：默认A源码、公共契约、锁文件、导出器和重建入口；无模型/语音权重、真实录音、Xilinx许可证、凭据或系统/WSL镜像。
- `source-bundle/wheels/`：已验证的PC Python3.10/x86_64依赖。只能用于该架构。
- `source-bundle/arm312-wheels/`：固定版本ARM64/CPython3.12输入，含SDK构建的MarkupSafe扩展。静态准备不是实板安装/导入验证，**不能与PC wheel混装**。
- `source-bundle/board-tools/`：ARM64 BO同步探针候选，默认profile禁用；只在到板身份、拓扑、预算、恢复和中央租约通过后启用。
- 模型/语音资产在受控本地私有目录另备，不自动分发Matcha/Baker非商业资源。许可证审核清单在DEPENDENCIES.md。

完整证据：`eval/qwen35/a09/refresh-20261004-v1/`；以前干净C++构建/145文件重导出证据按hash复用，新Python增量在隔离目录重新测试。A07目标链接/布局布线和交叉库已通过，无需重链；BOARD全部NOT_TESTED。

本包不是空白OS安装器。先按DEPLOYMENT.md核查实际OS/Python/库版本，再运行离线安装与健康检查。禁止把Common Image/SDK可用等同于KV260启动链已匹配。包清单和归档SHA见package.json，旧包原样保留。
