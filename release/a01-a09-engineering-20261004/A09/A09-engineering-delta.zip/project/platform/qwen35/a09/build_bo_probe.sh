#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Patientqwen
output="${1:?new absolute output folder}"
[[ "$output" = /* && ! -e "$output" ]] || exit 2
mkdir -p "$output"
cp "$repo/platform/qwen35/a09/bo_sync_probe.cpp" "$output/bo_sync_probe.cpp"
set +u
source /home/member-a/kv260-sdk-2026.1-common/environment-setup-cortexa72-cortexa53-amd-linux
set -u
read -r -a compiler <<< "$CXX"
set -x
"${compiler[@]}" -mcpu=cortex-a53 -std=c++17 -O2 -Wall -Wextra -Werror "$output/bo_sync_probe.cpp" -lxrt_coreutil -o "$output/bo-sync-probe"
"$READELF" -h -d "$output/bo-sync-probe"
sha256sum "$output/bo-sync-probe" "$output/bo_sync_probe.cpp"
