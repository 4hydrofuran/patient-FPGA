"""Read-only independent manifest/archive audit; does not unpack or execute."""
import argparse,hashlib,json,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[3]
parser=argparse.ArgumentParser();parser.add_argument('--release',type=Path,default=ROOT/'release/default_preboard');parser.add_argument('--receipt',type=Path,default=ROOT/'eval/qwen35/a09/package-verification.json');args=parser.parse_args()
release=args.release.resolve();bundle=release/'source-bundle'
def sha(stream):
    h=hashlib.sha256()
    for b in iter(lambda:stream.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
manifest=json.loads((bundle/'SHA256.json').read_text());receipt=json.loads((release/'package.json').read_text())
actual={p.relative_to(bundle).as_posix() for p in bundle.rglob('*') if p.is_file()}
assert actual==set(manifest)|{'SHA256.json'},'Directory inventory mismatch'
for name,value in manifest.items():
    p=bundle/name
    assert not p.is_symlink() and p.stat().st_size==value['bytes'],name
    with p.open('rb') as f:assert sha(f)==value['sha256'],name
archive=release/'source-bundle.tar.gz'
with archive.open('rb') as f:assert sha(f)==receipt['sha256'],'Archive hash mismatch'
seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for member in tar:
        path=PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and path.parts[0]=='source-bundle','Unsafe archive path'
        assert member.isdir() or member.isfile(),'Special archive entry'
        if member.isdir():continue
        name=path.relative_to('source-bundle').as_posix()
        assert name not in seen,'Duplicate archive entry';seen.add(name)
        expected=manifest.get(name)
        if name=='SHA256.json':
            with (bundle/name).open('rb') as f:expected={'sha256':sha(f),'bytes':(bundle/name).stat().st_size}
        assert expected is not None and member.size==expected['bytes'],name
        with tar.extractfile(member) as f:assert sha(f)==expected['sha256'],name
assert seen==actual,'Archive inventory mismatch'
result={'status':'PASS_SOURCE_PACKAGE_INTEGRITY','files':len(manifest),'archive_bytes':archive.stat().st_size,
 'archive_sha256':receipt['sha256'],'unpacked_or_executed':False,'BOARD':'NOT_TESTED','weights_included':False}
with args.receipt.open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
