"""Versioned A09 refresh; preserve the original sealed release and private assets."""
import hashlib,json,os,shutil,subprocess,sys,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a09/refresh-20261004-v1'
REL=ROOT/'release/default_preboard/20261004-v2'
OLD=ROOT/'release/default_preboard/source-bundle'
CLEAN=Path('/home/member-a/qwen35-a09/refresh-20261004-v2/project')
PRIOR=Path('/home/member-a/qwen35-a09/clean-v1/project')
PY='/home/member-a/qwen35-a09/venv-v1/bin/python'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_dir():shutil.copytree(src,dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
    else:shutil.copy2(src,dst)
def prepare():
    original=load(OLD/'SHA256.json');bad=[n for n,v in original.items() if sha(OLD/n)!=v['sha256']]
    archive=ROOT/'release/default_preboard/source-bundle.tar.gz';assert not bad and sha(archive)==load(archive.with_name('package.json'))['sha256']
    REL.mkdir(exist_ok=False);bundle=REL/'source-bundle'
    shutil.copytree(OLD,bundle,ignore=shutil.ignore_patterns('SHA256.json','__pycache__','*.pyc'))
    project=bundle/'project';overlays=[]
    for name in ['system_qwen35','config/qwen35','platform/qwen35/a09','platform/qwen35/a08/report.py',
       'platform/qwen35/a08/run.sh','platform/qwen35/a08/launch.cmd','platform/qwen35/a08/smoke.py',
       'modules/voice_A','models/sidecar_A/qwen35-v1/manifest.json']:
        copy(ROOT/name,project/name);overlays.append(name)
    # Paper/method/checklist additions are authored separately, never copied from B/C.
    shutil.copytree(project,CLEAN)
    linked=[]
    for name in ['artifacts','models/sidecar_A/qwen35-v1','runtime-bin']:
        src=PRIOR/name;dst=CLEAN/name
        # Copy only absent private resources as hardlinks; never modify their bytes.
        for p in src.rglob('*'):
            if p.is_file():
                q=dst/p.relative_to(src)
                if q.exists():continue
                q.parent.mkdir(parents=True,exist_ok=True);os.link(p,q);linked.append(str(q.relative_to(CLEAN)))
    copy(PRIOR/'modules/linear_A/manifest.a09.json',CLEAN/'modules/linear_A/manifest.a09.json')
    fixture=load(ROOT/'eval/qwen35/a03/audio-eval-v1/fixtures.json')[0]
    copy(ROOT/fixture['wav'],CLEAN/fixture['wav'])
    save(OUT/'fixture.json',[dict(fixture,wav=str(CLEAN/fixture['wav']))])
    source=load(ROOT/'modules/linear_A/manifest.a08.json')['source_sha256']
    unchanged={n:sha(ROOT/n)==h and sha(PRIOR/n)==h for n,h in source.items()}
    save(OUT/'prepare.json',{'old_package_files_verified':len(original),'old_archive_sha256':sha(archive),
        'overlays':overlays,'clean_project':str(CLEAN),'private_asset_hardlinks':linked,'asset_policy':'LOCAL_PRIVATE_REUSE_NOT_PACKAGE_CONTENT',
        'cpp_source_continuity':unchanged,'native_build':'REUSED_PREVIOUS_CLEAN_BUILD_EXPLICITLY_NOT_REBUILT','BOARD':'NOT_TESTED'})
    assert all(unchanged.values())
    print(json.dumps({'prepared':str(REL),'clean_project':str(CLEAN)}))
def tests():
    env=dict(os.environ,PYTHONPATH=str(CLEAN),SP_VOICE_PYTHON=PY)
    audio='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu';env['LD_LIBRARY_PATH']=audio+':'+audio+'/pulseaudio'
    rows=[]
    def run(args,expected=0):
        argv=['unshare','-Urn',PY,*args];t=time.monotonic();r=subprocess.run(argv,cwd=CLEAN,env=env,capture_output=True,text=True)
        rows.append({'argv':argv,'cwd':str(CLEAN),'exit_code':r.returncode,'expected':expected,'elapsed_s':time.monotonic()-t,'stdout':r.stdout,'stderr':r.stderr})
        (OUT/'clean-commands.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({'command':args,'exit':r.returncode}),flush=True)
        if r.returncode!=expected:raise RuntimeError('Clean test failed; retained')
    run(['scripts/release/check_contracts.py']);run(['scripts/release/qwen35_config.py'])
    run(['-m','unittest','system_qwen35.app.test_a02','system_qwen35.app.test_capture','system_qwen35.app.default_e2e.test_policy','system_qwen35.app.default_e2e.test_review','system_qwen35.app.default_e2e.test_accounting','modules.voice_A.test_voice'])
    run(['platform/qwen35/a09/test_deploy.py'])
    run(['platform/qwen35/a09/test_preboard.py'])
    run(['platform/qwen35/a09/deploy.py','health','--config','config/qwen35/deploy.pc.json'])
    run(['platform/qwen35/a09/board_probe.py','--profile','config/qwen35/bo_probe.pending.json'],2)
    run(['-m','system_qwen35.app.default_e2e','--output',str(OUT/'must-not-exist'),'--mode','fpga_required'],2)
    budget=ROOT/'docs/plan_qwen35/KV260_Qwen35_A_详细设计增强任务包_20261002/KV260_Qwen35_A_设计增强包_20261002/tools/design_budget.py'
    for t in ('1','8'):run([str(budget),'--config','artifacts/qwen35-0.8b/source/config.json','--t',t])
    run(['platform/qwen35/a09/refresh_smoke.py',str(OUT/'clean-smoke'),str(OUT/'fixture.json')])
    run(['platform/qwen35/a09/lifecycle_rehearsal.py',str(OUT/'lifecycle')])
    save(OUT/'clean-summary.json',{'status':'PASS_CLEAN_UPDATED_PYTHON_AND_REAL_WAV','BOARD':'NOT_TESTED','native_build':'REUSED_HASH_VERIFIED_PRIOR_CLEAN_BUILD','new_recording':False})
def sync():
    project=REL/'source-bundle/project'
    for base in (project,CLEAN):
        for name in ('platform/qwen35/a09','config/qwen35','system_qwen35'):
            copy(ROOT/name,base/name)
    for name in ('README.md','DEPENDENCIES.md','PREBOARD_CHECKLIST.md','DEPLOYMENT.md'):
        copy(REL/name,REL/'source-bundle'/name)
    tools=REL/'source-bundle/board-tools';tools.mkdir(exist_ok=True)
    copy(Path('/home/member-a/qwen35-a09/bo-probe-20261004-v1/bo-sync-probe'),tools/'bo-sync-probe')
    copy(ROOT/'platform/qwen35/a09/bo_sync_probe.cpp',tools/'bo_sync_probe.cpp')
    # Package the source and actual cross-build recipe used for the SDK wheel.
    copy(Path('/home/member-a/qwen35-a09/arm312-inputs-20261004-v1/MarkupSafe-2.0.1.tar.gz'),tools/'MarkupSafe-2.0.1.tar.gz')
    copy(OUT/'arm-inputs.json',REL/'source-bundle/ARM_INPUT_AUDIT.json')
    copy(OUT/'markupsafe-build.json',REL/'source-bundle/MARKUPSAFE_CROSS_BUILD.json')
    print(json.dumps({'updated_package_and_clean_python':True,'BOARD':'NOT_TESTED'}))
def retry_lifecycle():
    env=dict(os.environ,PYTHONPATH=str(CLEAN),SP_VOICE_PYTHON=PY)
    audio='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu';env['LD_LIBRARY_PATH']=audio+':'+audio+'/pulseaudio'
    rows=[]
    for args in (['-m','unittest','system_qwen35.app.test_a02','system_qwen35.app.test_capture','system_qwen35.app.default_e2e.test_policy','system_qwen35.app.default_e2e.test_review','system_qwen35.app.default_e2e.test_accounting','modules.voice_A.test_voice'],
                 ['platform/qwen35/a09/lifecycle_rehearsal.py',str(OUT/'lifecycle-v2')]):
        argv=['unshare','-Urn',PY,*args];r=subprocess.run(argv,cwd=CLEAN,env=env,capture_output=True,text=True)
        rows.append({'argv':argv,'cwd':str(CLEAN),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
        (OUT/'lifecycle-v2-commands.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
        if r.returncode:raise RuntimeError('Repair check failed; outputs retained')
    print(json.dumps({'status':'PASS_TARGETED_LIFECYCLE_AND_83_REGRESSION_TESTS','BOARD':'NOT_TESTED'}))
def seal():
    bundle=REL/'source-bundle';deny={'.lic','.pem','.key','.vhd','.vhdx','.wic','.img','.qcow2','.gguf','.safetensors','.onnx','.wav','.pcm'};files={}
    for p in sorted(bundle.rglob('*')):
        if p.is_symlink():raise ValueError('Package symlink '+str(p))
        if not p.is_file():continue
        if p.suffix.lower() in deny or p.name in ('.env','credentials','id_rsa','id_ed25519'):raise ValueError('Forbidden content '+str(p))
        raw=p.read_bytes() if p.stat().st_size<4*1024*1024 else b''
        if any(x in raw for x in (b'-----BEGIN PRIVATE KEY-----\n',b'-----BEGIN OPENSSH PRIVATE KEY-----\n')):raise ValueError('Private key marker')
        files[p.relative_to(bundle).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
    save(bundle/'SHA256.json',files)
    archive=REL/'source-bundle.tar.gz'
    with tarfile.open(archive,'x:gz') as tar:tar.add(bundle,arcname='source-bundle')
    save(REL/'package.json',{'status':'SOURCE_DEPENDENCY_CANDIDATE_NOT_BOARD_PRODUCT','sha256':sha(archive),'bytes':archive.stat().st_size,
        'files':len(files),'BOARD':'NOT_TESTED','weights_included':False,'publishing':'NOT_PUBLISHED',
        'base_package_sha256':load(OUT/'prepare.json')['old_archive_sha256'],'ARM_voice_closure':'SEE_TARGET_DEPENDENCIES_NOT_PC_WHEELS'})
    print(json.dumps({'files':len(files),'archive_sha256':sha(archive)}))
if __name__=='__main__':{'prepare':prepare,'tests':tests,'seal':seal,'sync':sync,'retry-lifecycle':retry_lifecycle}[sys.argv[1]]()
