"""Local-only clean CPU build/export rehearsal; never accesses board or network.

Only the explicit A source/asset allowlist is copied. Existing directories fail.
The patched llama tree is audited against the pinned upstream, not called a git
checkout. No previous library or binary is reused.
"""
import difflib,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
WORK=Path(sys.argv[1]).resolve()
WORK.mkdir(parents=True,exist_ok=False)
TREE=WORK/'project';TREE.mkdir()
EVIDENCE=ROOT/'eval/qwen35/a09';COMMANDS=[]
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2))
def copy(name):
    src=ROOT/name;dst=TREE/name;dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_dir():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
    else:shutil.copy2(src,dst)
def run(argv,*,env=None):
    i=len(COMMANDS);start=time.monotonic()
    with (WORK/f'command-{i:02d}.stdout').open('x') as out,(WORK/f'command-{i:02d}.stderr').open('x') as err:
        r=subprocess.run(argv,cwd=TREE,env=env,stdout=out,stderr=err)
    item=dict(argv=argv,cwd=str(TREE),exit_code=r.returncode,elapsed_s=time.monotonic()-start,
              stdout=str(out.name),stderr=str(err.name));COMMANDS.append(item);save(WORK/'commands.json',COMMANDS)
    print(json.dumps(item),flush=True)
    if r.returncode:raise RuntimeError('Command failed; logs retained: '+str(argv))

for name in ['system_qwen35','modules/voice_A','modules/linear_A','config/qwen35','contracts','runtime/qwen35_w4a8',
             'quant/export_w4a8','quant/reference','quant/qwen35_tensor_map.json','models/model.lock.json',
             'scripts/release/check_contracts.py','scripts/release/qwen35_config.py','platform/qwen35/a09',
             'platform/qwen35/a08/checker_counterexample.py','platform/qwen35/a08/checker_replay.py']:
    copy(name)
for name in ['eval/qwen35/a02/dataset.lock.json','eval/qwen35/a02/dev/questions-v2.json',
             *json.loads((ROOT/'eval/qwen35/a02/dataset.lock.json').read_text()).keys()]:copy(name)
lock=json.loads((ROOT/'models/model.lock.json').read_text())
for name,entry in lock['source_files'].items():
    if sha(ROOT/name)!=entry['sha256']:raise ValueError('Source mismatch '+name)
    copy(name)
copy('artifacts/qwen35-0.8b/qwen35-text-Q4_K_M.gguf')
voice=json.loads((ROOT/'modules/voice_A/resources.lock.json').read_text())
voice_copied={}
for name,expected in voice['files'].items():
    # Only runtime files; not download chunks, archives or real recordings.
    if '.chunks/' in name or '.incomplete-' in name or '.tar.bz2' in name or '/test_wavs/' in name:continue
    if sha(ROOT/name)!=expected:raise ValueError('Voice mismatch '+name)
    copy(name);voice_copied[name]=expected
save(WORK/'private-asset-inventory.json',{'scope':'LOCAL_REHEARSAL_ONLY_NOT_REDISTRIBUTION','voice':voice_copied,'model':lock['source_files']})

upstream=Path('/home/member-a/qwen35-a01/llama.cpp-'+lock['runtime_commit'])
patched=Path('/home/member-a/qwen35-a05/source-v3')
src=WORK/'llama-source'
shutil.copytree(patched,src,ignore=shutil.ignore_patterns('.git','__pycache__','*.pyc'))
base_hashes={};changed={};patch=[]
for p in sorted(src.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(src).as_posix();base=upstream/rel
    if base.is_file():
        base_hashes[rel]=sha(base)
        if sha(p)==base_hashes[rel]:continue
    changed[rel]={'base_sha256':base_hashes.get(rel),'patched_sha256':sha(p)}
    try:patch.extend(difflib.unified_diff(base.read_text().splitlines(True) if base.is_file() else [],p.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    except UnicodeError:raise ValueError('Unexpected binary source difference '+rel)
for rel,expected in lock['runtime_source_hashes'].items():
    if sha(upstream/rel)!=expected:raise ValueError('Pinned upstream audit mismatch '+rel)
(WORK/'llama-project.patch').write_text(''.join(patch))
# Mechanical path relocation only; preserve all graph/math/state changes.
cm=src/'src/CMakeLists.txt';text=cm.read_text()
text=text.replace('/mnt/c/Patientqwen/runtime/qwen35_w4a8',str(TREE/'runtime/qwen35_w4a8'));cm.write_text(text)
save(WORK/'source-provenance.json',{'base_commit':lock['runtime_commit'],'upstream_selected_files_verified':lock['runtime_source_hashes'],
 'base_files':base_hashes,'changed':changed,'consolidated_patch_sha256':sha(WORK/'llama-project.patch'),
 'relocated_cmake_sha256':sha(cm),'source_kind':'EXTRACTED_PINNED_SOURCE_WITH_A05_PATCHES_NOT_GIT_CHECKOUT','old_binaries_reused':False})
lib=WORK/'llama-build';native=TREE/'runtime-bin'
run(['cmake','-S',str(src),'-B',str(lib),'-DCMAKE_BUILD_TYPE=Release','-DGGML_CUDA=OFF','-DGGML_VULKAN=OFF','-DGGML_BLAS=OFF','-DGGML_NATIVE=OFF','-DLLAMA_OPENSSL=OFF','-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_SERVER=OFF','-DLLAMA_BUILD_EXAMPLES=OFF'])
run(['cmake','--build',str(lib),'--target','llama','-j','3'])
run(['cmake','-S',str(TREE/'runtime/qwen35_w4a8'),'-B',str(native),'-DCMAKE_BUILD_TYPE=Release','-DLLAMA_SOURCE='+str(src),'-DLLAMA_BUILD='+str(lib),'-DROOT='+str(TREE)])
run(['cmake','--build',str(native),'-j','3'])
manifest=json.loads((TREE/'modules/linear_A/manifest.a08.json').read_text())
manifest.update(native_entry='runtime-bin/qwen35-s1',shared_library='runtime-bin/libsp_linear_cpu.so',status='A09_CLEAN_BUILD_SMOKE_PENDING',files={},note='PC clean rebuild; BOARD NOT_TESTED. Runtime assets retained privately.')
for p in [native/'qwen35-s1',native/'libsp_linear_cpu.so',*sorted((lib/'bin').glob('*.so'))]:
    name=p.relative_to(TREE).as_posix() if p.is_relative_to(TREE) else str(p)
    manifest['files'][name]={'sha256':sha(p),'bytes':p.stat().st_size}
save(TREE/'modules/linear_A/manifest.a09.json',manifest)
venv='/home/member-a/voice-a03/venv/bin/python'
env=dict(os.environ,PYTHONPATH=str(TREE))
run([venv,'-m','quant.export_w4a8','--output',str(TREE/'models/sidecar_A/qwen35-v1')],env=env)
old=ROOT/'models/sidecar_A/qwen35-v1';new=TREE/'models/sidecar_A/qwen35-v1'
comparisons={p.name:sha(p)==sha(old/p.name) for p in new.iterdir() if p.suffix=='.bin' or p.name=='manifest.json'}
save(WORK/'export-comparison.json',{'files':comparisons,'pass':len(comparisons)==145 and all(comparisons.values()),'payload_bytes':140378112,'domain':'PC'})
if not all(comparisons.values()) or len(comparisons)!=145:raise ValueError('Re-export differs')
run(['python3','scripts/release/check_contracts.py'],env=env)
run(['python3','scripts/release/qwen35_config.py'],env=env)
run(['python3','-m','unittest','system_qwen35.app.test_a02','system_qwen35.app.test_capture','system_qwen35.app.default_e2e.test_policy','system_qwen35.app.default_e2e.test_review'],env=env)
run(['python3','platform/qwen35/a09/test_deploy.py'],env=env)
run(['python3','platform/qwen35/a08/checker_counterexample.py',str(WORK/'checker-after')],env=env)
save(WORK/'rehearsal.json',{'build':'PASS','export':'PASS','software_tests':'PASS','real_model_voice':'PENDING_SEPARATE_SMOKE','BOARD':'NOT_TESTED','project':str(TREE)})
save(EVIDENCE/'clean-location.json',{'work':str(WORK),'project':str(TREE),'commands':str(WORK/'commands.json')})
