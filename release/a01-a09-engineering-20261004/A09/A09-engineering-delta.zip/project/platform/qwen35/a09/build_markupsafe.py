"""Build the unchanged pinned MarkupSafe C extension with target CPython headers.

Produces an SDK-specific wheel, not a manylinux compatibility claim. Never imports
the ARM extension on the PC. Exact sources, license, commands and ELF are retained.
"""
import base64,csv,hashlib,io,json,os,shlex,subprocess,tarfile,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path('/mnt/c/Patientqwen');OUT=ROOT/'eval/qwen35/a09/refresh-20261004-v1'
WORK=Path('/home/member-a/qwen35-a09/markupsafe-arm312-20261004-v1');WORK.mkdir(exist_ok=False)
source=Path('/home/member-a/qwen35-a09/arm312-inputs-20261004-v1/MarkupSafe-2.0.1.tar.gz')
with tarfile.open(source) as t:
    for m in t:
        p=PurePosixPath(m.name)
        if p.is_absolute() or '..' in p.parts or not (m.isdir() or m.isfile()):raise ValueError('Unsafe source archive')
        if m.isfile():
            q=WORK/m.name;q.parent.mkdir(parents=True,exist_ok=True)
            with t.extractfile(m) as f,q.open('xb') as o:o.write(f.read())
src=WORK/'MarkupSafe-2.0.1';headers=Path(os.environ['SDKTARGETSYSROOT'])/'usr/include/python3.12'
extension=WORK/'_speedups.cpython-312-aarch64-linux-gnu.so'
cmd=[*shlex.split(os.environ['CC']),'-mcpu=cortex-a53','-O2','-shared','-fPIC','-I'+str(headers),str(src/'src/markupsafe/_speedups.c'),'-o',str(extension)]
r=subprocess.run(cmd,capture_output=True,text=True)
receipt={'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'BOARD':'NOT_TESTED'}
(OUT/'markupsafe-build.json').write_text(json.dumps(receipt,indent=2))
if r.returncode:raise SystemExit(r.returncode)
elf=subprocess.run([os.environ['READELF'],'-h','-d',str(extension)],capture_output=True,text=True)
receipt['readelf']={'exit_code':elf.returncode,'stdout':elf.stdout,'stderr':elf.stderr}
info='MarkupSafe-2.0.1.dist-info';entries={}
for p in (src/'src/markupsafe').glob('*'):
    if p.suffix in ('.py','.pyi') or p.name=='py.typed':entries['markupsafe/'+p.name]=p.read_bytes()
entries['markupsafe/'+extension.name]=extension.read_bytes()
entries[info+'/METADATA']=(src/'PKG-INFO').read_bytes()
entries[info+'/LICENSE.rst']=(src/'LICENSE.rst').read_bytes()
entries[info+'/WHEEL']=b'Wheel-Version: 1.0\nGenerator: A09-locked-sdk-build\nRoot-Is-Purelib: false\nTag: cp312-cp312-linux_aarch64\n'
record=io.StringIO();writer=csv.writer(record,lineterminator='\n')
for n,b in sorted(entries.items()):writer.writerow([n,'sha256='+base64.urlsafe_b64encode(hashlib.sha256(b).digest()).decode().rstrip('='),len(b)])
writer.writerow([info+'/RECORD','','']);entries[info+'/RECORD']=record.getvalue().encode()
wheel=WORK/'MarkupSafe-2.0.1-cp312-cp312-linux_aarch64.whl'
with zipfile.ZipFile(wheel,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(entries.items()):z.writestr(n,b)
receipt.update(wheel=str(wheel),wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),status='PASS_ARM64_CROSS_BUILD_NOT_TARGET_IMPORT',source_modified=False)
(OUT/'markupsafe-build.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({'status':receipt['status'],'wheel':str(wheel)}))
