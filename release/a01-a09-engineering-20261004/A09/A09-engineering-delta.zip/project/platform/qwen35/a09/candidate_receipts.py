"""Inspect only known manifest paths and declared hashes. Never run candidate code."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[3];O=R/'eval/qwen35/a09/refresh-20261004-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=R/'hw/linear_A/KERNEL_SOURCE.json';b=json.loads(source.read_text());xo=R/b['xo_path']
with zipfile.ZipFile(xo) as z:xml=z.read(b['embedded_metadata_member'])
result={'B_kernel':{'manifest':str(source.relative_to(R)),'manifest_sha256':sha(source),
    'prior_status':b['status'],'xo_sha256':sha(xo),'xo_matches':sha(xo)==b['xo_sha256'],
    'metadata_matches':hashlib.sha256(xml).hexdigest()==b['embedded_metadata_sha256'],
    'status':'STATIC_RECEIPT_CHECK_ONLY_NO_NEW_RUNTIME_ACCEPTANCE'},'optional_modules':{},'BOARD':'NOT_TESTED'}
for owner,name in [('B','modules/linear_B/manifest.json'),('C','modules/voice_C/manifest.json')]:
    p=R/name
    if not p.exists():result['optional_modules'][owner]={'status':'NOT_RECEIVED_DEFAULT_A_UNAFFECTED'};continue
    m=json.loads(p.read_text());checks={}
    for rel,entry in m.get('files',{}).items():
        q=Path(rel)
        if q.is_absolute() or '..' in q.parts or '\\' in rel:raise ValueError('Unsafe declared candidate path')
        f=p.parent/q
        if f.is_symlink() or not f.resolve().is_relative_to(p.parent.resolve()):raise ValueError('Candidate escape')
        expected=entry.get('sha256') if isinstance(entry,dict) else entry
        checks[rel]=f.is_file() and sha(f)==expected
    result['optional_modules'][owner]={'manifest_sha256':sha(p),'contract_matches':m.get('contract_sha256')=='83bd402b39350710d8689d50f79296e9625e9c75ccb0ecee145f08067c4ee3b6','files':checks,'status':'STAGED_NOT_ACTIVATED'}
assert result['B_kernel']['xo_matches'] and result['B_kernel']['metadata_matches']
with (O/'candidate-receipts.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({'kernel_hashes':'PASS','optional_modules':result['optional_modules'],'executed_candidate_code':False}))
