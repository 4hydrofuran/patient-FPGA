"""Final evidence seal: preserve failures; do not update historical seals."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];out=ROOT/'eval/qwen35/a09'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
pkg=ROOT/'release/default_preboard/package.json'
if not pkg.is_file():raise ValueError('Package has not completed; no completion claim')
meta=json.loads(pkg.read_text());archive=ROOT/'release/default_preboard/source-bundle.tar.gz'
if sha(archive)!=meta['sha256']:raise ValueError('Archive identity mismatch')
files={}
for name in ['platform/qwen35/a09','system_qwen35/app','config/qwen35/deploy.pc.json','runtime/qwen35_w4a8/CMakeLists.txt',
             'docs/PROJECT_STATUS.json','docs/status/A.md','docs/DESIGN_GAP.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md',
             'docs/handoffs/A_A09_20261003.md','release/default_preboard/README.md','release/default_preboard/DEPLOYMENT.md',
             'release/default_preboard/PREBOARD_CHECKLIST.md','release/default_preboard/paper','release/default_preboard/package.json',
             'release/default_preboard/source-bundle/SHA256.json','eval/qwen35/a09']:
    p=ROOT/name
    for q in sorted(p.rglob('*')) if p.is_dir() else [p]:
        if not q.is_file() or '__pycache__' in q.parts or q.name in ('files.sha256.json','seal-command.json'):continue
        files[q.relative_to(ROOT).as_posix()]={'sha256':sha(q),'bytes':q.stat().st_size}
with (out/'files.sha256.json').open('x') as f:json.dump({'files':files,'archive_sha256':meta['sha256'],'status':'PARTIAL_PC_REPRODUCTION_PASS_DEPLOYMENT_NOT_READY','BOARD':'NOT_TESTED'},f,indent=2)
print(json.dumps({'sealed_files':len(files),'seal_sha256':sha(out/'files.sha256.json'),'package_sha256':meta['sha256'],'BOARD':'NOT_TESTED'}))
