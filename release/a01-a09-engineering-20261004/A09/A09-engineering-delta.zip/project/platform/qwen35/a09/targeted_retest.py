"""Only retest the observed complete-clause failure, no repeated smoke suite."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];TREE=Path('/home/member-a/qwen35-a09/clean-v1/project')
out=ROOT/'eval/qwen35/a09/targeted-v3';out.mkdir(exist_ok=False)
name='system_qwen35/app/checking.py';shutil.copy2(TREE/name,out/'checking.before.py');shutil.copy2(ROOT/name,TREE/name)
env=dict(os.environ,PYTHONPATH=str(TREE),SP_VOICE_PYTHON='/home/member-a/qwen35-a09/venv-v1/bin/python')
audio='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu';env['LD_LIBRARY_PATH']=audio+':'+audio+'/pulseaudio'
python=env['SP_VOICE_PYTHON'];rows=[]
for argv in [
 [python,str(ROOT/'platform/qwen35/a09/checker_counterexample.py'),str(out/'checker-after.json')],
 [python,'platform/qwen35/a08/checker_counterexample.py',str(out/'previous-counterexample')],
 [python,'-m','system_qwen35.app.default_e2e','--native-manifest','modules/linear_A/manifest.a09.json','--mode','no_hardware','--output',str(out/'no-hardware'),'--text','有没有气短？']]:
    r=subprocess.run(['unshare','-Urn',*argv],cwd=TREE,env=env,capture_output=True,text=True)
    rows.append({'argv':['unshare','-Urn',*argv],'cwd':str(TREE),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    (out/'commands.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    if r.returncode:raise RuntimeError('Failure retained')
trace=json.loads((out/'no-hardware/rounds.jsonl').read_text())
assert trace['status']=='COMPLETED' and trace['answer_source']=='MODEL' and trace['actual_backend']=='CPU_REFERENCE'
assert trace['application']['candidate']=='是的，我有气短。' and trace['spool_after_bytes']==0
(out/'summary.json').write_text(json.dumps({'status':'PASS','domain':'PC_OFFLINE_REAL_S1_TTS_PLAY','observed_candidate':trace['application']['candidate'],
 'changes':'one exact positive whole-clause surface; no generic prefix stripping','checker_sha256':hashlib.sha256((TREE/name).read_bytes()).hexdigest(),
 'BOARD':'NOT_TESTED','medical_review':'PENDING'},ensure_ascii=False,indent=2))
print('PASS: one retained counterexample, two rule sets, one actual no_hardware round')
