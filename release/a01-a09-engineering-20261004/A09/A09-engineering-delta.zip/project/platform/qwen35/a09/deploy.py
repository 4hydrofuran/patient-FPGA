"""Fail-closed PC deployment rehearsal; board collection delegates the A1 lease gate.

No disk write, overlay load, download, privilege escalation or device reset.
This tool does not establish that an image can boot KV260.
"""
import argparse,hashlib,json,os,platform,signal,subprocess,sys,tarfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def safe(root,name):
    if not isinstance(name,str) or not name or Path(name).is_absolute() or '\\' in name or any(x in ('','.','..') for x in name.split('/')):raise ValueError('Relative path required')
    p=root/name
    if not p.resolve().is_relative_to(root.resolve()) or any(x.is_symlink() for x in [p,*p.parents] if x!=root):raise ValueError('Unsafe path')
    return p
def validate(config,root,*,files=True):
    if config.get('schema')!='A09_DEPLOY_V1' or config.get('domain') not in ('PC','BOARD'):raise ValueError('Schema/domain')
    if config.get('device_path')!='' or config.get('flash_allowed') is not False:raise ValueError('Disk writes prohibited')
    if config.get('mode') not in ('cpu_same_math','no_hardware','fpga_required'):raise ValueError('Mode')
    if config['mode']=='fpga_required':raise ValueError('HARDWARE_UNAVAILABLE: accepted kernel/board evidence absent')
    if config['domain']=='BOARD':raise ValueError('DEPLOYMENT_PENDING_BOARD: boot/DT/XRT/memory/architecture not verified')
    if config.get('architecture')!='x86_64':raise ValueError('Only rehearsed PC architecture may start')
    if config.get('native_manifest')!='modules/linear_A/manifest.a09.json':raise ValueError('Native manifest')
    if config.get('model_revision')!='2fc06364715b967f1860aea9cf38778875588b17':raise ValueError('Model revision')
    if files:
        from scripts.release.qwen35_config import validate as contracts
        contracts(root,json.loads((root/'config/qwen35/selection.json').read_text()))
        manifest=json.loads(safe(root,config['native_manifest']).read_text())
        for name,item in manifest['files'].items():
            # Rehearsal libraries may be in an explicit private build directory.
            p=Path(name) if Path(name).is_absolute() else safe(root,name)
            if not p.is_file() or sha(p)!=item['sha256']:raise ValueError('Runtime hash mismatch: '+name)
        if manifest.get('execution_kind')!='CPU_REFERENCE' or manifest.get('fpga_available') is not False:raise ValueError('Backend identity')
    return {'domain':'PC_CONFIG_REHEARSAL','status':'PASS','BOARD':'NOT_TESTED','hardware_available':False}
def identity(pid):
    # pid + boot ID + kernel start ticks prevents signalling a reused PID.
    stat=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
    return {'pid':pid,'start_ticks':stat[19],'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
def active(state):
    try:return identity(state['process']['pid'])==state['process']
    except (FileNotFoundError,ProcessLookupError):return False
def write_new(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2)
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['validate','health','start','stop','rollback','logs','collect-board'])
    p.add_argument('--config',type=Path);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--state',type=Path);p.add_argument('--output',type=Path);p.add_argument('--text')
    p.add_argument('--expected-config-sha256');p.add_argument('--registry',type=Path)
    a=p.parse_args();root=a.root.resolve()
    if a.action=='collect-board':
        if not a.registry or not a.output:raise ValueError('Registry/new output required')
        # The lease wrapper, not the collector alone, enforces the central lock.
        return subprocess.call([sys.executable,str(root/'platform/a1/lease.py'),'--registry',str(a.registry),
            'run','--log',str(a.output)+'.lease-command.json','--',sys.executable,str(root/'platform/a1/collect_board.py'),
            '--registry',str(a.registry),'--out',str(a.output)])
    if a.action=='logs':
        if not a.state or not a.output:raise ValueError('State/output required')
        s=json.loads(a.state.read_text());folder=Path(s['log_directory']).resolve()
        if active(s):raise ValueError('Stop owned application before sealing logs')
        if not folder.is_dir() or folder.is_symlink():raise ValueError('Log folder')
        entries=[]
        # Never include WAV/PCM, model assets, environment, SSH, licenses or disks.
        for f in folder.rglob('*'):
            if f.is_file() and not f.is_symlink() and f.suffix in ('.json','.jsonl','.stderr'):
                if f.stat().st_size>32*1024*1024:raise ValueError('Oversize log; inspect manually')
                entries.append(f)
        with tarfile.open(a.output,'x:gz') as t:
            for f in entries:t.add(f,arcname=f.relative_to(folder).as_posix(),recursive=False)
        print(json.dumps({'sha256':sha(a.output),'files':len(entries),'sharing':'PRIVATE_REVIEW_REQUIRED_TRANSCRIPTS_MAY_EXIST'}));return 0
    if a.action=='stop':
        s=json.loads(a.state.read_text())
        if active(s):
            os.kill(s['process']['pid'],signal.SIGINT)
            deadline=time.monotonic()+15
            while active(s) and time.monotonic()<deadline:time.sleep(.1)
            if active(s):raise RuntimeError('Still active; do not delete lock or kill unrelated process')
        print(json.dumps({'status':'STOPPED_OR_ALREADY_EXITED','files_deleted':0}));return 0
    if not a.config:raise ValueError('Config required')
    cfg=json.loads(a.config.read_text());result=validate(cfg,root)
    if a.action=='validate':print(json.dumps(result));return 0
    if a.action=='rollback':
        if not a.expected_config_sha256 or sha(a.config)!=a.expected_config_sha256:raise ValueError('Explicit known-good config hash required')
        if not a.state or not a.state.is_file():raise ValueError('Prior owned state required')
        if active(json.loads(a.state.read_text())):raise ValueError('Stop before rollback')
        if not a.output:raise ValueError('New selection receipt required')
        write_new(a.output,{'selected_config':str(a.config.resolve()),'sha256':sha(a.config),'action':'CONFIG_SELECTION_ONLY_NO_FIRMWARE_CHANGE','BOARD':'NOT_TESTED'})
        return 0
    if a.action=='health':
        if a.state and a.state.exists():result['owned_process_running']=active(json.loads(a.state.read_text()))
        else:result['owned_process_running']=False
        result['status']='CONFIG_VALID_NOT_APPLICATION_READY'
        print(json.dumps(result));return 0
    if platform.machine()!='x86_64' or sys.platform!='linux':raise ValueError('PC build is Linux x86_64 only')
    if not a.state or a.state.exists() or not a.output or a.output.exists() or not a.text:raise ValueError('Unique state/output and explicit text required')
    argv=[sys.executable,'-m','system_qwen35.app.default_e2e','--native-manifest',cfg['native_manifest'],'--mode',cfg['mode'],'--output',str(a.output.resolve()),'--text',a.text]
    # Running application remains foreground-attached for logs and signal ownership.
    child=subprocess.Popen(argv,cwd=root,start_new_session=True)
    write_new(a.state,{'process':identity(child.pid),'argv':argv,'log_directory':str(a.output.resolve()),'config_sha256':sha(a.config)})
    try:return child.wait()
    except KeyboardInterrupt:
        if child.poll() is None:child.send_signal(signal.SIGINT)
        return child.wait(timeout=15)
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,RuntimeError,OSError,KeyError) as e:print(json.dumps({'status':'REFUSED','reason':str(e),'BOARD':'NOT_TESTED'}));raise SystemExit(2)
