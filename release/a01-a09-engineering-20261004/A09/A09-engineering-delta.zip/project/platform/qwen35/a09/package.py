"""Build a source-only offline candidate from explicit allowlists; no weights."""
import hashlib,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];RELEASE=ROOT/'release/default_preboard'
bundle=RELEASE/'source-bundle';bundle.mkdir(exist_ok=False);project=bundle/'project';project.mkdir()
work=Path('/home/member-a/qwen35-a09/clean-v1')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def copy(name):
    src=ROOT/name;dst=project/name;dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_dir():shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git'))
    else:shutil.copy2(src,dst)
for name in ['system_qwen35','modules/voice_A','modules/linear_A','config/qwen35','contracts','runtime/qwen35_w4a8',
 'quant/export_w4a8','quant/reference','quant/qwen35_tensor_map.json','models/model.lock.json',
 'scripts/release/check_contracts.py','scripts/release/qwen35_config.py','platform/qwen35/a09',
 'platform/a1/lease.py','platform/a1/collect_board.py','platform/a1/record.py',
 'eval/qwen35/a02/dataset.lock.json','eval/qwen35/a02/dev/questions-v2.json',
 *json.loads((ROOT/'eval/qwen35/a02/dataset.lock.json').read_text()).keys()]:copy(name)
copy('artifacts/qwen35-0.8b/source/LICENSE')
shutil.copytree(work/'llama-source',project/'third_party/llama',ignore=shutil.ignore_patterns('.git','__pycache__','*.pyc','*.key','*.gguf'))
cm=project/'third_party/llama/src/CMakeLists.txt';text=cm.read_text();path=str(work/'project/runtime/qwen35_w4a8')
if text.count(path)!=2:raise ValueError('Unexpected source hook path count')
cm.write_text('set(SP_A_RUNTIME_DIR "" CACHE PATH "A runtime source")\nif(NOT SP_A_RUNTIME_DIR)\n message(FATAL_ERROR "SP_A_RUNTIME_DIR required")\nendif()\n'+text.replace(path,'${SP_A_RUNTIME_DIR}'))
shutil.copytree('/home/member-a/qwen35-a09/wheels-v1',bundle/'wheels')
shutil.copy2(ROOT/'eval/qwen35/a09/offline-install.json',bundle/'DEPENDENCIES_AND_LICENSE_METADATA.json')
for name in ('README.md','DEPLOYMENT.md','PREBOARD_CHECKLIST.md','rebuild.sh'):shutil.copy2(RELEASE/name,bundle/name)
shutil.copytree(RELEASE/'paper',bundle/'paper')
shutil.copy2(work/'llama-project.patch',bundle/'llama-project.patch')
shutil.copy2(work/'source-provenance.json',bundle/'SOURCE_PROVENANCE.json')
# Only public model-source LICENSE above, never local Xilinx license secrets.
deny={'.lic','.pem','.key','.vhd','.vhdx','.wic','.img','.qcow2','.gguf','.safetensors','.onnx','.wav','.pcm'}
hashes={}
for p in sorted(bundle.rglob('*')):
    if not p.is_file():continue
    if p.is_symlink() or p.suffix.lower() in deny or p.name in ('.env','credentials','id_rsa','id_ed25519'):raise ValueError('Forbidden package content '+str(p.relative_to(bundle)))
    if p.suffix in ('.json','.md','.py','.sh','.txt') and p.stat().st_size<4*1024*1024:
        raw=p.read_bytes()
        if b'-----BEGIN PRIVATE KEY-----\n' in raw or b'-----BEGIN OPENSSH PRIVATE KEY-----\n' in raw:raise ValueError('Secret marker in '+p.name)
    hashes[p.relative_to(bundle).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
(bundle/'SHA256.json').write_text(json.dumps(hashes,indent=2))
archive=RELEASE/'source-bundle.tar.gz'
with tarfile.open(archive,'x:gz') as t:t.add(bundle,arcname='source-bundle')
receipt={'status':'SOURCE_DEPENDENCY_CANDIDATE_NOT_BOARD_PRODUCT','sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(hashes),
 'excluded':'weights, audio recordings, Xilinx licenses, system/WSL/boot disk images, secrets','publishing':'NOT_PUBLISHED','BOARD':'NOT_TESTED',
 'system_dependencies':'Existing Ubuntu22.04/WSL compiler, libc, OpenMP, libcrypto, Pulse; not a bare-OS installer'}
(RELEASE/'package.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
