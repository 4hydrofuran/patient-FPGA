"""Stage ARM inputs and inspect ELF dependency names, not target execution."""
import hashlib,json,re,shutil,subprocess,zipfile
from pathlib import Path,PurePosixPath
R=Path('/mnt/c/Patientqwen');O=R/'eval/qwen35/a09/refresh-20261004-v1';D=R/'release/default_preboard/20261004-v2/source-bundle/arm312-wheels'
S=Path('/home/member-a/kv260-sdk-2026.1-common/sysroots/cortexa72-cortexa53-amd-linux')
X=Path('/home/member-a/qwen35-a09/arm312-inspect-20261004-v1');X.mkdir(exist_ok=False);D.mkdir(parents=True,exist_ok=False)
meta=json.loads((O/'target-dependencies.json').read_text());markup=json.loads((O/'markupsafe-build.json').read_text());files={};metadata={}
for name,item in meta['packages'].items():
    p=Path(markup['wheel'] if name=='MarkupSafe' else item['file']);expected=markup['wheel_sha256'] if name=='MarkupSafe' else item['sha256']
    assert p.suffix=='.whl' and hashlib.sha256(p.read_bytes()).hexdigest()==expected
    shutil.copy2(p,D/p.name);files[p.name]={'sha256':expected,'bytes':p.stat().st_size}
    with zipfile.ZipFile(p) as z:
        for n in z.namelist():
            path=PurePosixPath(n)
            if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe wheel path')
            if n.endswith('/'):continue
            q=X/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(n))
            if n.endswith('.dist-info/METADATA'):metadata[name]=q.read_text()
elf={};all_needed=set();provided=set(p.name for p in X.rglob('*') if p.is_file())
for p in X.rglob('*'):
    if not p.is_file():continue
    with p.open('rb') as f:magic=f.read(4)
    if magic!=b'\x7fELF':continue
    r=subprocess.run(['readelf','-h','-d',str(p)],capture_output=True,text=True)
    assert r.returncode==0 and 'AArch64' in r.stdout,p
    needed=re.findall(r'\(NEEDED\).*?\[(.*?)\]',r.stdout);sonames=re.findall(r'\(SONAME\).*?\[(.*?)\]',r.stdout)
    provided.update(sonames);all_needed.update(needed)
    elf[str(p.relative_to(X))]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'needed':needed,'readelf':r.stdout}
resolution={}
for n in sorted(all_needed-provided):
    paths=[S/'usr/lib'/n,S/'lib'/n,S/'usr/lib/aarch64-amd-linux'/n]
    p=next((p for p in paths if p.is_file()),None)
    resolution[n]={'sdk_path':str(p) if p else None,'status':'SDK_ONLY_NOT_ROOTFS_VERIFIED' if p else 'MISSING'}
result={'status':'TARGET_INPUTS_STAGED_NOT_ARM_IMPORTED','wheel_files':files,'elf_objects':elf,'system_resolution':resolution,
 'distribution_metadata':metadata,'target':'SDK CPython3.12 / Linux aarch64 / Cortex-A53; board Python ABI must be checked first',
 'BOARD':'NOT_TESTED','runtime_import':'NOT_TESTED','all_elf_aarch64':True,'native_extension':'MarkupSafe2.0.1 unchanged source built with SDK; no version upgrade',
 'limitations':['ELF SONAME resolution is static, not a runtime symbol/version or ISA test','SDK libraries are not proof of matching rootfs libraries','Do not install PC cp310/x86_64 wheels on target']}
(O/'arm-inputs.json').write_text(json.dumps(result,indent=2));(D/'SHA256.json').write_text(json.dumps(files,indent=2))
print(json.dumps({'wheels':len(files),'aarch64_elfs':len(elf),'missing':[n for n,v in resolution.items() if v['status']=='MISSING'],'BOARD':'NOT_TESTED'}))
