"""One genuine clean-project WAV round; not a repeated soak."""
import json,sys
from pathlib import Path
from system_qwen35.app.default_e2e.service import Service
from system_qwen35.app.default_e2e.policy import validate_trace
out=Path(sys.argv[1]);f=json.loads(Path(sys.argv[2]).read_text())[0]
s=Service(out,native_manifest='modules/linear_A/manifest.a09.json')
try:
    r=s.turn(wav=f['wav'],synthetic_reference=f['text'],stream=True);validate_trace(r)
    result={'status':r['status'],'source':r['answer_source'],'actual_backend':r['actual_backend'],'error':r.get('error'),
            'case':r['case_identity'],'provenance':r['provenance'],'BOARD':'NOT_TESTED'}
    (out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    assert r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['actual_backend']=='CPU_REFERENCE'
    print(json.dumps(result,ensure_ascii=False))
finally:s.close()
