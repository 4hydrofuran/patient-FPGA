"""Retained A09 real candidate plus explicit safety counterfactuals."""
import json,sys
from pathlib import Path
from system_qwen35.app.domain import load_case,Transcript
from system_qwen35.app.planning import plan
from system_qwen35.app.checking import check
out=Path(sys.argv[1]);rows=[]
for case,question,text,expect in [
 ('SYN_CP_01','有没有气短','是的，我有气短。',True),
 ('SYN_CP_02','有没有气短','是的，我有气短。',False),
 ('SYN_CP_03','有没有气短','是的，我有气短。',False),
 ('SYN_CP_01','有没有气短','是的，我没有气短。',False),
 ('SYN_CP_01','有没有气短','是的，我有气短，而且有药物过敏。',False),
 ('SYN_CP_01','每次疼痛持续多久，有没有气短','是的，我有气短。',False)]:
    p=plan(load_case(case),Transcript.parse({'request_id':'a09-counterexample','text':question,'source':'typed','final':True}),[])
    r=check(p,text);rows.append({'case':case,'question':question,'text':text,'expected_pass':expect,'actual':r,'pass':(r['status']=='pass')==expect})
with out.open('x') as f:json.dump({'source':'A09 clean actual S1 candidate plus authored counterfactuals','domain':'PC_RULE','medical_review':'PENDING','rows':rows},f,ensure_ascii=False,indent=2)
print(json.dumps({'passed':sum(x['pass'] for x in rows),'total':len(rows)}))
raise SystemExit(0 if all(x['pass'] for x in rows) else 2)
