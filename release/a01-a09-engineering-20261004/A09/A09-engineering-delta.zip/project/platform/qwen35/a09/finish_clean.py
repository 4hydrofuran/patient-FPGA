"""Repair missing data allowlist, preserving the failed clean test and build."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];WORK=Path('/home/member-a/qwen35-a09/clean-v1');TREE=WORK/'project'
out=ROOT/'eval/qwen35/a09/clean-tests-v2';out.mkdir(exist_ok=False)
copied={}
def copy(name):
    src=ROOT/name;dst=TREE/name;dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        if dst.read_bytes()!=src.read_bytes():raise ValueError('Unexpected existing data '+name)
    else:shutil.copy2(src,dst)
    copied[name]=hashlib.sha256(src.read_bytes()).hexdigest()
for name in ['eval/qwen35/a02/dataset.lock.json','eval/qwen35/a02/dev/questions-v2.json',
             *json.loads((ROOT/'eval/qwen35/a02/dataset.lock.json').read_text()).keys()]:copy(name)
fixture=json.loads((ROOT/'eval/qwen35/a03/audio-eval-v1/fixtures.json').read_text())[0]
copy(fixture['wav'])
(WORK/'one-synthetic-fixture.json').write_text(json.dumps([fixture],ensure_ascii=False))
for name in ['platform/qwen35/a09/smoke.py','platform/qwen35/a09/install_offline.py']:copy(name)
# Deliberately versioned copy, since the lease wrapper was tightened during build.
shutil.copy2(ROOT/'platform/qwen35/a09/deploy.py',TREE/'platform/qwen35/a09/deploy.py')
copied['platform/qwen35/a09/deploy.py']=hashlib.sha256((TREE/'platform/qwen35/a09/deploy.py').read_bytes()).hexdigest()
(out/'copied.json').write_text(json.dumps(copied,indent=2))
rows=[];python='/home/member-a/qwen35-a09/venv-v1/bin/python'
env=dict(os.environ,PYTHONPATH=str(TREE),SP_VOICE_PYTHON=python)
audio='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu'
env['LD_LIBRARY_PATH']=audio+':'+audio+'/pulseaudio'
def run(args,expected=0):
    start=time.monotonic();r=subprocess.run(['unshare','-Urn',python,*args],cwd=TREE,env=env,capture_output=True,text=True)
    rows.append({'argv':['unshare','-Urn',python,*args],'cwd':str(TREE),'exit_code':r.returncode,'expected_exit_code':expected,
                 'elapsed_s':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr})
    (out/'commands.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    print(json.dumps({'command':args,'exit_code':r.returncode}),flush=True)
    if r.returncode!=expected:raise RuntimeError('Retained failure '+str(args))
run(['scripts/release/check_contracts.py'])
run(['scripts/release/qwen35_config.py'])
run(['-m','unittest','system_qwen35.app.test_a02','system_qwen35.app.test_capture','system_qwen35.app.default_e2e.test_policy','system_qwen35.app.default_e2e.test_review','modules.voice_A.test_voice'])
run(['platform/qwen35/a09/test_deploy.py'])
run(['platform/qwen35/a08/checker_counterexample.py',str(WORK/'checker-after')])
run(['platform/qwen35/a09/deploy.py','validate','--config','config/qwen35/deploy.pc.json'])
run(['platform/qwen35/a09/smoke.py',str(out/'real-smoke'),str(WORK/'one-synthetic-fixture.json')])
(out/'summary.json').write_text(json.dumps({'status':'PASS_PC_CLEAN_TESTS_AND_TWO_REAL_ROUNDS','BOARD':'NOT_TESTED','original_failure':'clean-v1/command-07.stderr','no_rebuild':True},indent=2))
(ROOT/'eval/qwen35/a09/clean-location.json').write_text(json.dumps({'work':str(WORK),'project':str(TREE),'build_commands':str(WORK/'commands.json'),'retest':str(out)},indent=2))
