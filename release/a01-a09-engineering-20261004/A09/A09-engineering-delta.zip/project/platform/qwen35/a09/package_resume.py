"""Seal the audited package after a conservative non-runtime .key exclusion."""
import hashlib,json,shutil,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];RELEASE=ROOT/'release/default_preboard';bundle=RELEASE/'source-bundle'
for name in ('source-bundle/SHA256.json','source-bundle.tar.gz','package.json'):
    if (RELEASE/name).exists():raise FileExistsError('Preserve existing output and inspect before retry: '+name)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
# Stage the final, tested deploy sources and provenance; do not rerun build.
for p in (ROOT/'platform/qwen35/a09').glob('*.py'):shutil.copy2(p,bundle/'project/platform/qwen35/a09'/p.name)
for name in ('README.md','DEPLOYMENT.md','PREBOARD_CHECKLIST.md','rebuild.sh'):shutil.copy2(RELEASE/name,bundle/name)
hashes={};deny={'.lic','.pem','.key','.vhd','.vhdx','.wic','.img','.qcow2','.gguf','.safetensors','.onnx','.wav','.pcm'}
for p in sorted(bundle.rglob('*')):
    if p.is_symlink():raise ValueError('Symlink in bundle')
    if not p.is_file():continue
    if p.suffix.lower() in deny or p.name in ('.env','credentials','id_rsa','id_ed25519'):raise ValueError('Forbidden content '+str(p.relative_to(bundle)))
    if p.suffix in ('.json','.md','.py','.sh','.txt') and p.stat().st_size<4*1024*1024:
        raw=p.read_bytes()
        if b'-----BEGIN PRIVATE KEY-----\n' in raw or b'-----BEGIN OPENSSH PRIVATE KEY-----\n' in raw:raise ValueError('Private key header')
    hashes[p.relative_to(bundle).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
print(json.dumps({'step':'audited','files':len(hashes)}),flush=True)
(bundle/'SHA256.json').write_text(json.dumps(hashes,indent=2))
archive=RELEASE/'source-bundle.tar.gz'
with tarfile.open(archive,'x:gz') as t:t.add(bundle,arcname='source-bundle')
print(json.dumps({'step':'archive_created','bytes':archive.stat().st_size}),flush=True)
receipt={'status':'SOURCE_DEPENDENCY_CANDIDATE_NOT_BOARD_PRODUCT','sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(hashes),
 'excluded':'model/voice weights, recordings, Xilinx licenses, system/WSL/boot disks, secrets, non-runtime upstream .key document and 19 vocabulary GGUF fixtures',
 'upstream_document_preserved':'Original unchanged; rejected copy in eval/qwen35/a09/excluded-upstream-idea-arch.key',
 'publishing':'NOT_PUBLISHED','BOARD':'NOT_TESTED','system_dependencies':'Existing Ubuntu22.04/WSL compiler, libc, OpenMP, libcrypto, Pulse; not bare OS'}
(RELEASE/'package.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
