"""Actual PC process lifecycle only. No fake inference, board, or recording."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(sys.argv[1]);OUT.mkdir(exist_ok=False)
deploy=ROOT/'platform/qwen35/a09/deploy.py';config=ROOT/'config/qwen35/deploy.pc.json';state=OUT/'state.json';run=OUT/'application'
commands=[]
def call(args):
    argv=[sys.executable,str(deploy),*args];r=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
    commands.append({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    (OUT/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2))
    return r
argv=[sys.executable,str(deploy),'start','--config',str(config),'--state',str(state),'--output',str(run),'--text','疼痛在什么位置？']
with (OUT/'start.stdout').open('x') as stdout,(OUT/'start.stderr').open('x') as stderr:
    parent=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
    # Once real model/voice objects are initialized, test stop while this one
    # actual task is in flight. No unowned PID scanning or signalling.
    deadline=time.monotonic()+180
    while not (run/'startup.json').exists() and parent.poll() is None and time.monotonic()<deadline:time.sleep(.1)
    ready=(run/'startup.json').exists()
    if not ready:
        if parent.poll() is None:parent.send_signal(2)
        raise RuntimeError('Application not ready; retained outputs, do not fabricate lifecycle success')
    health=call(['health','--config',str(config),'--state',str(state)])
    stop=call(['stop','--state',str(state)]);code=parent.wait(timeout=30)
commands.append({'argv':argv,'exit_code':code,'stdout_file':'start.stdout','stderr_file':'start.stderr'})
(OUT/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2))
assert stop.returncode==0 and health.returncode==0
traces=[json.loads(line) for line in (run/'rounds.jsonl').read_text().splitlines()]
assert len(traces)==1 and traces[0]['status']=='CANCELLED' and traces[0]['error']
assert traces[0]['session_after']['played_count']==0 and traces[0]['timestamps']['first_effective_sound_ns'] is None
assert code==3,'CLI must report a cancelled task, not a successful answer or raw SIGINT escape'
post=call(['health','--config',str(config),'--state',str(state)])
assert not json.loads(post.stdout)['owned_process_running']
rollback=call(['rollback','--config',str(config),'--state',str(state),'--expected-config-sha256',hashlib.sha256(config.read_bytes()).hexdigest(),'--output',str(OUT/'rollback.json')]);assert rollback.returncode==0
logs=call(['logs','--state',str(state),'--output',str(OUT/'private-logs.tar.gz')]);assert logs.returncode==0
result={'status':'PASS_PC_REAL_PROCESS_START_READY_STOP_HEALTH_CONFIG_ROLLBACK_LOGS','start_exit':code,
 'meaning':'Cancellation/stop is not a completed answer. Rollback selects config, not firmware or model hot-swap.',
 'BOARD':'NOT_TESTED','real_model_ready':True,'cancel_trace_status':traces[0]['status'],'recording':False,'log_sharing':'PRIVATE_REVIEW_REQUIRED'}
(OUT/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
