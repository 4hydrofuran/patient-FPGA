"""Read-only A09 continuity checks and copied build receipts; no board execution."""
import hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a09/refresh-20261004-v1'
CLEAN=Path('/home/member-a/qwen35-a09/refresh-20261004-v2/project')
PRIOR=Path('/home/member-a/qwen35-a09/clean-v1/project')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def load(p):return json.loads(p.read_text())
def main():
    result={'BOARD':'NOT_TESTED','new_native_build':False,'new_weight_export':False}
    export=load(ROOT/'eval/qwen35/a09/final/clean-export-comparison.json')
    assert export['pass'] and len(export['files'])==145
    weights={n:sha(ROOT/'models/sidecar_A/qwen35-v1'/n)==sha(PRIOR/'models/sidecar_A/qwen35-v1'/n)==sha(CLEAN/'models/sidecar_A/qwen35-v1'/n) for n in export['files']}
    assert all(weights.values());result['reexport_continuity']=weights
    manifest=load(CLEAN/'modules/linear_A/manifest.a09.json')
    binaries={n:sha(CLEAN/n)==v['sha256'] for n,v in manifest['files'].items()}
    assert all(binaries.values());result['prior_clean_binary_hashes']=binaries
    assert not Path('/home/member-a/qwen35-a09/must-not-create-arm-venv').exists()
    result['wrong_target_install_created_directory']=False
    copied=[]
    for name in ('bo-build.json','markup-run.json'):
        wrapper=load(OUT/name);assert wrapper['exit_code']==0
        receipt=json.loads(wrapper['stdout']);assert receipt['exit_code']==0
        work=Path(receipt['cwd']);dest=OUT/'build-logs'/receipt['job'];dest.mkdir(parents=True,exist_ok=False)
        for p in work.iterdir():
            if p.is_file() and p.suffix in ('.log','.json','.txt'):
                shutil.copy2(p,dest/p.name);copied.append(str((dest/p.name).relative_to(OUT)))
    result['build_logs_copied']=copied
    source={}
    for folder in ('platform/qwen35/a09','system_qwen35','config/qwen35'):
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
                n=p.relative_to(ROOT);q=CLEAN/n
                source[str(n)]={'sha256':sha(p),'clean_equal':q.is_file() and sha(q)==sha(p)}
    assert all(v['clean_equal'] for v in source.values());result['clean_source']=source
    result['lifecycle']=load(OUT/'lifecycle-v2/summary.json')
    assert result['lifecycle']['cancel_trace_status']=='CANCELLED'
    result['real_wav']=load(OUT/'clean-smoke/summary.json')
    assert result['real_wav']['source']=='MODEL' and result['real_wav']['error'] is None
    cmds=[]
    for p in sorted(OUT.glob('*command.json')):
        row=load(p);cmds.append({'receipt':p.name,'argv':row['argv'],'exit_code':row['exit_code']})
    result['command_index']=cmds
    result['git_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    result['git_branch']=subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()
    result['commit_created']=False;result['pushed']=False
    with (OUT/'continuity-audit.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps({'status':'PASS_CONTINUITY_AUDIT','weights':len(weights),'binaries':len(binaries),'clean_source_files':len(source),'build_logs':len(copied),'BOARD':'NOT_TESTED'}))
if __name__=='__main__':main()
