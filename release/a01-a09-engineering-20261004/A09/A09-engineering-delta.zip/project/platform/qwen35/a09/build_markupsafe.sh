#!/usr/bin/env bash
set -euo pipefail
set +u
source /home/member-a/kv260-sdk-2026.1-common/environment-setup-cortexa72-cortexa53-amd-linux
set -u
python3 /mnt/c/Patientqwen/platform/qwen35/a09/build_markupsafe.py
