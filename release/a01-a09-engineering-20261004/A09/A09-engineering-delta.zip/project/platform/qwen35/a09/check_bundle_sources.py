"""Confirm packaged first-party sources match current A source, read-only."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
manifest=json.loads((ROOT/'release/default_preboard/source-bundle/SHA256.json').read_text())
rows={}
for path,item in manifest.items():
    if not path.startswith('project/') or path.startswith('project/third_party/'):continue
    rel=path[len('project/'):];p=ROOT/rel
    rows[rel]=p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
result={'status':'PASS' if all(rows.values()) else 'FAIL','checked':len(rows),'mismatches':[n for n,ok in rows.items() if not ok],
        'scope':'Packaged first-party files only; upstream archive separately verified','BOARD':'NOT_TESTED'}
print(json.dumps(result));raise SystemExit(0 if all(rows.values()) else 2)
