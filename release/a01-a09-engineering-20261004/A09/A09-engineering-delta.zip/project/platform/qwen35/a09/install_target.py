"""Locked ARM Python input check / explicit new-venv install. No network or OS writes.

Run the install action only on the reviewed target through the central lease.
System packages are prerequisites; this script never apt-installs another OS.
"""
import argparse,ctypes,hashlib,json,os,platform,subprocess,sys
from pathlib import Path
def inputs(folder):
    lock=json.loads((folder/'SHA256.json').read_text());files=[]
    if len(lock)!=9:raise ValueError('Nine locked distributions required')
    for name,data in lock.items():
        if Path(name).name!=name or not name.endswith('.whl'):raise ValueError('Wheel filename')
        p=folder/name
        if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=data['sha256']:raise ValueError('Wheel hash mismatch '+name)
        files.append(str(p.resolve()))
    return files
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--wheels',type=Path,required=True);ap.add_argument('--install',action='store_true');ap.add_argument('--target',type=Path);ap.add_argument('--receipt',type=Path,required=True);a=ap.parse_args()
    wheels=inputs(a.wheels);result={'input_hashes':'PASS','action':'CHECK_ONLY','BOARD':'NOT_TESTED','commands':[]}
    with a.receipt.open('x') as f:json.dump(result,f,indent=2)
    if not a.install:return 0
    if platform.system()!='Linux' or platform.machine()!='aarch64' or sys.version_info[:2]!=(3,12) or not os.environ.get('A1_BOARD_LEASE'):raise ValueError('Reviewed ARM64 CPython3.12 target and central lease required')
    if not a.target or not a.target.is_absolute() or a.target.exists() or a.target.is_symlink():raise ValueError('Fresh absolute venv target required')
    libs=['libstdc++.so.6','libgomp.so.1','libffi.so.8','libsndfile.so.1','libpulse-simple.so.0','libpulse.so.0']
    for lib in libs:ctypes.CDLL(lib)
    result.update(action='INSTALL_EXPLICIT_TARGET',system_libraries_loaded=libs)
    py=str(a.target/'bin/python')
    commands=[[sys.executable,'-m','venv',str(a.target)],[py,'-m','pip','install','--no-index','--no-deps',*wheels],
        [py,'-m','pip','check'],[py,'-c','import sherpa_onnx,numpy,scipy,soundfile,jinja2,markupsafe; print("target imports complete")']]
    for cmd in commands:
        r=subprocess.run(cmd,capture_output=True,text=True);result['commands'].append({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
        a.receipt.write_text(json.dumps(result,indent=2))
        if r.returncode:raise RuntimeError('Target install failed; retain partial venv and receipt')
    result['target_import']='PASS_ACTUALLY_EXECUTED_NOT_MODEL_OR_BOARD_BENCHMARK';a.receipt.write_text(json.dumps(result,indent=2));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,RuntimeError,OSError) as e:print(json.dumps({'status':'REFUSED_OR_FAILED','error':str(e)}));raise SystemExit(2)
