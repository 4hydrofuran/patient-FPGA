"""Inspect SDK and prepare pinned ARM64/Python3.12 inputs. Never install or upgrade.

Downloads only PyPI distribution files selected from exact-version metadata and
verifies the advertised SHA256. An sdist is not a built target wheel.
"""
import hashlib,json,subprocess,sys,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a09/refresh-20261004-v1'
SDK=Path('/home/member-a/kv260-sdk-2026.1-common/sysroots/cortexa72-cortexa53-amd-linux')
DEST=Path('/home/member-a/qwen35-a09/arm312-inputs-20261004-v1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    DEST.mkdir(exist_ok=False)
    result={'domain':'OFFLINE_TARGET_PREPARATION_NOT_ARM_EXECUTION','sdk':str(SDK),'python_header':{},'system_libraries':{},'packages':{},'BOARD':'NOT_TESTED','installed':False}
    header=SDK/'usr/include/python3.12/patchlevel.h'
    result['python_header']={'sha256':sha(header),'version_lines':[s for s in header.read_text().splitlines() if s.startswith('#define PY_VERSION ')]}
    for name in ['libpython3.12.so.1.0','libpulse-simple.so.0','libpulse.so.0','libsndfile.so.1','libgomp.so.1','libcrypto.so.3','libstdc++.so.6','libc.so.6']:
        matches=[SDK/'usr/lib'/name,SDK/'lib'/name];p=next((p for p in matches if p.is_file()),None)
        if p:
            r=subprocess.run(['readelf','-h','-d',str(p)],capture_output=True,text=True)
            result['system_libraries'][name]={'path':str(p),'sha256':sha(p),'readelf_exit':r.returncode,'elf':r.stdout,'stderr':r.stderr,'scope':'SDK presence, not rootfs runtime availability'}
        else:result['system_libraries'][name]={'status':'NOT_FOUND_IN_CHECKED_SDK_PATHS'}
    packages=json.loads((ROOT/'eval/qwen35/a09/offline-install.json').read_text())['packages']
    for name,locked in packages.items():
        item={'version':locked['version'],'metadata_url':f'https://pypi.org/pypi/{name}/{locked["version"]}/json'};result['packages'][name]=item
        try:
            with urllib.request.urlopen(item['metadata_url'],timeout=30) as response:data=json.load(response)
            urls=data['urls']
            wheels=[x for x in urls if x['filename'].endswith('.whl') and ('-py3-none-any.' in x['filename'] or '-py2.py3-none-any.' in x['filename'] or ('aarch64' in x['filename'] and ('-cp312-cp312-' in x['filename'] or '-py3-none-' in x['filename'] or '-py2.py3-none-' in x['filename'])))]
            choices=wheels or [x for x in urls if x['packagetype']=='sdist']
            item['status']='TARGET_WHEEL_INPUT_ONLY_NOT_IMPORTED' if wheels else 'SOURCE_BUILD_REQUIRED' if choices else 'MISSING_DISTRIBUTION'
            item['license_metadata']=data['info'].get('license');item['requires_dist']=data['info'].get('requires_dist')
            if choices:
                chosen=sorted(choices,key=lambda x:x['filename'])[0];namefile=chosen['filename']
                if Path(namefile).name!=namefile:raise ValueError('Unsafe package filename')
                p=DEST/namefile
                with urllib.request.urlopen(chosen['url'],timeout=60) as response,p.open('xb') as f:
                    for block in iter(lambda:response.read(1024*1024),b''):f.write(block)
                item.update(file=str(p),sha256=sha(p),expected_sha256=chosen['digests']['sha256'],url=chosen['url'])
                if item['sha256']!=item['expected_sha256']:raise ValueError('Distribution hash mismatch; retained for inspection')
                if wheels:
                    with zipfile.ZipFile(p) as z:
                        item['wheel_metadata']={n:z.read(n).decode(errors='replace') for n in z.namelist() if n.endswith('.dist-info/WHEEL') or n.endswith('.dist-info/METADATA')}
        except Exception as e:item.update(status='FETCH_OR_VALIDATION_FAILED',error=repr(e))
        (OUT/'target-dependencies.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    result['closure']='BLOCKED_SOURCE_BUILD_OR_TARGET_IMPORT_VALIDATION'
    (OUT/'target-dependencies.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({n:x['status'] for n,x in result['packages'].items()}))
if __name__=='__main__':main()
