"""Post-process explicitly supplied instrument data, never fabricate acquisition."""
import argparse,csv,hashlib,json,math
from pathlib import Path
def power(rows,meta):
    if meta.get('measurement_domain')!='BOARD' or meta.get('power_boundary')!='BOARD_DC_INPUT_INCLUDING_AUDIO_AND_FAN' or not meta.get('instrument_id') or not meta.get('calibration_record'):raise ValueError('Instrument/boundary/calibration required')
    values=[tuple(float(r[k]) for k in ('time_s','voltage_v','current_a')) for r in rows]
    if len(values)<2 or not all(all(math.isfinite(x) for x in r) and r[1]>0 and r[2]>=0 for r in values):raise ValueError('Invalid samples')
    if any(b[0]<=a[0] for a,b in zip(values,values[1:])):raise ValueError('Nonmonotonic samples')
    joules=sum((b[0]-a[0])*(a[1]*a[2]+b[1]*b[2])/2 for a,b in zip(values,values[1:]))
    duration=values[-1][0]-values[0][0]
    return {'interval_s':duration,'energy_j':joules,'mean_w':joules/duration,'samples':len(values),'not_idle_subtracted':True,'acquisition_validity':'REQUIRES_INSTRUMENT_REVIEW'}
def acoustic(meta):
    required=['recording_sha256','calibration_record','input_end_sample','first_effective_output_sample','sample_rate_hz','reviewer']
    if any(meta.get(k) is None or meta.get(k)=='' for k in required):raise ValueError('No acoustic result without capture, calibration and reviewed onset')
    rate=meta['sample_rate_hz'];start=meta['input_end_sample'];end=meta['first_effective_output_sample']
    if not all(type(x)is int for x in (rate,start,end)) or rate<=0 or start<0 or end<start:raise ValueError('Invalid synchronized sample positions')
    return {'first_effective_sound_latency_ms':(end-start)*1000/rate,'method':'MANUALLY_REVIEWED_SAME_CAPTURE_SAMPLE_CLOCK','playback_submit_is_not_onset':True}
def main():
    p=argparse.ArgumentParser();p.add_argument('kind',choices=['power','acoustic']);p.add_argument('--metadata',type=Path,required=True);p.add_argument('--csv',type=Path);p.add_argument('--recording',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    meta=json.loads(a.metadata.read_text())
    if a.kind=='power':
        if not a.csv:raise ValueError('Actual CSV required')
        r=power(list(csv.DictReader(a.csv.open())),meta);r['raw_sha256']=hashlib.sha256(a.csv.read_bytes()).hexdigest()
    else:
        if not a.recording or hashlib.sha256(a.recording.read_bytes()).hexdigest()!=meta.get('recording_sha256'):raise ValueError('Actual authorized capture/hash required')
        r=acoustic(meta)
    r['metadata']=meta
    with a.out.open('x') as f:json.dump(r,f,indent=2)
if __name__=='__main__':main()
