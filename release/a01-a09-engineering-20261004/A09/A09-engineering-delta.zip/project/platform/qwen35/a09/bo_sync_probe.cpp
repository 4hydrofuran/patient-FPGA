// Synchronous BO API timing only. No kernel, xclbin load, DDR stress or AXI claim.
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <sys/utsname.h>
#include <unistd.h>
static uint64_t number(const char* s) {
  std::string v(s); if(v.empty()||v.find_first_not_of("0123456789")!=std::string::npos)throw std::invalid_argument("unsigned decimal required");
  return std::stoull(v);
}
static double ms(std::chrono::steady_clock::time_point a,std::chrono::steady_clock::time_point b){return std::chrono::duration<double,std::milli>(b-a).count();}
int main(int argc,char**argv){
  xrt::device* dev=nullptr; xrt::bo* bo=nullptr; bool sync_started=false;
  try {
    struct utsname host{};uname(&host);
    if(argc!=5 || std::string(host.machine)!="aarch64" || !std::getenv("A1_BOARD_LEASE"))throw std::runtime_error("ARM64 authorized lease wrapper required; args=device bank bytes repeats");
    const auto device=number(argv[1]),bank=number(argv[2]),bytes=number(argv[3]),repeats=number(argv[4]);
    if(device>15||bank>255||bytes<4096||bytes>16*1024*1024||bytes%4096||repeats<1||repeats>100)throw std::invalid_argument("bounded profile violation");
    dev=new xrt::device(static_cast<unsigned>(device));
    const auto begin=std::chrono::steady_clock::now();
    bo=new xrt::bo(*dev,static_cast<size_t>(bytes),xrt::bo::flags::normal,static_cast<unsigned>(bank));
    const auto allocated=std::chrono::steady_clock::now();auto p=bo->map<uint8_t*>();
    std::cout<<"{\"event\":\"allocated\",\"bytes\":"<<bytes<<",\"bank\":"<<bank<<",\"allocation_ms\":"<<ms(begin,allocated)<<"}"<<std::endl;
    for(uint64_t r=0;r<repeats;++r){
      for(uint64_t i=0;i<bytes;++i)p[i]=static_cast<uint8_t>((i*17+r)%251);
      sync_started=true;auto a=std::chrono::steady_clock::now();bo->sync(XCL_BO_SYNC_BO_TO_DEVICE,bytes,0);
      auto b=std::chrono::steady_clock::now();bo->sync(XCL_BO_SYNC_BO_FROM_DEVICE,bytes,0);auto c=std::chrono::steady_clock::now();sync_started=false;
      for(uint64_t i=0;i<bytes;++i)if(p[i]!=static_cast<uint8_t>((i*17+r)%251))throw std::runtime_error("BO persistence check failed");
      std::cout<<"{\"event\":\"sync\",\"iteration\":"<<r<<",\"payload_bytes_each_direction\":"<<bytes
        <<",\"to_device_ms\":"<<ms(a,b)<<",\"from_device_ms\":"<<ms(b,c)
        <<",\"measured_axi_bytes\":null,\"kernel_executed\":false,\"method\":\"HOST_BO_SYNC_API_NOT_PL_LOOPBACK\"}"<<std::endl;
    }
    delete bo;delete dev;return 0;
  }catch(const std::exception&e){
    std::cerr<<e.what()<<std::endl;
    if(sync_started){std::cerr<<"QUIESCENCE_UNPROVED retaining device/BO ownership; operator recovery required"<<std::endl;for(;;)pause();}
    delete bo;delete dev;return 2;
  }
}
