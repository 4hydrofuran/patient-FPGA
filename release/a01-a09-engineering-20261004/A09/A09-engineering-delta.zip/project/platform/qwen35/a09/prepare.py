"""Preserve only A-owned touched inputs; no scan of other members."""
import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[3];out=root/'eval/qwen35/a09/before';out.mkdir(parents=True,exist_ok=False)
files=['runtime/qwen35_w4a8/CMakeLists.txt','runtime/qwen35_w4a8/main.cpp','system_qwen35/app/native_w4a8.py','system_qwen35/app/audio_adapter.py',
 'system_qwen35/app/checking.py','system_qwen35/app/default_e2e/service.py','system_qwen35/app/default_e2e/__main__.py','system_qwen35/app/default_e2e/resources.py',
 'docs/PROJECT_STATUS.json','docs/status/A.md','docs/DESIGN_GAP.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md']
identity={}
for name in files:
    p=root/name;d=out/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);identity[name]=hashlib.sha256(p.read_bytes()).hexdigest()
cmd=[]
for argv in (['git','status','--short'],['git','rev-parse','HEAD']):
    r=subprocess.run(argv,cwd=root,capture_output=True,text=True);cmd.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
(out/'snapshot.json').write_text(json.dumps({'files':identity,'commands':cmd},ensure_ascii=False,indent=2))
print(json.dumps({'preserved':len(files),'BOARD':'NOT_TESTED'}))
