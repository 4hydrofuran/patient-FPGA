"""Configuration/arithmetic rejection tests, never simulated BOARD results."""
import importlib.util,json,unittest
from pathlib import Path
def module(name):
    s=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
b=module('board_probe')
class Preboard(unittest.TestCase):
    def setUp(self):
        self.p={'schema':'A09_BO_PROBE_V1','status':'VERIFIED_ON_BOARD','enabled':True,'probe':'/test-only/probe',
          'board_profile':'/test-only/board.json','memory_topology':'/test-only/topology.json',
          'board_profile_sha256':'a'*64,'memory_topology_sha256':'b'*64,'probe_sha256':'c'*64,'registry_sha256':'d'*64,
          'device_index':0,'memory_group':0,'bytes':4096,'max_safe_probe_bytes':8192,'repeats':2,'recovery_reviewed':True}
    def test_pending_refused(self):
        with self.assertRaises(ValueError):b.validate(json.loads((b.ROOT/'config/qwen35/bo_probe.pending.json').read_text()))
    def test_plan_only(self):self.assertEqual(b.validate(self.p),['/test-only/probe','0','0','4096','2'])
    def test_bounds(self):
        for key,v in [('bytes',4095),('bytes',12288),('bytes',True),('memory_group',-1),('repeats',101),('recovery_reviewed',False),('probe_sha256',None),('probe','relative'),('enabled',False)]:
            with self.subTest(key=key,v=v),self.assertRaises(ValueError):b.validate(dict(self.p,**{key:v}))
    def test_missing_identity(self):
        for k in ('registry_sha256','board_profile_sha256','memory_topology_sha256'):
            p=dict(self.p);p.pop(k)
            with self.assertRaises(ValueError):b.validate(p)
if __name__=='__main__':unittest.main()
