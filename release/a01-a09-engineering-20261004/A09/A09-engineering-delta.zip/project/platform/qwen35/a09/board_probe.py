"""Validated profile -> central board lease -> bounded synchronous BO probe.

Default pending profile refuses even --plan. This is not a boot/PL acceptance tool.
"""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def validate(p):
    if p.get('schema')!='A09_BO_PROBE_V1' or p.get('status')!='VERIFIED_ON_BOARD' or p.get('enabled') is not True:raise ValueError('DEPLOYMENT_PENDING_BOARD')
    for key in ('board_profile_sha256','memory_topology_sha256','probe_sha256','registry_sha256'):
        v=p.get(key)
        if not isinstance(v,str) or len(v)!=64 or any(c not in '0123456789abcdef' for c in v):raise ValueError('Reviewed identity/hash required: '+key)
    for key,lo,hi in [('device_index',0,15),('memory_group',0,255),('bytes',4096,16777216),('repeats',1,100),('max_safe_probe_bytes',4096,16777216)]:
        if type(p.get(key)) is not int or not lo<=p[key]<=hi:raise ValueError('Bounded value required: '+key)
    if p['bytes']%4096 or p['bytes']>p['max_safe_probe_bytes']:raise ValueError('Memory range/size not approved')
    for key in ('probe','board_profile','memory_topology'):
        if not isinstance(p.get(key),str) or not Path(p[key]).is_absolute():raise ValueError('Explicit input path required: '+key)
    if p.get('recovery_reviewed') is not True:raise ValueError('Recovery review required')
    return [p['probe'],*[str(p[k]) for k in ('device_index','memory_group','bytes','repeats')]]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    a=argparse.ArgumentParser();a.add_argument('--profile',type=Path,required=True);a.add_argument('--registry',type=Path);a.add_argument('--output',type=Path);a.add_argument('--execute',action='store_true');x=a.parse_args()
    p=json.loads(x.profile.read_text());cmd=validate(p)
    if not x.execute:print(json.dumps({'argv':cmd,'execution':'NOT_EXECUTED','BOARD':'NOT_TESTED'}));return 0
    if not x.registry or not x.output or x.output.exists():raise ValueError('Registry and new output required')
    if sha(x.registry)!=p['registry_sha256'] or any(sha(p[k])!=p[k+'_sha256'] for k in ('probe','board_profile','memory_topology')):raise ValueError('Input identity mismatch')
    return subprocess.call([sys.executable,str(ROOT/'platform/a1/lease.py'),'--registry',str(x.registry),'run','--log',str(x.output),'--',*cmd])
if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,KeyError) as e:print(json.dumps({'status':'REFUSED','error':str(e),'BOARD':'NOT_TESTED'}));raise SystemExit(2)
