"""Two real bounded CPU/voice checks, never another 200-round/soak run."""
import json,os,sys
from pathlib import Path
from system_qwen35.app.default_e2e.service import Service
from system_qwen35.app.default_e2e.policy import HardwareUnavailable
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
fixture=json.loads(Path(sys.argv[2]).read_text())[0]
rows=[]
for mode in ('cpu_same_math','no_hardware'):
    s=Service(out/mode,mode=mode,native_manifest='modules/linear_A/manifest.a09.json')
    try:
        r=s.turn(wav=fixture['wav'],synthetic_reference=fixture['text']) if mode=='cpu_same_math' else s.turn(text='有没有气短？')
        rows.append({'mode':mode,'status':r['status'],'answer_source':r['answer_source'],'actual_backend':r['actual_backend'],
                     'answer':r.get('application',{}).get('text'),'error':r.get('error'),'spool_bytes':r['spool_after_bytes']})
    finally:s.close()
try:Service(out/'must-not-exist',mode='fpga_required')
except HardwareUnavailable:hardware_refusal=not (out/'must-not-exist').exists()
else:raise AssertionError('Unexpected hardware success')
result={'domain':'PC_REAL_MODELS_OFFLINE_NETNS','rounds':rows,'fpga_required_refused_before_init':hardware_refusal,
        'network_namespace':os.readlink('/proc/self/ns/net'),'microphone':'NOT_TESTED_THIS_INCREMENT','human_review':'NOT_TESTED_THIS_INCREMENT',
        'acoustic_onset':None,'BOARD':'NOT_TESTED'}
(out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
assert hardware_refusal and all(r['status']=='COMPLETED' and r['answer_source']=='MODEL' and r['actual_backend']=='CPU_REFERENCE' and r['spool_bytes']==0 for r in rows)
