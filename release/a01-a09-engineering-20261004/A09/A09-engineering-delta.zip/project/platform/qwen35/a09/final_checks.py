"""Bounded closeout checks, no repeated inference or long-run soak."""
import hashlib,importlib.util,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];TREE=Path('/home/member-a/qwen35-a09/clean-v1/project');WORK=TREE.parent
OUT=ROOT/'eval/qwen35/a09/final';OUT.mkdir(exist_ok=False)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
# No binary rebuild: only copied Python deployment/test entries changed since snapshot.
for name in ['platform/qwen35/a09/test_deploy.py','platform/qwen35/a09/measurements.py','platform/qwen35/a09/deploy.py']:
    shutil.copy2(ROOT/name,TREE/name)
budget=ROOT/'docs/plan_qwen35/KV260_Qwen35_A_详细设计增强任务包_20261002/KV260_Qwen35_A_设计增强包_20261002/tools/design_budget.py'
shutil.copy2(budget,TREE/'platform/qwen35/a09/design_budget.py')
rows=[];python='/home/member-a/qwen35-a09/venv-v1/bin/python';env=dict(os.environ,PYTHONPATH=str(TREE))
def run(args,expected=0):
    r=subprocess.run(['unshare','-Urn',python,*args],cwd=TREE,env=env,capture_output=True,text=True)
    rows.append({'argv':['unshare','-Urn',python,*args],'cwd':str(TREE),'exit_code':r.returncode,'expected_exit_code':expected,'stdout':r.stdout,'stderr':r.stderr})
    save(OUT/'commands.json',rows)
    if r.returncode!=expected:raise RuntimeError('Evidence retained: '+str(args))
run(['scripts/release/check_contracts.py'])
run(['scripts/release/qwen35_config.py'])
run(['-m','unittest','system_qwen35.app.test_a02','system_qwen35.app.test_capture','system_qwen35.app.default_e2e.test_policy','system_qwen35.app.default_e2e.test_review','modules.voice_A.test_voice'])
run(['platform/qwen35/a09/test_deploy.py'])
for t in ('1','8'):run(['platform/qwen35/a09/design_budget.py','--config','artifacts/qwen35-0.8b/source/config.json','--t',t])
run(['platform/qwen35/a09/deploy.py','health','--config','config/qwen35/deploy.pc.json'])
bad=json.loads((TREE/'config/qwen35/deploy.pc.json').read_text());bad['domain']='BOARD';save(OUT/'board-refusal-input.json',bad)
run(['platform/qwen35/a09/deploy.py','validate','--config',str(OUT/'board-refusal-input.json')],2)
run(['-m','system_qwen35.app.default_e2e','--output',str(OUT/'must-not-exist'),'--mode','fpga_required'],2)
assert not (OUT/'must-not-exist').exists()
# Inventory only the received B manifest and its explicitly named sources/header/config.
source=ROOT/'hw/linear_A/KERNEL_SOURCE.json';b=json.loads(source.read_text());base=ROOT/b['received_directory'].replace('\\','/')
candidate={'B':{'receipt_sha256':sha(source),'accepted':False,'provider_state':b['status'],'actual_xo':b['xo_path'],'variants':{}},'C':{'status':'NOT_RECEIVED'}}
for variant,data in b['candidates'].items():
    checks={}
    for field in ('source','header','config'):
        p=base/data[field];checks[field]={'path':str(p),'exists':p.is_file(),'actual_sha256':sha(p) if p.is_file() else None,'expected_sha256':data[field+'_sha256']}
        checks[field]['matches']=checks[field]['actual_sha256']==checks[field]['expected_sha256']
    candidate['B']['variants'][variant]=checks
for owner,path in [('B','modules/linear_B/manifest.json'),('C','modules/voice_C/manifest.json')]:
    p=ROOT/path
    if p.exists():
        manifest=json.loads(p.read_text());candidate[owner]['optional_manifest']={'path':path,'sha256':sha(p),'contract_matches':manifest.get('contract_sha256')=='83bd402b39350710d8689d50f79296e9625e9c75ccb0ecee145f08067c4ee3b6','status':'STAGED_UNVERIFIED_NOT_LOADED'}
    else:candidate[owner]['optional_manifest']='NOT_RECEIVED'
save(OUT/'candidates.json',candidate)
# Check current C++ CPU files against already cross-compiled A07 source seals where available.
old=json.loads((ROOT/'modules/linear_A/manifest.a08.json').read_text())['source_sha256']
same={n:sha(ROOT/n)==s for n,s in old.items()};save(OUT/'native-source-continuity.json',same)
assert all(same.values())
for name in ['commands.json','export-comparison.json','source-provenance.json','llama-project.patch']:
    shutil.copy2(WORK/name,OUT/('clean-'+name))
for f in WORK.glob('command-*'):shutil.copy2(f,OUT/f.name)
save(OUT/'summary.json',{'PC':'PASS_BOUNDED_SOFTWARE_AND_CONFIG_CHECKS','candidate_loading':'NONE','BOARD':'NOT_TESTED','Csim':'NOT_TESTED_THIS_INCREMENT','Cosim':'NOT_TESTED','implementation':'NOT_TESTED','cross_build':'REUSED_A07_UNCHANGED_CPP_ONLY','compile':'CLEAN_PC_BUILD_PASS','weights':'145_FILES_IDENTICAL','network':'ISOLATED_NETNS','inference_repeated':False})
print(json.dumps({'status':'PASS','commands':len(rows),'BOARD':'NOT_TESTED'}))
