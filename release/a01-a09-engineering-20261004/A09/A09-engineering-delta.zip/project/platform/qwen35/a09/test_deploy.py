"""Pure config/control tests. No model or hardware success is simulated."""
import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('deploy',Path(__file__).with_name('deploy.py'));d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
from system_qwen35.app.default_e2e.resources import spool_usage
class DeployTests(unittest.TestCase):
    def setUp(self):self.c=json.loads((ROOT/'config/qwen35/deploy.pc.json').read_text())
    def test_legal_config_not_board(self):self.assertEqual(d.validate(self.c,ROOT,files=False)['BOARD'],'NOT_TESTED')
    def test_wrong_configs_refused(self):
        for key,value in [('domain','BOARD'),('architecture','aarch64'),('mode','fpga_required'),('device_path','/dev/sda'),('flash_allowed',True),('model_revision','old'),('native_manifest','../../etc/passwd')]:
            with self.subTest(key=key):
                c=dict(self.c);c[key]=value
                with self.assertRaises(ValueError):d.validate(c,ROOT,files=False)
    def test_paths(self):
        for path in ('../x','/etc/passwd','a//b','a/./b','a\\b'):
            with self.assertRaises(ValueError):d.safe(ROOT,path)
    def test_spool_count_and_removed_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'out').mkdir();(p/'out/a').write_bytes(b'abc')
            self.assertEqual(spool_usage(p),(3,1,0))
            (p/'out/a').unlink();(p/'out').rmdir();self.assertEqual(spool_usage(p),(0,0,0))
            self.assertEqual(spool_usage(p/'removed'),(0,0,1))
    def test_measurement_arithmetic_not_board_measurement(self):
        spec=importlib.util.spec_from_file_location('measurements',Path(__file__).with_name('measurements.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        meta={'measurement_domain':'BOARD','power_boundary':'BOARD_DC_INPUT_INCLUDING_AUDIO_AND_FAN','instrument_id':'UNIT_TEST_ONLY','calibration_record':'SYNTHETIC_UNIT_TEST_NOT_VALID_CALIBRATION'}
        rows=[{'time_s':0,'voltage_v':12,'current_a':1},{'time_s':2,'voltage_v':12,'current_a':2}]
        self.assertEqual(m.power(rows,meta)['energy_j'],36)
        with self.assertRaises(ValueError):m.power(rows[::-1],meta)
        with self.assertRaises(ValueError):m.power(rows,{})
        with self.assertRaises(ValueError):m.acoustic({})
if __name__=='__main__':unittest.main()
