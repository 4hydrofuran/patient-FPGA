"""Install only locked local wheels into a new Python 3.10 x86_64 venv."""
import hashlib,json,subprocess,sys,zipfile
from pathlib import Path
wheelhouse=Path(sys.argv[1]).resolve();target=Path(sys.argv[2]).resolve();receipt=Path(sys.argv[3])
if target.exists() or receipt.exists():raise ValueError('Fresh target/evidence required')
packages={};licenses={}
for p in sorted(wheelhouse.glob('*.whl')):
    with zipfile.ZipFile(p) as z:
        meta=[n for n in z.namelist() if n.endswith('.dist-info/METADATA')]
        if len(meta)!=1:raise ValueError('Wheel metadata')
        text=z.read(meta[0]).decode();name=next(x[6:] for x in text.splitlines() if x.startswith('Name: '));version=next(x[9:] for x in text.splitlines() if x.startswith('Version: '))
        packages[name]={'version':version,'wheel':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        licenses[name]={'metadata':text,'embedded_license_files':[n for n in z.namelist() if any(k in n.lower() for k in ('license','copying','notice'))]}
if len(packages)!=9:raise ValueError('Expected nine locked wheel distributions')
rows=[]
def run(argv):
    r=subprocess.run(argv,capture_output=True,text=True);rows.append({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    receipt.parent.mkdir(parents=True,exist_ok=True)
    receipt.write_text(json.dumps({'domain':'PC_OFFLINE_INSTALL','packages':packages,'licenses':licenses,'commands':rows,'BOARD':'NOT_TESTED'},indent=2))
    if r.returncode:raise RuntimeError('Offline install failed; receipt retained')
run([sys.executable,'-m','venv',str(target)])
run([str(target/'bin/python'),'-m','pip','install','--no-index','--no-deps',*[str(wheelhouse/v['wheel']) for v in packages.values()]])
run([str(target/'bin/python'),'-m','pip','check'])
run([str(target/'bin/python'),'-m','pip','freeze'])
print(json.dumps({'status':'PASS','venv':str(target),'distributions':len(packages),'network_required':False,'BOARD':'NOT_TESTED'}))
