# 原始停止样例与断言缺口

`lifecycle/`保留2026-10-04真实首次启停：start退出254，主程序KeyboardInterrupt，trace status仍RUNNING/error=null。进程停止、health、配置选择回滚及日志归档确实执行，但初版测试没有校验逐轮状态，因此其summary中的PASS**不足以作为最终生命周期验收**。不删除或改写原始输出。

修复：活动轮捕获KeyboardInterrupt，发起本服务取消，写CANCELLED/原因、保持未完成时间null，不提交已播历史；初始化阶段中断同样关闭自己已创建的worker。不吞掉普通错误或伪造完成。

新断言：必须得到一个CANCELLED trace、非空原因、played_count=0、声学起点null，CLI退出3明确未完成。只在`lifecycle-v2/`重测真实停止路径，原200/两小时不重复。初始化中断的各微小时隙没有逐个实际注入，不能据此次运行声称全部覆盖。
