# A09 无板收口与部署演练（2026-10-03）

最新续作：此前封存中断记录`INTERRUPTED.json`原样保留。用户授权继续后，已完成3792文件的包审计/压缩以及独立逐文件、清单、tar内容校验，均exit0。归档85,415,371字节，SHA256 `fee8a310088f957d4062a52182bc6357e892584baee2c694a1e4a5955c4c3e21`。没有重复编译、权重导出或推理压测；只是源码/依赖候选封存完成，不升级硬件或医学验收。

## 结论

`PARTIAL_PC_REPRODUCTION_PASS_DEPLOYMENT_NOT_READY`。
默认电脑链的清洁源码构建、权重重导出、离线Python依赖与定向真模型复测已完成；A09整体不签PASS：A06/A07硬件链、启动配套、BO执行测量入口、系统/ARM语音安装闭包尚缺。BOARD全部NOT_TESTED。

没有重跑200轮或恢复用户停止的两小时soak；无新录音、刷写、登录、购买、推送或B/C代签。旧工程/WSL/权重/失败保留，未升级2026.1。分支`member-a/qwen35-a00-20261002`；原HEAD `ed9df6c7152c908d512ecd1f871583182823e1eb`，无新commit。

## 实际改动

- `runtime/qwen35_w4a8/CMakeLists.txt`：ROOT从当前项目推导，可显式指定；未改C++数学和状态源码。
- `system_qwen35/app/`：受限A09 manifest、相对路径、voice Python配置；普通WAV人工ticket确认接入Service/CLI；spool目录消失计数；两个完整肯定句的检查器修复，否定/未知/额外事实/漏答仍拒绝。
- `platform/qwen35/a09/`：独立构建/复现/定向测试、部署管理与原lease封装、计量后处理、打包和验收记录。
- `config/qwen35/deploy.pc.json`：设备路径空、禁刷写，BOARD/未验证硬件拒绝，内存字段null。
- `release/default_preboard/`：源码/wheel候选包、部署/物理连接清单、PREBOARD_CHECKLIST、论文方法/实验矩阵/答辩问题与NA图表。

## 实际执行及退出码

全部argv/cwd/stdout/stderr见本目录JSON和`final/commands.json`，不是只写计划：

| 命令/入口 | exit | 说明 |
|---|---|---|
| 开工/干净目录/收尾 `check_contracts.py`、`qwen35_config.py` | 0 | 旧/新契约保护通过 |
| `build_queue.py submit/run-next` → `clean_rehearsal.py` | submit0 / job1 | 4条cmake配置/编译及导出均0，随后缺3份测试输入而失败 |
| `python -m quant.export_w4a8 --output <clean>/models/sidecar_A/qwen35-v1` | 0 | 72矩阵、144payload+manifest共145hash一致 |
| `unshare -Urn python3 install_offline.py …` | 0 | 9固定wheel新venv安装、pip check |
| `finish_clean.py` | 1 | 补齐测试输入后规则通过；真实no_hardware因“是的，我有气短。”误拦为模板，保留断言失败 |
| 新检查器反例修复前 | 2 | 5/6，通过负例，正例失败 |
| `targeted_retest.py` | 0 | 两组各6反例通过；只复测一轮no_hardware，MODEL |
| `final_checks.py` | 0 | 75+5单测、预算T1/T8、合法/错误配置、候选hash |
| `plot_results.py` | 0 | PC/BOARD各PDF与300dpi PNG，缺值NA |
| `package.py`首次 | 1 | 白名单安全检查拒绝上游非运行必需`.key`文档，未忽略错误 |
| `package_resume.py`首次 | 1 | 进一步拦截19个上游词表GGUF测试fixture，非默认运行输入 |
| 包修复/封存 | null / INTERRUPTED | v2命令只留下RESERVED_NOT_COMPLETED；源文件及排除副本保留，无最终包/hash |
| `package_resume.py` v3续作 | 0 | 生成3792项SHA256清单、85.4MB源码/依赖候选归档和package.json |
| `verify_package.py` | 0 | 独立核验目录清单、文件hash、归档hash、tar逐成员hash/大小；拒绝重复路径和特殊文件 |

构建位置`/home/member-a/qwen35-a09/clean-v1`；从固定upstream提取树+已有A05补丁重新编译，不复用旧库。不谎称source-v3有.git；源码差异、上游文件hash和patch保留。队列失败进程已退出并核验FAILED receipt后才归档marker。

模型revision `2fc06364715b967f1860aea9cf38778875588b17`，llama commit `81e39ad34368329b5db77620721510fd91107e80`。原BF16→W4A8重导出payload140378112字节；manifest SHA256仍为`cdb2a04dbd95d426ea8967cda0adb219a769d3630107a2af72d6ddf2d5285688`。不是从GGUF再量化。

## 分域测试

| 域 | 结果与边界 |
|---|---|
| PC软件 | 最终75应用/语音/控制+5部署/计量方法PASS，两组各6检查器反例PASS |
| PC真模型 | 首轮断网ASR→S1→检查→TTS→播放MODEL；无硬件模式原TEMPLATE反例保留、仅一轮修复后MODEL；实际CPU后端及72权重可查trace |
| PC离线安装 | 新venv9wheel `--no-index --no-deps`、pip check，隔离网络命名空间；未全局安装 |
| PC构建/导出 | 从源码实际构建、145文件重现PASS；只做一次构建/导出 |
| Csim | 本轮NOT_TESTED，保留原A06三版各61条有效证据 |
| Cosim/综合/实现/新核目标链接 | 本轮NOT_TESTED，不升级A06/A07 |
| ARM64交叉 | 复用A07已有136单元有效证据；生产C++hash未变，本轮未再交叉构建 |
| ARM执行/BOARD/功率/声学/BO带宽 | NOT_TESTED，数值null |
| 医学/教师/隔离300题 | 未完成，软件规则通过不等于医学有效 |

WAV小样PC采样峰值PSS1,032,230KiB、RSS1,061,772KiB；修复后no_hardware为PSS1,014,068KiB、RSS1,043,552KiB。采样器error均null，但不是长期竞态证明或KV260预算。不新增电脑对Jetson/FPGA性能优劣结论。

人工确认新UI没有再请用户实操，不伪造yes；服务管理活进程停止/真实回滚未验证；声学起点仍null。CPU软件拒绝fpga_required发生在输出目录/模型初始化前，没有隐式回退。B仅核9个指定文件hash全部一致，XO仍null；C未收到、不扫整仓。

## 交付与未决

`release/default_preboard/source-bundle`是源码/依赖候选，不含模型/语音权重、真实录音、令牌、Xilinx许可或系统/WSL镜像。Matcha/Baker非商业限制保留，不自动发布。系统编译器、OpenSSL/OpenMP/glibc/Pulse等沿用宿主，**不是空白OS/ARM一键安装包**。

先补系统/ARM语音依赖安装闭包及BO执行测量入口；硬件侧待选定XO/完整同版证据后再链接。到板先身份、串口、DT/MemTotal/XRT/BO核查，完整启动链/恢复计划明确且有专项授权才刷写。不能把PS DDR表项2GB或物理容量直接当预算。

证据入口`final/`、`targeted-v3/`、`clean-tests-v2/`、`package-verification.json`；前置和物理操作见`PREBOARD_CHECKLIST.md`、`DEPLOYMENT.md`。包哈希见package.json，最终源/报告证据封存见files.sha256.json及seal-command.json实际成功记录。旧失败不删，NA不改0；硬件与系统/ARM语音缺口仍需后续工作，不重跑已有压测。
