# A09 无板收口与部署演练增量

日期：2026-10-04。范围：成员A当前Qwen3.5工程；未提交、未推送、未录音、未刷写或调用板卡。

结论：**PASS_PC_PREBOARD_REHEARSAL；DEPLOYMENT_PENDING_BOARD**。本轮无板交付和有界演练完成，不是所有产品/质量关口通过，更不是KV260可启动或部署成功。平台组合、实际系统依赖及板端内存仍未验证。旧包、旧失败、脏工作树全部保留。

## 实际变更

- `platform/qwen35/a09/`：BO探针/门禁/测试、固定目标依赖获取与审计、MarkupSafe SDK构建、目标离线安装校验、版本化发布和独立包验证、真实生命周期演练、连续性审计。
- `config/qwen35/bo_probe.pending.json`：默认禁用，设备/内存身份待核验；不假设4GB可分配。
- `system_qwen35/app/default_e2e/service.py`、`app/native.py`、`app/audio_adapter.py`：SIGINT取消及初始化中断的自有worker收尾；未改模型数学、图、公共接口或B核。
- `release/default_preboard/20261004-v2/`：源码/依赖候选、清单、部署与安装说明、论文/答辩/空图表。独立版本，不覆盖旧封存包。
- `docs/PROJECT_STATUS.json`、`docs/status/A.md`及本轮交接：当前结果与历史分域记录。

## 实际命令与退出码

完整argv、cwd、stdout/stderr、时间、退出码在本目录各`*-command.json`；嵌套PC命令在`clean-commands.json`和`lifecycle-v2-commands.json`。外层使用`platform/a1/record.py`，Linux为现有KV260-A-2204。主要命令如下（路径均相对当前仓库）：

| 命令/入口 | 退出码 | 含义 |
|---|---:|---|
| `scripts/release/check_contracts.py`、`qwen35_config.py` | 0 | 旧保护及新契约配置通过 |
| `refresh.py prepare` | 0 | 原3792文件/归档验证；全新隔离源码目录，私有资产显式复用 |
| `refresh.py tests` | 0 | 83单测、5部署、4门禁，真实断网WAV；最初生命周期断言不足另列，不以总exit0掩盖 |
| `refresh.py retry-lifecycle` | 0 | 修复后83单测及真实启停通过；模型子进程退出3代表取消，不是回答完成 |
| 通过唯一构建队列运行`build_bo_probe.sh` | 0 | 实际2026.1 SDK Cortex-A53 C++/XRT编译和readelf；未运行目标文件 |
| `target_dependencies.py`、`build_markupsafe.sh`、`arm_inputs.py` | 0 | 原版本9个目标依赖准备、真实C扩展交叉编译、146 AArch64 ELF静态检查 |
| pip目标`--dry-run`初试 | 2 | 现有pip不支持参数，失败保留；未升级pip |
| pip `download --no-index --only-binary=:all:`指定cp312/aarch64/固定版本 | 0 | 改用离线解析/复制；不是目标安装 |
| `install_target.py`默认输入核验 | 0 | 9 wheel hash通过 |
| `install_target.py --install`在PC | 2（预期） | 错误架构/租约拒绝，目标venv未创建 |
| `board_probe.py`默认pending、`fpga_required`无板 | 2（预期） | 拒绝启动，不回退成功 |
| `design_budget.py --t 1`及`--t 8` | 0 | 预算方法通过，不是实测结果 |
| `candidate_receipts.py`、`closeout_audit.py` | 0 | 最小候选审计、145权重+6二进制+68源码连续性、4份原构建日志复制 |
| `paper/plot_results.py` | 0 | PC/BOARD PDF与300dpi PNG；数据NA，不填0 |
| `refresh.py seal`、`verify_package.py --release ...20261004-v2` | 0、0 | 最终3835文件清单、归档SHA和逐成员独立校验通过，见`package-verification.json` |

更新后的干净目录：`/home/member-a/qwen35-a09/refresh-20261004-v2/project`。新Python测试全部`unshare -Urn`网络隔离。原生源码未变，复用上次真实干净CMake构建；本次没有把复用写成新构建。145个导出文件再次与原/旧干净/新干净目录逐项hash相同，包含manifest，payload仍140378112字节；未重做同版导出。

## 分域结果

| 域 | 结果 |
|---|---|
| PC规则/管理 | PASS 83+5+4；修复后再次83。重复方法不累计成独立覆盖 |
| PC真实离线模型 | PASS 1个合成WAV，经ASR→S1 Qwen→检查器→TTS→播放提交；MODEL、CPU_REFERENCE、COMPLETED，无新录音 |
| PC真实停止 | PASS 模型ready后停止，CANCELLED/非空原因，played_count=0，首声时间null；配置回滚及日志归档，不是硬件恢复 |
| PC既有200轮 | 复用A08封存133 MODEL/67 TEMPLATE；本轮不重复，不能当医学准确率 |
| Csim/Cosim/综合 | 本轮NOT_TESTED；引用A06已验收同版证据，不制造新增仿真 |
| 实现/目标链接 | 本轮NOT_TESTED；复用A07真实2026.1 kv260_base布局布线，保留警告 |
| ARM64交叉构建 | PASS本轮BO同步探针与MarkupSafe扩展；A07完整CPU/XRT/host证据复用 |
| ARM执行/BOARD/BO可达预算/功耗/真实声学 | NOT_TESTED/null |

BO探针只记录host BO分配/双向sync API时间及逻辑payload；没有调用PL核，不能称AXI实测带宽或PL回环通过。未验证静止的异常保留所有权，不自动重载或静默CPU回退。

## 失败、未测与边界

1. 初次真实SIGINT退出254、trace遗留RUNNING。原`lifecycle/`完整保留；初次summary的PASS不足以验收，解释见`LIFECYCLE_DEFECT.md`。修复后只补该路径，`lifecycle-v2/`明确通过。初始化中断各微小时隙未穷举。
2. pip旧版不支持dry-run，原错误保留；用其支持的离线download解析替代，不升级依赖。
3. ARM轮子架构/SONAME静态检查和SDK编译不证明真实rootfs动态符号、ISA、音频服务或导入成功。启动链/DT/内核/固件/zocl/XRT须实际核对，任何缺件继续阻断。
4. 医学审核、独立最终300问答、自然语音质量、实际声学起点/功率、设备断连及Pulse硬超时仍未验收。不以此次单样例或静态任务包通过替代。
5. C未收到不阻断默认准备；B仅核已知manifest/XO/XML，不递归扫描其工程，不代B/C签核。没有新联合签核。
6. P2快照/全并发/推测首句等NOT_IMPLEMENTED/禁用。本阶段未擅自扩大范围。

## 交付与下一步

新交付入口`release/default_preboard/20261004-v2/README.md`；具体hash在该目录`package.json`和本目录`package-verification.json`。封存不含权重、真实录音、许可证/密钥、SD/WSL镜像。模型/语音锁与原许可保留，Matcha/Baker非商业约束不消失，禁止自动公开权重。

归档150732021字节，3835个清单文件。SHA256：`aafd26460771a84ef98b33d923dd7ef1d854c6a53a7b2b799825b7faf79af990`。独立验证同时校验磁盘文件清单和tar每个成员、路径/类型、归档hash；未执行归档中的代码，不等于安装成功。旧归档hash仍为`fee8a310088f957d4062a52182bc6357e892584baee2c694a1e4a5955c4c3e21`。

论文先方法后结果，五基线按PC/BOARD分域；FPGA/Jetson速度、能效、体积比较全部尚无实测结论。用academic-plotting流程输出PDF/PNG和NA，不用预算填结果。

下一步仅按用户明确指令进入实际到板流程：物理身份/准确介质与恢复确认→只读采集→核验启动组合/ABI/内存/XRT→中央租约下小额测试。刷写、录音/仪表和恢复动作分别授权。当前停止A09，不启动板测、不推送。
