# A04 专用导出与独立 CPU 参考验收

2026-10-02，成员A。结论：**PASS_PC_A04_NUMERICS_FULL_GRAPH_PENDING_A05**。

本阶段可交付72个可复现sidecar及独立数值参考，不代表完整S1问答质量、SP_LINEAR ABI或FPGA已通过。当前机器原始汇总以`REPORT.v2.json`为准；首次`REPORT.json`、内存采样v1及启动失败保留。

## 1. 身份和范围

- 模型Qwen/Qwen3.5-0.8B revision `2fc06364715b967f1860aea9cf38778875588b17`，原BF16文件1,746,942,600字节，SHA256 `04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696`。
- 固定llama.cpp `81e39ad34368329b5db77620721510fd91107e80`，旧11项可执行/库身份不变。新capture观察post-compute节点，不改变原模型、原入口或图计算。
- 公共契约SHA256 `83bd402b39350710d8689d50f79296e9625e9c75ccb0ecee145f08067c4ee3b6`，不改数学/ABI/fixture。源权重不来自Q4_K_M；embedding/head、attention、视觉及MTP不导出。MLP无bias。
- 当前分支`member-a/qwen35-a00-20261002`，基线commit `ed9df6c7152c908d512ecd1f871583182823e1eb`。保留既有脏树；未commit/push，不读取B/C工程、不录音、不上板。

## 2. 交付与实际体积

新实现`quant/export_w4a8`、`quant/reference`、`platform/qwen35/a04`。产物`models/sidecar_A/qwen35-v1`，复现副本`qwen35-repro-v1`，两份manifest逐字节相同：

`cdb2a04dbd95d426ea8967cda0adb219a769d3630107a2af72d6ddf2d5285688`

| 类型 | 每矩阵形状N×K | 每个W字节 | 每个Sw字节 | 数量 |
|---|---|---:|---:|---:|
| gate/up | 3584×1024，G8 | 1,835,008 | 114,688 | 48 |
| down | 1024×3584，G28 | 1,835,008 | 114,688 | 24 |

实际payload **140,378,112字节（133.875 MiB）**，与设计理论值完全一致。144个二进制均无头、无对齐尾；原模型维度整除，无padding开销。manifest另88,101字节，总产物140,466,213字节；其中每个源tensor/hash、N/K、方向、dtype、布局、文件hash、源码hash与许可均记录。尾块语义由N33/K129测试覆盖，不冒称真实模型有尾块。

## 3. 分域测试

| 测试 | 实测结果 | 原始证据 |
|---|---|---|
| 独立手算/字节/FP32/拒绝 | 210断言通过 | vectors-v1/summary.json，每例输入和gold/CPP输出 |
| 同套ASan+UBSan | 210断言通过；不是420种独立测试 | vectors-sanitize-v1/summary.json |
| 只读加载器/路径/hash/非法元数据 | 6测试方法通过，含多子例 | evidence/loader-tests-v1.json及loader-tests-v1 |
| 原BF16独立C++导出 | 72矩阵W/Sw逐字节匹配，两次生产导出一致 | export-cross-v1/summary.json |
| 真模型采集 | 0/3/4/23层gate/up/down；2模型×12投影×prefill/decode=48 | captures-v1/H0_F16/manifest.json、S0_Q4/manifest.json和原始x/y |
| 真输入同数学CPU | 每个INT32和、FP32输出逐位相同；max_abs=0 | real-v1/summary.json及各cpp/金标文件 |
| Csim/Cosim/综合/实现/交叉构建/BOARD | **NOT_TESTED** | 未执行；不借用旧0.5B/vector-add |

冻结容差`atol=1e-4, rtol=1e-5`未放宽；本次CPU实际达到更严格bit-exact。测试覆盖正负half ties、合法subnormal、非零尺度下溢拒绝、NaN/Inf、保留码-8/-128、全零、跨组Sw、T1..8尾块、短/长buffer、uint64长度溢出前拒绝、恢复溢出、FP32结合顺序。负例实际exit2和输入均保存。

F16/Q4使用既有256token固定诊断提示，4线程CPU、0 GPU，先后加载，分别采最后8个prefill位置和真实1步decode。层0/4是线性注意力、3/23是完整注意力，覆盖3→4切换。样例来自固定A01上下文，不是独立临床测试集。capture仅观察投影，未把新W4A8写入模型图。

## 4. 误差分账和质量定位

| 比较 | 结论 |
|---|---|
| H0高精度F16→S0通用Q4 | 24对真实投影对照，含上游状态差异；quality-diagnostics-v1单列，非本格式误差 |
| 原BF16 FP32复算→本W4A8，同一真实H0输入 | NRMSE 0.062727—0.171426；跨样例最大abs 0.768042 |
| 原BF16 FP32复算→本W4A8，同一真实S0输入 | NRMSE 0.062473—0.171145；跨样例最大abs 0.884117 |
| C++实现→独立Python同数学参考 | 整数及FP32逐位相同，max_abs=0，48/48 |
| 完整图S0→S1 | **NOT_TESTED_A05**，不能靠相似回答跳过 |
| S1→硬件S2 | **NOT_TESTED，误差null**，不填0 |

NRMSE=`||实际-参考||₂ / ||参考||₂`；每例max_abs/RMSE/NRMSE见原JSON。H0是原F16运行库，不冒充纯FP32，另从原BF16对相同x做FP32复算，运行库舍入误差单列。方向由原mapping/offset验证，72独立pack一致；已核查scale、A8和无bias，不存在重复bias。进一步隔离同输入W4-only最大NRMSE0.161955、同权重A8-only0.067714，仅是本固定小样的诊断，不能推论全部质量。

没有高精度敏感层替换、校准、格式变体或容差放宽。A05必须完成全图logits与固定问题质量验证后才决定是否需另立变体范围/hash。

## 5. 性能和内存清单

C++ g++11.4，单线程，`-O3 -fno-fast-math -ffp-contract=off`。32lane连续读并跨T复用；向量化日志证明整数循环实际SIMD。每投影仅一次诊断，不提供p95、可推广加速比或板端速度。

| 单投影时间 | T1（ms） | T8（ms） |
|---|---:|---:|
| C++标量 | 4.955—5.631 | 39.750—44.382 |
| C++tile计算 | 2.565—2.833 | 7.956—8.823 |
| 激活量化 | 0.0147—0.0403 | 0.0466—0.3854 |
| 优化计算+激活量化 | 2.582—2.867 | 8.016—9.155 |
| 文件加载/验证/量化（另外披露） | 67.050—72.668 | 63.872—86.630 |

无需完整重排：运行按导出tile直接读；量化权重只在离线导出做一次。当前CLI用于正确性，每次进程读盘/验证；不代表未来正式运行时每token需重读盘。A05负责持久加载/预分配。Python慢标量从未用于性能基线。

| 内存项 | 实测或逻辑范围 |
|---|---|
| 常驻BO/CMA | null，BOARD未测；不是0字节可用预算 |
| 全部sidecar文件页 | payload133.875 MiB；144只读mmap，触达所有字节，无GGUF/raw权重同进程 |
| 全sidecar加载进程峰值观测 | 173516 KiB ≈169.45 MiB，load-profile-v2；含Python/NumPy、hash临时区与测量开销 |
| 导出进程rusage峰值 | 105720 KiB；单矩阵升FP32/量化/打包，23.597秒 |
| 原GGUF文件页 | capture每次仅一份F16或Q4；先后运行，不同时常驻；load-profile中0 |
| 原BF16文件页 | 1,746,942,600字节是磁盘文件总长；导出按张量读、FP32矩阵14 MiB，不是整文件常驻 |
| 完整重排副本 | load-profile中0；生产导出有单张量临时数组，已计峰值 |
| C++工作区 | Xq=T×Kp，Sx=4T，Y=4T×Np，诊断sum=4T×Np×G；tile栈8×32 INT32和32lane，不分配完整解包权重 |
| A05完整S1页/工作区总预算 | NOT_TESTED，须与原GGUF不再使用的MLP页/其它主干页分开核算 |

初次内存采样v1的rusage早于proc读取，且两种来源数值不同；保留原值。v2取rusage/VmHWM/VmRSS/smaps RSS最大观测173516，原rusage171136也保留，不选择性报小值。上述是电脑进程测量，不是KV260可分配内存。

## 6. 命令、修复和接续

每条完整argv/时间/退出码/stdout/stderr在`C:/Patientqwen/platform/qwen35/a04/evidence/`；阶段源码、数据、记录最终seal为`files.sha256.json`。主要实际命令（WSL源码目录`/mnt/c/Patientqwen`）见导出与参考README，命令原貌及退出码也收录`REPORT.v2.json:commands`。

两次队列构建、两次生产导出、72独立重导、采集、48对照、质量分解、6加载器测试、普通/消毒器向量及内存两次测量均exit0。最初`python -m platform.qwen35.a04.test_vectors`因stdlib platform冲突exit1，在任何向量执行前失败；改显式脚本入口后exit0，原日志不删除。负例expect2并非被隐藏的异常成功。

P2：更强SIMD/多线程、敏感层高精度与校准均未实施，不写收益。下一项A05：正式CPU模块/图接入、全图logits和任务质量、常驻页预算；A04结束不擅自开始。原A03质量、可靠性、声学和教师审核待办继续保留。
