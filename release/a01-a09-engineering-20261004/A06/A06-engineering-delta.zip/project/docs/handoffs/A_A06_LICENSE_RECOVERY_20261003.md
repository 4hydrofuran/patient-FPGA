# A06 官方许可恢复与Csim补测（2026-10-03）

结论：本地许可阻断解除，三版实际Vitis2026.1 Csim通过；A06整体仍`NOT_ACCEPTED_B_DELIVERY_BLOCKED`。不是板测，也不是XO接收通过。

## 许可与安全

用户在官方门户自行完成重新绑定，提供`D:/EdgeDownload/Xilinx (1).lic`。SHA256为`46ef2a17d5100e55d7181a8e9b7acc4d79580852a921cdea6c5eeccb33bf177f`，Host ID `00155dbc2453`与本次WSL eth0一致。新增安装`/home/member-a/.Xilinx/kv260-a-rehost-20261003.lic`，0600，原许可/下载文件不改、不输出签名、不入Git。重试进程显式指定XILINXD_LICENSE_FILE，无全局环境或MAC修改。此前只读diagnostic脚本仍固定检查旧文件，不应用它判断新许可无效。

许可证列出Vivado与HLS功能，但本次仅以实际HLS Csim验证可运行；Vivado综合/实现许可checkout未在本次重测。WSL重启后MAC仍可能变，不能保证永久稳定。

## 命令与退出码

工作仓库`C:/Patientqwen`，WSL `KV260-A-2204`。全部原始argv、cwd、stdout/stderr、时间与退出码保存在`evidence/A06_acceptance/license-rehost-v1/*.json`及`csim-retry-rehost-20261003-v2/*.json`。

- `python3 scripts/release/check_contracts.py`：0。
- `python3 scripts/release/qwen35_config.py`：0。
- `/bin/bash platform/qwen35/a06/install_rehost_20261003.sh`：0，字节hash与当前MAC前后检查，独立新文件安装。
- 共享唯一队列v1：退出1，旧重试器以POSIX路径索引Windows反斜杠清单导致KeyError；未进入仿真，旧证据未更改。确认该任务返回、无存活构建后，只把active.json保留为active.failed-rehost-v1.json，未删失败。
- v2提交：`python3 platform/ra02/build_queue.py submit --owner A --label a06-rehost-20261003-v2 -- /bin/bash /mnt/c/Patientqwen/platform/qwen35/a06/retry_rehost_v2.sh`，0。
- `python3 platform/ra02/build_queue.py run-next`：0；三个`vitis-run --mode hls --csim --config <variant>.cfg --work_dir <unique>/<variant>-csim`均0。
- `summarize_rehost.py`校验每版实际SUMMARY及CSim done with 0 errors：0。
- 队列最终active=null、pending=[]。

v2工作区：`/home/member-a/kv260-build/ra02-coordinator/work/01791003462275424403-A-a06-rehost-20261003-v2-38ad95c0/`。

## 数值与域

baseline/reuse/double各61案例、2,800,022检查，共183案例/8,400,066检查。实际B核源码、A04独立参考、A测试、原配置字节不变；启动前全部test-inputs SHA及244份B文件SHA重新验证。覆盖手算、尾块、跨组scale、两真实shape T1..8、真实权重加合成激活、错误隔离等，与原PC覆盖相同。没有伪装成新采集的真实激活。

PC：此前PASS保留，未重跑；Csim：三版PASS；本次Cosim/综合/实现/交叉构建/BOARD：NOT_TESTED。硬件误差与板端内存预算null。未改舍入、结合顺序或容差。

## 产物与未决项

新增`platform/qwen35/a06/install_rehost_20261003.sh`、`retry_rehost_20261003.sh`（失败v1保留）、`retry_rehost_v2.sh`、`retry_csim_rehost.py`、`summarize_rehost.py`；新增独立增量证据目录。只更新PROJECT_STATUS、A状态和KERNEL_SOURCE未接受原因；原REPORT、原seal和失败日志不重写。被更新治理文件旧字节在`license-rehost-v1/before/`。

B仍需交唯一选定版本的实际XO/内嵌metadata及缺失RTL/历史构建证明，集中清单沿用`evidence/A06_acceptance/B_MISSING_AND_DEFECTS.md`中的B项。未代签、未发送消息、未推送，new_commit=null；不进入A07链接，不重写B核。下一步接收缺件并复核对应版本。
