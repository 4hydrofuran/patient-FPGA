# A06补交接收交接

状态`PARTIAL_LOCAL_CSIM_LICENSE_BLOCKED`。完整报告`evidence/A06_acceptance/supplement-v1/REPORT.md`，B反馈`B_FEEDBACK.md`（本地未发送），实际接口`interface-map.json`。

实际收到B03 supplement release的double核及XO，ZIP SHA256 `506f079daabf37f6dc539d35c49add0b4c0e7629a0a97c461c470b0f75c59513`；1925归档文件；14份精确输入收据、270原始TV、382固定文件。A独立PC61/2800022通过；A04独立回放RTL66、641472参考部分和及Y/meta负例通过。B同版Csim50证据核验通过，普通必需T1/T8 Cosim均有原始成功证据。

本机新版Vitis Csim仍exit1许可不匹配，未执行数值；不继承旧版本成功。B严格清洁自测exit1（42 JSON CRLF/LF），其所有数值运行已通过；不隐去这个失败。stall_max_k原Cosim失败、postcheck恢复另账，不冒称66笔native PASS。

accepted=false/frozen=false保留；记录已收到的实际源/XO/内嵌XML身份，不再笼统称“B没交XO”。A07已有独立代码/交叉构建以及A08/A09工作保留，本轮不继续其他阶段、不重跑长测。

改动前治理原件在`evidence/A06_acceptance/supplement-v1/before/`。实际命令/退出码/失败在commands、tests、a04-rtl、final-checks-v2；SHA清单files.sha256.json。未改B原件、模型、公共契约、容差，无commit/push/代签；BOARD/实现/新ARM执行NOT_TESTED，CMA/BO预算null。

下一步：持续保持WSL实例开启，即时核对HOSTID并由用户官方重新绑定许可，只补新版Csim；B修正Linux文本重建口径/内嵌XML字段即可，无需重跑全部优化。A06最终接收后A07再链接，HLS负slack不是实现收敛。
