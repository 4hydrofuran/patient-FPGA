# A03收口核验 / A04前置检查

2026-10-02；A-DESIGN-1.0；唯一阶段依据为增强包`03_A_系统实现与验证_阶段提示词_措辞精简版.md`，结合02公共接口及12设计D00/D02/D10/D14。A04只读D06/D08及输入，不实施。

## 结论

**A03：PASS_PC_ENGINEERING_BASELINE_QUALITY_PENDING。A04：PASS_INPUTS_READY，未开始实现。按用户要求在此停止。**

通过范围为电脑离线功能基线：真实模型、持久协议、可追溯输入/输出、事实检查、授权麦克风与小样本听辨。不是完整产品质量、医学审核、声学时延或KV260验收。不能把仍存在的ASR错误和端点失败改称通过。

本轮未录音、未播放、未重新运行已有效的模型测试、未改运行代码或模型。原报告/旧封存及失败原件保留；更新的是当前治理入口和模块验收元数据。用户撤销的第三轮不恢复、不使用。

## 逐项证据核验

| 任务要求 | 实际证据及判断 |
|---|---|
| 持久worker、全部必需操作、stdout JSONL、spool边界 | 原32项真实模型协议检查与wire；6项拒绝；源码hash未变化，复用有效结果 |
| sherpa/ASR/TTS版本、许可、资源 | resources.lock中44项SHA256全部匹配，许可证快照保留；Matcha/Baker非商业限制未解除 |
| WAV再到麦克风、否定/数字/中文听辨 | 12条合成音频；首轮实录保留“没有气短/两小时前/三十分钟”；第四轮真人问句准确、用户反馈“转录准确 播放清晰” |
| 半双工、取消epoch、迟到丢弃、partial不评分 | 原协议检查/取消播放原始日志，取消后已播历史为空；只确认软件播放完成，不伪称瞬时声学停止 |
| 能力检测、隔离依赖、缺资源失败 | 原真实hello与6拒绝检查；固定隔离venv和本地资源，运行时不下载 |
| 断外网冷启动 | offline-v4：进程树无外网路由、外部连接ENETUNREACH，本地Unix音频可用；4轮实际播放，其中2 MODEL、2显式TEMPLATE；不是宿主全机断网 |
| 200ms/ack/有界spool | 原实现和测试保留，64MiB/512文件、4作业；上限存在不等于200轮维护已通过 |
| 600/900/1200ms端点 | 9次实测保留，三个阈值均截断构造停顿例；默认PTT，不宣称自动端点质量PASS |
| 完整事实检查后首句/时间边界 | 第四轮Qwen真实生成“每次疼痛持续10分钟。”，duration检查通过后TTS；ready、提交、drain分别记录，声学起点null |
| 录音修复与当前代码关联 | 首块PCM之后提示且首块保留；无后台抢YES线程；62项测试回执及修复seal匹配；第四轮实际执行修复后的入口 |

静态审计共49项通过：19项A03证据检查，30项A04输入检查（含72个张量逐项验证，不把其拆算成72个独立模型测试）。旧213项seal有4处已登记变化：两份状态文件及两份录音源码；旧源码在capture-fix/before与旧hash匹配，当前源码与修复seal匹配。修复15项seal仅两份状态随实录更新；不存在未解释的模型/协议/原始日志变化。完整差异见`AUDIT.json`。

## 必要补测与后续待办

| 类别 | 工作/验收边界 |
|---|---|
| 本次必要收口，已完成 | 契约/配置检查、历史证据真实性与完整性、当前源码关联、真人确认链与原始Qwen结果复核；更正过时“未录音”状态，无剩余A03功能基线补测 |
| 补充而非本阶段阻断 | 网络隔离＋真人麦克风冷启动组合：NOT_TESTED。条文允许WAV/麦克风输入，已分别验证；无需重复录音才做A04 |
| A08必做可靠性 | 200轮/持续运行、spool输入输出清理及4096请求额度维护、音频设备异常阻塞/断连的超时和恢复。15秒目前只是采样数上限，不是严格墙钟上界；不是当前代码已证明故障恢复 |
| 后续质量/教师审核 | 更广说话人、否定/数字/时间/术语、TTS盲听；独立300题仍只有计划；合成病例与评分教师审核未完成，正式教学关闭 |
| A13/A15正式性能 | 声学首个有内容音节/停止、设备回采误差、统计分位、能量；均NOT_TESTED，不能以播放提交代替 |
| P2可选优化 | 自动端点取代PTT、流式TTS/重叠、额外去噪/热词；收益未测，不是默认启用项 |

质量风险不隐藏：第二轮错识保留、根因UNDETERMINED；12合成样本CER9.09%不代表真人总体；三种端点截断、`shei2`告警保留。第四轮单例成功不证明上述问题均已修复。无新增性能数字。

## A04前置检查

机器可读结果：`A04_PREFLIGHT.json`。

- 官方Qwen3.5-0.8B revision `2fc06364715b967f1860aea9cf38778875588b17`；11项源文件（含tokenizer、模板、许可、索引、原始权重）hash匹配。
- 原始safetensors 1,746,942,600字节，SHA256 `04b1c301231dd422b8860db31311ab2721511346a32cb1e079c4c4e5f1fe4696`；同时验证现有F16/Q4 GGUF完整性，但它们不是W4导出源。
- 实际config：24层、hidden1024、MLP3584、18线性＋6完整注意力、共享embedding/head。72个gate/up/down的实际header、N/K、offset、BF16 tensor hash与映射一致，无MLP bias；不重猜转置。
- 固定llama.cpp commit `81e39ad34368329b5db77620721510fd91107e80`，8项已锁源码hash匹配，现有独立CPU入口存在并记录当前hash；原A01生成证据保留，不重编。
- 公共SP_W4A8_128x32_V1契约完整；包内手算fixture文件hash与标注0x97/0x2f一致。这里只验证输入，不称独立参考或数值实现已通过。
- 实际72个shape计算W4+Sw理论总数据140378112字节（133.875MiB），不含头/对齐；未导出，不是BO预算。
- 后续A04必须做：72矩阵导出、彼此独立Python/C++参考、边界数值回归、新模型0/3/4/23层激活和分账误差/内存。旧0.5B激活不能代替；缺B golden/C候选/开发板不阻断开始。

## 实际命令与分域结果

本次命令均由`platform/a1/record.py --log <独占新日志> -- <命令>`保存argv/cwd/UTC/退出码/输出：

| 命令 | 日志（platform/qwen35/a03/evidence/） | 退出码 |
|---|---|---:|
| `platform/local/a1/venv/Scripts/python.exe scripts/release/check_contracts.py` | closeout-contracts.json | 0 |
| `platform/local/a1/venv/Scripts/python.exe scripts/release/qwen35_config.py` | closeout-config.json | 0 |
| `wsl -d KV260-A-2204 --cd /mnt/c/Patientqwen -- python3 platform/qwen35/a03/closeout_audit.py --output eval/qwen35/a03/closeout-v1` | closeout-audit-v1.json | 0 |

封存完成后的附加自检命令见`closeout-final.json`；不是新模型测试。此前只读定位中一次不存在的fixtures路径及PowerShell下rg通配参数错误已在AUDIT登记，使用真实包内路径完成核验，未安装/修改依赖。

PC功能基线/本次静态核验PASS；Csim/Cosim/综合/实现/交叉构建/BOARD、声学和功耗NOT_TESTED；医学REVIEW_PENDING。A04仅输入前置PASS、实现NOT_STARTED。

修改前治理文件快照在`before/`，本次产物与关联证据SHA256见`files.sha256.json`。分支`member-a/qwen35-a00-20261002`、HEAD `ed9df6c7152c908d512ecd1f871583182823e1eb`；未commit/push。llama-cpp技能仅用于固定CPU身份/隔离检查，没有采用技能中的通用速度估计，也没有把GGUF视作本项目sidecar。
