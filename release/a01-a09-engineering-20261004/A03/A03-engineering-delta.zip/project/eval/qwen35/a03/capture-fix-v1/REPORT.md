# A03 录音时序修复：PC控制测试通过，真人复测待完成

2026-10-02。保留第二轮ASR错误“凸痛每四持续多久”；原音频按约定为临时数据，没有拿指定问句伪造其内容。**不能确定第二轮错误的声学/模型根因**。

## 已确认的源码问题与改动

1. 旧voice_cli先显示“正在录音”并启动stdin线程，随后才调用Pulse打开录音设备。新实现先打开设备并收到第一块200ms PCM，再显示“现在开始说话”；第一块原样保留，不作为warm-up删除。
2. 旧停止输入线程可能在15秒采样上限结束后继续等待，从而抢占YES确认。新实现使用同一主线程的非阻塞stdin检查，没有后台读键线程；EOF明确取消。
3. 添加有界CaptureBuffer，15秒最多75块，严格16k/mono/PCM16；输出原PCM，未降噪、裁剪静音、提高增益、改字/加热词或替换模型。
4. 新capture-receipt.json在ASR前保存数值诊断：设备打开/首块/就绪提示时间、样本数、RMS、峰值、削波数、首尾200ms能量、停止原因。它们不是VAD、声学词对齐、ASR置信度或出声时间。仍只临时保存原音频。

改动：`system_qwen35/app/pc_audio.py`、`voice_cli.py`、新增`test_capture.py`。第三轮启动器为`platform/qwen35/a03/microphone_round3.py`，保持第二轮同一句问句，不挑简单句以掩盖失败。旧源码/状态在本目录before中，旧报告、原始转录和命令不覆盖。

## 实际验证

- `python scripts/release/check_contracts.py`，退出0，日志capture-fix-contracts.json。
- `python scripts/release/qwen35_config.py`，退出0，日志capture-fix-config.json。
- WSL `python3 -m unittest system_qwen35.app.test_capture modules.voice_A.test_voice system_qwen35.app.test_a02 -v`，退出0，62项：新增11项PCM/控制单测+此前51项。日志capture-fix-unit.json。
- 新增测试使用合成PCM字节和真实OS pipe检验有界保存、统计、就绪顺序、输入所有权与权限拒绝；没有假麦克风/假模型来充当硬件或识别验收。

此次未录音、未更换ASR/TTS或llama模型。实际麦克风修复效果NOT_TESTED，识别率变化null。原生Pulse阻塞读取在异常设备断连时的严格墙钟超时保证尚未验证，15秒限制是有效音频采样数上限，不宣称覆盖所有驱动故障。

## 下一步与边界

第三轮由用户按键准备、看到数据就绪提示后，以正常语速问“你的胸痛每次持续多久？”。检查转录、数值诊断及llm_calls；若仍错，保留错误再定位输入/模型，不静默用预设文本代替ASR，也不强行进入Qwen。A03仍PARTIAL；BOARD、声学起点、正式医学审核均NOT_TESTED。没有新commit/push、无B/C工程读取。
