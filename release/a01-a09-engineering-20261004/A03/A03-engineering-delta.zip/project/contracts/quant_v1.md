# W4A8 数值与布局契约

contract_version: 0.1.0-draft.2；status: DRAFT；按用户指定 B0 讨论稿0.1对齐，补全提案见 ADR A-0002。

## 数学

X[T,K]，W[N,K]，Y[T,N]=X·W^T。T合法范围1..8，先验证1再验证全部2..8；N/K容量仍待B确认。
仅线性乘法；bias、SiLU、RMSNorm、RoPE、残差、attention、KV Cache、采样留PS。fpga_required只要求声明的目标MLP线性运算必须由PL完成。
Kp=ceil(K/128)*128，Np=ceil(N/32)*32，G=Kp/128。
W 每输出行每 128 个有效 k 对称量化到 [-7,7]；-8 保留且不允许使用。
X 每 token 的整条有效 K 向量量化到 [-127,127]；-128非法；零点为 0。
scale=absmax/7 或 absmax/127；全零组 scale=1，码值全零。padding 不参与 absmax。
舍入为 ties-to-even，量化后饱和到上述范围；NaN/Inf 拒绝。

待 B 评审的确定性细则：原浮点输入先转 FP32；scale 计算用 FP64 除法后舍入为 FP32；
用 FP64(input)/FP64(stored_scale) 计算待舍入商，显式 ties-to-even，不依赖 C++ round 的半入语义。
非零组的 scale 若转换后为零、非有限或非正，必须报错，不静默丢弃极小/异常输入。

S[t,n,g]=sum(int32(Wq[n,128g+r])*int32(Xq[t,128g+r]))，r=0..127。
每组绝对界为 113792；整数组部分和必须 bit-exact。
按 g 升序先计算 FP32(S)*Sw，再乘 Sx，再加进 FP32 输出；共同样例参考禁止 fast-math/FMA 融合。
硬件与该参考可按预注册容差比较：max_abs_error <= 1e-4 + 1e-5*max_abs_reference。
该容差仍是B0建议起点，尚未开发集确认/正式冻结；非有限中间/最终结果按A提案拒绝，不标成功，等待B核对实现。
这不是量化相对原模型的质量容差；两类误差分别报告，失败后不可擅自放宽。

## 布局与长度

全部小端、紧密连续，无 stride。Xq=int8[T,Kp]，Sx=float32[T]，Y=float32[T,Np]。
W 的一字节打包相同 k 的相邻输出行：低半字节偶数 lane，高半字节奇数 lane，二补码。
nb=n//32，g=k//128，r=k%128，lane=n%32。
byte_offset=(((nb*G+g)*128+r)*16)+lane//2；shift=(lane%2)*4。
Sw 的 float32 索引=(nb*G+g)*32+lane；不是普通 [N,G] 平铺。
越过 N 或 K 的 Wq 和 Xq 为零；填充输出行 Sw=1，输出列为零。Sx 对全零 token 为 1。

精确长度：w=Np*Kp/2；sw=Np*G*4；x=T*Kp；sx=T*4；y=T*Np*4；meta=64 字节。
host 用 checked uint64 运算并核实真实 BO 大小，再提交；禁止溢出、非连续/错误 stride 或缺字节。
声明长度按精确负载校验；BO 可因分配对齐更大，但内核不得使用负载之外空间。
不将 GGUF Q4_K_M/Q4_0 原始字节当此格式。不宣称零复制或已实现完整导出器。

## 手算样例

examples/b0_handcheck_v1.json 精确保留B0单组样例：0x97/0x2F、S=890/-891、Y=890/-891，其余输出0。
它与下方跨组尾块样例同时保留，不把任一A检查器标成B独立golden。

examples/handcheck_v1.json 包含 T=1,N=33,K=129，覆盖 N/K 尾部、跨组缩放及奇偶行符号。
Np=64，Kp=256，G=2。输出前三个非零行对应 n=0,1,32：5、-14.75、-34.125。
所有未列码值均为零，未列 scale 均为 1；其余有效行和填充行输出为零。
它只是共同互认样例；B 须独立实现完整边界/随机/真实 shape 测试，不能调用 A 的检查循环计算真值。
