# 契约评审入口

版本 `0.1.0-draft.2`，状态 **DRAFT**，不是已冻结 v1。文件名中的 v1 是目标 ABI 家族。
内容 SHA256 由 `scripts/release/check_contracts.py` 计算，评审必须引用同一个值。

| 文件 | 责任与用途 |
| --- | --- |
| quant_v1.md | A 导出器与 B 独立参考/核共同数学边界 |
| kernel_v1.yaml | BO 顺序、标量宽度、meta 字节布局、容量草案 |
| runtime_api_v1.yaml | A 推理接口、C 业务事件边界，OpenAPI 3.1 |
| metrics_v1.json | 计时域、硬件真值及缺失值约定 |
| kernel_v1.hpp | 与机器契约核对的 C++ 元数据结构和布局公式 |
| examples/handcheck_v1.json | 手算稀疏样例，不依赖 A2 导出器 |
| examples/b0_handcheck_v1.json | 用户指定B0的单组手算样例，与跨组/尾块样例并存 |
| examples/runtime_events_v1.json | 明确标为 PC_SAMPLE 的业务事件样例 |
| review_state.json | 三方评审记录；当前未获得任何成员签核 |

YAML 文件使用 JSON 子集，能被 YAML 和 JSON 解析器读取。不要另写一套隐含字节格式。
评审要点见 `docs/adr/A-0001-contract-draft.md`：尤其是 sentence_checked 的生产者、容量、FP32 舍入顺序及 reset 语义。

## B 可以立即开始

独立复算样例、构造边界反例、准备自己的 B0/B1 测试。不得把 A 的样例检查器当独立 golden。
用户已选B0为接口方向，B可按本版数学、布局、17参数顺序准备独立参考；涉及数值精度、meta64/类型和容量的A补全提案见A-0002，先同digest确认再固定HLS ABI。器件、XRT group_id、内存拓扑仍不能猜。

## C 可以立即开始

独立盘点旧业务、病例 Schema 和医学审核事项；用此草案编写明确标识的客户端 mock 和用例。
评分、病例事实检查和 TTS 属于 C。A 不提供其医学实现。见 A0_to_C 对流式检查事件的评审请求。

## 冻结规则

目前只发布可评审草案，不宣称接口永久稳定。B/C 通过各自 handoff 返回：角色、reviewer、commit、contract_digest、结论和最小反例。
A 验证三方审阅同一 digest、处理 ADR 后提升契约版本并同步回归。不能由 A 填写 B/C 的 approved。
实际批准缺失时 `check_contracts.py --require-frozen` 必须非零退出。
