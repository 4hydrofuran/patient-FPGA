#pragma once
#include <cstddef>
#include <cstdint>

// DRAFT 0.1.0-draft.2: host-side ABI definitions, not an HLS implementation.
namespace kv260_contract {
constexpr std::uint32_t abi_version = 1;
constexpr std::uint32_t magic = 0x314C3457u;
constexpr std::uint32_t done_success = 0xD04E0001u;
struct Meta {
    std::uint32_t magic, abi_version;
    std::uint64_t kernel_build_id, job_id;
    std::uint32_t status, done;
    std::uint64_t hw_completed_count, algorithm_weight_bytes;
    std::uint32_t reserved[4];
};
static_assert(sizeof(Meta) == 64, "meta size mismatch");
static_assert(offsetof(Meta, kernel_build_id) == 8, "build offset mismatch");
static_assert(offsetof(Meta, job_id) == 16, "job offset mismatch");
static_assert(offsetof(Meta, status) == 24, "status offset mismatch");
static_assert(offsetof(Meta, done) == 28, "done offset mismatch");
static_assert(offsetof(Meta, hw_completed_count) == 32, "count offset mismatch");
static_assert(offsetof(Meta, algorithm_weight_bytes) == 40, "bytes offset mismatch");
static_assert(offsetof(Meta, reserved) == 48, "reserved offset mismatch");
constexpr std::uint64_t w_offset(std::uint64_t n, std::uint64_t k, std::uint64_t G) {
    return (((n / 32 * G + k / 128) * 128 + k % 128) * 16) + n % 32 / 2;
}
constexpr std::uint64_t sw_index(std::uint64_t n, std::uint64_t g, std::uint64_t G) {
    return (n / 32 * G + g) * 32 + n % 32;
}
constexpr int unpack(std::uint8_t value, std::uint64_t n) {
    const int q = (value >> (n % 2 * 4)) & 15;
    return q >= 8 ? q - 16 : q;
}
}
