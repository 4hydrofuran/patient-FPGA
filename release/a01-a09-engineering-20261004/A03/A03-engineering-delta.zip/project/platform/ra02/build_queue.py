"""Single A-host offline build queue. Cooperative locking, not a security sandbox.

No remote access is granted by this tool. A must review jobs before run-next.
Persistent active marker blocks crash recovery; never auto-unlock a stale job.
"""
import argparse
import contextlib
import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

CENTRAL = Path('/home/member-a/kv260-build/ra02-coordinator')

def save_new(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def prepare(base):
    if base.is_symlink():
        raise ValueError('central directory cannot be a symlink')
    base.mkdir(parents=True, exist_ok=True)
    for name in ('requests', 'work', 'results'):
        p = base / name
        if p.is_symlink():
            raise ValueError('queue subdirectory cannot be a symlink')
        p.mkdir(exist_ok=True)

def submit(base, owner, label, argv):
    if owner not in ('A', 'B', 'C') or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', label):
        raise ValueError('invalid owner/label')
    if not argv or not Path(argv[0]).is_absolute():
        raise ValueError('absolute executable required')
    prepare(base)
    job = f'{time.time_ns():020d}-{owner}-{label}-{uuid.uuid4().hex[:8]}'
    save_new(base / 'requests' / (job + '.json'), {
        'job': job, 'owner': owner, 'argv': argv,
        'submitted_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'OFFLINE_BUILD_ONLY', 'board_authorized': False})
    return job

@contextlib.contextmanager
def exclusive(base):
    import fcntl
    prepare(base)
    lockpath = base / 'queue.lock'
    if lockpath.is_symlink():
        raise ValueError('lock cannot be a symlink')
    with lockpath.open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)

def run_next(base):
    with exclusive(base):
        if (base / 'active.json').exists() or (base / 'active.json').is_symlink():
            raise RuntimeError('active marker retained; A must reconcile processes before recovery')
        pending = [p for p in sorted((base / 'requests').glob('*.json'))
                   if not (base / 'results' / p.name).exists()]
        if not pending:
            return {'status': 'EMPTY', 'exit_code': 0}
        request = json.loads(pending[0].read_text())
        if request['job'] != pending[0].stem:
            raise ValueError('job identity mismatch')
        work = base / 'work' / request['job']
        work.mkdir(exist_ok=False)
        save_new(base / 'active.json', request)
        start = time.monotonic()
        # Unexpected interruption leaves active.json. Never clear it in finally.
        with (work / 'stdout.txt').open('xb') as stdout, (work / 'stderr.txt').open('xb') as stderr:
            try:
                result = subprocess.run(request['argv'], cwd=work, stdout=stdout, stderr=stderr)
                code = result.returncode
            except OSError as error:
                stderr.write(str(error).encode())
                code = 127
        receipt = dict(request, cwd=str(work), elapsed_s=time.monotonic()-start,
                       exit_code=code, status='COMPLETED' if code == 0 else 'FAILED',
                       hardware_execution='NOT_TESTED')
        save_new(base / 'results' / pending[0].name, receipt)
        # Removes only this job's tiny marker after its subprocess has returned.
        if code == 0:
            (base / 'active.json').unlink()
        return receipt

def main():
    if sys.platform != 'linux':
        raise RuntimeError('central queue runs only on the A Linux build host')
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='action', required=True)
    p = sub.add_parser('submit')
    p.add_argument('--owner', choices=['A','B','C'], required=True)
    p.add_argument('--label', required=True)
    p.add_argument('argv', nargs=argparse.REMAINDER)
    sub.add_parser('run-next')
    sub.add_parser('status')
    args = ap.parse_args()
    if args.action == 'submit':
        argv = args.argv[1:] if args.argv[:1] == ['--'] else args.argv
        print(submit(CENTRAL, args.owner, args.label, argv))
        return 0
    if args.action == 'run-next':
        result = run_next(CENTRAL)
        print(json.dumps(result, indent=2))
        return result['exit_code']
    prepare(CENTRAL)
    print(json.dumps({'central': str(CENTRAL),
        'active': json.loads((CENTRAL/'active.json').read_text()) if (CENTRAL/'active.json').exists() else None,
        'pending': [p.name for p in sorted((CENTRAL/'requests').glob('*.json'))
                    if not (CENTRAL/'results'/p.name).exists()]}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
