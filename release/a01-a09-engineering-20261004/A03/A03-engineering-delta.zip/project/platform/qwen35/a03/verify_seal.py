import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];p=ROOT/'eval/qwen35/a03/files.sha256.json'
manifest=json.loads(p.read_text(encoding='utf-8'))
bad=[name for name,h in manifest.items() if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h]
assert not bad,bad
print(json.dumps({'status':'PASS_SHA256','files':len(manifest),'manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
