"""Real model evaluation on clearly synthetic fixtures; no microphone."""
import hashlib,json,math,re,sys,time,wave
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.audio_adapter import VoiceClient
from modules.voice_A.engine import wav_write,wav_read
TEXTS=[('q_location','疼痛在什么位置？',[]),('q_duration','每次疼痛持续多久？',[]),
 ('q_onset','胸痛什么时候开始？',[]),('q_dyspnea','有没有气短？',['有','没']),
 ('neg','我没有气短。',['没有']),('double_neg','不是没有气短。',['不是','没有']),
 ('number','疼痛持续三十分钟。',['三十','分钟']),('time','胸痛从两小时前开始。',['两','小时']),
 ('symptom','我的左肩也痛。',['左肩']),('unknown','过敏情况我不清楚。',['不清楚']),
 ('pause_a','我没有',['没有']),('pause_b','药物过敏。',['过敏'])]
def dump(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalize(s):return ''.join(re.findall('[\u4e00-\u9fff0-9]',s))
def edit(a,b):
    d=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        row=[i]
        for j,y in enumerate(b,1):row.append(min(row[-1]+1,d[j]+1,d[j-1]+(x!=y)))
        d=row
    return d[-1]
def main():
    out=ROOT/'eval/qwen35/a03/audio-eval-v1';out.mkdir(exist_ok=False)
    spool=out/'spool';c=VoiceClient(spool,out/'worker');results=[];fixtures=[]
    try:
        for ident,text,critical in TEXTS:
            t=c.call('synthesize',session_id='fixture',text=text if text.endswith(('。','？')) else text+'。',output_dir='fixture/tts')
            if t['type']!='result':raise RuntimeError(t)
            original=spool/t['wav_path']
            with wave.open(str(original),'rb') as w:rate=w.getframerate();x=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
            y=resample_poly(x,320,441).astype(np.float32) # one explicit 22050 -> 16000 conversion
            p=spool/'fixture'/f'{ident}.wav';wav_write(p,y,16000)
            a=c.call('transcribe',session_id='fixture',wav_path=f'fixture/{ident}.wav',language='zh')
            if a['type']!='result':raise RuntimeError(a)
            ref=normalize(text);hyp=normalize(a['text'])
            row=dict(id=ident,reference=text,asr=a,tts=t,cer_edits=edit(ref,hyp),reference_chars=len(ref),
                     critical_missing=[x for x in critical if x not in hyp],critical_metric='literal_proxy_not_human_semantics',
                     origin='LOCAL_MATCHA_BAKER_SYNTHETIC_NOT_REAL_PERSON',wav=str(p.relative_to(ROOT)),sha256=sha(p),
                     original_rate=rate,input_rate=16000,source_text_sha256=hashlib.sha256(text.encode()).hexdigest())
            results.append(row);fixtures.append({'id':ident,'text':text,'wav':str(p.relative_to(ROOT)),'sha256':sha(p)})
            with (out/'results.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
            print(json.dumps({'id':ident,'asr':a['text'],'edits':row['cer_edits'],'critical_missing':row['critical_missing']},ensure_ascii=False),flush=True)
        # Known internal 900ms pause, retain both words and silence; no trimming.
        x=wav_read(spool/'fixture/pause_a.wav');z=wav_read(spool/'fixture/pause_b.wav')
        joined=np.concatenate([x,np.zeros(14400,dtype=np.float32),z,np.zeros(25600,dtype=np.float32)])
        wav_write(spool/'fixture/pause_joined.wav',joined,16000)
        fixtures.append({'id':'pause_joined','text':'我没有药物过敏。','wav':str((spool/'fixture/pause_joined.wav').relative_to(ROOT)),
                         'sha256':sha(spool/'fixture/pause_joined.wav'),'inserted_internal_silence_ms':900,
                         'last_phrase_start_ms':(len(x)+14400)/16})
        dump(out/'fixtures.json',fixtures)
        dump(out/'summary.json',{'domain':'PC','synthetic_only':True,'count':len(results),
             'cer':sum(x['cer_edits'] for x in results)/sum(x['reference_chars'] for x in results),
             'critical_missing':sum(bool(x['critical_missing']) for x in results),'human_intelligibility':'NOT_TESTED',
             'mic':'NOT_AUTHORIZED','board':'NOT_TESTED','confidence':None,'tts_speed':1.0,'silence_scale':1.0,
             'note':'Same TTS generates ASR inputs; not independent human acoustic evaluation or clinical accuracy'})
    finally:c.close()
if __name__=='__main__':main()
