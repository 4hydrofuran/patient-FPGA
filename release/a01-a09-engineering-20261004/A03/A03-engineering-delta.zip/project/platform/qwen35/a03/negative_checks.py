"""Real invalid input/dependency checks, not substitute inference tests."""
import json,subprocess,sys,tempfile,wave
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from modules.voice_A.engine import wav_read
from system_qwen35.app.pc_audio import PulseAudio
out=ROOT/'eval/qwen35/a03/negative-v1';out.mkdir(exist_ok=False);checks=[]
with tempfile.TemporaryDirectory() as d:
    for rate,channels,width,name in [(8000,1,2,'rate'),(16000,2,2,'stereo'),(16000,1,1,'width'),(16000,1,2,'empty')]:
        p=Path(d)/(name+'.wav')
        with wave.open(str(p),'wb') as w:
            w.setnchannels(channels);w.setsampwidth(width);w.setframerate(rate);w.writeframes(b'' if name=='empty' else bytes(rate*channels*width))
        try:wav_read(p);passed=False
        except ValueError:passed=True
        checks.append(dict(name='reject_'+name,passed=passed))
    # System Python has no voice dependencies: worker must fail, not download/fallback.
    p=subprocess.run(['/usr/bin/python3','-m','modules.voice_A.worker','--spool',d],cwd=ROOT,input='',capture_output=True,text=True)
    (out/'missing_dependency.json').write_text(json.dumps(dict(argv=p.args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2))
    checks.append(dict(name='missing_dependency_explicit',passed=p.returncode==2 and not p.stdout and 'VOICE_STARTUP_ERROR' in p.stderr))
    try:PulseAudio.record_push_to_talk(None,Path(d)/'forbidden.wav',None,recording_authorized=False);passed=False
    except PermissionError:passed=True
    checks.append(dict(name='microphone_denied_without_consent',passed=passed and not (Path(d)/'forbidden.wav').exists()))
(out/'summary.json').write_text(json.dumps(dict(domain='PC',checks=checks),indent=2))
assert all(x['passed'] for x in checks),checks
print(json.dumps({'pass':len(checks)}))
