"""Explicit developer-time fetch only. Runtime worker never downloads resources."""
import hashlib,json,tarfile,urllib.request,shutil,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a03'
ASSETS=ROOT/'artifacts/voice_A'
def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(url,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():return
    print('FETCH '+url,flush=True)
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'patient-FPGA-A03'}),timeout=90) as src,path.open('xb') as dst:shutil.copyfileobj(src,dst)
def metadata(url,name):
    p=OUT/'sources'/name;get(url,p);return json.loads(p.read_text(encoding='utf-8'))
def extract(archive):
    with tarfile.open(archive) as t:
        members=t.getmembers()
        for m in members:
            p=Path(m.name)
            if p.is_absolute() or '..' in p.parts or not (m.isfile() or m.isdir()):raise ValueError('Unsafe archive member '+m.name)
        t.extractall(ASSETS,filter='data')
def asset(url,path,info):
    expected=info['size'];published=info.get('digest')
    if path.exists():
        if path.stat().st_size==expected and (not published or published=='sha256:'+sha(path)):return
        path.rename(path.with_name(path.name+'.incomplete-'+str(time.time_ns())))
    chunks=ASSETS/(path.name+'.chunks');chunks.mkdir(exist_ok=True)
    for start in range(0,expected,8*1024*1024):
        end=min(start+8*1024*1024,expected)-1;p=chunks/str(start)
        if p.exists() and p.stat().st_size==end-start+1:continue
        print('RANGE '+path.name+' '+str(start)+'-'+str(end),flush=True)
        req=urllib.request.Request(url+'?a03_range='+str(start),headers={'User-Agent':'patient-FPGA-A03','Range':f'bytes={start}-{end}'})
        with urllib.request.urlopen(req,timeout=90) as r:
            if r.status!=206 or not r.headers.get('Content-Range','').startswith(f'bytes {start}-{end}/'):raise ValueError('Range unsupported')
            data=r.read()
        if len(data)!=end-start+1:raise ValueError('Truncated range')
        with p.open('xb') as f:f.write(data)
    with path.open('xb') as f:
        for start in range(0,expected,8*1024*1024):
            with (chunks/str(start)).open('rb') as src:shutil.copyfileobj(src,f)
    assert path.stat().st_size==expected
    if published:assert published=='sha256:'+sha(path)
def main():
    OUT.mkdir(parents=True,exist_ok=True);ASSETS.mkdir(parents=True,exist_ok=True)
    for p in ('docs/PROJECT_STATUS.json','docs/status/A.md','docs/DESIGN_GAP.md','system_qwen35/app/session.py'):
        dst=OUT/'before'/p;dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():shutil.copy2(ROOT/p,dst)
    old=json.loads((ROOT/'eval/qwen35/a02/files.sha256.json').read_text());assert all(sha(ROOT/p)==h for p,h in old.items())
    if not (OUT/'preflight.json').exists():write(OUT/'preflight.json',{'a02_files_verified':len(old),'board':'NOT_TESTED','microphone':'NOT_AUTHORIZED'})
    version='1.12.40'
    pypi=metadata('https://pypi.org/pypi/sherpa-onnx/'+version+'/json','pypi.json')
    tag=metadata('https://api.github.com/repos/k2-fsa/sherpa-onnx/git/ref/tags/v'+version,'tag.json')
    commit=tag['object']['sha']
    for name in ('LICENSE','sherpa-onnx/python/sherpa_onnx/online_recognizer.py','python-api-examples/offline-tts.py'):
        get('https://raw.githubusercontent.com/k2-fsa/sherpa-onnx/'+commit+'/'+name,OUT/'sources'/Path(name).name)
    base='https://github.com/k2-fsa/sherpa-onnx/releases/download/'
    names=[('asr-models','sherpa-onnx-streaming-zipformer-small-ctc-zh-int8-2025-04-01.tar.bz2'),('tts-models','matcha-icefall-zh-baker.tar.bz2'),('vocoder-models','vocos-22khz-univ.onnx')]
    downloaded=[]
    for release,name in names:
        release_info=metadata('https://api.github.com/repos/k2-fsa/sherpa-onnx/releases/tags/'+release,release+'.json')
        info=next(x for x in release_info['assets'] if x['name']==name)
        url=base+release+'/'+name;p=ASSETS/name;asset(url,p,info)
        downloaded.append({'url':url,'file':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
        if name.endswith('.bz2'):extract(p)
    for url,name in [('https://k2-fsa.github.io/sherpa/onnx/tts/pretrained_models/matcha.html','matcha_official.html'),('https://k2-fsa.github.io/sherpa/onnx/pretrained_models/online-ctc/zipformer-ctc-models.html','asr_official.html')]:get(url,OUT/'sources'/name)
    files={p.relative_to(ROOT).as_posix():sha(p) for p in ASSETS.rglob('*') if p.is_file()}
    write(ROOT/'modules/voice_A/resources.lock.json',{'version':1,'sherpa_onnx':version,'source_commit':commit,'downloads':downloaded,'files':files,
          'license':{'sherpa_onnx':'Apache-2.0','matcha_baker':'NON_COMMERCIAL_DATA_RESTRICTION; no redistribution; teacher/research use only pending review','asr_model':'PENDING_SOURCE_REVIEW','vocos':'PENDING_SOURCE_REVIEW'},
          'runtime_auto_download':False,'redistribution_allowed':False,'domain':'PC_ONLY'})
    print(json.dumps({'version':version,'commit':commit,'files':len(files)}))
if __name__=='__main__':main()
