#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Patientqwen
python3 -m unittest modules.voice_A.test_voice system_qwen35.app.test_a02 -v
python3 platform/qwen35/a03/protocol_eval.py eval/qwen35/a03/protocol-v2
audio_prefix=/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu
export LD_LIBRARY_PATH="$audio_prefix:$audio_prefix/pulseaudio${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
unshare -Urn python3 platform/qwen35/a03/cancel_loop.py
unshare -Urn python3 platform/qwen35/a03/offline_loop.py eval/qwen35/a03/offline-v3
