"""Fresh user-requested retest, independent of the withdrawn round."""
import datetime,json,os,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a03/mic-round4-20261002'

def main():
    OUT.mkdir(parents=True,exist_ok=False)
    consent={'authorized':True,'evidence':'User explicitly requested a fresh recording test after withdrawing the previous round',
        'scope':'Own voice, one synthetic question, up to 15 seconds; user Enter starts device',
        'expected_reading':'你的胸痛每次持续多久？','recording_started_at_launch':False,
        'raw_audio':'temporary /dev/shm, removed on normal CLI exit',
        'retained':'local transcript, numeric diagnostics and command log',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT/'authorization.json').write_text(json.dumps(consent,ensure_ascii=False,indent=2),encoding='utf-8')
    print('新的测试（第四轮）：请只问“你的胸痛每次持续多久？”',flush=True)
    print('按Enter准备，看到“现在开始说话”再读；读完按Enter停止。',flush=True)
    print('请在这个窗口操作：转录准确就输入英文 YES，再按Enter；不准确直接回车。',flush=True)
    env=dict(os.environ);prefix='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu'
    env['LD_LIBRARY_PATH']=prefix+':'+prefix+'/pulseaudio';env['PYTHONUNBUFFERED']='1'
    command='python3 -u -m system_qwen35.app.voice_cli --record-authorized --output eval/qwen35/a03/mic-round4-20261002/run'
    argv=['script','-q','-e','-f','-c',command,str(OUT/'terminal.log')]
    result=subprocess.run(argv,cwd=ROOT,env=env)
    (OUT/'command.json').write_text(json.dumps({'argv':argv,'exit_code':result.returncode,'domain':'PC','board':'NOT_TESTED',
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2),encoding='utf-8')
    print('\n测试进程结束，退出码：'+str(result.returncode)+'。请回Codex反馈。',flush=True)
    input('按Enter关闭窗口。')
    return result.returncode
if __name__=='__main__':raise SystemExit(main())
