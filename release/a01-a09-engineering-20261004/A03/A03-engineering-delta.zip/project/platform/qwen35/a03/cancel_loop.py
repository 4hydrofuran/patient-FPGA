"""Real models and playback cancellation, no microphone and no dummy backend."""
import json,sys,time,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.voice_loop import VoiceLoop,Cancelled
out=ROOT/'eval/qwen35/a03/cancel-loop-v1'
loop=VoiceLoop(out);result={}
def run():
    try:
        result['unexpected_success']=loop.turn(ROOT/'eval/qwen35/a03/audio-eval-v1/spool/fixture/q_location.wav',synthetic_reference='疼痛在什么位置？')
    except Cancelled as e:result['cancelled']=str(e)
    except Exception as e:result['failure']=repr(e)
t=threading.Thread(target=run);t.start()
try:
    deadline=time.monotonic()+90
    while loop.machine.state!='PLAYING' and t.is_alive() and time.monotonic()<deadline:time.sleep(.01)
    assert loop.machine.state=='PLAYING',result
    time.sleep(.2)
    result['control']=loop.cancel();t.join(timeout=60)
    result['thread_finished']=not t.is_alive()
    result['session']=loop.session.snapshot()
    result['pass']=bool(result.get('cancelled')) and not t.is_alive() and not result['session']['played'] and result['session']['pending'] is None
    result.update(domain='PC',microphone='NOT_TESTED',acoustic_stop_verified=False,board='NOT_TESTED')
    with (out/'summary.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
    assert result['pass'],result
    print(json.dumps({'pass':True,'cancel_epoch':result['control']['epoch'],'played_history':0,'acoustic_stop_verified':False}))
finally:
    if t.is_alive():loop.cancel();t.join(timeout=60)
    loop.close()
