"""Build-time source evidence only; never imported by the offline service."""
import hashlib,json,urllib.request,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'eval/qwen35/a03/licenses-v1';out.mkdir(exist_ok=False)
sources={
 'asr_card.json':'https://huggingface.co/api/models/csukuangfj/icefall-streaming-zipformer-small-ctc-zh-2025-04-01/revision/6768aa8b65bc68e128af2ee08a7142dd0abe4be4',
 'asr_README.md':'https://huggingface.co/csukuangfj/icefall-streaming-zipformer-small-ctc-zh-2025-04-01/raw/6768aa8b65bc68e128af2ee08a7142dd0abe4be4/README.md',
 'vocos_card.json':'https://huggingface.co/api/models/BSC-LT/vocos-mel-22khz/revision/b4b331d85370cdd94c644b5d1922a27a0b219c15',
 'vocos_README.md':'https://huggingface.co/BSC-LT/vocos-mel-22khz/raw/b4b331d85370cdd94c644b5d1922a27a0b219c15/README.md',
 'vocos_code_LICENSE':'https://raw.githubusercontent.com/gemelo-ai/vocos/main/LICENSE',
}
receipt=[]
for name,url in sources.items():
    with urllib.request.urlopen(url,timeout=90) as r:data=r.read()
    (out/name).write_bytes(data)
    receipt.append(dict(file=name,url=url,sha256=hashlib.sha256(data).hexdigest()))
for name,path in [('matcha_README.md',ROOT/'artifacts/voice_A/matcha-icefall-zh-baker/README.md'),('sherpa_LICENSE',ROOT/'eval/qwen35/a03/sources/LICENSE')]:
    shutil.copy2(path,out/name);receipt.append(dict(file=name,source=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
assert json.loads((out/'asr_card.json').read_text())['cardData']['license']=='apache-2.0'
assert json.loads((out/'vocos_card.json').read_text())['cardData']['license']=='apache-2.0'
with (out/'receipt.json').open('x') as f:json.dump(receipt,f,indent=2)
shutil.copy2(ROOT/'modules/voice_A/resources.lock.json',out/'resources.lock.before-license-review.json')
print(json.dumps({'sources':len(receipt),'legal_clearance':False,'redistribution':False}))
