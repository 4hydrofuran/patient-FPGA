"""Cold-start full process tree in a network namespace; real WSLg output API."""
import json,os,socket,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.voice_loop import VoiceLoop
out=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'eval/qwen35/a03/offline-v2')
sock=socket.socket();sock.settimeout(1)
try:sock.connect(('1.1.1.1',443));isolated=False;error=None
except OSError as exc:isolated=True;error=str(exc)
finally:sock.close()
assert isolated,'Do not label an online run as offline'
network={'namespace':os.readlink('/proc/self/ns/net'),'interfaces':os.listdir('/sys/class/net'),
         'route':Path('/proc/net/route').read_text(),'external_connect_error':error,'scope':'process-tree namespace, host network not disabled'}
loop=VoiceLoop(out)
try:
    with (out/'network.json').open('x') as f:json.dump(network,f,indent=2)
    fixtures=json.loads((ROOT/'eval/qwen35/a03/audio-eval-v1/fixtures.json').read_text())
    results=[]
    for fixture in [x for x in fixtures if x['id'] in ('q_location','q_duration','q_onset','q_dyspnea')]:
        r=loop.turn(ROOT/fixture['wav'],synthetic_reference=fixture['text'],use_stream=fixture['id']!='q_duration')
        r['fixture_id']=fixture['id'];results.append(r)
        with (out/'turns.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n')
        print(json.dumps({'fixture':fixture['id'],'asr':r['asr']['text'],'source':r['application']['answer_source'],
                          'reply':r['application']['text'],'playback_complete':r['playback']['playback_api_completed']},ensure_ascii=False),flush=True)
    with (out/'summary.json').open('x',encoding='utf-8') as f:json.dump({'domain':'PC','turns':len(results),
        'model_answer_turns':sum(x['application']['answer_source']=='MODEL' for x in results),
        'review_or_template_turns':sum(x['application']['answer_source']!='MODEL' for x in results),
        'playback_api_completed':sum(x['playback']['playback_api_completed'] for x in results),
        'asr_review_required':True,'confidence':None,'microphone':'NOT_AUTHORIZED','human_intelligibility':'NOT_TESTED',
        'acoustic_onset_ns':None,'network_isolation':network,'board':'NOT_TESTED'},f,ensure_ascii=False,indent=2)
finally:loop.close()
