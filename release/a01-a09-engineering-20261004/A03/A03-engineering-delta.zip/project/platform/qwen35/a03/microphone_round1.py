"""User-authorized interactive first microphone round; never auto-press Enter."""
import datetime,json,os,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a03/mic-round1-20261002'

def main():
    OUT.mkdir(parents=True,exist_ok=False)
    consent={'scope':'User reads synthetic test sentence, own voice only, up to 15 seconds',
        'evidence':'User explicitly allowed recording and asked to start round one in this chat on 2026-10-02',
        'authorized':True,'recording_started':False,'raw_audio':'temporary /dev/shm, removed on normal CLI exit',
        'retained':'local transcription, diagnostics and command transcript',
        'expected_reading':'我没有气短，胸痛从两小时前开始，每次持续三十分钟。',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT/'authorization.json').write_text(json.dumps(consent,ensure_ascii=False,indent=2),encoding='utf-8')
    print('第一轮：请读「我没有气短，胸痛从两小时前开始，每次持续三十分钟。」',flush=True)
    print('正在加载模型，尚未录音。出现准备提示后按 Enter 开始；读完按 Enter 停止。',flush=True)
    env=dict(os.environ)
    prefix='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu'
    env['LD_LIBRARY_PATH']=prefix+':'+prefix+'/pulseaudio'
    env['PYTHONUNBUFFERED']='1'
    command='python3 -u -m system_qwen35.app.voice_cli --record-authorized --output eval/qwen35/a03/mic-round1-20261002/run'
    argv=['script','-q','-e','-f','-c',command,str(OUT/'terminal.log')]
    result=subprocess.run(argv,cwd=ROOT,env=env)
    (OUT/'command.json').write_text(json.dumps({'argv':argv,'exit_code':result.returncode,'domain':'PC',
        'board':'NOT_TESTED','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2),encoding='utf-8')
    print('\n测试进程已结束，退出码：'+str(result.returncode),flush=True)
    print('请返回 Codex 告诉我已完成，我会检查真实转录和错误。',flush=True)
    input('按 Enter 关闭此窗口。')
    return result.returncode

if __name__=='__main__':raise SystemExit(main())
