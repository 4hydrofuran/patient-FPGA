"""Seal the A03 closeout and verify current status; no runtime/device execution."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'eval/qwen35/a03/closeout-v1'


def read(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    audit = read(OUT/'AUDIT.json')
    pre = read(OUT/'A04_PREFLIGHT.json')
    assert audit['passed'] and pre['status'] == 'PASS_INPUTS_READY'
    assert len(audit['checks']) == 19 and len(pre['checks']) == 30
    status = read('docs/PROJECT_STATUS.json')
    manifest = read('modules/voice_A/manifest.json')
    assert status['stage'] == 'A03' and status['stage_status'] == 'PASS_PC_ENGINEERING_BASELINE_QUALITY_PENDING'
    assert status['a04_preflight']['implementation_started'] is False
    assert status['next_action'].startswith('STOP') and not status['a03_required_retests_outstanding']
    assert status['domains']['board'] == manifest['board'] == 'NOT_TESTED'
    assert status['linux_memory_bytes'] is None and status['pl_bo_budget_bytes'] is None
    assert (ROOT/status['stage_prompt']).is_file()
    assert status['stage_prompt'] in (ROOT/'AGENTS.md').read_text(encoding='utf-8')
    # The original reports are immutable. This new seal records subsequent
    # document revisions; it does not modify the previous seals or raw results.
    original = read('eval/qwen35/a03/files.sha256.json')
    for p,h in original.items():
        if p.startswith('eval/') or p.startswith('platform/') or p.startswith('contracts/'):
            assert sha(ROOT/p) == h, p
    fixed = read('eval/qwen35/a03/capture-fix-v1/files.sha256.json')
    for p in ('system_qwen35/app/pc_audio.py','system_qwen35/app/voice_cli.py','system_qwen35/app/test_capture.py'):
        assert sha(ROOT/p) == fixed[p], p
    # Check tested executable/libraries against the earlier real build identity,
    # not merely existence or an invented current commit string.
    identity = read('eval/qwen35/design_import/build/identity.json')
    binary_checks = []
    for p,h in identity['files'].items():
        actual = sha(Path(p))
        binary_checks.append({'path':p,'expected':h,'actual':actual,'passed':actual == h})
    assert all(x['passed'] for x in binary_checks)
    commands = []
    for script in ('scripts/release/check_contracts.py','scripts/release/qwen35_config.py'):
        argv = [sys.executable, script]
        r = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
        commands.append({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
        if r.returncode:
            with (OUT/'FINAL_FAILURE.json').open('x',encoding='utf-8') as f:
                json.dump(commands,f,ensure_ascii=False,indent=2)
            return r.returncode
    summary = {'domain':'PC','status':'PASS_CLOSEOUT_STATIC_CHECKS','runtime_identity':binary_checks,
               'commands':commands,'runtime_rebuilt':False,'models_rerun':False,'new_recording':False,
               'BOARD':'NOT_TESTED','a04_implementation_started':False}
    with (OUT/'FINAL_CHECKS.json').open('x',encoding='utf-8') as f:
        json.dump(summary,f,ensure_ascii=False,indent=2)
    paths = {ROOT/p for p in original} | {ROOT/p for p in fixed}
    paths.update(ROOT/p for p in ['AGENTS.md','models/model.lock.json','quant/qwen35_tensor_map.json',
        'modules/voice_A/manifest.json','modules/voice_A/README.md','modules/voice_A/resources.lock.json',
        'platform/qwen35/a03/closeout_audit.py','platform/qwen35/a03/closeout_finalize.py',
        'docs/handoffs/A_A03_CLOSEOUT_20261002.md','eval/qwen35/design_import/build/identity.json',
        'eval/qwen35/a03/files.sha256.json','eval/qwen35/a03/capture-fix-v1/files.sha256.json',
        'platform/qwen35/a03/evidence/closeout-contracts.json','platform/qwen35/a03/evidence/closeout-config.json',
        'platform/qwen35/a03/evidence/closeout-audit-v1.json'])
    pkg = (ROOT/status['stage_prompt']).parent
    paths.update(pkg/p for p in ['03_A_系统实现与验证_阶段提示词_措辞精简版.md',
        '02_公共接口与替换规则.md','12_A_详细设计与性能优化方案.md'])
    paths.update((pkg/'fixtures').glob('*'))
    for name in ('mic-round1-20261002','mic-round2-20261002','mic-round4-20261002'):
        # Deliberately never walk or restore the withdrawn round.
        paths.update(p for p in (ROOT/'eval/qwen35/a03'/name).rglob('*') if p.is_file())
    paths.update(p for p in OUT.rglob('*') if p.is_file())
    hashes = {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths) if p.is_file()}
    with (OUT/'files.sha256.json').open('x',encoding='utf-8') as f:
        json.dump(hashes,f,ensure_ascii=False,indent=2)
    assert all(sha(ROOT/p) == h for p,h in hashes.items())
    print(json.dumps({'sealed_files':len(hashes),'manifest_sha256':sha(OUT/'files.sha256.json'),
         'runtime_identity_files':len(binary_checks),'commands_exit_codes':[x['exit_code'] for x in commands],
         'A03':'PASS_PC_ENGINEERING_BASELINE_QUALITY_PENDING','A04':'PREFLIGHT_ONLY_PASS','BOARD':'NOT_TESTED'}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
