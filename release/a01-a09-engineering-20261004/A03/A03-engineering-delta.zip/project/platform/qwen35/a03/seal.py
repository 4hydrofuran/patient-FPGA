"""Seal actual A03 files and check historical evidence, no board or network."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'eval/qwen35/a03'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((ROOT/'eval/qwen35/a02/files.sha256.json').read_text())
allowed={'docs/DESIGN_GAP.md','docs/PROJECT_STATUS.json','docs/status/A.md','system_qwen35/app/native.py','system_qwen35/app/planning.py','system_qwen35/app/session.py'}
changes=[p for p,h in old.items() if sha(ROOT/p)!=h]
assert set(changes)<=allowed,changes
report=json.loads((OUT/'REPORT.json').read_text(encoding='utf-8'))
assert report['status'].startswith('PARTIAL_') and report['domain_tests']['BOARD']=='NOT_TESTED'
assert report['offline_loop']['microphone']=='NOT_AUTHORIZED'
assert report['unit_tests']['total']==51
commands=[]
for p in sorted((ROOT/'platform/qwen35/a03/evidence').glob('*.json')):
    obj=json.loads(p.read_text(encoding='utf-8'))
    if obj.get('exit_code') is not None:commands.append({'log':str(p.relative_to(ROOT)).replace('\\','/'),'argv':obj['argv'],'exit_code':obj['exit_code']})
with (OUT/'commands-final.json').open('x',encoding='utf-8') as f:json.dump(commands,f,ensure_ascii=False,indent=2)
with (OUT/'historical-preservation.json').open('x',encoding='utf-8') as f:json.dump({'old_total':len(old),'unchanged':len(old)-len(changes),'intentional_source_status_changes':changes,'old_evidence_and_datasets':'UNCHANGED'},f,indent=2)
paths=[]
for folder in ['modules/voice_A','system_qwen35/app','platform/qwen35/a03','eval/qwen35/a03']:
    paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
paths += [ROOT/p for p in ['docs/PROJECT_STATUS.json','docs/DESIGN_GAP.md','docs/status/A.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md','docs/DECISIONS.md','docs/handoffs/A_A03_20261002.md','contracts/qwen35/contracts.lock']]
# Seal/verify command logs are written after execution: exclude these self-references.
paths=[p for p in paths if p.name not in ('files.sha256.json','seal.json','verify-seal.json')]
manifest={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(set(paths))}
with (OUT/'files.sha256.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
print(json.dumps({'files':len(manifest),'manifest_sha256':sha(OUT/'files.sha256.json'),'report_sha256':sha(OUT/'REPORT.json'),'historical_changes':changes}))
