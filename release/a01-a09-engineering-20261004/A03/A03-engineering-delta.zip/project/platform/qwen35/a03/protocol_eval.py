"""Real persistent worker: mandatory ops, streaming order, cancellation, paths."""
import json,sys,time,shutil,wave
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.audio_adapter import VoiceClient
out=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'eval/qwen35/a03/protocol-v1');out.mkdir(exist_ok=False);spool=out/'spool'
c=VoiceClient(spool,out/'worker');checks=[]
def ck(name,condition):checks.append({'name':name,'pass':bool(condition)})
try:
    ck('hello_capability',c.hello['capabilities']['streaming_asr'] and c.hello['max_concurrency']==1)
    (spool/'s').mkdir()
    src=ROOT/'eval/qwen35/a03/audio-eval-v1/spool/fixture/q_location.wav';shutil.copy2(src,spool/'s/input.wav')
    for path in ('../outside.wav','/tmp/anything.wav','other/input.wav','s/../../input.wav','https://example.com/a.wav'):
        r=c.call('transcribe',session_id='s',wav_path=path,language='zh');ck('path_reject:'+path,r['type']=='error')
    (spool/'s/link.wav').symlink_to(src)
    r=c.call('transcribe',session_id='s',wav_path='s/link.wav',language='zh');ck('symlink_reject',r['type']=='error');(spool/'s/link.wav').unlink()
    h=c.call('asr_begin',session_id='s',sample_rate=16000,channels=1,format='pcm_s16le');ck('begin',h['type']=='result');stream=h['stream_id']
    with wave.open(str(src),'rb') as w:raw=w.readframes(w.getnframes())
    chunk=spool/'s/chunk.pcm';chunk.write_bytes(raw[:6400].ljust(6400,b'\0'))
    r=c.call('asr_push',session_id='s',stream_id=stream,seq=1,pcm_path='s/chunk.pcm');ck('out_of_order_reject',r['type']=='error')
    r=c.call('asr_push',session_id='s',stream_id=stream,seq=0,pcm_path='s/chunk.pcm');ck('ordered_ack',r.get('ack') is True and r.get('final') is False)
    # Input removed only AFTER ack; reset must not delete unrelated input.
    chunk.unlink();r=c.call('reset',session_id='s');ck('reset_epoch',r['epoch']==1 and (spool/'s/input.wav').exists())
    r=c.call('asr_finish',session_id='s',stream_id=stream);ck('old_stream_reject',r['type']=='error')
    r=c.call('transcribe',session_id='s',epoch=0,wav_path='s/input.wav',language='zh');ck('old_epoch_reject',r['type']=='error')
    begin=c.call('asr_begin',session_id='s',sample_rate=16000,channels=1,format='pcm_s16le');stream=begin['stream_id']
    for seq,start in enumerate(range(0,len(raw),6400)):
        chunk.write_bytes(raw[start:start+6400].ljust(6400,b'\0'))
        r=c.call('asr_push',session_id='s',stream_id=stream,seq=seq,pcm_path='s/chunk.pcm')
        ck('ack_'+str(seq),r.get('ack') is True);chunk.unlink()
    r=c.call('asr_finish',session_id='s',stream_id=stream);ck('unique_final',r.get('final') is True and bool(r.get('text')))
    r=c.call('asr_finish',session_id='s',stream_id=stream);ck('duplicate_final_reject',r['type']=='error')
    handle=c.begin('synthesize',request_id='canceljob',session_id='s',text='我没有气短。'*20,output_dir='s/out')
    time.sleep(.05) # Real in-flight compute, not a fake delayed model.
    cancelled=c.call('cancel',request_id='canceljob')
    r=c.finish(handle);ck('cancel_pending_truthful',cancelled.get('status')=='cancel_pending' and cancelled.get('computation_stopped') is False)
    ck('late_tts_discarded',r['type']=='event' and r.get('status')=='cancelled_result_discarded' and 'wav_path' not in r)
    ck('was_actually_running',cancelled.get('was_running') is True)
    r=c.call('synthesize',session_id='s',text='这是合成测试。',output_dir='s/out');ck('reuse_persistent_models',r['type']=='result')
    output=spool/r['wav_path'];ck('output_exists',output.is_file())
    c.call('reset',session_id='s');ck('reset_owned_outputs_only',not output.exists() and (spool/'s/input.wav').exists())
finally:c.close()
with (out/'summary.json').open('x',encoding='utf-8') as f:json.dump({'checks':checks,'pass':all(x['pass'] for x in checks),'domain':'PC'},f,ensure_ascii=False,indent=2)
print(json.dumps({'passed':sum(x['pass'] for x in checks),'total':len(checks)}))
raise SystemExit(0 if all(x['pass'] for x in checks) else 1)
