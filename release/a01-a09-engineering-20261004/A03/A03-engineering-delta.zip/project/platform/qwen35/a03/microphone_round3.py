"""User-gated retest of capture readiness; preserve the same spoken prompt."""
import datetime,json,os,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a03/mic-round3-20261002'

def main():
    OUT.mkdir(parents=True,exist_ok=False)
    consent={'authorized':True,'evidence':'User authorized own-voice synthetic testing and requested continuation after round2 failure',
        'scope':'Own voice, same synthetic question, up to 15 seconds; user Enter starts device',
        'expected_reading':'你的胸痛每次持续多久？','recording_started_at_launch':False,
        'raw_audio':'temporary /dev/shm, removed on normal CLI exit',
        'retained':'local raw transcript, numeric PCM diagnostics and command logs; no waveform retention',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT/'authorization.json').write_text(json.dumps(consent,ensure_ascii=False,indent=2),encoding='utf-8')
    print('第三轮复测：你的胸痛每次持续多久？（保持正常语速）',flush=True)
    print('按Enter准备后，等看到“现在开始说话”再读；读完按Enter停止。',flush=True)
    print('转录准确才输入 YES 再按Enter；错误就直接回车，不改成预设问句。',flush=True)
    env=dict(os.environ);prefix='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu'
    env['LD_LIBRARY_PATH']=prefix+':'+prefix+'/pulseaudio';env['PYTHONUNBUFFERED']='1'
    command='python3 -u -m system_qwen35.app.voice_cli --record-authorized --output eval/qwen35/a03/mic-round3-20261002/run'
    argv=['script','-q','-e','-f','-c',command,str(OUT/'terminal.log')]
    result=subprocess.run(argv,cwd=ROOT,env=env)
    (OUT/'command.json').write_text(json.dumps({'argv':argv,'exit_code':result.returncode,'domain':'PC','board':'NOT_TESTED',
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2),encoding='utf-8')
    print('\n测试进程结束，退出码：'+str(result.returncode)+'。请回Codex反馈识别及播放情况。',flush=True)
    input('按Enter关闭窗口。')
    return result.returncode
if __name__=='__main__':raise SystemExit(main())
