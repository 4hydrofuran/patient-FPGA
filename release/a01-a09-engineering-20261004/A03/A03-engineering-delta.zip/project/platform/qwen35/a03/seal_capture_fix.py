"""Capture-fix evidence index; does not access or open any audio device."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'eval/qwen35/a03/capture-fix-v1'
paths=[ROOT/p for p in ['system_qwen35/app/pc_audio.py','system_qwen35/app/voice_cli.py',
    'system_qwen35/app/test_capture.py','platform/qwen35/a03/microphone_round3.py',
    'platform/qwen35/a03/evidence/capture-fix-unit.json','platform/qwen35/a03/evidence/capture-fix-contracts.json',
    'platform/qwen35/a03/evidence/capture-fix-config.json','docs/PROJECT_STATUS.json','docs/status/A.md',
    'eval/qwen35/a03/mic-round2-20261002/REVIEW.json']]
paths+=list((out/'before').glob('*'))+[out/'REPORT.md']
manifest={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with (out/'files.sha256.json').open('x',encoding='utf-8') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
unit=json.loads((ROOT/'platform/qwen35/a03/evidence/capture-fix-unit.json').read_text())
assert unit['exit_code']==0 and 'Ran 62 tests' in unit['stderr']
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
print(json.dumps({'files':len(manifest),'sha256':hashlib.sha256((out/'files.sha256.json').read_bytes()).hexdigest(),
    'unit_tests':62,'microphone_retest':'NOT_TESTED','BOARD':'NOT_TESTED'}))
