"""Summarize actual immutable run outputs, never infer missing tests as PASS."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=ROOT/'eval/qwen35/a03'
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
audio=read('eval/qwen35/a03/audio-eval-v1/summary.json')
protocol=read('eval/qwen35/a03/protocol-v2/summary.json')
negative=read('eval/qwen35/a03/negative-v1/summary.json')
endpoint=read('eval/qwen35/a03/endpoint-v1/summary.json')
offline=read('eval/qwen35/a03/offline-v4/summary.json')
turns=[json.loads(x) for x in (OUT/'offline-v4/turns.jsonl').read_text(encoding='utf-8').splitlines()]
cancel=read('eval/qwen35/a03/cancel-loop-v1/summary.json')
commands=[]
for p in sorted((ROOT/'platform/qwen35/a03/evidence').glob('*.json')):
    obj=json.loads(p.read_text(encoding='utf-8'))
    if 'argv' in obj and obj.get('exit_code') is not None:commands.append(dict(log=str(p.relative_to(ROOT)).replace('\\','/'),argv=obj['argv'],exit_code=obj['exit_code']))
pip=read('eval/qwen35/a03/pip-install.json');packages=[]
for obj in pip['install']:
    packages.append(dict(name=obj['metadata']['name'],version=obj['metadata']['version'],url=obj['download_info']['url'],sha256=obj['download_info']['archive_info']['hashes']['sha256']))
with (OUT/'python-packages.lock.json').open('x',encoding='utf-8') as f:json.dump(dict(target='CPython310_linux_x86_64',packages=packages),f,indent=2)
with (ROOT/'modules/voice_A/requirements.pc.lock.txt').open('x',encoding='utf-8') as f:
    f.write('# Generated from successful pip installation receipt, PC CPython310 x86_64 only.\n')
    for p in packages:f.write(f"{p['name']} @ {p['url']} --hash=sha256:{p['sha256']}\n")
timings=[]
for t in turns:
    timings.append(dict(fixture=t['fixture_id'],answer_source=t['application']['answer_source'],fallback_reason=t['application']['fallback_reason'],
        startup_ready_ms=(t['service_ready_ns']-t['startup_begin_ns'])/1e6,
        wav_ready_from_file_submit_ms=(t['tts']['wav_ready_ns']-t['turn_begin_ns'])/1e6,
        playback_submit_from_file_submit_ms=(t['playback']['playback_submit_ns']-t['turn_begin_ns'])/1e6,
        first_valid_sound_ms=None,acoustic_onset_ns=None))
assert protocol['pass'] and cancel['pass'] and all(x['passed'] for x in negative['checks'])
assert offline['playback_api_completed']==4 and all(x['application']['final_check']['status']=='pass' for x in turns)
report=dict(stage='A03',status='PARTIAL_PC_SYNTHETIC_LOOP_PASS_PENDING_MIC_AND_HUMAN_LISTEN',
    domain='PC',domain_tests={'PC':'PASS_SCOPED_SOFTWARE_TESTS','Csim':'NOT_TESTED','Cosim':'NOT_TESTED','synthesis':'NOT_TESTED','implementation':'NOT_TESTED','cross_build':'NOT_TESTED','BOARD':'NOT_TESTED'},
    unit_tests={'new':15,'a02_regression':36,'total':51,'evidence':'platform/qwen35/a03/evidence/unit-final.json'},
    real_protocol_checks={'passed':len(protocol['checks']),'total':len(protocol['checks'])},negative_checks=len(negative['checks']),
    synthetic_audio=audio,endpoint={'runs':endpoint['runs'],'endpoint_text_mismatch_by_threshold':{str(ms):sum(r['endpoint_text_differs_from_full_ptt'] for r in endpoint['rows'] if r['endpoint_ms']==ms) for ms in [600,900,1200]},
        'default':'PUSH_TO_TALK','human_tail_cutoff':'NOT_TESTED','caveat':'Synthetic full-PTT literal proxy, not word-aligned clinical metric'},
    offline_loop=offline,real_playback_cancel={'pass':cancel['pass'],'played_history_count':len(cancel['session']['played']),'acoustic_stop_verified':False},
    timings=timings,timing_scope='Small samples, file input faster than realtime; startup not acoustic onset; no KV260 claim',
    resources_lock='modules/voice_A/resources.lock.json',sources='eval/qwen35/a03/licenses-v1/receipt.json',commands=commands,
    known_quality_failures=['ASR clinical slot substitutions retained despite zero literal negation/number deletion','Model candidate rejected by checker: visible template fallback','All endpoint thresholds truncated constructed pause example','TTS shei2 lexicon warning; no human listening'],
    pending=['Explicit microphone consent and actual recording test','Human Chinese intelligibility and negative/number review','Actual human verification of implemented confirmation UX','Medical teacher review remains pending','ARM64 build and actual BOARD','Acoustic loopback timestamp measurement'],
    next='Request microphone consent / listening review; do not label whole A03 PASS',commit=None,remote_push=False,
    skill='llama-cpp: preserve fixed isolated CPU runtime, no model rebuild',codex_settings={'requested':'GPT-6 Astra / High / Standard','actual':'unknown','changed':False})
with (OUT/'REPORT.json').open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
print(json.dumps({'report':str(OUT/'REPORT.json'),'status':report['status'],'protocol_checks':len(protocol['checks']),'unit_tests':51},ensure_ascii=False))
