#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Patientqwen
audio_prefix=/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu
export LD_LIBRARY_PATH="$audio_prefix:$audio_prefix/pulseaudio${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
# User+network namespace, no external route. Unix WSLg audio socket is local.
exec unshare -Urn python3 platform/qwen35/a03/offline_loop.py "$@"
