"""Development endpoint sweep; retain every sample and never trim source silence."""
import json,shutil,sys,wave
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.audio_adapter import VoiceClient
out=ROOT/'eval/qwen35/a03/endpoint-v1';out.mkdir(exist_ok=False);rows=[]
fixtures=json.loads((ROOT/'eval/qwen35/a03/audio-eval-v1/fixtures.json').read_text())
selected=[x for x in fixtures if x['id'] in ('q_location','number','pause_joined')]
for endpoint in (600,900,1200):
    base=out/str(endpoint);spool=base/'spool';c=VoiceClient(spool,base/'worker',endpoint)
    try:
        (spool/'s').mkdir()
        for fixture in selected:
            c.call('reset',session_id='s')
            r=c.call('asr_begin',session_id='s',sample_rate=16000,channels=1,format='pcm_s16le');stream=r['stream_id']
            with wave.open(str(ROOT/fixture['wav']),'rb') as w:raw=w.readframes(w.getnframes())
            # Append fixed flush-test silence without removing any original audio.
            raw+=b'\0'*(16000*2*2);first_endpoint=None;partials=[]
            for seq,pos in enumerate(range(0,len(raw),6400)):
                chunk=spool/'s/chunk.pcm';chunk.write_bytes(raw[pos:pos+6400].ljust(6400,b'\0'))
                p=c.call('asr_push',session_id='s',stream_id=stream,seq=seq,pcm_path='s/chunk.pcm')
                if not p.get('ack'):raise RuntimeError(p)
                chunk.unlink();partials.append(p)
                if p.get('endpoint_detected') and first_endpoint is None:first_endpoint={'at_audio_ms':(seq+1)*200,'text':p['partial_text']}
            final=c.call('asr_finish',session_id='s',stream_id=stream)
            row={'endpoint_ms':endpoint,'fixture':fixture,'first_endpoint':first_endpoint,'full_ptt_final':final,
                'would_cut_before_last_phrase':bool(first_endpoint and fixture.get('last_phrase_start_ms') and first_endpoint['at_audio_ms']<fixture['last_phrase_start_ms']),
                'endpoint_text_differs_from_full_ptt':bool(first_endpoint and first_endpoint['text']!=final.get('text')),
                'metric_scope':'constructed pause/literal tail proxy, not human acoustic word alignment','partials':partials}
            rows.append(row)
            with (out/'results.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    finally:c.close()
with (out/'summary.json').open('x',encoding='utf-8') as f:json.dump({'domain':'PC','runs':len(rows),'default_mode':'PUSH_TO_TALK',
    'automatic_endpoint_not_selected_by_best_score':True,'rows':[{k:v for k,v in x.items() if k not in ('partials','fixture')}|{'fixture_id':x['fixture']['id']} for x in rows],
    'human_slow_speech':'NOT_TESTED','board':'NOT_TESTED'},f,ensure_ascii=False,indent=2)
print(json.dumps({'runs':len(rows),'before_last_phrase':sum(x['would_cut_before_last_phrase'] for x in rows)}))
