"""Second user-started mic round; preserve round-one artifacts and runtime."""
import datetime,json,os,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'eval/qwen35/a03/mic-round2-20261002'

def main():
    OUT.mkdir(parents=True,exist_ok=False)
    consent={'scope':'User asks one synthetic interview question, own voice only, up to 15 seconds',
        'evidence':'User authorized recording and replied 好的 继续 to the proposed second question in this chat on 2026-10-02',
        'authorized':True,'recording_started_at_launch':False,
        'raw_audio':'temporary /dev/shm, removed on normal CLI exit',
        'retained':'local transcription, diagnostics and command transcript',
        'expected_reading':'你的胸痛每次持续多久？',
        'acceptance':'Inspect actual llm_calls and answer_source; do not assume MODEL or conceal fallback',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT/'authorization.json').write_text(json.dumps(consent,ensure_ascii=False,indent=2),encoding='utf-8')
    print('第二轮：请只问「你的胸痛每次持续多久？」',flush=True)
    print('正在加载模型，尚未录音。出现准备提示后按 Enter 开始；读完按 Enter 停止。',flush=True)
    print('核对原始转录，准确时输入 YES 并按 Enter；不准确则直接回车。',flush=True)
    env=dict(os.environ)
    prefix='/home/member-a/voice-a03/audio-libs/root/usr/lib/x86_64-linux-gnu'
    env['LD_LIBRARY_PATH']=prefix+':'+prefix+'/pulseaudio'
    env['PYTHONUNBUFFERED']='1'
    command='python3 -u -m system_qwen35.app.voice_cli --record-authorized --output eval/qwen35/a03/mic-round2-20261002/run'
    argv=['script','-q','-e','-f','-c',command,str(OUT/'terminal.log')]
    result=subprocess.run(argv,cwd=ROOT,env=env)
    (OUT/'command.json').write_text(json.dumps({'argv':argv,'exit_code':result.returncode,'domain':'PC',
        'board':'NOT_TESTED','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2),encoding='utf-8')
    print('\n测试进程已结束，退出码：'+str(result.returncode),flush=True)
    print('请返回 Codex 告诉我已完成，以及是否听清回复。',flush=True)
    input('按 Enter 关闭此窗口。')
    return result.returncode

if __name__=='__main__':raise SystemExit(main())
