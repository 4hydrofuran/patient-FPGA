#!/usr/bin/env bash
set -euo pipefail
audio_root=/home/member-a/voice-a03/audio-libs
mkdir -p "$audio_root/packages" "$audio_root/root"
cd "$audio_root/packages"
apt download libpulse0 libsndfile1 libasyncns0 libwrap0 libflac8 libogg0 libvorbis0a libvorbisenc2
for package in ./*.deb; do dpkg-deb -x "$package" "$audio_root/root"; done
sha256sum ./*.deb
