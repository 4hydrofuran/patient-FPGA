import json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from system_qwen35.app.audio_adapter import VoiceClient
out=ROOT/'eval/qwen35/a03/smoke-v1';out.mkdir(exist_ok=False)
c=VoiceClient(out/'spool',out/'worker')
try:
    print(json.dumps({'hello':c.hello},ensure_ascii=False),flush=True)
    r=c.call('synthesize',session_id='synthetic',text='我没有气短。疼痛持续十分钟。',output_dir='synthetic/out')
    print(json.dumps(r,ensure_ascii=False),flush=True)
    with (out/'tts.json').open('x',encoding='utf-8') as f:json.dump(r,f,ensure_ascii=False,indent=2)
    assert r['type']=='result',r
finally:c.close()
