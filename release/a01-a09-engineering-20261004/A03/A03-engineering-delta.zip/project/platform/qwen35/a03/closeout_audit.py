"""Read-only evidence/A04-input audit. No models, devices, downloads or export.

Only writes a new evidence directory. Historical seals are checked against their
own snapshots, not silently replaced with hashes of changed files.
"""
import argparse
import hashlib
import json
import shutil
import struct
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PKG = ROOT / 'docs/plan_qwen35/KV260_Qwen35_A_详细设计增强任务包_20261002/KV260_Qwen35_A_设计增强包_20261002'
MUTABLE = ['AGENTS.md', 'docs/PROJECT_STATUS.json', 'docs/status/A.md',
           'docs/DESIGN_GAP.md', 'docs/TEST_MATRIX.md', 'docs/DECISIONS.md',
           'docs/AI_ASSISTANCE.md', 'modules/voice_A/manifest.json',
           'modules/voice_A/README.md']


def read(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', required=True)
    a = ap.parse_args()
    out = ROOT / a.output
    out.mkdir(parents=True, exist_ok=False)
    checks = []

    def check(name, ok, detail=None):
        checks.append(dict(name=name, passed=bool(ok), detail=detail))

    def dump(name, value):
        with (out / name).open('x', encoding='utf-8') as f:
            json.dump(value, f, ensure_ascii=False, indent=2)

    for name in MUTABLE:
        dest = out / 'before' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, dest)

    initial = read('eval/qwen35/a03/files.sha256.json')
    capture = read('eval/qwen35/a03/capture-fix-v1/files.sha256.json')
    initial_diff = {p: {'expected': h, 'actual': sha(ROOT/p) if (ROOT/p).is_file() else None}
                    for p, h in initial.items() if not (ROOT/p).is_file() or sha(ROOT/p) != h}
    allowed = {'docs/PROJECT_STATUS.json', 'docs/status/A.md',
               'system_qwen35/app/pc_audio.py', 'system_qwen35/app/voice_cli.py'}
    check('initial_seal_only_documented_changes', set(initial_diff) <= allowed, initial_diff)
    for p in ('system_qwen35/app/pc_audio.py', 'system_qwen35/app/voice_cli.py'):
        before = ROOT / 'eval/qwen35/a03/capture-fix-v1/before' / Path(p).name
        check('old_source_retained:' + p, sha(before) == initial[p])
    capture_diff = {p: {'expected': h, 'actual': sha(ROOT/p) if (ROOT/p).is_file() else None}
                    for p, h in capture.items() if not (ROOT/p).is_file() or sha(ROOT/p) != h}
    check('capture_fix_seal_only_status_updates', set(capture_diff) <= {'docs/PROJECT_STATUS.json', 'docs/status/A.md'}, capture_diff)
    unit = read('platform/qwen35/a03/evidence/capture-fix-unit.json')
    check('62_test_receipt', unit['exit_code'] == 0 and 'Ran 62 tests' in unit['stderr'])
    protocol = read('eval/qwen35/a03/protocol-v2/summary.json')
    check('32_real_protocol_checks', len(protocol['checks']) == 32 and all(x['pass'] for x in protocol['checks']))
    neg = read('eval/qwen35/a03/negative-v1/summary.json')
    check('6_rejections', len(neg['checks']) == 6 and all(x['passed'] for x in neg['checks']))
    cancel = read('eval/qwen35/a03/cancel-loop-v1/summary.json')
    check('cancel_unplayed_history_empty', cancel['pass'] and cancel['thread_finished'] and not cancel['session']['played'])
    offline = read('eval/qwen35/a03/offline-v4/summary.json')
    turns = [json.loads(x) for x in (ROOT/'eval/qwen35/a03/offline-v4/turns.jsonl').read_text().splitlines()]
    network = read('eval/qwen35/a03/offline-v4/network.json')
    check('offline_cold_wav_four_real_turns', len(turns) == 4 and offline['playback_api_completed'] == 4
          and not network['route'] and 'Network is unreachable' in network['external_connect_error']
          and sum(t['application']['answer_source'] == 'MODEL' for t in turns) == 2
          and all(t['application']['final_check']['status'] == 'pass' and t['playback']['playback_api_completed'] for t in turns))
    check('no_acoustic_timestamp_fabrication', all(t['acoustic_onset_ns'] is None and t['first_valid_sound_ns'] is None for t in turns))
    ep = read('eval/qwen35/a03/endpoint-v1/summary.json')
    ep_fail = {str(ms): sum(r['endpoint_text_differs_from_full_ptt'] for r in ep['rows'] if r['endpoint_ms'] == ms) for ms in (600, 900, 1200)}
    check('endpoint_failures_retained_PTT_default', ep['runs'] == 9 and ep_fail == {'600': 1, '900': 1, '1200': 1}
          and ep['default_mode'] == 'PUSH_TO_TALK', ep_fail)
    m = 'eval/qwen35/a03/mic-round4-20261002/'
    mic = read(m+'run/microphone-result.json'); result = mic['result']
    review = read(m+'REVIEW.json')
    wire = [json.loads(x) for x in (ROOT/m/'run/qwen/wire.jsonl').read_text().splitlines()]
    generated = [x for x in wire if x.get('type') == 'result']
    check('mic4_actual_qwen_and_fact_check', result['asr']['text'] == review['actual_transcript']
          and result['application']['answer_source'] == 'MODEL' and result['application']['llm_calls'] == 1
          and len(generated) == 1 and generated[0]['text'] == result['application']['text']
          and generated[0]['status'] == 'OK' and generated[0]['gpu_layers'] == 0
          and result['application']['final_check']['status'] == 'pass'
          and result['human_transcript_confirmation'] and result['playback']['playback_api_completed'])
    check('mic4_user_listening_and_exit', review['human_reports_playback_clear'] and review['human_reports_transcript_accurate']
          and read(m+'command.json')['exit_code'] == 0 and wire[-1]['exit_code'] == 0)
    diag = mic['recording']['diagnostics']
    check('capture_first_block_before_prompt', diag['first_chunk_received_ns'] <= diag['ready_announced_ns'])
    check('raw_mic4_audio_not_retained', not list((ROOT/m).rglob('*.wav')))
    r1 = read('eval/qwen35/a03/mic-round1-20261002/REVIEW.json')
    check('mic1_negation_number_evidence', all(s in r1['actual_transcript'] for s in r1['checked_fragments'])
          and r1['user_confirmed_transcript_in_terminal'] == 'YES')
    r2 = read('eval/qwen35/a03/mic-round2-20261002/REVIEW.json')
    check('mic2_failure_still_retained', r2['human_confirms_asr_error'] and r2['root_cause'] == 'UNDETERMINED'
          and sha(ROOT/'eval/qwen35/a03/mic-round2-20261002/REVIEW.json') == capture['eval/qwen35/a03/mic-round2-20261002/REVIEW.json'])
    check('withdrawn_round_not_restored', not (ROOT/'eval/qwen35/a03/mic-round3-20261002').exists())
    voice_lock = read('modules/voice_A/resources.lock.json')
    voice_bad = [p for p,h in voice_lock['files'].items() if not (ROOT/p).is_file() or sha(ROOT/p) != h]
    check('voice_locked_resources', not voice_bad, {'count':len(voice_lock['files']), 'mismatches':voice_bad})
    voice_checks = list(checks)

    # A04 preflight: source identities, actual safetensors header/data, no export.
    lock = read('models/model.lock.json'); mapping = read('quant/qwen35_tensor_map.json')
    for p, spec in lock['source_files'].items():
        check('model_source:' + p, (ROOT/p).stat().st_size == spec['bytes'] and sha(ROOT/p) == spec['sha256'])
    for p, spec in lock['converted_files'].items():
        fp = ROOT/'artifacts/qwen35-0.8b'/p
        check('existing_GGUF:' + p, fp.stat().st_size == spec['bytes'] and sha(fp) == spec['sha256'])
    check('revision_match', mapping['model_revision'] == lock['revision'] == '2fc06364715b967f1860aea9cf38778875588b17')
    config = read('artifacts/qwen35-0.8b/source/config.json')['text_config']
    check('architecture', config['num_hidden_layers'] == 24 and config['hidden_size'] == 1024
          and config['intermediate_size'] == 3584 and config['layer_types'].count('linear_attention') == 18
          and config['layer_types'].count('full_attention') == 6 and config['tie_word_embeddings'])
    mlp = mapping['mlp']; source = ROOT/'artifacts/qwen35-0.8b/source'
    check('72_unique_MLPs', len(mlp) == 72 and {(t['layer'],t['op']) for t in mlp} == {(l,o) for l in range(24) for o in ('gate','up','down')})
    tensor_results = []
    with (source/mlp[0]['source_file']).open('rb') as f:
        header_len = struct.unpack('<Q', f.read(8))[0]; header = json.loads(f.read(header_len))
        for t in mlp:
            h = header[t['source']]; n,k = t['source_shape_NK']; start,end = h['data_offsets']
            f.seek(8+header_len+start); digest = hashlib.sha256(f.read(end-start)).hexdigest()
            ok = (h['shape'] == [n,k] == ([1024,3584] if t['op'] == 'down' else [3584,1024])
                  and h['dtype'] == t['dtype'] == 'BF16' and t['absolute_offset'] == 8+header_len+start
                  and t['data_offsets'] == [start,end] and t['ggml_ne_KN'] == [k,n]
                  and t['bias'] is None and t['transpose_data'] is False and digest == t['source_tensor_sha256'])
            tensor_results.append(dict(source=t['source'], N=n, K=k, sha256=digest, passed=ok))
    check('actual_72_tensor_shapes_offsets_hashes', all(t['passed'] for t in tensor_results))
    total = sum(n*k//2 + n*(k//128)*4 for n,k in (t['source_shape_NK'] for t in mlp))
    check('theoretical_W4_Sw_bytes', total == 140378112, total)
    runtime_source = Path('/home/member-a/qwen35-a01/llama.cpp-'+lock['runtime_commit'])
    for p,h in lock['runtime_source_hashes'].items():
        check('fixed_runtime_source:'+p, (runtime_source/p).is_file() and sha(runtime_source/p) == h)
    binary = Path('/home/member-a/qwen35-a01/native-design-v1/qwen35-cpu')
    check('native_CPU_entry_exists', binary.is_file())
    fixture = PKG/'fixtures'; hand = json.loads((fixture/'hand_sample.json').read_text())
    check('hand_sample_files', all(sha(fixture/p) == h for p,h in hand['files'].items()))
    packed = (fixture/'w_packed.bin').read_bytes()
    check('hand_sample_byte_labels', all(packed[int(i)] == int(b,16) for i,b in hand['w_bytes_at_offsets'].items()))
    check('fixed_public_contract', all(sha(ROOT/'contracts/qwen35'/p) == h for p,h in read('contracts/qwen35/contracts.lock')['files'].items()))
    preflight_checks = checks[len(voice_checks):]
    dump('A04_PREFLIGHT.json', dict(status='PASS_INPUTS_READY' if all(c['passed'] for c in preflight_checks) else 'FAIL',
        implementation_started=False, checks=preflight_checks, tensor_checks=tensor_results,
        model_revision=lock['revision'], runtime_commit=lock['runtime_commit'], binary_sha256=sha(binary) if binary.is_file() else None,
        theoretical_weight_scale_bytes=total, theoretical_not_exported=True, BOARD='NOT_TESTED',
        remaining_A04_deliverables=['72 W4/Sw sidecars', 'Independent Python/C++ reference',
            'Byte/numerical edge regressions', 'Qwen3.5 activations at layers 0/3/4/23', 'Quantization error and memory measurements'],
        candidate_delivery_not_required=True))
    dump('AUDIT.json', dict(domain='PC', passed=all(c['passed'] for c in checks), checks=voice_checks,
         historical_seal_files=len(initial), capture_seal_files=len(capture), new_recording=False,
         reran_models=False, runtime_modified=False, source_inspection_errors=[
             'Read-only discovery: design/qwen35/fixtures did not exist; used package fixtures instead.',
             'Read-only PowerShell rg wildcard argument was invalid; resolved exact paths.'],
         branch=subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(),
         head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()))
    print(json.dumps({'checks':len(checks), 'failed':[c['name'] for c in checks if not c['passed']],
                      'output':str(out),'models_run':False,'board':'NOT_TESTED'}))
    return 0 if all(c['passed'] for c in checks) else 1


if __name__ == '__main__':
    raise SystemExit(main())
