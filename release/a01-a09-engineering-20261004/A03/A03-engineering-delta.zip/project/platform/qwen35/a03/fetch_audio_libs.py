"""HTTPS fetch from official Ubuntu paths; unpack only in private audio prefix."""
import hashlib,json,subprocess,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
out=ROOT/'artifacts/voice_A/audio-packages';out.mkdir(exist_ok=True)
names=['libpulse0','libsndfile1','libasyncns0','libwrap0','libflac8','libogg0','libvorbis0a','libvorbisenc2','libopus0']
results=[]
for name in names:
    text=subprocess.check_output(['wsl','-d','KV260-A-2204','--','apt-cache','show','--no-all-versions',name],text=True,encoding='utf-8')
    fields=dict(line.split(': ',1) for line in text.splitlines() if ': ' in line and not line.startswith(' '))
    url='https://archive.ubuntu.com/ubuntu/'+fields['Filename'];p=out/Path(fields['Filename']).name
    if not p.exists():
        data=None
        for host in ('https://archive.ubuntu.com/ubuntu/','https://security.ubuntu.com/ubuntu/','http://security.ubuntu.com/ubuntu/'):
            url=host+fields['Filename']
            try:
                with urllib.request.urlopen(url,timeout=15) as src:data=src.read()
                assert hashlib.sha256(data).hexdigest()==fields['SHA256']
                break
            except Exception as exc:print('FETCH_FAILED '+url+' '+str(exc),flush=True);data=None
        if data is None:raise RuntimeError('All official download routes failed: '+name)
        with p.open('xb') as dst:dst.write(data)
    digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest==fields['SHA256']
    subprocess.run(['wsl','-d','KV260-A-2204','--','dpkg-deb','-x','/mnt/c/'+str(p.relative_to(Path('C:/'))).replace('\\','/'),'/home/member-a/voice-a03/audio-libs/root'],check=True)
    results.append({'package':name,'version':fields['Version'],'sha256':digest,'url':url})
with (ROOT/'eval/qwen35/a03/audio-packages-v2.json').open('x',encoding='utf-8') as f:json.dump(results,f,indent=2)
print(json.dumps({'downloaded_verified_unpacked':len(results),'system_install':False}))
