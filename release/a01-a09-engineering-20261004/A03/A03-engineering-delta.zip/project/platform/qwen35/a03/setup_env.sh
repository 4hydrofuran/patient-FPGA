#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Patientqwen
envdir=/home/member-a/voice-a03/venv
if [ ! -e "$envdir/bin/python" ]; then python3 -m venv "$envdir"; fi
"$envdir/bin/python" -m pip install --index-url https://pypi.org/simple pip==25.0.1
"$envdir/bin/python" -m pip install --index-url https://pypi.org/simple --report /mnt/c/Patientqwen/eval/qwen35/a03/pip-install.json sherpa-onnx==1.12.40 numpy==1.26.4 scipy==1.15.3 soundfile==0.13.1
"$envdir/bin/python" -m pip freeze
