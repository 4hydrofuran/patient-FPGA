"""Compile/run A0 fixed ABI fixture with a caller-selected C++ compiler."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from common_sample import ROOT, write_fixture


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cxx", required=True)
    args = parser.parse_args()
    cxx = Path(args.cxx).resolve()
    if not cxx.is_file():
        parser.error("Compiler path does not exist")
    build = ROOT / "bench/runtime/build"
    data = build / "sample"
    write_fixture(data)
    exe = build / ("common_sample.exe" if os.name == "nt" else "common_sample")
    env = os.environ.copy()
    env["PATH"] = str(cxx.parent) + os.pathsep + env.get("PATH", "")
    # AMD-bundled MinGW keeps compiler support DLLs beside libexec cc1plus.
    support = list(cxx.parent.parent.glob("libexec/gcc/*/*"))
    env["PATH"] = os.pathsep.join(str(p) for p in support) + os.pathsep + env["PATH"]
    records = []
    def run(command, expected=0):
        cp = subprocess.run([str(x) for x in command], cwd=ROOT, env=env, capture_output=True, text=True, timeout=90)
        records.append({"command":[str(x) for x in command], "exit_code":cp.returncode,
                        "expected_exit_code":expected,"stdout":cp.stdout,"stderr":cp.stderr})
        if cp.returncode != expected:
            raise RuntimeError(cp.stdout + cp.stderr)
    passed = False
    try:
        run([cxx, "--version"])
        run([cxx, "-std=c++17", "-O2", "-fno-fast-math", "-ffp-contract=off", "-I", ROOT,
             ROOT / "bench/runtime/common_sample.cpp", "-o", exe])
        run([exe, data])
        for name, mode in [("bad-sign", "sign"), ("reserved-code", "reserved"), ("short-file", "short")]:
            case = build / name
            case.mkdir(parents=True, exist_ok=True)
            for src in data.iterdir():
                shutil.copy2(src, case / src.name)
            path = case / "w.bin"
            b = bytearray(path.read_bytes())
            if mode == "sign": b[0] ^= 0x10
            elif mode == "reserved": b[0] = (b[0] & 0xF0) | 8
            else: b = b[:-1]
            path.write_bytes(b)
            run([exe, case], expected=1)
        passed = True
    finally:
        output = ROOT / "bench/runtime/results/common_sample.json"
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps({"status":"PASS" if passed else "FAIL", "verification_level":"PC_TEST",
            "scope":"ONE fixed ABI fixture and three rejected mutations; NOT B golden, HLS or board test",
            "commands":records,"fixture_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in data.iterdir()}}, indent=2), encoding="utf-8", newline="\n")
    print(f"PASS: cross-language hand fixture + 3 negative cases; {output}")


if __name__ == "__main__":
    main()
