"""Local-only recovery archive. Does not stage, clean, push, or read B/C workspaces."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "platform/local/qwen35-a00-checkpoint-20261002"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    head = git("rev-parse", "HEAD").decode().strip()
    branch = git("branch", "--show-current").decode().strip()
    (OUT / "status-before.txt").write_bytes(git("status", "--porcelain=v1", "-uall"))
    (OUT / "tracked-before.patch").write_bytes(git("diff", "--binary", "HEAD"))
    (OUT / "index-before.patch").write_bytes(git("diff", "--cached", "--binary"))
    subprocess.run(["git", "bundle", "create", str(OUT / "history.bundle"), "--all"], cwd=ROOT, check=True)
    tracked = set(git("ls-files", "-z").decode().split("\0")) - {""}
    others = set(git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0")) - {""}
    prefixes = ("platform/", "quant/", "scripts/release/", "docs/handoffs/A", "docs/adr/A-", "docs/replan_20261001/", "docs/plan_qwen35/")
    selected = tracked | {p for p in others if p.startswith(prefixes)}
    manifest = {}
    with zipfile.ZipFile(OUT / "working-files.zip", "x", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(selected):
            p = ROOT / name
            if not p.is_file():
                continue
            if p.is_symlink() or p.suffix.lower() in {".lic", ".pem", ".key", ".gguf", ".safetensors"}:
                raise ValueError("Sensitive/large source unexpectedly selected: " + name)
            data = p.read_bytes()
            z.writestr(name, data)
            manifest[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    with zipfile.ZipFile(OUT / "working-files.zip") as z:
        assert set(z.namelist()) == set(manifest)
        for name, item in manifest.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == item["sha256"]
    result = {"branch": branch, "head": head, "files": manifest,
              "excluded_untracked_preserved_in_place": sorted(others - selected),
              "ignored_assets": "Preserved in place; NOT backed up by this archive",
              "archive_sha256": hashlib.sha256((OUT / "working-files.zip").read_bytes()).hexdigest()}
    (OUT / "manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    subprocess.run(["git", "bundle", "verify", str(OUT / "history.bundle")], cwd=ROOT, check=True)
    print(json.dumps({"checkpoint": str(OUT), "files": len(manifest), "head": head,
                      "archive_sha256": result["archive_sha256"], "verification": "PASS"}))


if __name__ == "__main__":
    main()
