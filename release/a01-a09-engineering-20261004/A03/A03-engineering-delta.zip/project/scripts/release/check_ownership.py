"""Local ownership guard; not a substitute for hosted branch protection."""
import argparse
import json
import subprocess
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]
RULES = json.loads((ROOT / "scripts/release/ownership.json").read_text(encoding="utf-8"))


def matches(path, rule):
    if rule.endswith("/") or rule in ("docs/handoffs/A", "docs/handoffs/B", "docs/handoffs/C", "docs/adr/A-"):
        return path.startswith(rule)
    return path == rule


def allowed(role, path, shared_draft=False):
    if "\\" in path or PurePosixPath(path).is_absolute() or ".." in PurePosixPath(path).parts or ":" in path:
        return False
    if any(matches(path,r) for r in RULES["read_only"]): return False
    delegated = [(p, owner) for p, owner in RULES.get("delegated_paths", {}).items() if matches(path, p)]
    if delegated:
        return role == max(delegated, key=lambda item: len(item[0]))[1]
    if any(matches(path,r) for r in RULES["shared_review"]):
        return role == "A" and shared_draft
    return any(matches(path,r) for r in RULES[role])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role",required=True,choices=list("ABC"))
    parser.add_argument("--allow-shared-draft",action="store_true")
    parser.add_argument("--staged",action="store_true")
    args=parser.parse_args()
    if args.allow_shared_draft:
        state=json.loads((ROOT/"contracts/review_state.json").read_text(encoding="utf-8"))
        if state["status"] != "DRAFT": parser.error("draft exception cannot approve a frozen contract change")
    commands=[["git","diff","--cached","--name-only","-z"]] if args.staged else [
        ["git","diff","HEAD","--name-only","-z"],["git","ls-files","--others","--exclude-standard","-z"]]
    paths=set()
    for command in commands:
        cp=subprocess.run(command,cwd=ROOT,check=True,capture_output=True)
        paths.update(p for p in cp.stdout.decode("utf-8").split("\0") if p)
    failures=[p for p in sorted(paths) if not allowed(args.role,p,args.allow_shared_draft)]
    print(json.dumps({"role":args.role,"checked_files":len(paths),"violations":failures,
        "shared_draft_only":args.allow_shared_draft,"remote_enforcement":"NOT_CONFIGURED"},indent=2))
    return 1 if failures else 0


if __name__ == "__main__": raise SystemExit(main())
