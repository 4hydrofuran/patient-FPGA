"""Serialize ONE hand-written ABI fixture. Not a general quantizer or B golden."""
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def fixture():
    return json.loads((ROOT / "contracts/examples/handcheck_v1.json").read_text(encoding="utf-8"))


def payloads(f=None):
    f = fixture() if f is None else f
    n_pad, k_pad, groups = f["Np"], f["Kp"], f["G"]
    w = bytearray(f["expected_lengths"]["w"])
    for n, k, q in f["wq"]:
        assert -7 <= q <= 7
        offset = (((n // 32 * groups + k // 128) * 128 + k % 128) * 16) + n % 32 // 2
        w[offset] |= (q & 15) << ((n % 32) * 4)
    assert [(i, b) for i, b in enumerate(w) if b] == [tuple(p) for p in f["expected_nonzero_w_bytes"]]
    sw = [1.0] * (n_pad * groups)
    for n, g, scale in f["sw"]:
        sw[(n // 32 * groups + g) * 32 + n % 32] = scale
    x = [0] * (f["T"] * k_pad)
    for t, k, q in f["xq"]:
        x[t * k_pad + k] = q
    expected_s = [0] * (f["T"] * n_pad * groups)
    for t, n, g, value in f["expected_s"]:
        expected_s[(t * n_pad + n) * groups + g] = value
    expected_y = [0.0] * (f["T"] * n_pad)
    for t, n, value in f["expected_y"]:
        expected_y[t * n_pad + n] = value
    return {"w.bin": bytes(w), "sw.bin": struct.pack(f"<{len(sw)}f", *sw),
            "x.bin": struct.pack(f"<{len(x)}b", *x), "sx.bin": struct.pack(f"<{f['T']}f", *f["sx"]),
            "expected_s.bin": struct.pack(f"<{len(expected_s)}i", *expected_s),
            "expected_y.bin": struct.pack(f"<{len(expected_y)}f", *expected_y)}


def write_fixture(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    for name, data in payloads().items():
        (directory / name).write_bytes(data)
