"""Run and persist A0 no-board checks with actual exit codes and hashes."""
import datetime as dt
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from check_contracts import ROOT, digest


def main():
    cxx="D:/AMDDesignTools/2026.1/tps/mingw/10.0.0/win64.o/nt/bin/g++.exe"
    cases=[
        ([sys.executable,"scripts/release/check_contracts.py"],0),
        ([sys.executable,"-m","unittest","discover","-s","bench/runtime/tests","-v"],0),
        ([sys.executable,"scripts/release/run_common_sample.py","--cxx",cxx],0),
        ([sys.executable,"scripts/release/check_contracts.py","--require-frozen"],1),
        ([sys.executable,"scripts/release/check_ownership.py","--role","A","--allow-shared-draft"],0)]
    records=[]
    for command,expected in cases:
        cp=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=120)
        records.append({"command":command,"exit_code":cp.returncode,"expected_exit_code":expected,
            "passed":cp.returncode==expected,"stdout":cp.stdout,"stderr":cp.stderr})
        print(f"{'PASS' if cp.returncode==expected else 'FAIL'} expected={expected} actual={cp.returncode}: {' '.join(command)}",flush=True)
    results=ROOT/"bench/runtime/results"
    results.mkdir(parents=True,exist_ok=True)
    report={"recorded_at":dt.datetime.now().astimezone().isoformat(),"verification_level":"PC_TEST",
        "status":"PASS" if all(r["passed"] for r in records) else "FAIL",
        "contract_sha256":digest(),"commands":records,"hardware":"NOT_TESTED",
        "note":"require-frozen expected failure proves the DRAFT gate; it is not a successful freeze or board run."}
    (results/"a0_checks.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8",newline="\n")
    # A deliverable integrity index; exclude itself to avoid recursive hashes.
    folders=["contracts","platform/audit","bench/runtime/results"]
    manifest={str(p.relative_to(ROOT)).replace("\\","/"):hashlib.sha256(p.read_bytes()).hexdigest()
        for folder in folders for p in sorted((ROOT/folder).rglob("*"))
        if p.is_file() and p.suffix in (".json",".yaml",".md",".hpp")}
    (ROOT/"platform/a0_evidence_sha256.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8",newline="\n")
    return 0 if report["status"]=="PASS" else 1


if __name__ == "__main__": raise SystemExit(main())
