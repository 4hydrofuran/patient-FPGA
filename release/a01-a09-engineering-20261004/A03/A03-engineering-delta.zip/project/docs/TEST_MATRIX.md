# Qwen3.5 分域测试矩阵

## A07最终无板验收（2026-10-04，当前）

| 域 | 结果 |
|---|---|
| PC规则/meta | 干净包970断言、66真实归档meta/396篡改/4build与相同ASan/UBSan PASS |
| PC完整C ABI控制 | 29场景554检查与相同ASan/UBSan PASS；醒目标记替身，仅故障/传输，不计算假核 |
| Csim/Cosim | 当前本地Csim61/2800022通过；同版既有65 native RTL PASS+1恢复、66回放复用，不新跑RTL或重复计独立例 |
| 综合/实现 | 实际2026.1 target hw链接成功，原约150MHz，WNS+0.809ns、WHS+0.010ns、未约束/布线错误0；CDC safely timed；93 DRC警告/18 advisory和2 methodology建议保留 |
| ARM64交叉构建 | 新生产XRT库/host6导出9依赖PASS并干净重建；旧完整模型136单元/10库证据hash复用 |
| 交付复现 | B原preflight实际ELF/hash PASS，干净源码构建/测试 PASS，最终1101文件hash PASS |
| BOARD/ARM执行/BO/恢复/功耗 | NOT_TESTED，实际内存预算与性能为null；A12未接入PL |

正式`release/a07_b04_v3`；完整命令/退出码、原失败、hash见`evidence/A07_closeout/20261004-v1/`。A07只通过无板阶段，不等于G1或B04联合签核。

## A06最终离线接收（2026-10-04，当前）

| 域 | 结果 |
|---|---|
| 当前源码A Csim | Linux Vitis2026.1/HLS6493734实际exit0，61例/2800022检查PASS；两shape T1..8、tail1..8及错误/手算/FP32顺序 |
| PC/向量/ABI | 沿用并核验原A04独立PC、382精确SHA、17参数/meta40及源/XO/内嵌XML，不重复计算 |
| Cosim | 必需两shape T1与T8同版原始native PASS；66输出独立回放。总65 native PASS+1历史失败后恢复，未新跑RTL |
| 综合 | 复用精确XO报告，HLS slack -0.40ns，不是实现收敛 |
| 实现/ARM执行/BOARD | NOT_TESTED；A07与B04完整验收不因本次核验升级 |

A06=e227 double离线核接收PASS，hash冻结；A07仅前置解除。原所有失败保留，报告`evidence/A06_acceptance/final-20261004-v1/REPORT.md`。

## A06 A接手补全（2026-10-03，当前）

| 域 | 实际结果与边界 |
|---|---|
| A序列化补丁 | 两个派生testbench只改JSON二进制输出及CRLF；原B源码/XO不改 |
| 干净PC接收 | full50 + 真实权重/合成激活4例PASS；382文件SHA全部精确匹配，原1923payload rehash通过 |
| 归档RTL | 原66笔再次回放PASS；不是新RTL仿真，65 native PASS + 1失败后postcheck恢复区别保留 |
| 工具单测 | Windows/Linux各3方法PASS，数值修改/二进制翻转/换行不符/多文件均被拒；归档11方法PASS |
| 新版A本地Csim | NOT_PASSED；Linux许可失配，Windows2026.1备选K26 part检查exit1；无数值结果 |
| 原A独立数值/同版B仿真/综合 | 沿用已核验61例/2800022、B full50及required真实shape Cosim、确切XO报告，不重跑优化 |
| 实现/ARM执行/BOARD | NOT_TESTED；不因修好工具改变板预算、功耗或硬件误差 |

完整矩阵、命令退出码及失败保留见`evidence/A06_acceptance/a-owned-closeout-v1/REPORT.json`。A06整体仍未通过，已无等待B的项目。

## A06补交（2026-10-03，最新）

| 域 | 结果 |
|---|---|
| 实物/接口 | 1925归档文件、实际double XO及内嵌XML、14来源收据hash核验 |
| 新版A PC | A04独立61案例/2800022检查PASS；FP32 max_abs=0 |
| 新版A Csim | 许可失配exit1，数值NOT_TESTED；旧版3Csim成功仍只属旧源 |
| B同版Csim | 50笔及两shape T1..8审计PASS |
| B原Cosim＋A回放 | 65笔native PASS＋1笔原FAIL/postcheck恢复；实际66输出A04独立回放PASS |
| 向量重建 | 340字节一致、42JSON仅CRLF/LF；严格B入口exit1保留 |
| A归档工具 | 新旧共11方法最终PASS，首次Windows路径原始名问题已修复 |
| 实现/新ARM执行/BOARD | NOT_TESTED；物理预算/硬件误差null |

未签A06整体PASS；细节及负例见`evidence/A06_acceptance/supplement-v1/REPORT.md`。下方“许可已解除”仅为此前实例与旧版本历史，不覆盖本次MAC变化。

## A09（2026-10-03）

PC：新源码构建、72矩阵/145文件复现、9wheel断网新环境PASS；最终75应用/语音/控制+5部署/计量方法及两组各6反例PASS。真实WAV MODEL；no_hardware原TEMPLATE保留，定向修复后MODEL。首次缺输入/包安全检查失败均保留。Csim/Cosim/综合/实现/BOARD本轮NOT_TESTED；A07交叉构建复用，生产C++hash未变。功率/声学/BO为null，A09整体PARTIAL。报告`eval/qwen35/a09/REPORT.md`。

## A07不依赖B实物的准备（2026-10-03，增量）

| 域 | 结果 | 边界 |
|---|---|---|
| PC生产共用host逻辑 | 969断言PASS；ASan/UBSan相同969再次PASS | 不调用XRT设备，无假核计算 |
| PC ZIP/XO收件工具 | 8 unittest方法PASS | 合成结构fixture不是B实物或RTL证据 |
| ARM64交叉构建 | S1/CPU库/XRT候选库/自测/llama库PASS，136编译单元A53配置 | 不执行目标二进制 |
| SDK/rootfs库一致性 | 10个实际运行库SHA相同，ELF依赖闭包可解析 | Common rootfs不是完整KV260可启动链 |
| 本轮Csim/Cosim/综合/实现/BOARD | NOT_TESTED | 前次旧核Csim恢复PASS保留，不能迁给新版本 |

证据`evidence/A07_independent/preboard-v1/`。候选XRT六函数只证明真实SDK编译/链接；实际BO/超时/资源隔离需到板验证。A06/A07整体仍未通过，CPU默认不变。

勘误/历史边界：下表A06首次Csim许可失败已由`license-rehost-v1/REPORT.json`中的三版共183例成功补测解除；原失败行保留为首次记录，不再视为当前许可阻断。

## A06 B计算核接收（当前，2026-10-03）

| 域 | 结果 | 证据 |
|---|---|---|
| PC静态 | 244下载文件Git对象/SHA256通过，公共数学/ABI原字节一致，11项A04/A05身份保持 | evidence/A06_acceptance/static-audit.json、A04_A05_input_identity.json |
| PC数值 | 三版各61例/2,800,022检查PASS；每版2,586,304 INT32部分和及所测FP32逐位一致 | local-tests-v1/*-pc.json |
| A本地Csim | BLOCKED_LICENSE_BEFORE_SIMULATION；三次exit1，不计数值执行 | local-tests-v1/*-csim.json |
| B原有Csim | 提供方日志50笔成功；实际kernel源一致，部分testbench/runner历史哈希未闭环 | static-audit.json |
| B原有Cosim | baseline日志34笔成功，A未完整重放（五组各缺27tv文件）；reuse/double未完成 | B batches manifests + A static-audit.json |
| 综合 | B日志2026.1/K26/6.667ns存在；XO未交、负HLS slack；A未综合 | B verification/*/synth.log |
| 实现/交叉构建/BOARD | NOT_TESTED，硬件数值误差/BO预算null | REPORT.json |

A06仍未接收，不用PC零差异填硬件误差0。以下A05的PC PASS保留。

## A05续作收口（当前，2026-10-02）

| 域/项目 | 结果 | 证据（eval/qwen35/a05/） |
|---|---|---|
| PC最终v8真实物理T1/2/4/8+尾块 | PASS，72投影/23全词表位置/48混合状态数组逐位一致 | state-v8/numerics.json |
| PC与旧canonical T1固定样例 | PASS，逐位一致；不是所有长上下文无差异的声明 | state-v8/canonical-history-comparison.json |
| PC状态/功能 | 17检查PASS：取消/reset/未播重算/病例/256与1024token | state-v8/checks.json |
| PC补充压力 | 74断言PASS：3种提示、257/1025token全词表与decode、物理T8计数 | extra-batch-v8/report.json |
| PC应用 | 80断言PASS；17MODEL/7策略TEMPLATE、0非预期回退 | app-dev-v8/S1-summary.json |
| PC断网合成语音 | 两条真ASR→S1→检查→TTS→播放API完成 | voice-s1-v8/summary.json |
| PC算子历史保护 | CPU库SHA不变，沿用103 ABI与48独立SIMD样例 | batch-fix-v1/REPORT.json |
| 量化质量 | 原H0/S0/S1差异非零；医学/最终集未验收 | quality-v1/quality.json |
| Csim/Cosim/综合/实现/ARM64/BOARD | NOT_TESTED，硬件误差/BO预算null | 未执行 |

本次A05电脑工程门禁通过。旧失败不删除、不改为PASS；实际argv/退出码在`platform/qwen35/a05/evidence/continue-*.json`。以下表为首次实施历史。

## A05（首次实施历史，2026-10-02）

| 域/项目 | 状态 | 原始证据 |
|---|---|---|
| PC CPU ABI | PASS，103检查 | a05/abi-v4/summary.json |
| PC SIMD真实输入 | PASS，48整数与FP32逐位 | evidence/simd-real-v2.json |
| PC 全图/外部块状态 | PASS，仅physical T1；24层、23logits位置、48状态数组 | a05/state-v2/numerics.json |
| PC 取消/R0/病例/长输入 | PASS，17项；256/1024 token | a05/state-v2/checks.json |
| PC 最终v3 | PASS，11真实检查 | a05/final-native-v1/summary.json |
| PC 开发集 | PASS，17MODEL/7策略TEMPLATE、0非预期回退 | a05/app-dev-v3/S1-summary.json |
| PC 断网合成语音 | PASS，2条真ASR/S1/检查/TTS/播放 | a05/voice-s1-v1/summary.json |
| PC 物理较大batch同等性 | **FAIL/未闭环**；不能用API分块冒认 | a05/state-v1/numerics.json、batch-precision-v1 |
| PC 量化质量 | MEASURED_NONZERO，非临床验收 | a05/quality-v1/quality.json |
| Csim/Cosim/综合/实现/ARM/BOARD | NOT_TESTED | 没有调用，数值null |

本阶段整体PARTIAL；下一步修复物理batch或取得明确T1范围验收。完整路径前缀为`eval/qwen35/`或`platform/qwen35/a05/`；实际argv/exit在a05/evidence和a05/commands.json。36旧规则方法+3新方法通过，失败/误拒/真实deadline均保留。以下为历史。

## A04（当前，2026-10-02）

| 域/内容 | 实际结果 |
|---|---|
| PC字节/数值/拒绝 | 210断言PASS；同套ASan/UBSan再运行210，非420独立用例；6加载器测试方法PASS |
| PC完整导出 | 原BF16→72矩阵两遍；manifest逐字节相同；独立C++ BF16 pack72/72逐字节PASS |
| PC真实投影 | F16/Q4输入各24，共48；0/3/4/23层gate/up/down，T8 prefill+T1 decode；整数/FP32同数学逐位一致 |
| PC量化诊断 | 原BF16 FP32复算对W4A8同输入的NRMSE范围H0 0.062727—0.171426、S0 0.062473—0.171145；不等于全图质量已通过 |
| PC计时/内存 | 单线程O3，逐投影一次计时；含激活量化、无完整权重重排；RSS见load-profile-v2，未建立统计性能门槛 |
| PC历史保护 | 开始292旧seal全匹配；旧运行库11项身份不变；只更新状态文件且保留before |
| Csim/Cosim/综合/实现/交叉构建/BOARD | 全部NOT_TESTED；CPU普通g++不是Csim，旧vector-add不借用 |
| S1完整图、S2误差/功耗、医学 | NOT_TESTED，S2误差null；未修改病例/音频/医学审核状态 |

证据`eval/qwen35/a04/REPORT.v2.json`、逐例原始目录和`platform/qwen35/a04/evidence/`。启动命令冲突exit1保留，修复显式脚本入口后exit0；所有负例预期exit2保留，不伪装成消失的失败。下方为旧阶段。

## A03收口（历史增量，2026-10-02）

| 域 | 当前结果与范围 |
|---|---|
| PC A03功能 | PASS基线：原62单测、32真协议、6拒绝、4轮隔离外网WAV及真人录音/确认/听辨；本轮只复核真实证据，不重复计为新运行 |
| PC本轮静态核验 | 49项通过（19证据+30 A04输入），包括72个tensor各自形状/偏移/hash；旧seal的文档和两项录音修复差异明确列出 |
| PC质量 | 12合成WAV CER9.09%是历史小样；第二轮真人ASR错误与端点失败不变，单例听清不等于统计质量通过 |
| PC A04 | 前置PASS_INPUTS_READY；导出/独立数值/新激活未开始、NOT_TESTED |
| Csim/Cosim/综合/实现/交叉构建/BOARD | NOT_TESTED，未借用旧vector-add或0.5B结果 |
| 声学/医学/功耗 | NOT_TESTED或REVIEW_PENDING；ready/播放提交不冒充声学首音节 |

证据：`eval/qwen35/a03/closeout-v1/`；新实际命令日志`platform/qwen35/a03/evidence/closeout-*.json`。后续A08需长测、设备故障/额度恢复验证；A13/A15做声学与正式质量。以下是此前时点历史。

## A03 2026-10-02 增量

PC软件测试：51单测（15新增+36旧A02）、32真实worker协议检查、6拒绝检查通过；4轮断外网合成音频闭环及真实播放接口中途取消通过。12条合成ASR CER9.09%，医学词错识保留；9次端点检查保留3个停顿截断，不作为质量PASS。首次ready、WAV ready和播放提交已测；实际声学起点、麦克风和人工可懂度NOT_TESTED。Csim/Cosim/综合/实现/交叉构建/BOARD全部NOT_TESTED。阶段整体PARTIAL，报告`eval/qwen35/a03/REPORT.json`，命令/退出码`platform/qwen35/a03/evidence/`。以下历史证据保留。

## 📊 A-DESIGN-1.0 当前增量结果

| 域 | 状态 | 范围/证据 |
|---|---|---|
| PC 原 A01 | PASS 保留 | `eval/qwen35/a01/A01_REPORT.json` |
| PC 新构建 | PASS | 原固定库、新独立 native-design-v1，A唯一队列 |
| PC 集成 | PASS | F16/Q4 两套 256/1024/2048、多轮、取消、reset、fresh-process |
| PC logits/剖面 | PASS | 两套 final/legacy/all；真实后端输出行数；逐节点诊断 |
| PC 单测 | PASS，保留首次失败 | 导入6项、原配置9项；初次UTF-8问题已修复 |
| Csim/Cosim/综合/实现/交叉构建 | NOT_TESTED | 本轮不改变新默认核未验证状态 |
| BOARD/正式质量/功耗 | NOT_TESTED | 无板、不伪造医学审核；PC小样不充当产品指标 |

原始命令/退出码：`platform/qwen35/design_import/evidence/`；完整 trace、allocator 日志、报告：`eval/qwen35/design_import/`。正常与节点插桩耗时分别记录，不直接比较为优化收益。以下为 A00 历史矩阵，不用其“模型未运行”覆盖当前 A01 证据。

_A · 2026-10-02 · A00，仅工程入口验收_

---

## 📊 本轮结果

| 域 | 状态 | 实际范围 |
|---|---|---|
| PC | PASS | 包31项哈希；661项历史文件不变；恢复666文件逐项校验 |
| PC | PASS | 配置9项测试，Windows和WSL各运行一次，不相加为18个独立用例 |
| PC | PASS | 原包12项静态测试在WSL重跑；C11/C++17头文件语法检查 |
| PC | EXPECTED_REJECTION | --require-installed退出2；没有加载器不能宣布运行就绪 |
| Csim | NOT_TESTED | 新Qwen3.5默认核未实现 |
| 综合 | NOT_TESTED | 不搬用vector-add结果 |
| Cosim | NOT_TESTED | 不搬用B2小样例 |
| 实现 | NOT_TESTED | 新W4A8未链接 |
| 交叉构建 | NOT_TESTED | 本轮只查SDK文件，不称ARM构建通过 |
| BOARD | NOT_TESTED | 无板、无设备调用 |
| 质量/时延/功耗 | NOT_TESTED | 新模型与语音未运行，数值null |

## 🔗 复现与日志

Windows使用现有 `platform/local/a1/venv/Scripts/python.exe`；日志均由现有 `platform/a1/record.py --log <新文件> -- <命令>` 独占保存，包含cwd、argv、UTC、退出码、stdout及stderr。

| 日志文件（platform/qwen35/a00/evidence/下） | 命令 | 退出码 |
|---|---|---:|
| legacy-contracts.json | python scripts/release/check_contracts.py | 0 |
| checkpoint.json | python scripts/release/qwen35_checkpoint.py | 0 |
| create-branch.json | git switch -c member-a/qwen35-a00-20261002 | 0 |
| package-audit.json | python platform/qwen35/a00/audit.py | 0 |
| config-tests.json | python -m unittest discover -s platform/qwen35/a00 -p test_config.py -v | 0 |
| config-check.json | python scripts/release/qwen35_config.py | 0 |
| runtime-negative.json | python scripts/release/qwen35_config.py --require-installed | 2（预期拒绝） |
| wsl-tests.json | wsl -d KV260-A-2204 -- bash /mnt/c/Patientqwen/platform/qwen35/a00/verify_pc.sh | 0 |

WSL脚本只调用Python、gcc/g++语法检查、文件存在检查、df和sha256sum；没有XRT或目标板调用。旧require-frozen失败、RTL失败、链接失败及重试日志原样保留，新计划不将其追认为PASS。
# A08 当前分域结果（2026-10-03）

PC：固定200轮工程闭环完成（133 MODEL/67 TEMPLATE），9个故障/策略符合预期，69历史/策略单测及6新增确认控件单测通过。额外424轮后按用户要求停止，最后1条中断不计通过，两小时NOT_COMPLETED_USER_STOPPED。独立no_hardware实际任务尚未执行；fpga_required真实CLI预期退出2。资源采样FileNotFoundError保留；新控件未接线。A08整体PARTIAL，不是质量/声学/医学/实板通过。Csim/Cosim/综合/实现/A08交叉构建/BOARD本增量均NOT_TESTED。详见`eval/qwen35/a08/REPORT.md`，不覆盖下面各阶段历史有效结果。
