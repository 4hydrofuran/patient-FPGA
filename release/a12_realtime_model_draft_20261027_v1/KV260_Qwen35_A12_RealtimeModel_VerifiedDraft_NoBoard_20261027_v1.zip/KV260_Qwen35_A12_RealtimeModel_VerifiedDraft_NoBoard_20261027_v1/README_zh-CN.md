# A12 实时模型未命中优化：无板总交付 v1

日期2026-10-27（北京时间）。先读SUMMARY_zh-CN.md，再按用途选packages内的子包。

- Deployment：当前推荐部署候选。解压后从realtime34-threads3-out32/START_HERE.md开始；continuous缓存未命中时每问真实目标模型验证，ordinary仍原串行R0/warm/hit窗口。
- EngineeringIncrement：本轮源码、测试、198组真实模型配对、浏览器逐题数据、交叉构建及原失败证据。用于已有Patientqwen工程接续，前一交付commit为d9ed467；在新复核目录展开，不是模型权重、工具链或系统备份。

完整回答真实浏览器25题：879.0→618.3ms中位，23/25低于1秒。部署副本另测622.8ms中位。以上答案缓存命中0、各25次实际模型调用，中性KV前缀仍复用；不是冷启动速度或实板速度。

每个草稿token和EOS均由目标贪心选择核验，失败全清状态并重放完整prompt；只从原checker已有表达选择完整输入。新连续32输出/22320保守预算，修复旧24在3个双事实组合缺EOS；不截断答案换速度。旧缓存来源保留，未命中MODEL与命中MODEL_CACHE分开。

包内MANIFEST.json及checksums/SUBPACKAGES.sha256提供摘要。Deployment先运行PC package检查，模型与匹配依赖仍需现有环境；BOARD尚未运行，另获实板授权后才按其START_HERE创建新Owner窗口。停止需等待原完成/恢复/独立释放，再从旧独立包开新窗口回退。
