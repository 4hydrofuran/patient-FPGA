# A12 实时模型草稿验证：独立UNBOUND候选

本包保留已核验答案缓存，并优化必须实时运行模型的未命中路径。continuous命中仍标MODEL_CACHE；未命中由真实目标模型验证本次事实草稿的每个token与EOS，来源MODEL。草稿未通过则全清recurrent/conv/KV、恢复中性前缀并重放原prompt，正常实时生成。不是未核验文本回显。

连续窗口输出上限32（旧24在3个双事实组合缺EOS），1024上下文、physical_ubatch=8、34-token中性前缀不变。每问保守预留22320次运行，显式覆盖验证和完整重放；实际用量另记。ordinary仍是24上限的原串行R0/warm/hit窗口。模型/量化/HLS/公共ABI不变；native二进制是本次新派生版本。

从本目录离线检查（不接触设备）：

```sh
python3 continuous/fast_response_verify.py --domain PC --bundle . --suite package
```

现有开发机环境的纯实时PC服务（完全不加载答案缓存）：

```sh
python3 continuous/answer_cache_serve_pc.py --mode realtime --output /tmp/a12-realtime-new-pc-001 --port 8768
```

PC工具使用PC_DEPENDENCIES.json和PC_PREFIX_CONFIG.json中的现有开发机模型/二进制/依赖；ARM部署二进制在各bundle/bin内。新的PC进程用独立输出目录，结束时在该输出目录创建stop-request.json并等待RESULT.json的正常关闭回执。

BOARD尚未测试。只有另获实板授权、具备原irq2/登录/空闲条件后，才从新目录/新Owner窗口执行：

```sh
sudo python3 continuous/fast_response_verify.py --domain BOARD --bundle . --suite web --execute-board --window-id a12-realtime-draft-new-001
```

停止整个BOARD服务（结束问诊仅冻结评分）：

```sh
sudo touch continuous/stop-request.json
```

等待在途完成与原Owner恢复/独立释放回执，再从旧a12_verified_answer_cache_20261027或a12_fast_response_20261027_v2独立目录开新窗口回退。不要复用已消费窗口。此包无模型权重、工具链、系统镜像或可重放计算授权。

PC完整回答的实测前后对照、198组合、错误草稿重放、资源和失败记录见本轮REPORT；PC速度不替代实板时延/功耗/CMA/计数与恢复/释放。

本候选线程数：3。未命中输入表达策略：allowed-compact-01（仅从原checker允许表达中选择较短的完整表达）。
旧缓存目录的生成策略仍为facts-only-02-verified-answers-v1，来源/模型/病例/事实身份逐次复核；目录不被标为新输入策略生成。新策略只在未命中后构造实时模型输入，可能改变措辞，原必需事实及原checker不变。
