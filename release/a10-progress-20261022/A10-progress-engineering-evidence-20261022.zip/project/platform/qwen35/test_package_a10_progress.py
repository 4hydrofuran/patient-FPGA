import json
from pathlib import Path
import unittest
import package_a10_progress as m


class PackageTests(unittest.TestCase):
    def test_git_unicode_paths(self):
        name='release/a10-progress-20261022/交付.md'
        self.assertEqual(m.changed_paths(name.encode()+b'\0'),[name])

    def test_structured_redaction_preserves_status(self):
        b=b'{"token":"temporary-value","status":"FAIL","exit_code":1}'
        out=json.loads(m.public_bytes(Path('x.json'),b))
        self.assertEqual(out['token'],'[REDACTED_FOR_PUBLICATION]')
        self.assertEqual(out['exit_code'],1)
        self.assertEqual(out['status'],'FAIL')

    def test_embedded_log_redaction(self):
        b=json.dumps({'raw':'{"lease_token": "temporary-value", "event": "FAIL"}'}).encode()
        self.assertNotIn(b'temporary-value',m.public_bytes(Path('x.json'),b))

    def test_source_unchanged(self):
        b=b'token = "unit-test-fixture"\n'
        self.assertEqual(m.public_bytes(Path('source.py'),b),b)

    def test_private_material_blocked(self):
        with self.assertRaises(ValueError):
            m.scan('fixture',('-----BEGIN '+'PRIVATE KEY-----').encode())
        for name in ['image.wic','disk.vhdx','Xilinx.lic','id.key','binary.ko']:
            self.assertIsNotNone(m.exclusion(Path(name)))

    def test_jsonl_status_preserved(self):
        b=b'{"event":"FAILED","password":"private-value"}\n'
        out=json.loads(m.public_bytes(Path('log.jsonl'),b))
        self.assertEqual(out['event'],'FAILED')
        self.assertNotIn('private-value',str(out))


if __name__=='__main__':
    unittest.main()
