"""Explicit A10 progress publication; isolated Git index, no board access."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'release/a10-progress-20261022'
EV = ROOT / 'evidence/A10_publication/20261022-v1'
BASE = '9276b4a33084325ec2a72c12f99a6fbb91bbfe1c'
BRANCH = 'a/a10-progress-20261022'
REMOTE = 'https://github.com/4hydrofuran/patient-FPGA.git'
TEXT = {'.py','.ps1','.sh','.c','.cpp','.h','.hpp','.inc','.its','.sources',
        '.json','.jsonl','.md','.txt','.csv','.yaml','.yml','.lock','.patch',
        '.cfg','.tcl','.cmake','.dts','.dtsi','.stdout','.stderr','.rst'}
SPECIAL = {'Makefile','CMakeLists.txt','LICENSE','NOTICE','contracts.lock'}
SCOPES = ['platform/qwen35/a10','evidence/board_platform','contracts/qwen35',
          'docs/PROJECT_STATUS.json','docs/A10_ACCEPTANCE_SAFE_20261019.md',
          'docs/A10_REMAINING_MINIMUM_20261021.md','docs/DESIGN_GAP.md',
          'docs/DECISIONS.md','docs/TEST_MATRIX.md','docs/AI_ASSISTANCE.md',
          'docs/status/A.md','AGENTS.md','platform/toolchain.lock.json',
          'platform/qwen35/package_a10_progress.py',
          'platform/qwen35/test_package_a10_progress.py']
PRIVATE = [re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
           re.compile(rb'gh[pousr]_[A-Za-z0-9]{30,}'),
           re.compile(rb'github_pat_[A-Za-z0-9_]{50,}'),
           re.compile(rb'AKIA[A-Z0-9]{16}'),
           re.compile(rb'(?i)(?:sshpass\s+-p\s+|https?://[^\s/:]+:[^\s/@]+@)')]
SENSITIVE = {'password','passwd','secret','token','access_token','refresh_token',
             'authorization','private_key','credential','lease_token'}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def changed_paths(raw):
    # Git quotes non-ASCII names in newline mode; -z preserves actual paths.
    return [n.decode('utf-8') for n in raw.split(b'\0') if n]


def git(*args, env=None, data=None):
    p = subprocess.run(['git', *args], cwd=ROOT, env=env, input=data, capture_output=True)
    if p.returncode:
        raise RuntimeError('git failed: ' + p.stderr.decode(errors='replace'))
    return p.stdout


def save(path, obj):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def exclusion(p):
    if p.is_symlink() or any(x in p.parts for x in ('__pycache__','.git','.venv','venv')):
        return 'link_or_cache'
    if p.name == 'board_ssh_known_hosts':
        return 'operator_host_trust_reestablish_locally'
    if p.suffix.lower() not in TEXT and p.name not in SPECIAL:
        return 'binary_or_not_selected_source_text'
    if p.stat().st_size > 16 * 1024**2:
        return 'large_artifact_local_only'
    return None


def redact_text(text):
    # Handles literal JSON and JSON embedded in a raw console string.
    return re.sub(r'(?i)(["\'](?:password|passwd|secret|token|access_token|refresh_token|lease_token)["\']\s*:\s*["\'])([^"\'\r\n]+)(["\'])',
                  lambda m: m[1] + '[REDACTED_FOR_PUBLICATION]' + m[3], text)


def redact_value(v):
    if isinstance(v, dict):
        return {k: ('[REDACTED_FOR_PUBLICATION]' if k.lower() in SENSITIVE and x not in (None, False, '')
                    else redact_value(x)) for k, x in v.items()}
    if isinstance(v, list):
        return [redact_value(x) for x in v]
    return redact_text(v) if isinstance(v, str) else v


def public_bytes(p, raw):
    text = raw.decode('utf-8-sig')
    # Source remains byte-exact: scan it, never silently rewrite executable code.
    if p.suffix == '.json':
        before = json.loads(text)
        after = redact_value(before)
        if before != after:
            return (json.dumps(after, ensure_ascii=False, indent=2)+'\n').encode()
    elif p.suffix == '.jsonl':
        rows = [json.loads(s) for s in text.splitlines() if s.strip()]
        after = [redact_value(r) for r in rows]
        if rows != after:
            return ('\n'.join(json.dumps(r, ensure_ascii=False) for r in after)+'\n').encode()
    elif p.suffix in {'.stdout','.stderr','.txt','.md'}:
        changed = redact_text(text)
        if changed != text:
            return changed.encode()
    return raw


def scan(name, data):
    if any(p.search(data) for p in PRIVATE):
        raise ValueError('Potential secret; publication stopped (content not printed): ' + name)


def prepare():
    if git('remote','get-url','origin').decode().strip() != REMOTE:
        raise ValueError('Unexpected repository')
    sources = {}
    scopes = [ROOT / s for s in SCOPES]
    scopes += sorted((ROOT/'platform/build').glob('a10-*'))
    # Small shared source helpers, not unrelated installer/history evidence.
    scopes += [p for p in (ROOT/'platform/a1').rglob('*')
               if p.is_file() and 'evidence' not in p.parts]
    for scope in scopes:
        if not scope.exists():
            raise FileNotFoundError(scope)
        for p in ([scope] if scope.is_file() else sorted(scope.rglob('*'))):
            if p.is_file():
                sources[p.relative_to(ROOT).as_posix()] = p
    data, entries, excluded = {}, {}, []
    for name, p in sorted(sources.items()):
        why = exclusion(p)
        if why:
            excluded.append(dict(path=name, reason=why)); continue
        raw = p.read_bytes()
        try:
            public = public_bytes(p, raw)
        except UnicodeDecodeError:
            excluded.append(dict(path=name, reason='non_utf8_not_public_text')); continue
        scan(name, public)
        data[name] = public
        entries[name] = dict(bytes=len(public), sha256=sha(public), source_sha256=sha(raw),
                             redacted=public != raw)
    status = json.loads(data['docs/PROJECT_STATUS.json'])
    if status['a10_newboard_20261018']['irq2_authorized_boot_preflight_20261021']['reboot_commands_sent'] != 0:
        raise ValueError('Board state changed; update handoff before packaging')
    readme = (ROOT/'docs/A10_PROGRESS_HANDOFF_20261022.md').read_bytes()
    scan('handoff', readme)
    manifest = dict(status='A10_PROGRESS_NOT_ACCEPTED', client_date='2026-10-22',
                    files=entries, source_head=git('rev-parse','HEAD').decode().strip(),
                    A10='NOT_PASSED', board_access_this_publication=False,
                    exclusions='EXCLUDED.json', source_files_unchanged=True)
    OUT.mkdir(parents=True, exist_ok=False)
    EV.mkdir(parents=True, exist_ok=True)
    save(OUT/'MANIFEST.json', manifest)
    save(OUT/'EXCLUDED.json', dict(files=excluded, excluded_entire_scopes=[
        'platform/local (backups, dependencies, candidate FIT/module archives)',
        'WSL system disks, SD/QSPI images, credentials, licenses, model/voice weights',
        'screenshots and raw binary UART captures; text/JSON counterparts retained'],
        limitation='Source/evidence handoff, not a standalone boot/deployment image'))
    (OUT/'交付.md').write_bytes(readme)
    archive = OUT/'A10-progress-engineering-evidence-20261022.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, b in data.items():
            z.writestr('project/'+name, b)
        for name in ('MANIFEST.json','EXCLUDED.json','交付.md'):
            z.write(OUT/name, name)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or len(z.namelist()) != len(entries)+3:
            raise ValueError('ZIP integrity/count')
        for name, entry in entries.items():
            b=z.read('project/'+name)
            if sha(b) != entry['sha256']:
                raise ValueError('ZIP readback mismatch')
            scan(name,b)
    result = dict(status='PASS_PACKAGE_READBACK_AND_PATTERN_SCAN', archive=archive.name,
                  bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()),
                  included_files=len(entries), excluded_files=len(excluded),
                  redacted_files=sum(e['redacted'] for e in entries.values()),
                  A10='NOT_PASSED', board_access=False,
                  secret_scan_scope='Explicit scope/extension allowlist, structured-field redaction and high-confidence secret patterns; not a guarantee against all possible secrets')
    save(OUT/'PACKAGE_CHECK.json',result)
    print(json.dumps(result))


def publish():
    if git('remote','get-url','origin').decode().strip() != REMOTE:
        raise ValueError('Unexpected remote')
    if git('ls-remote','--heads','origin','refs/heads/'+BRANCH).strip():
        raise ValueError('Ref already exists; no overwrite')
    check=json.loads((OUT/'PACKAGE_CHECK.json').read_text())
    if sha((OUT/check['archive']).read_bytes()) != check['sha256']:
        raise ValueError('Archive changed')
    head=git('rev-parse','HEAD'); index=git('diff','--cached','--raw')
    paths=sorted(p for p in OUT.iterdir() if p.is_file())
    names=[p.relative_to(ROOT).as_posix() for p in paths]
    oids=git('hash-object','-w','--no-filters','--stdin-paths',data=('\n'.join(names)+'\n').encode()).decode().splitlines()
    with tempfile.TemporaryDirectory(prefix='a10-publication-index-') as temp:
        env=dict(os.environ,GIT_INDEX_FILE=str(Path(temp)/'index'))
        git('read-tree',BASE,env=env)
        git('update-index','-z','--index-info',env=env,
            data=b''.join(f'100644 {oid}\t{name}'.encode()+b'\0' for oid,name in zip(oids,names)))
        tree=git('write-tree',env=env).decode().strip()
        commit=git('-c','user.name=Member A (Codex)','-c','user.email=codex@localhost',
                   'commit-tree',tree,'-p',BASE,'-m','A10: package completed engineering and evidence; document remaining board acceptance',env=env).decode().strip()
    for p,n in zip(paths,names):
        if sha(git('show',commit+':'+n)) != sha(p.read_bytes()):
            raise ValueError('Commit blob mismatch')
    changed=changed_paths(git('diff-tree','--no-commit-id','--name-only','-z','-r',commit))
    if any(not n.startswith('release/a10-progress-20261022/') for n in changed):
        raise ValueError('Out-of-scope commit')
    git('update-ref','refs/heads/'+BRANCH,commit,'0'*40)
    save(EV/'commit.json',dict(commit=commit,branch=BRANCH,files=names,base=BASE))
    git('push','origin','refs/heads/'+BRANCH+':refs/heads/'+BRANCH)
    remote=git('ls-remote','--heads','origin','refs/heads/'+BRANCH).decode().split()[0]
    if remote != commit or git('rev-parse','HEAD') != head or git('diff','--cached','--raw') != index:
        raise ValueError('Remote or working-index verification failed')
    result=dict(status='PUSHED_REMOTE_SHA_VERIFIED',commit=commit,branch=BRANCH,
                archive_sha256=check['sha256'],working_HEAD_and_index_unchanged=True,
                no_force_push=True,A10='NOT_PASSED')
    save(EV/'publish.json',result)
    print(json.dumps(result))


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['prepare','publish'])
    args=p.parse_args()
    (prepare if args.mode=='prepare' else publish)()
