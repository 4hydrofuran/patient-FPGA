$ErrorActionPreference='Stop'
$scriptPath=Join-Path $PSScriptRoot 'collect_readonly_uart.ps1'
$parseErrors=$null
$tokens=$null
[void][System.Management.Automation.Language.Parser]::ParseFile($scriptPath,[ref]$tokens,[ref]$parseErrors)
if ($parseErrors.Count) { throw 'Parser errors' }
$checked=0
foreach ($phase in @('initial','sensors_dt','package_metadata','binding','dt_snapshot','driver_preflight')) {
    $plan = & $scriptPath -ValidateOnly -Phase $phase -OutputPath ([IO.Path]::Combine([IO.Path]::GetTempPath(),[Guid]::NewGuid().ToString()+'.json')) | ConvertFrom-Json
    if ($plan.board_contact -ne $false) { throw 'Dry run attempted board contact' }
    foreach ($job in $plan.jobs) {
        if ($phase -eq 'driver_preflight' -and $job.name -eq 'sudo_noninteractive_probe' -and $job.command -eq 'sudo -n true') { $checked++; continue }
        $commandToCheck = $job.command -replace 'command -v insmod; command -v rmmod;', ''
        if ($commandToCheck -match '\b(sudo|modprobe|insmod|rmmod|reboot|shutdown|reset|dd|mkfs|mount|make|apt-get|tee)\b|\bapt\s+(install|update)|(?<![<])>(?![>])') { throw "Mutation found in $($job.name)" }
        $checked++
    }
}
if ($checked -ne 17) { throw "Unexpected command group count: $checked" }
$text=Get-Content -LiteralPath $scriptPath -Raw
if ($text -notmatch 'finally' -or $text -notmatch '\$serial.Close\(\)' -or $text -notmatch '\$serial.DtrEnable = \$false') { throw 'Serial cleanup/control guard missing' }
$pattern='(?:thermal_zone\d+/temp|hwmon\d+/temp\d+_input):\s*(\d+)'
foreach ($sensor in @('thermal_zone0/temp: 60000','hwmon0/temp1_input: 60000')) {
    $m=[regex]::Match($sensor,$pattern)
    if (-not $m.Success -or [int]$m.Groups[1].Value -lt 60000) { throw 'Temperature stop pattern failed' }
}
[ordered]@{status='PASS_PC_PLAN_CHECK_NOT_BOARD';command_groups=$checked;syntax='PASS';dry_run_phases=6;temperature_patterns=2;board_contact=$false} | ConvertTo-Json
