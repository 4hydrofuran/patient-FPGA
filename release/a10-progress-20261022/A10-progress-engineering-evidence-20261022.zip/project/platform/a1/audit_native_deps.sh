#!/usr/bin/env bash
# Read-only image access; rpm may write locks ONLY in this new scratch directory.
set -e
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
source /home/member-a/kv260-sdk-2026.1-common/environment-setup-cortexa72-cortexa53-amd-linux
set -u
out="${1:?new scratch output directory required}"
case "$out" in
  /home/member-a/kv260-build/native-db-*) ;;
  *) printf '%s\n' 'Use a new native-db-* directory under /home/member-a/kv260-build' >&2; exit 2 ;;
esac
[[ "$out" != *'..'* && "$out" != *' '* ]]
mkdir -- "$out"
mkdir -- "$out/rpmdb"
debugfs -R "dump /var/lib/rpm/rpmdb.sqlite $out/rpmdb/rpmdb.sqlite" /home/member-a/kv260-build/common-audit-20260927/rootfs.ext4
test -s "$out/rpmdb/rpmdb.sqlite"
sha256sum "$out/rpmdb/rpmdb.sqlite"
rpm --dbpath "$out/rpmdb" -q gcc libstdc++6 libc6 rpm
# No --ignorearch/--nodeps/--force. This is a TEST, never a package installation.
# The scratch root has a database only, so success would still not prove file
# conflicts, disk space or native execution on a real root filesystem.
rpm --root "$out" --dbpath /rpmdb --test --noscripts --notriggers -i platform/local/native-build-rpms-20260928/*.rpm
