"""A-smoke hardware file generation ONLY; never packages, deploys, or passes G1.

See A-0003. Existing link_hw.validated full matched-bundle gate is unchanged.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import re
import shutil

from file_hash import sha256_file
from inspect_vadd_xo import inspect
from record import run

ROOT = Path(__file__).resolve().parents[2]


def validate_inputs(bundle):
    if bundle.get("scope") != "A_VADD_OFFLINE_HARDWARE_LINK":
        raise ValueError("A-vadd offline scope required")
    if bundle.get("deployment_authorized") is not False:
        raise ValueError("offline input cannot authorize deployment")
    if (bundle.get("platform"), bundle.get("tools"), bundle.get("part")) != (
            "kv260_base", "2026.1", "xck26-sfvc784-2LV-c"):
        raise ValueError("wrong hardware/tool family")
    for key in ("linux_safe_budget_bytes", "pl_safe_budget_bytes"):
        if key not in bundle or bundle[key] is not None:
            raise ValueError("offline link cannot set board memory budgets")
    for key in ("xpfm", "xsa", "xo", "config"):
        item = bundle.get(key, {})
        path = Path(item.get("path", ""))
        if not path.is_file() or sha256_file(path) != item.get("sha256"):
            raise ValueError("input hash/path mismatch: " + key)
    # The platform file uses the XSA at this path; do not validate an unrelated XSA.
    if Path(bundle["xsa"]["path"]).resolve() != (
            Path(bundle["xpfm"]["path"]).resolve().parent / "hw/hw.xsa"):
        raise ValueError("XSA is not the pinned installed platform XSA")
    return bundle


def new_manifest(inputs, output, digest=None):
    return {
        "status": "OFFLINE_BUILD_ONLY_NOT_DEPLOYABLE",
        "deployment_authorized": False, "g1": "NOT_PASSED",
        "hardware_execution": "NOT_TESTED",
        "platform": "kv260_base", "tools": "2026.1",
        "inputs": inputs, "xclbin": str(output), "xclbin_sha256": digest,
        "memory_source_discrepancies_resolved": False,
        "linux_safe_budget_bytes": None, "pl_safe_budget_bytes": None,
        "review": "docs/adr/A-0003-offline-hardware-link.md",
    }


def write_new(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def link_command(inputs, output):
    return ["v++", "--link", "--target", "hw", "--save-temps",
            "--platform", inputs["xpfm"]["path"],
            "--config", inputs["config"]["path"],
            "--vivado.synth.jobs", "2", "--vivado.impl.jobs", "2",
            "--output", str(output), inputs["xo"]["path"]]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--inputs", type=Path, default=ROOT / "platform/a1/offline_link_inputs.json")
    ap.add_argument("--label", required=True)
    ap.add_argument("--work-root", type=Path, default=Path("/home/member-a/kv260-build"))
    a = ap.parse_args()
    if platform.system() != "Linux" or os.environ.get("XCL_EMULATION_MODE") is not None:
        raise ValueError("Linux non-emulation build environment required")
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}", a.label):
        raise ValueError("unsafe label")
    b = validate_inputs(json.loads(a.inputs.read_text()))
    intake = inspect(b["xo"]["path"])
    workroot = a.work_root.resolve(strict=True)
    if shutil.disk_usage(workroot).free < 30 * 1024**3:
        raise ValueError("need at least 30GiB build storage reserve")
    work = workroot / ("offline-link-" + a.label)
    work.mkdir(exist_ok=False)
    evidence = ROOT / "platform/a1/evidence" / ("offline-link-" + a.label)
    evidence.mkdir(exist_ok=False)
    output = work / "vadd.xclbin"
    write_new(evidence / "inputs.json", b)
    write_new(evidence / "xo-intake.json", intake)
    write_new(work / "NOT_DEPLOYABLE.json", new_manifest(b, output))
    for command, logfile in [(["v++", "--version"], "version.json"),
                             (["platforminfo", "--platform", b["xpfm"]["path"]], "platforminfo.json")]:
        rc = run(command, evidence / logfile, cwd=work)
        if rc:
            return rc
    version = json.loads((evidence / "version.json").read_text())
    info = json.loads((evidence / "platforminfo.json").read_text())
    if "2026.1" not in version["stdout"] or "6511674" not in version["stdout"]:
        raise ValueError("unexpected actual tool version/build")
    if b["part"] not in info["stdout"] or "kv260_base" not in info["stdout"]:
        raise ValueError("unexpected actual platform identity")
    rc = run(link_command(b, output), evidence / "link.json", cwd=work)
    if rc:
        return rc
    if not output.is_file() or output.stat().st_size == 0:
        raise ValueError("link returned zero but no xclbin")
    write_new(evidence / "artifact.json", new_manifest(b, output, sha256_file(output)))
    return run(["xclbinutil", "--input", str(output), "--info"], evidence / "xclbin-info.json", cwd=work)


if __name__ == "__main__":
    raise SystemExit(main())
