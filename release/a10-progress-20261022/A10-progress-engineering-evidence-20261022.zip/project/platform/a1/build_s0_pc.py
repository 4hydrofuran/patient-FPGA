"""Windows PC compile-only/development checks; never classified as board S0."""
import json
import os
from pathlib import Path
from record import run
ROOT=Path(__file__).resolve().parents[2]
pins=json.loads((ROOT/"platform/a1/pins.json").read_text())
base=Path("D:/AMDDesignTools/2026.1")
cc=base/"tps/mingw/10.0.0/win64.o/nt/bin"
env=os.environ.copy()
env["GIT_CEILING_DIRECTORIES"]=str(ROOT/"platform/local/a1")
env["PATH"]=str(cc)+os.pathsep+str(cc.parent/"libexec/gcc/x86_64-w64-mingw32/9.5.0")+os.pathsep+env["PATH"]
cmake=str(base/"tps/win64/cmake-4.0.1/bin/cmake.exe")
build=ROOT/"bench/runtime/build/a1-s0-pc"
args=[cmake,"-S",str(ROOT/"bench/runtime/s0"),"-B",str(build),"-G","Ninja",
      "-DCMAKE_MAKE_PROGRAM="+str(cc/"ninja.exe"),"-DCMAKE_C_COMPILER="+str(cc/"gcc.exe"),
      "-DCMAKE_CXX_COMPILER="+str(cc/"g++.exe"),"-DCMAKE_BUILD_TYPE=Release",
      "-DLLAMA_BUILD_COMMIT="+pins['llama_cpp']['commit'],"-DLLAMA_BUILD_NUMBER=6000",
      "-DLLAMA_SOURCE="+str(ROOT/"platform/local/a1"/('llama.cpp-'+pins['llama_cpp']['commit'])),
      "-DGGML_NATIVE=OFF","-DGGML_OPENMP=ON","-DGGML_AVX2=ON","-DGGML_FMA=ON","-DGGML_F16C=ON"]
code=run(args,ROOT/"platform/a1/evidence/s0_pc_configure.json",env=env)
if code==0:code=run([cmake,"--build",str(build),"--target","a1-s0","-j","8"],ROOT/"platform/a1/evidence/s0_pc_build.json",env=env)
raise SystemExit(code)
