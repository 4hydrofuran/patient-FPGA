"""Decode a local WIC into new regular files; never mount or open block devices.

Output is private build storage, not a rootfs approved for deployment. No image
program is executed. sfdisk only reads the partition table using --json.
"""
import argparse
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import stat
import subprocess

CHUNK = 4 * 1024 * 1024


def sparse_copy(src, dst, limit):
    digest = hashlib.sha256()
    total = 0
    while total < limit:
        chunk = src.read(min(CHUNK, limit-total))
        if not chunk:
            break
        digest.update(chunk)
        if chunk.count(0) == len(chunk):
            dst.seek(len(chunk), 1)
        else:
            dst.write(chunk)
        total += len(chunk)
    dst.truncate(total)
    return total, digest.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--image', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--max-bytes', type=int, default=32 * 1024**3)
    a = ap.parse_args()
    if not stat.S_ISREG(a.image.stat().st_mode):
        raise ValueError('input must be a regular downloaded file, never a device')
    if a.max_bytes <= 0:
        raise ValueError('positive limit required')
    a.out.mkdir(parents=True, exist_ok=False)
    if shutil.disk_usage(a.out).free < 2*a.max_bytes:
        raise ValueError('insufficient conservative free-space reserve')
    raw = a.out / 'image.wic'
    compressed_hash = hashlib.sha256()
    with a.image.open('rb') as f:
        for block in iter(lambda: f.read(CHUNK), b''):
            compressed_hash.update(block)
    with lzma.open(a.image, 'rb') as src, raw.open('xb') as dst:
        size, digest = sparse_copy(src, dst, a.max_bytes)
        if src.read(1):
            raise ValueError('image exceeds configured bound; incomplete output retained')
    command = ['sfdisk', '--json', str(raw)]
    result = subprocess.run(command, capture_output=True, text=True)
    (a.out/'sfdisk.json').write_text(json.dumps({'argv': command, 'exit_code': result.returncode,
        'stdout': result.stdout, 'stderr': result.stderr}, indent=2)+'\n')
    result.check_returncode()
    table = json.loads(result.stdout)['partitiontable']
    sector = table.get('sectorsize', 512)
    manifest = {'level': 'OFFLINE_IMAGE_CONTENTS_ONLY', 'g1': 'NOT_PASSED',
                'compressed_sha256': compressed_hash.hexdigest(), 'image_sha256': digest,
                'image_bytes': size, 'partition_table': table, 'partitions': []}
    previous_end = 0
    for i, part in enumerate(table['partitions'], 1):
        start, length = part['start']*sector, part['size']*sector
        if start < previous_end or length <= 0 or start+length > size:
            raise ValueError('overlapping/out-of-bounds partition')
        previous_end = start+length
        target = a.out / f'partition-{i}.img'
        with raw.open('rb') as src, target.open('xb') as dst:
            src.seek(start)
            copied, part_hash = sparse_copy(src, dst, length)
        if copied != length:
            raise ValueError('short partition')
        with target.open('rb') as f:
            f.seek(1080)
            ext = f.read(2) == b'\x53\xef'
        manifest['partitions'].append({'index': i, 'file': str(target), 'bytes': length,
                                       'sha256': part_hash, 'ext_magic': ext})
    with (a.out/'manifest.json').open('x') as f:
        json.dump(manifest, f, indent=2)
        f.write('\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
