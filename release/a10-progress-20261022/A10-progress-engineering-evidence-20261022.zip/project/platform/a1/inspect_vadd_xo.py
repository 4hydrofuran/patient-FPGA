"""Static intake for A's smoke XO, NOT acceptance of B's kernel or board G1."""
import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile


def inspect(path):
    path = Path(path)
    with zipfile.ZipFile(path) as archive:
        # Vivado also embeds an identical private .kernelxml copy deep in ip_repo.
        # The public XO descriptor is at the archive root or one directory deep.
        descriptors = [n for n in archive.namelist() if n.endswith('/kernel.xml') or n == 'kernel.xml']
        names = [n for n in descriptors if len(n.split('/')) <= 2]
        if len(names) != 1:
            raise ValueError('expected exactly one kernel.xml')
        info = archive.getinfo(names[0])
        if info.file_size > 1024 * 1024:
            raise ValueError('unexpectedly large kernel.xml')
        raw = archive.read(info)
        for name in descriptors:
            nested = archive.getinfo(name)
            if nested.file_size > 1024 * 1024 or archive.read(nested) != raw:
                raise ValueError('conflicting embedded kernel.xml')
    if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw:
        raise ValueError('XML entities forbidden')
    root = ET.fromstring(raw)
    kernels = root.findall('kernel')
    if len(kernels) != 1 or kernels[0].get('name') != 'krnl_vadd':
        raise ValueError('not the A smoke kernel')
    kernel = kernels[0]
    if kernel.get('hwControlProtocol') != 'ap_ctrl_chain':
        raise ValueError('unexpected control protocol')
    args = [a.attrib for a in kernel.findall('args/arg')]
    expected = [('a', 1, 'M_AXI_GMEM0', 8, 0x10),
                ('b', 1, 'M_AXI_GMEM1', 8, 0x1c),
                ('c', 1, 'M_AXI_GMEM0', 8, 0x28),
                ('n', 0, 'S_AXI_CONTROL', 4, 0x34)]
    if len(args) != len(expected):
        raise ValueError('wrong argument count')
    for i, (arg, (name, qualifier, port, size, offset)) in enumerate(zip(args, expected)):
        if (int(arg['id'], 0), arg['name'], int(arg['addressQualifier'], 0),
            arg['port'], int(arg['size'], 0), int(arg['hostSize'], 0),
            int(arg['offset'], 0)) != (i, name, qualifier, port, size, size, offset):
            raise ValueError('argument ABI mismatch: ' + name)
    ports = [p.attrib for p in kernel.findall('ports/port')]
    by_name = {p['name']: p for p in ports}
    for name, mode in [('M_AXI_GMEM0', 'master'), ('M_AXI_GMEM1', 'master'), ('S_AXI_CONTROL', 'slave')]:
        if name not in by_name or by_name[name]['mode'] != mode or int(by_name[name]['dataWidth']) != 32:
            raise ValueError('port mismatch: ' + name)
    return {'level': 'XO_STATIC_ONLY', 'status': 'PASS', 'path': str(path.resolve()),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'kernel_xml_sha256': hashlib.sha256(raw).hexdigest(),
            'kernel': kernel.attrib, 'args': args, 'ports': ports,
            'note': 'n is limited by host to 1..4096; generated unsigned-int metadata has the same 32-bit encoding in that range.',
            'hardware_execution': 'NOT_TESTED', 'g1': 'NOT_PASSED'}


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--xo', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    result = inspect(a.xo)
    with Path(a.out).open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
        f.write('\n')
    print(json.dumps(result, indent=2))
