import os
from pathlib import Path
from record import run
ROOT=Path(__file__).resolve().parents[2]
cc=Path("D:/AMDDesignTools/2026.1/tps/mingw/10.0.0/win64.o/nt/bin")
env=os.environ.copy();env["PATH"]=str(cc)+os.pathsep+env["PATH"]
build=ROOT/"platform/build/a1-pc";build.mkdir(parents=True,exist_ok=True)
code=run([str(cc/"g++.exe"),"-std=c++17","-O2","-Wno-unknown-pragmas",
          "platform/a1/vadd/krnl_vadd.cpp","platform/a1/vadd/test_cpu.cpp","-o",str(build/"vadd.exe")],
         ROOT/"platform/a1/evidence/vadd_pc_compile.json",cwd=ROOT,env=env)
if not code:code=run([str(build/"vadd.exe")],ROOT/"platform/a1/evidence/vadd_pc_run.json",cwd=ROOT,env=env)
raise SystemExit(code)
