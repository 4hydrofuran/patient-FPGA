# Read-only checkpoint audit; report files only, no programming or design edits.
if {$argc != 2} { error "usage: audit_routed.tcl <routed.dcp> <new-report-dir>" }
set checkpoint [file normalize [lindex $argv 0]]
set reportdir [file normalize [lindex $argv 1]]
if {![file isfile $checkpoint]} { error "checkpoint missing" }
if {[file exists $reportdir]} { error "report directory already exists" }
file mkdir $reportdir
set_param general.maxThreads 2
open_checkpoint $checkpoint
report_route_status -file [file join $reportdir route_status.rpt]
report_drc -file [file join $reportdir drc.rpt]
report_methodology -file [file join $reportdir methodology.rpt]
close_design
puts "REPORTS_GENERATED_NOT_AUTOMATIC_PASS; review report contents"
exit
