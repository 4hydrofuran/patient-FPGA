"""Read-only audit of generated PL overlay, two candidate base DTBs and final XSA.

Does not load an overlay, execute ARM code, write media or approve a boot bundle.
Run under the Common SDK environment for its native fdtget.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def get(blob, node, prop=None, kind='x', children=False):
    cmd = ['fdtget', '-l' if children else '-t']
    if not children:
        cmd.append(kind)
    cmd += [str(blob), node]
    if prop is not None:
        cmd.append(prop)
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(json.dumps({'argv': cmd, 'error': result.stderr}))
    return result.stdout.strip()


def memory(blob):
    nodes = get(blob, '/', children=True).splitlines()
    result = {'memory': {}, 'reserved': {}}
    for node in nodes:
        if node == 'memory' or node.startswith('memory@'):
            result['memory'][node] = get(blob, '/' + node, 'reg')
    if 'reserved-memory' in nodes:
        for node in get(blob, '/reserved-memory', children=True).splitlines():
            path = '/reserved-memory/' + node
            props = subprocess.check_output(['fdtget', '-p', str(blob), path], text=True).splitlines()
            result['reserved'][node] = {p: get(blob, path, p) for p in props}
    chosen_props = subprocess.check_output(['fdtget', '-p', str(blob), '/chosen'], text=True).splitlines()
    result['bootargs'] = get(blob, '/chosen', 'bootargs', 's') if 'bootargs' in chosen_props else None
    return result


def inspect_pair(base, merged):
    amba = get(merged, '/__symbols__', 'amba', 's')
    cu = get(merged, '/__symbols__', 'krnl_vadd_1', 's')
    intc = get(merged, '/__symbols__', 'axi_intc_0', 's')
    fpga = get(merged, '/__symbols__', 'fpga_full', 's')
    before, after = memory(base), memory(merged)
    if before != after:
        raise ValueError('overlay changed memory or bootargs')
    reg = get(merged, cu, 'reg')
    if reg != '0 b0000000 0 10000':
        raise ValueError('CU mapping differs from linked xclbin')
    cells = [get(merged, amba, x) for x in ('#address-cells', '#size-cells')]
    if cells != ['2', '2']:
        raise ValueError('merged parent does not support four-cell reg')
    return {'base': str(base), 'base_sha256': sha(base), 'merged': str(merged),
            'merged_sha256': sha(merged), 'memory_and_bootargs_unchanged': True,
            'memory': after, 'amba': amba, 'parent_cells': cells, 'cu': cu, 'cu_reg': reg,
            'cu_interrupts': get(merged, cu, 'interrupts'),
            'intc': intc, 'intc_kind': get(merged, intc, 'xlnx,kind-of-intr'),
            'intc_interrupts': get(merged, intc, 'interrupts'),
            'zocl_interrupts_extended': get(merged, amba + '/zyxclmm_drm', 'interrupts-extended'),
            'firmware_name': get(merged, fpga, 'firmware-name', 's')}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--xsa', type=Path, required=True)
    ap.add_argument('--linked-bit', type=Path, required=True)
    ap.add_argument('--xclbin-bit', type=Path, required=True)
    ap.add_argument('--overlay-dir', type=Path, required=True)
    ap.add_argument('--platform-base', type=Path, required=True)
    ap.add_argument('--bootfw-base', type=Path, required=True)
    args = ap.parse_args()
    with zipfile.ZipFile(args.xsa) as archive:
        bits = [n for n in archive.namelist() if n.endswith('.bit')]
        if len(bits) != 1:
            raise ValueError('expected exactly one bitstream')
        bit_hash = hashlib.sha256(archive.read(bits[0])).hexdigest()
    if bit_hash != sha(args.linked_bit) or bit_hash != sha(args.xclbin_bit):
        raise ValueError('XSA / linked / xclbin bitstream mismatch')
    report = {'status': 'OFFLINE_STRUCTURE_ONLY_NOT_DEPLOYABLE', 'g1': 'NOT_PASSED',
              'deployment_authorized': False, 'xsa_sha256': sha(args.xsa),
              'bitstreams_equal': True, 'bitstream_sha256': bit_hash,
              'overlay_sha256': sha(args.overlay_dir / 'a1-vadd.dtbo'),
              'pairs': [], 'linux_safe_budget_bytes': None, 'pl_safe_budget_bytes': None,
              'interrupt_runtime_validation': 'NOT_TESTED; generated CU and ZOCL flags must be reconciled'}
    for name, base in [('platform', args.platform_base), ('bootfw', args.bootfw_base)]:
        report['pairs'].append(inspect_pair(base, args.overlay_dir / (name + '-merged-audit-only.dtb')))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
