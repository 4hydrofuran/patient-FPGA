"""Unpack this common-image archive to NEW regular files, without executing SDK.

No tar links/devices, ownership restoration, mounts or executable modes accepted.
"""
import argparse
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile
from file_hash import sha256_file
from unpack_wic_readonly import sparse_copy

PREFIX = "xilinx-zynqmp-common-v2026.1"
NAMES = {"Image", "sdk.sh", "rootfs.tar.gz", "rootfs.manifest", "rootfs.ext4",
         "u-boot.elf", "bl31.elf", "boot.scr", "README.txt"}
EXPECTED = "2506c1a0ce458665ce01b9b58a6ca10cf21919513cb125896a64f3d001ad14d9"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("archive", type=Path)
    ap.add_argument("out", type=Path)
    a = ap.parse_args()
    if not a.archive.is_file() or sha256_file(a.archive) != EXPECTED:
        raise ValueError("input differs from reviewed archive")
    a.out.mkdir(parents=True, exist_ok=False)
    if shutil.disk_usage(a.out).free < 12 * 1024**3:
        raise ValueError("need 12GiB free reserve")
    records, seen, total = [], set(), 0
    with tarfile.open(a.archive, "r|gz") as tar:
        for item in tar:
            parts = PurePosixPath(item.name).parts
            if item.isdir() and parts == (PREFIX,):
                continue
            if not item.isfile() or len(parts) != 2 or parts[0] != PREFIX or parts[1] not in NAMES:
                raise ValueError("unexpected or unsafe archive member: " + item.name)
            if parts[1] in seen:
                raise ValueError("duplicate member")
            seen.add(parts[1])
            total += item.size
            if item.size < 0 or total > 8 * 1024**3:
                raise ValueError("archive size bound exceeded")
            with tar.extractfile(item) as src, (a.out / parts[1]).open("xb") as dst:
                size, digest = sparse_copy(src, dst, item.size)
            if size != item.size:
                raise ValueError("truncated member")
            record = {"name": parts[1], "bytes": size, "sha256": digest}
            records.append(record)
            print(json.dumps(record), flush=True)
    if seen != NAMES:
        raise ValueError("missing members")
    manifest = {"archive_sha256": EXPECTED, "status": "EXTRACTED_NOT_EXECUTED_NOT_BOARD",
                "files": records}
    with (a.out / "audit-manifest.json").open("x") as f:
        json.dump(manifest, f, indent=2)
    print("No SDK installation, guest execution, mounts or device writes.")


if __name__ == "__main__":
    main()
