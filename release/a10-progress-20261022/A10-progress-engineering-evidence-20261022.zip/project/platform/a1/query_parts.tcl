puts "A1 READ-ONLY DEVICE CATALOG"
puts "TOOL [version -short]"
puts "K26_PARTS [get_parts -quiet *k26*]"
puts "KV260_BOARDS [get_board_parts -quiet *kv260*]"
exit
