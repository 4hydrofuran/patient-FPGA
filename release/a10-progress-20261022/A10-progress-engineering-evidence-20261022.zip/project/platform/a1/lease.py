"""Single central on-board lease; persistent after timeout/crash, no auto takeover.

CLI requires Linux board and manual registration. Unit tests call the core on
temporary directories: those tests are NOT a distributed/board lock validation.
"""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import platform as host_platform
import secrets
import sys
import time
from record import run

CENTRAL=Path("/var/lock/kv260-a1")

def write(path,data):
    path.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8",newline="\n")


def write_new_provenance(log, data):
    """Never replace evidence even when a prior run failed or crashed."""
    log = Path(log)
    if log.exists() or log.is_symlink():
        raise FileExistsError("command log exists; choose a new evidence path")
    provenance = Path(str(log) + ".provenance.json")
    provenance.parent.mkdir(parents=True, exist_ok=True)
    with provenance.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(data, indent=2) + "\n")
        stream.flush()
        os.fsync(stream.fileno())

def acquire(base,owner,scope,identity,ttl=3600):
    if owner not in ("A","B","C") or not 1<=ttl<=14400 or not scope:
        raise ValueError("invalid owner/scope/TTL")
    active=base/"active"
    active.mkdir()  # atomic; a stale/incomplete directory also blocks admission
    record={"owner":owner,"scope":scope,"identity":identity,"token":secrets.token_hex(32),
            "issued_unix":time.time(),"expires_unix":time.time()+ttl,"pid":os.getpid()}
    write(active/"lease.json",record)
    return record

def require(base,token,identity,now=None):
    record=json.loads((base/"active/lease.json").read_text())
    if not secrets.compare_digest(record["token"],token) or record["identity"]!=identity:
        raise PermissionError("lease token or board identity mismatch")
    if (time.time() if now is None else now)>=record["expires_unix"]:
        raise PermissionError("expired: no automatic takeover, A must reconcile board state")
    return record

def release(base,token,confirmed_idle):
    record=json.loads((base/"active/lease.json").read_text())
    if not confirmed_idle or not secrets.compare_digest(record["token"],token):
        raise PermissionError("explicit idle confirmation and exact token required")
    history=base/"history";history.mkdir(exist_ok=True)
    record["released_unix"]=time.time()
    # Rename only this known tiny lease, never delete user directories.
    (base/"active/lease.json").rename(history/(record["token"]+".json"))
    write(history/(record["token"]+".json"),record)
    (base/"active").rmdir()

def check_board(registry):
    if host_platform.system()!="Linux" or host_platform.machine() not in ("aarch64","arm64"):
        raise RuntimeError("must execute on the authorized ARM64 board")
    compatible=Path("/sys/firmware/devicetree/base/compatible").read_bytes()
    machine=hashlib.sha256(Path("/etc/machine-id").read_bytes()).hexdigest()
    if b"kv260" not in compatible or b"xlnx" not in compatible:
        raise RuntimeError("KV260 compatible identity absent; do not bypass with environment variables")
    if registry.get("board_test_authorized") is not True or registry.get("host_key_verified") is not True:
        raise PermissionError("board access not authorized/host key not verified")
    if not registry.get("board_identity") or registry.get("identity_reviewed") is not True:
        raise PermissionError("physical board identity/serial review is missing")
    if registry.get("machine_id_sha256")!=machine:
        raise PermissionError("registered machine identity does not match")
    return machine+":"+Path("/proc/sys/kernel/random/boot_id").read_text().strip()

@contextmanager
def deployment_lock(base):
    import fcntl  # on-board Linux only; all members must use this SAME inode
    with (base/"deployment.lock").open("a+") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try: yield
        finally: fcntl.flock(lock,fcntl.LOCK_UN)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--registry",required=True)
    sub=ap.add_subparsers(dest="action",required=True)
    a=sub.add_parser("acquire");a.add_argument("--owner",choices=["A","B","C"],required=True);a.add_argument("--scope",required=True)
    sub.add_parser("status")
    r=sub.add_parser("release");r.add_argument("--confirmed-idle",action="store_true")
    r=sub.add_parser("run");r.add_argument("--log",required=True);r.add_argument("argv",nargs=argparse.REMAINDER)
    args=ap.parse_args();registry=json.loads(Path(args.registry).read_text())
    identity=check_board(registry)
    if args.action in ("acquire","release") and registry.get("coordinator_uid")!=os.getuid():
        raise PermissionError("only the registered A coordinator may grant/release leases")
    if not CENTRAL.is_dir() or CENTRAL.is_symlink():
        raise PermissionError("A/admin must provision the single trusted central lock directory first")
    with deployment_lock(CENTRAL):
        if args.action=="acquire": print(json.dumps(acquire(CENTRAL,args.owner,args.scope,identity)))
        elif args.action=="status":
            rec=json.loads((CENTRAL/"active/lease.json").read_text());rec.pop("token");print(json.dumps(rec))
        elif args.action=="release":release(CENTRAL,os.environ.get("A1_LEASE_TOKEN",""),args.confirmed_idle)
        else:
            token=os.environ.get("A1_LEASE_TOKEN","");require(CENTRAL,token,identity)
            argv=args.argv[1:] if args.argv[:1]==["--"] else args.argv
            if not argv:raise ValueError("missing command")
            env=os.environ.copy();env["A1_BOARD_LEASE"]=token
            record=require(CENTRAL,token,identity)
            write_new_provenance(args.log,{"board_identity":registry["board_identity"],"machine_and_boot_id":identity,
                              "owner":record["owner"],"scope":record["scope"],
                              "registry_sha256":hashlib.sha256(Path(args.registry).read_bytes()).hexdigest(),
                              "verification_level":"ON_REGISTERED_BOARD_COMMAND_NOT_TEST_ASSERTION"})
            code=run(argv,args.log,env=env)
            # Lease retained even on success; release is a separate explicit step.
            return code
    return 0

if __name__=="__main__":
    try:raise SystemExit(main())
    except (OSError,ValueError,RuntimeError) as e:print(str(e),file=sys.stderr);raise SystemExit(1)
