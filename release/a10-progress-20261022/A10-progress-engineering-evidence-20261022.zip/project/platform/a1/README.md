# A1：无板准备已执行，真实 G1 未通过

2026-09-28后续：[Kria打包/overlay审查](../../docs/handoffs/A1_OVERLAY_AUDIT_20260928.md)。v++ package的Kria no-op已实证；最终XSA/候选DTBO/bit.bin已生成并离线核对，非可部署套件。91项PC回归通过，仍需中断绑定审查及真实G1。

2026-09-28最新：[离线硬件链接交接](../../docs/handoffs/A1_OFFLINE_LINK_20260928.md)。A-vadd xclbin已生成，布线/DRC/拓扑已审查，BO防护host已ARM64链接；87项PC回归通过。产物OFFLINE_BUILD_ONLY_NOT_DEPLOYABLE，G1未通过、部署/内存门禁不变。下文“无xclbin”等为历史记录。

2026-09-28：Common Image 已审查、SDK 已独立安装、最小 XRT host 已 ARM64 编译/链接成功（非执行）。入口 `build_common_vadd.sh`，产物与失败修复记录见 `evidence/common-sdk-host-manifest.json`；77 项 PC 单元测试通过。详见 [Common Image 交接](../../docs/handoffs/A1_COMMON_IMAGE_20260928.md)。启动/内存门禁仍阻断、xclbin 未生成；下方旧输入请求和“仅源码语法检查”是历史状态。

证据记录更新：vadd CSV必须是全新路径，任何XRT调用前独占创建；已存在文件/符号链接拒绝，写入或flush失败不计成功。record.py命令日志亦独占创建，崩溃可能留下RESERVED_NOT_COMPLETED，不能覆盖重跑或凭该状态认定进程仍活跃。租约来源记录同样不可覆盖。主机71项回归见`evidence/evidence-integrity-regression.json`，不计G1；后续待Common Image输入见`../../docs/handoffs/A1_PLATFORM_ROUTE_20260927.md`。

2026-09-27增量见[无板G1交接](../../docs/handoffs/A1_G1_PREBOARD_20260927.md)：Linux正式许可、K26目录、HLS综合与XO生成已有真实成功证据，DTB内存描述已静态核对。下方“无XO/器件拒绝”等是早期失败历史；实时摘要以`g1_status.json`及本次原始日志为准。rootfs/启动固件/XRT/实际内存仍未闭环，不跳过link门禁，也不以仿真代替板测。

当前截止：2026-09-26；用户板卡 10 月 7 日以后到。**9 月 30 日没有真实板测，G1 就是未通过**。
不打 `g1-platform` 标签；PC 原生 C++、Csim、cosim、硬件链接和真实板测分别记录。

最新进展见 `../linux/README.md`、`../../docs/handoffs/A1_B0.md`：Linux软件环境/模型恢复/主机S0/ARM64交叉编译已完成；B0接口已对齐draft.2，XRT仅源码头文件语法编译通过。下方“已实施与失败”保留早期A1历史，不应据它断言现在仍无Linux/完整模型。G1仍未通过；rootfs/平台/板端内存事实没有更新为通过。

## 已实施与失败

- 固定版本见 `pins.json`；公共业务/量化契约未修改。
- `vadd/` 是 A 自有平台烟雾核，不是 B 的 W4A8 计算核。20 种合法长度，每种 50 次完整向量比较；uint32 模 2^32 相加。不同 job 改变输入、输出预填反码、尾部 16 元素检查；5 类非法参数只在 host 验证，不向硬件发送非法地址。
- PC 编译与 1000 次比较通过；不是 host emulation，更不是板测。HLS 真实运行失败，修正源路径后仍报告 K26 part 不支持/未安装/许可证不适配。Vivado `get_parts *k26*` 为空，BASIC 许可证存在不代表目标功能可用。没有 `.xo`、`.xclbin`。
- S0 harness、固定 256 token 输入、官方 chat template 与许可证已准备。PC 编译在旧 MinGW Windows SDK 的 `THREAD_POWER_THROTTLING_STATE` 缺失处失败；未改上游源码规避。ARM64 原生编译未执行。
- 原权重下载两次 SHA256 失败，均不足 988097824 字节；失败文件在 ignored cache 中隔离，禁止转换/推理。不重新全量下载第三次；待处理网络或由用户提供同 revision、同 SHA256 的完整文件。模型指标全部 null。

实际命令、stdout/stderr、退出码均在 `evidence/*.json`。`record.py` 支持记录额外构建/SSH命令，拒绝覆盖旧日志；重复运行需用新日志名，构建辅助脚本内固定日志名也需更换。
软件准备依赖装在 `platform/local/a1/venv`（继承已安装 Python torch/numpy），未改原工程环境；精确版本见 `python_freeze.json`。没有安装 WSL、大型 AMD 组件、驱动或刷写工具。

## KV260 2026.1 核验结论

优先取得官方同版本、已匹配的 `kv260_base` XPFM/XSA、KV260 Linux 镜像/SDK 与启动文件，不先自己改驱动/PYNQ。

| 官方材料 | 当前证据 | 结论 |
| --- | --- | --- |
| KV260 专用 README | XRT `202610.2.23.0_Petalinux`；Ubuntu/Yocto 入口；PS DDR=2GB；候选时钟 150/300/75/100/200/400/600 MHz，HP0–3/HPC0–1/LPD | 这是源码配置表，不是实板可用空间、bank/group_id 或已实现频率 |
| 总 README | 将 kv260_base 列入 EDF；平台构建 Linux-only | 与专用说明及 platform.mk 的 ZynqMP common 路线存在待核实差异，不能照抄 Versal OSPI/PDI |
| platform.mk / generate_platform.py | Cortex-A53、ZynqMP common 路径；Linux xrt domain；设备树 overlay/zocl；no_boot_bsp | 确认是 MPSoC 路线；未取得实际 image/DTB/boot 文件，不能宣称兼容 |
| bd.tcl vs reference_bd.tcl | 前者 MPSoC CED、Include_DDR=false；后者含 VCK190/Versal 器件和 NoC | reference 文件可能不参与实际构建；不能将其约束当 KV260 约束 |
| system-user.dtsi | CMA=1536M；0x800000000 起 2GiB no-map 保留区；QSPI 分区描述；构建会传入该 DTSI | 潜在模板残留/配置不一致，需官方已匹配产物和实测消除，禁止直接应用 |
| 本机 board.xml 2.0 | 候选 part xck26-sfvc784-2LV-c | 仅板描述；本机可用器件目录没有 K26，工具环境阻断 |

固定源文件 URL/完整哈希/行号见 `evidence/acquisition.json`、`source_findings.json`。
来源：[专用 README](https://github.com/Xilinx/Vitis_Embedded_Platform_Source/blob/f7bdd9f5c8ef52636b138f3bbe751148d9690de1/Xilinx_Official_Platforms/kv260_base/README.md)、[总 README](https://github.com/Xilinx/Vitis_Embedded_Platform_Source/blob/f7bdd9f5c8ef52636b138f3bbe751148d9690de1/README.md)、[KV260 DTSI](https://github.com/Xilinx/Vitis_Embedded_Platform_Source/blob/f7bdd9f5c8ef52636b138f3bbe751148d9690de1/Xilinx_Official_Platforms/kv260_base/user_dts/system-user.dtsi)、[reference BD](https://github.com/Xilinx/Vitis_Embedded_Platform_Source/blob/f7bdd9f5c8ef52636b138f3bbe751148d9690de1/Xilinx_Official_Platforms/kv260_base/hw/xsa_scripts/reference_bd.tcl)、[XRT tag](https://github.com/Xilinx/XRT/releases/tag/202610.2.23.0_Petalinux)。

## 解阻后的构建顺序（以下未执行成功）

1. 在已批准 Linux 构建主机核实 2026.1、K26 part/许可证和官方产物完整性；保留 `platforminfo --help`、`platforminfo -p <exact.xpfm>` 原始输出，确认实际 part/default clock/memory ports。镜像与 SDK/sysroot 必须同版，不能用 PC /usr/include 替换。
2. 修复目标环境后，从仓库根执行 `python3 platform/a1/run_hls.py --mode csim --label linux-csim`、`--mode synth --label linux-synth`、`--mode package --label linux-package`。当前 config 150MHz 只是烟雾核请求；实际目标频率来自已匹配平台且需时序验证。
3. 将实际匹配证据写进 `matched_bundle.template.json` 的独立实例（不是直接把状态改为通过）。每个 artifact 是 `{path,sha256}`。核对 XO XML 的 `krnl_vadd` 参数顺序 a,b,c,n、端口与标量宽度。`.xo` 必须指向实际 package 输出，不能猜路径。
4. `python3 platform/a1/link_hw.py --bundle <reviewed.json> --label <unique-id>` 只执行 `--target hw` 的链接并记录 xclbin SHA256；不会生成/刷写 SD 或 QSPI。当前模板必拒绝。
5. XRT host 使用匹配 rootfs 的头文件/库构建：`c++ -O2 -std=c++17 platform/a1/vadd/host.cpp -I<verified-XRT-include> -L<verified-XRT-lib> -lxrt_coreutil -pthread -o <output>/a1-vadd`。交叉构建用该镜像 SDK 的 CXX/sysroot，不能用 Windows host 编译器。此 host 尚未编译验证。

## 到板后：身份、租约、内存，再运行

1. 用户提供板卡与连接授权；SSH host key 经串口/可信途径核验，保留 SSH 完整会话日志。核对物理标签/序列号、DT model/compatible、`/etc/machine-id` SHA256、boot_id；machine-id 不是物理身份的替代物。将 registry 的对应字段经人工复核后填写，当前全部未授权。
2. A/管理员显式配置板上唯一 `/var/lock/kv260-a1` 目录及最小 OS 权限；coordinator_uid 仅 A。所有成员通过同一板执行 `lease.py`，不各自创建 PC 锁。`acquire --owner A --scope <task>` 返回 token；保存在会话环境 `A1_LEASE_TOKEN`，不放 Git/命令行日志。
3. `python3 platform/a1/lease.py --registry <verified-registry.json> acquire --owner A --scope A1`；`run --log <new.json> -- <argv...>` 持有同一 deployment flock。发放/释放仅 A；TTL 到期、进程崩溃、重启均不自动抢占。失败后由 A 核实设备/DMA 是否空闲，再 `release --confirmed-idle`。当前仅 PC 核心语义测试通过，板上 flock/权限/跨机竞争尚未验证。脚本是合作式排他机制，不是防恶意绕过的权限沙箱。
4. 在租约下运行 `collect_board.py --registry <verified-registry.json> --out <new-dir>`。它只读采集 DT reg/reserved-memory、MemTotal/MemAvailable/CMA、XRT报告/原始拓扑、zocl、启动参数、设备与进程；另含 `/proc/interrupts`、`/proc/modules`、RPM/dpkg 包查询和 xrt-smi/xbutil 双路径。工具缺失/不支持/权限错误保留原退出码；不 sudo 绕过。首次身份读取可以先人工在已授权 SSH/串口读出，不以未登记身份运行加速器。加载后执行前、结束后卸载前分别采集到新目录；核对同一boot_id及IRQ映射，结合dmesg记录是否中断/轮询，不能仅凭结果正确认定中断通过。详见 `docs/handoffs/A1_IRQ_AUDIT_20260928.md`。
5. 对照实际 XSA/DTB、rootfs、内核/XRT/启动固件与 `memory_review.template.json`。Linux MemTotal 不等于物理 DDR；CMA 可与 Linux 内存统计重叠，PL 可能经共享池访问 PS DDR，禁止将两侧容量相加。先辨明地址窗口和 reservation，任何不一致保持平台 BLOCKED。
6. A 单独批准有界 BO 烟雾测试预算后，在同一租约运行 host；最大每 BO=(4096+16)*4=16448 字节，三者同时最多49344字节（不含驱动对齐开销）。日志记录实际 group_id、BO 地址与大小。结果只能证明这些范围可用，不能推断最大 CMA/BO，更不能按 4GB 预算。随后在明确安全上限内逐级做实际负载 BO 分配/同步/校验；记录最大已验证单 BO 和同时驻留量，不做 OOM 极限探测。
7. 首次测试成功且进程退出后，复核同一 boot_id、重新加载同一个已验 SHA256 xclbin，再完整重跑，用两份独立 CSV 与日志证明正常加载/重载。它不是总线挂死恢复证明。超时/总线错误保留租约，不自动重启；按匹配平台官方支持路径和针对性授权处理。

## S0：板端原生 CPU，独立于业务服务

完整原权重必须先匹配 `pins.json` 的 SHA256，才使用固定源码中的 `convert_hf_to_gguf.py <source-model-dir> --outtype f16 --outfile <F16.gguf>`。源码 BF16 转 F16 与后续 W4A8 格式不同，不能把 GGUF 字节解释成 B 的核格式。保存 converter 命令、版本、输出 hash；当前未转换。

板端原生构建（在匹配 rootfs/内存核验与租约通过后）：若使用归档解压的非Git源码，设置 `GIT_CEILING_DIRECTORIES` 为其父目录，避免上游CMake错误拾取本项目的commit。首次PC配置曾显示父仓库commit，编译失败未生成推理程序；真实源码身份以固定archive hash为准。

```sh
cmake -S bench/runtime/s0 -B platform/build/s0-arm -DCMAKE_BUILD_TYPE=Release -DLLAMA_SOURCE=<pinned-source-dir> -DLLAMA_BUILD_COMMIT=4762ad7316dcdec20016ab5985fb46a27902204d -DLLAMA_BUILD_NUMBER=6000 -DGGML_NATIVE=ON -DGGML_OPENMP=ON
cmake --build platform/build/s0-arm --target a1-s0 -j 2
```

以上 `<...>` 必须替换真实路径，不直接运行占位符。保存 uname/compiler/CMake 输出。基线 GPU layers=0，mmap=false，ctx=512，batch=256，ubatch=128；分别 threads=1/2/4，逐次独立进程运行，输出目录必须是新目录。固定参数：

```text
a1-s0 <verified-F16.gguf> bench/runtime/s0/fixture/prompt.txt bench/runtime/s0/fixture/tokens.txt <1|2|4> <new-output-prefix>
```

每次必须通过实际 llama tokenizer 的 256 token ID 一致性检查，并核对导出的 `.chat_template.txt` 与 fixture SHA256。收集 model_load/context_init/prefill、真实逐 token decode 调用时间/次数、采样时间、答案、peak RSS、CPU频率/温度/线程与背景进程；无 ASR/TTS。page cache 未清空，明确是未控制冷热页状态，不能称冷启动。短答最多32token，decode_calls 与输出 token 数分开，不能把首个 prefill 产生的 token 算作一次 decode eval。

如果 F16 常驻内存不安全，停止并列阻断，不默默换量化模型来凑性能。后续 Q4/Q8 需独立 S0 变体、hash 与质量说明。

## 恢复与写介质边界

本阶段没有 `dd`/格式化/QSPI 写入/boot firmware 更新命令。未来任何介质写入前单独展示：
准确设备路径 + 容量/厂商/序列号 + 当前挂载/系统盘排除 + 所用镜像 SHA256 + 现有固件版本 + 可读备份位置/校验 + 串口/已知可启动介质恢复步骤。
用户对该目标和操作明确授权后才执行。没有设备就不填写假路径，也不假定 SD 启动意味着可以忽略 QSPI 固件匹配。

## G1 人工证据清单

真实板身份/权限、中央租约、平台版本链、内存复核、HW xclbin hash、20长度/1000整向量比较、5类 host 拒绝、正常重载两轮日志、板端原生 S0、许可证/模型/模板 hash、串口/SSH日志。缺一项不通过。当前以 `g1_status.json` 为准，报告标题和 PC PASS 不满足此清单。
