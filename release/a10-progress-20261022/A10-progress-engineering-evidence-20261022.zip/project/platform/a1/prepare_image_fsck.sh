#!/usr/bin/env bash
# Build a private newer checker; no sudo, install, mount or image repair.
set -euo pipefail
work=/home/member-a/kv260-build/e2fsprogs-1.47.3-audit
mkdir "$work"
cd "$work"
base=https://www.kernel.org/pub/linux/kernel/people/tytso/e2fsprogs/v1.47.3
curl --fail --location --retry 1 --max-time 120 "$base/e2fsprogs-1.47.3.tar.xz" -o e2fsprogs-1.47.3.tar.xz
curl --fail --location --retry 1 --max-time 60 "$base/sha256sums.asc" -o sha256sums.asc
# HTTPS publisher checksum comparison; NOT a claim of verified GPG identity.
awk '$2 == "e2fsprogs-1.47.3.tar.xz" {print}' sha256sums.asc | sha256sum --check -
tar -xJf e2fsprogs-1.47.3.tar.xz
mkdir build
cd build
../e2fsprogs-1.47.3/configure --disable-nls
make -j2
./e2fsck/e2fsck -V
./e2fsck/e2fsck -f -n /home/member-a/kv260-build/image-audit-20260927/partition-3.img
