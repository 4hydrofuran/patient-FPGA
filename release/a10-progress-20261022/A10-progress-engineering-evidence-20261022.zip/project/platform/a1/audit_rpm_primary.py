"""Read pinned official RPM primary metadata; no RPM extraction/install/guest execution."""
import argparse
import ctypes
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

COMPRESSED_SHA = "e4d4f452d5ef4b7356eafb56bb4407cd9ffa67ae6925b3ebba591067a68cb041"
OPEN_SHA = "24c5b41c93a208c595ba89890c6f5d03c26b5eb8173100d7f075a2546a4efded"
OPEN_SIZE = 22805494
BASE = "https://petalinux.xilinx.com/sswreleases/rel-v2026.1/generic/rpm/cortexa72_cortexa53/"
NS = {"c": "http://linux.duke.edu/metadata/common", "r": "http://linux.duke.edu/metadata/rpm"}
NAMES = {"g++", "g++-symlinks", "cmake", "gcc", "gcc-symlinks", "ninja", "pkgconfig",
         "pkgconf", "libstdc++-dev", "libgomp1", "make"}


def select_packages(xml):
    if b"<!DOCTYPE" in xml or b"<!ENTITY" in xml:
        raise ValueError("XML entity declarations forbidden")
    root = ET.fromstring(xml)
    rows = []
    for pkg in root.findall("c:package", NS):
        name = pkg.findtext("c:name", namespaces=NS)
        if name not in NAMES:
            continue
        location = pkg.find("c:location", NS).attrib["href"]
        if ":" in location or ".." in Path(location).parts or location.startswith("/"):
            raise ValueError("unexpected package URL path")
        checksum = pkg.find("c:checksum", NS)
        rows.append({"name": name, "arch": pkg.findtext("c:arch", namespaces=NS),
                     "version": pkg.find("c:version", NS).attrib,
                     "checksum_type": checksum.attrib["type"], "checksum": checksum.text,
                     "url": BASE + location, "size": pkg.find("c:size", NS).attrib,
                     "requires": [e.attrib for e in pkg.findall("c:format/r:requires/r:entry", NS)],
                     "provides": [e.attrib for e in pkg.findall("c:format/r:provides/r:entry", NS)]})
    return rows


def inspect(path):
    if path.stat().st_size != 1471618:
        raise ValueError("unexpected compressed metadata size")
    data = path.read_bytes()
    if len(data) != 1471618 or hashlib.sha256(data).hexdigest() != COMPRESSED_SHA:
        raise ValueError("compressed metadata differs from reviewed repomd.xml")
    zstd = ctypes.CDLL("libzstd.so.1")
    zstd.ZSTD_decompress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t]
    zstd.ZSTD_decompress.restype = ctypes.c_size_t
    zstd.ZSTD_isError.argtypes = [ctypes.c_size_t]
    zstd.ZSTD_isError.restype = ctypes.c_uint
    dst = ctypes.create_string_buffer(OPEN_SIZE)
    src = ctypes.create_string_buffer(data)
    size = zstd.ZSTD_decompress(dst, OPEN_SIZE, src, len(data))
    if zstd.ZSTD_isError(size) or size != OPEN_SIZE:
        raise ValueError("zstd decompression/size mismatch")
    xml = dst.raw
    if hashlib.sha256(xml).hexdigest() != OPEN_SHA:
        raise ValueError("decompressed metadata checksum mismatch")
    return {"status": "METADATA_ONLY_NOT_INSTALLED", "compressed_sha256": COMPRESSED_SHA,
            "open_sha256": OPEN_SHA, "open_bytes": OPEN_SIZE,
            "source": BASE, "rpm_signature_verified": False,
            "packages": select_packages(xml),
            "note": "HTTPS metadata digests checked, not a verified RPM install transaction. Rootfs repo uses gpgcheck=0; this tool does not change policy."}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("metadata", type=Path)
    args = ap.parse_args()
    print(json.dumps(inspect(args.metadata), indent=2))
