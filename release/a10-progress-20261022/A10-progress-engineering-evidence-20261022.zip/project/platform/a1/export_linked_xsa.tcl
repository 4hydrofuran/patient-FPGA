# Export only from existing routed A-smoke project; never rebuild or program.
if {$argc != 2} { error "usage: export_linked_xsa.tcl <project.xpr> <new-output-dir>" }
set project [file normalize [lindex $argv 0]]
set outdir [file normalize [lindex $argv 1]]
if {![file isfile $project]} { error "missing project" }
if {[file exists $outdir]} { error "output exists" }
file mkdir $outdir
set_param general.maxThreads 2
open_project -read_only $project
if {![string equal -nocase [get_property PART [current_project]] "xck26-sfvc784-2LV-c"]} {
    error "not the expected K26 part"
}
open_run impl_1
write_hw_platform -fixed -include_bit -file [file join $outdir vadd-final.xsa]
close_project
puts "EXPORTED_FOR_OFFLINE_SDT_AUDIT_ONLY_NOT_DEPLOYABLE"
exit
