"""Read the embedded SDK tar.xz without executing the installer or extracting files."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def inspect(path):
    count = total = 0
    selected = []
    with path.open("rb") as raw:
        for _ in range(2000):
            line = raw.readline(65537)
            if len(line) > 65536:
                raise ValueError("installer prefix line too long")
            if line == b"MARKER:\n":
                break
            if not line:
                raise ValueError("missing payload marker")
        else:
            raise ValueError("installer prefix too long")
        with tarfile.open(fileobj=raw, mode="r|xz") as archive:
            for member in archive:
                p = PurePosixPath(member.name)
                if p.is_absolute() or ".." in p.parts:
                    raise ValueError("unsafe member path: " + member.name)
                count += 1
                total += member.size
                if member.isfile() and (
                    len(p.parts) == 1 or
                    "post-relocate" in member.name or
                    "environment-setup.d/" in member.name
                ):
                    if member.size > 256 * 1024:
                        raise ValueError("unexpected large setup script")
                    data = archive.extractfile(member).read()
                    selected.append({"path": member.name, "bytes": len(data),
                                     "sha256": hashlib.sha256(data).hexdigest(),
                                     "text": data.decode("utf-8", errors="replace")})
    return {"status": "READ_ONLY_NOT_INSTALLED", "members": count,
            "sum_member_bytes": total, "setup_files": selected}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("sdk", type=Path)
    args = ap.parse_args()
    print(json.dumps(inspect(args.sdk), indent=2))
