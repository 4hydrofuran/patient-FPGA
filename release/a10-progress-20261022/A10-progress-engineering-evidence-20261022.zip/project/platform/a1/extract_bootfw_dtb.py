"""Extract the audited KV260 boot DTB; never execute firmware or open devices.

Offsets are from bootgen 2026.1 -arch zynqmp -read (bootfw-headers.json).
This intentionally only accepts the exact audited file, not arbitrary BOOT.BIN.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct

EXPECTED_SHA256 = "d08a66ba5c04c713ce663ecc74ffb4d34bc0f7e4885c6d0875c7961ce6e8e678"


def extract(data):
    if hashlib.sha256(data).hexdigest() != EXPECTED_SHA256:
        raise ValueError("Not the audited boot firmware; re-review bootgen headers")
    header = struct.unpack_from("<16I", data, 0x1280)
    size, offset = header[1] * 4, header[8] * 4
    if size != 0x50B1 * 4 or offset != 0x11810 * 4:
        raise ValueError("Partition header differs from audited bootgen output")
    if offset + size > len(data):
        raise ValueError("Partition exceeds file")
    dtb = data[offset:offset + size]
    magic, total = struct.unpack_from(">II", dtb)
    if magic != 0xD00DFEED or not 40 <= total <= size:
        raise ValueError("Invalid FDT header or size")
    return dtb[:total], {"partition_offset": offset, "partition_bytes": size,
                         "fdt_bytes": total, "partition_padding_bytes": size - total}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("firmware", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if not args.firmware.is_file():
        parser.error("Input must be a regular file")
    if args.output.exists() or args.output.is_symlink():
        parser.error("Output must not exist")
    dtb, info = extract(args.firmware.read_bytes())
    with args.output.open("xb") as stream:
        stream.write(dtb)
    info.update(source=str(args.firmware), source_sha256=EXPECTED_SHA256,
                output=str(args.output), dtb_sha256=hashlib.sha256(dtb).hexdigest())
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
