"""Pin local board metadata and record upstream inconsistencies; never fix upstream."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2]
source=ROOT/"platform/local/a1/platform_source/Xilinx_Official_Platforms/kv260_base"
board=Path("D:/AMDDesignTools/2026.1/data/xhub/boards/XilinxBoardStore/boards/Xilinx/kv260_som/2.0/board.xml")
tree=ET.parse(board)
parts=[x.attrib["part_name"] for x in tree.iter("component") if "part_name" in x.attrib]
checks={"README_2GB":("README.md","2GB"),"bd_no_PL_DDR":("hw/xsa_scripts/bd.tcl","Include_DDR.VALUE false"),
        "reference_VCK190_part":("hw/xsa_scripts/reference_bd.tcl","xcvc1902-vsva2197-2MP-e-S"),
        "CMA_1536M":("user_dts/system-user.dtsi","cma=1536M"),
        "high_PL_reserved_range":("user_dts/system-user.dtsi","reg = <0x08 0x00 0x00 0x80000000>"),
        "zynqmp_common_path":("platform.mk","xilinx-zynqmp-common-v2026.1"),
        "dtsi_in_build":("Makefile","--dtsi $(DTSI_FILES)")}
report={"board_xml":{"path":str(board),"sha256":hashlib.sha256(board.read_bytes()).hexdigest(),"candidate_parts":parts},
        "observations":{},"platform_compatibility":"BLOCKED_UNVERIFIED",
        "note":"reference_bd.tcl may be unused, but its content cannot establish KV260 constraints. Source DTS is passed to platform generation. Do not modify reservations or allocate a presumed 4GB."}
for key,(file,needle) in checks.items():
    path=source/file;text=path.read_text(encoding="utf-8")
    report["observations"][key]={"file":file,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"found":needle in text,
                                 "lines":[i for i,line in enumerate(text.splitlines(),1) if needle in line]}
(ROOT/"platform/a1/evidence/source_findings.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(report))
