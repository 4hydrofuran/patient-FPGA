import concurrent.futures
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/"platform/a1"))
from lease import acquire,require,release,check_board
from collect_board import decode_reg

class A1Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_only_one_atomic_acquisition(self):
        def get(_):
            try:acquire(self.base,"A","test","pc-fixture");return 1
            except FileExistsError:return 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:
            self.assertEqual(sum(p.map(get,range(16))),1)
    def test_wrong_token_and_identity(self):
        rec=acquire(self.base,"A","test","fixture")
        with self.assertRaises(PermissionError):require(self.base,"wrong","fixture")
        with self.assertRaises(PermissionError):require(self.base,rec["token"],"other")
    def test_expired_not_stolen(self):
        rec=acquire(self.base,"B","test","fixture",ttl=1)
        with self.assertRaises(PermissionError):require(self.base,rec["token"],"fixture",rec["expires_unix"]+1)
        with self.assertRaises(FileExistsError):acquire(self.base,"A","test","fixture")
    def test_incomplete_crash_lease_blocks(self):
        (self.base/"active").mkdir()
        with self.assertRaises(FileExistsError):acquire(self.base,"A","test","fixture")
    def test_release_needs_confirmation(self):
        rec=acquire(self.base,"C","test","fixture")
        with self.assertRaises(PermissionError):release(self.base,rec["token"],False)
        with self.assertRaises(PermissionError):release(self.base,"wrong",True)
        release(self.base,rec["token"],True)
        self.assertFalse((self.base/"active").exists())
        self.assertEqual(len(list((self.base/"history").glob("*.json"))),1)
    def test_invalid_ttl(self):
        for ttl in (0,14401):
            with self.assertRaises(ValueError):acquire(self.base,"A","test","fixture",ttl)
    def test_dt_above_4gb_not_truncated(self):
        raw=bytes.fromhex("00000008000000000000000080000000")
        self.assertEqual(decode_reg(raw,2,2),[{"base":0x800000000,"size_bytes":0x80000000,"end_exclusive":0x880000000}])
    def test_dt_multiple_ranges(self):
        self.assertEqual(len(decode_reg(bytes.fromhex("00000000100000002000000010000000"),1,1)),2)
    def test_dt_truncation_rejected(self):
        with self.assertRaises(ValueError):decode_reg(b"\0"*15,2,2)
        with self.assertRaises(ValueError):decode_reg(b"",3,2)
    def test_pc_cannot_be_board(self):
        with self.assertRaises((RuntimeError,PermissionError,OSError)):check_board({"board_test_authorized":False})
    def test_fixed_prompt_hashes(self):
        fixture=ROOT/"bench/runtime/s0/fixture"
        m=json.loads((fixture/"manifest.json").read_text())
        self.assertEqual(len((fixture/"tokens.txt").read_text().split()),256)
        for name,digest in m["sha256"].items():self.assertEqual(hashlib.sha256((fixture/name).read_bytes()).hexdigest(),digest)
    def test_memory_budget_unverified(self):
        m=json.loads((ROOT/"platform/a1/memory_review.template.json").read_text())
        self.assertEqual(m["status"],"BLOCKED_UNVERIFIED")
        self.assertIsNone(m["linux_safe_budget_bytes"]);self.assertIsNone(m["pl_safe_budget_bytes"])

if __name__=="__main__":unittest.main()
