import hashlib
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('wic_audit', Path(__file__).resolve().parents[1]/'unpack_wic_readonly.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SparseCopyTests(unittest.TestCase):
    def run_copy(self, data, limit):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'regular.img'
            with p.open('xb') as out:
                size, sha = module.sparse_copy(io.BytesIO(data), out, limit)
            self.assertEqual(p.read_bytes(), data[:limit])
            self.assertEqual(size, len(data[:limit]))
            self.assertEqual(sha, hashlib.sha256(data[:limit]).hexdigest())

    def test_zero_tail_preserved(self):
        self.run_copy(b'x' + bytes(module.CHUNK*2), module.CHUNK*3)

    def test_short_source(self):
        self.run_copy(b'abc', 123)

    def test_length_bound(self):
        self.run_copy(b'abcdef', 3)

    def test_empty(self):
        self.run_copy(b'', 1)


if __name__ == '__main__':
    unittest.main()
