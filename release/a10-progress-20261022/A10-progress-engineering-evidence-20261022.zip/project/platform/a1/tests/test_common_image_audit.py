import contextlib
import hashlib
import io
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import extract_common_image as common
import inspect_sdk_payload as sdk


def archive_bytes(members, mode):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode=mode) as archive:
        for name, data, kind in members:
            item = tarfile.TarInfo(name)
            item.mode = 0o755
            item.type = kind
            if kind == tarfile.SYMTYPE:
                item.linkname = "/etc/passwd"
            else:
                item.size = len(data)
            archive.addfile(item, io.BytesIO(data) if item.isfile() else None)
    return buffer.getvalue()


class CommonImageAuditTests(unittest.TestCase):
    def extract(self, base, members):
        data = archive_bytes(members, "w:gz")
        archive = base / "input.tar.gz"
        archive.write_bytes(data)
        with patch.object(common, "EXPECTED", hashlib.sha256(data).hexdigest()), \
             patch.object(common.shutil, "disk_usage", return_value=type("Usage", (), {"free": 20 * 1024**3})()), \
             patch.object(sys, "argv", ["extract", str(archive), str(base / "out")]), \
             contextlib.redirect_stdout(io.StringIO()):
            common.main()

    def test_extract_only_regular_expected_files(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            self.extract(base, [(common.PREFIX + "/" + name, b"data", tarfile.REGTYPE) for name in common.NAMES])
            self.assertEqual((base / "out/sdk.sh").read_bytes(), b"data")
            if sys.platform != "win32":
                self.assertEqual((base / "out/sdk.sh").stat().st_mode & 0o111, 0)
            self.assertTrue((base / "out/audit-manifest.json").is_file())

    def test_reject_traversal_and_symlink(self):
        for name, kind in [(common.PREFIX + "/../escape", tarfile.REGTYPE),
                           (common.PREFIX + "/sdk.sh", tarfile.SYMTYPE)]:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp:
                with self.assertRaises(ValueError):
                    self.extract(Path(temp), [(name, b"data", kind)])
                self.assertFalse((Path(temp) / "escape").exists())

    def test_reject_existing_output(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            (base / "out").mkdir()
            with self.assertRaises(FileExistsError):
                self.extract(base, [])

    def test_sdk_read_only_selection(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "sdk.sh"
            data = b"#!/bin/sh\nMARKER:\n" + archive_bytes([
                ("./environment-setup-target", b"export TEST=1\n", tarfile.REGTYPE),
                ("sysroots/host/environment-setup.d/test.sh", b"true\n", tarfile.REGTYPE),
                ("sysroots/host/bin/no-execute", b"binary", tarfile.REGTYPE),
            ], "w:xz")
            path.write_bytes(data)
            result = sdk.inspect(path)
            self.assertEqual(result["members"], 3)
            self.assertEqual(len(result["setup_files"]), 2)
            self.assertEqual(path.read_bytes(), data)
            self.assertEqual(list(Path(temp).iterdir()), [path])

    def test_sdk_missing_marker(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "sdk.sh"
            path.write_bytes(b"#!/bin/sh\nexit 1\n")
            with self.assertRaises(ValueError):
                sdk.inspect(path)

    def test_sdk_reject_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "sdk.sh"
            path.write_bytes(b"MARKER:\n" + archive_bytes([("../bad", b"bad", tarfile.REGTYPE)], "w:xz"))
            with self.assertRaises(ValueError):
                sdk.inspect(path)


if __name__ == "__main__":
    unittest.main()
