from pathlib import Path
import platform
import subprocess
import tempfile
import unittest


class BoRangeTests(unittest.TestCase):
    @unittest.skipUnless(platform.system() == "Linux", "compile/run PC fixture in WSL")
    def test_static_boundaries_overflow_and_runtime_rejection(self):
        source = Path(__file__).resolve().parents[1] / "vadd/test_bo_range.cpp"
        with tempfile.TemporaryDirectory() as tmp:
            binary = str(Path(tmp) / "bo-range")
            subprocess.run(["g++", "-std=c++17", "-Wall", "-Wextra", "-Werror",
                            str(source), "-o", binary], check=True, capture_output=True)
            subprocess.run([binary], check=True, capture_output=True)


if __name__ == "__main__":
    unittest.main()
