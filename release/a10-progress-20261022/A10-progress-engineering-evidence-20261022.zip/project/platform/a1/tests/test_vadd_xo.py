import importlib.util
from pathlib import Path
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / 'inspect_vadd_xo.py'
spec = importlib.util.spec_from_file_location('vadd_intake', SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class VaddXOTests(unittest.TestCase):
    def xml(self):
        ports = ''.join(f'<port name="{p}" mode="{m}" dataWidth="32"/>' for p, m in
                        [('M_AXI_GMEM0', 'master'), ('M_AXI_GMEM1', 'master'), ('S_AXI_CONTROL', 'slave')])
        args = ''.join(f'<arg id="{i}" name="{n}" addressQualifier="{q}" port="{p}" size="{s}" hostSize="{s}" offset="{o}"/>'
                       for i, (n, q, p, s, o) in enumerate([
                           ('a', 1, 'M_AXI_GMEM0', 8, 16), ('b', 1, 'M_AXI_GMEM1', 8, 28),
                           ('c', 1, 'M_AXI_GMEM0', 8, 40), ('n', 0, 'S_AXI_CONTROL', 4, 52)]))
        return f'<root><kernel name="krnl_vadd" hwControlProtocol="ap_ctrl_chain"><ports>{ports}</ports><args>{args}</args></kernel></root>'

    def check(self, xml, duplicate=False, nested=None):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'sample.xo'
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('ip/kernel.xml', xml)
                if duplicate:
                    z.writestr('other/kernel.xml', xml)
                if nested is not None:
                    z.writestr('ip_repo/ip/.Xil/.kernelxml/kernel.xml', nested)
            return module.inspect(path)

    def test_good_static_is_not_g1(self):
        self.assertEqual(self.check(self.xml())['g1'], 'NOT_PASSED')

    def test_wrong_offset(self):
        with self.assertRaises(ValueError):
            self.check(self.xml().replace('offset="52"', 'offset="56"'))

    def test_wrong_kernel(self):
        with self.assertRaises(ValueError):
            self.check(self.xml().replace('krnl_vadd', 'other_kernel'))

    def test_duplicate_xml(self):
        with self.assertRaises(ValueError):
            self.check(self.xml(), duplicate=True)

    def test_entity_rejected(self):
        with self.assertRaises(ValueError):
            self.check('<!DOCTYPE root>' + self.xml())

    def test_identical_private_copy(self):
        self.assertEqual(self.check(self.xml(), nested=self.xml())['status'], 'PASS')

    def test_conflicting_private_copy(self):
        with self.assertRaises(ValueError):
            self.check(self.xml(), nested=self.xml().replace('krnl_vadd', 'other'))


if __name__ == '__main__':
    unittest.main()
