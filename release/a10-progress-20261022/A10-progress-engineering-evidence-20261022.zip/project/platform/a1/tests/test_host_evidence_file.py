import concurrent.futures
from pathlib import Path
import platform
import subprocess
import tempfile
import unittest


@unittest.skipUnless(platform.system() == "Linux", "POSIX host logger; tested in WSL")
class HostEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory()
        cls.binary = Path(cls.build.name) / "test-evidence"
        source = Path(__file__).resolve().parents[1] / "vadd/test_evidence_file.cpp"
        subprocess.run(["g++", "-std=c++17", "-Wall", "-Wextra", "-Werror", str(source),
                        "-o", str(cls.binary)], check=True, capture_output=True, text=True)

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, path, *args):
        return subprocess.run([str(self.binary), str(path), *args], capture_output=True, text=True)

    def test_new_file_and_refuse_overwrite(self):
        path = self.root / "out.csv"
        self.assertEqual(self.invoke(path).returncode, 0)
        self.assertEqual(self.invoke(path).returncode, 1)
        self.assertEqual(path.read_text(), "PC_FIXTURE_ONLY\n")

    def test_symlink_refused(self):
        target = self.root / "target.csv"
        target.write_text("preserve")
        link = self.root / "link.csv"
        link.symlink_to(target)
        self.assertEqual(self.invoke(link).returncode, 1)
        self.assertEqual(target.read_text(), "preserve")

    def test_concurrent_creation_has_one_winner(self):
        path = self.root / "race.csv"
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
            results = list(executor.map(lambda _: self.invoke(path).returncode, range(6)))
        self.assertEqual(results.count(0), 1)
        self.assertEqual(results.count(1), 5)

    def test_write_after_close_fails(self):
        path = self.root / "closed.csv"
        self.assertEqual(self.invoke(path, "write-after-close").returncode, 1)
        self.assertEqual(path.read_text(), "PC_FIXTURE_ONLY\n")


if __name__ == "__main__":
    unittest.main()
