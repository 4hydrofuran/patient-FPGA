import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('overlay_audit', Path(__file__).resolve().parents[1] / 'audit_overlay_files.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class OverlayAuditTests(unittest.TestCase):
    def run_pair(self, reg='0 b0000000 0 10000', size_cells='2', mem=None):
        def get(blob, node, prop=None, kind='x', children=False):
            values = {'amba': '/axi', 'krnl_vadd_1': '/axi/krnl_vadd@b0000000',
                      'axi_intc_0': '/axi/interrupt-controller@80020000', 'fpga_full': '/fpga',
                      'reg': reg, '#address-cells': '2', '#size-cells': size_cells,
                      'interrupts': '1 2', 'xlnx,kind-of-intr': 'fffffffd',
                      'interrupts-extended': '115 1 4', 'firmware-name': 'a1-vadd.bit.bin'}
            return values[prop]
        with patch.object(audit, 'get', side_effect=get), patch.object(audit, 'sha', return_value='fixture'), \
             patch.object(audit, 'memory', side_effect=mem or [{}, {}]):
            return audit.inspect_pair(Path('base-fixture'), Path('merged-fixture'))

    def test_records_distinct_interrupt_flags_without_claiming_runtime_pass(self):
        result = self.run_pair()
        self.assertEqual(result['cu_interrupts'], '1 2')
        self.assertEqual(result['zocl_interrupts_extended'], '115 1 4')
        self.assertNotIn('board_pass', result)

    def test_changed_memory_or_bootargs_rejected(self):
        with self.assertRaisesRegex(ValueError, 'changed memory'):
            self.run_pair(mem=[{'bootargs': 'old'}, {'bootargs': 'new'}])

    def test_wrong_cu_address_rejected(self):
        with self.assertRaisesRegex(ValueError, 'CU mapping'):
            self.run_pair(reg='0 a0000000 0 10000')

    def test_incompatible_parent_cell_width_rejected(self):
        with self.assertRaisesRegex(ValueError, 'parent'):
            self.run_pair(size_cells='1')


if __name__ == '__main__':
    unittest.main()
