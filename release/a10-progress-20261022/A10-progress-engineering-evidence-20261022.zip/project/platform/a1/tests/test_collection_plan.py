from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from collect_board import PROC_FILES, collection_commands


class CollectionPlanTests(unittest.TestCase):
    def test_irq_snapshots_include_boot_identity(self):
        self.assertTrue({"/proc/interrupts", "/proc/modules", "/proc/sys/kernel/random/boot_id"}
                        .issubset(PROC_FILES))
        self.assertEqual(len(PROC_FILES), len(set(PROC_FILES)))

    def test_both_xrt_tools_get_separate_readonly_reports(self):
        out = Path("fixture-output")
        plan = dict(collection_commands(out))
        for name, tool, filename in [("xrt_smi_examine", "xrt-smi", "xrt_smi_all.json"),
                                     ("xrt_examine", "xbutil", "xbutil_all.json")]:
            self.assertEqual(plan[name], [tool, "examine", "--report", "all", "--format",
                                          "JSON", "--output", str(out / filename)])

    def test_package_queries_never_install(self):
        plan = dict(collection_commands(Path("fixture-output")))
        self.assertEqual(plan["packages_rpm"], ["rpm", "-qa"])
        self.assertEqual(plan["packages"], ["dpkg-query", "-W", "xrt*"])
        self.assertFalse({"sudo", "sh", "bash", "modprobe", "dd", "apt", "dnf"}
                         .intersection(argv[0] for argv in plan.values()))

    def test_no_duplicate_evidence_names(self):
        plan = collection_commands(Path("fixture-output"))
        self.assertEqual(len(plan), len(dict(plan)))
        report_outputs = [argv[-1] for _, argv in plan if "--output" in argv]
        self.assertEqual(len(report_outputs), len(set(report_outputs)))


if __name__ == "__main__":
    unittest.main()
