import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location(
    "bootfw_extract", Path(__file__).resolve().parents[1] / "extract_bootfw_dtb.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class BootFirmwareTests(unittest.TestCase):
    def test_empty_rejected_before_header_read(self):
        with self.assertRaisesRegex(ValueError, "Not the audited"):
            module.extract(b"")

    def test_unknown_firmware_rejected(self):
        with self.assertRaisesRegex(ValueError, "Not the audited"):
            module.extract(bytes(1939796))


if __name__ == "__main__":
    unittest.main()
