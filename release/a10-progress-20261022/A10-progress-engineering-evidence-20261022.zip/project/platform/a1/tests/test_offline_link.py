import copy
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from link_offline import validate_inputs, new_manifest, link_command, write_new
from link_hw import validated


class OfflineLinkTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.inputs = dict(scope="A_VADD_OFFLINE_HARDWARE_LINK", deployment_authorized=False,
                           platform="kv260_base", tools="2026.1", part="xck26-sfvc784-2LV-c",
                           linux_safe_budget_bytes=None, pl_safe_budget_bytes=None)
        for key, relative in [("xpfm", "kv260_base.xpfm"), ("xsa", "hw/hw.xsa"),
                              ("xo", "vadd.xo"), ("config", "link.cfg")]:
            path = root / relative
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(key.encode())
            self.inputs[key] = {"path": str(path), "sha256": hashlib.sha256(key.encode()).hexdigest()}

    def test_validated_files_only(self):
        self.assertEqual(validate_inputs(self.inputs), self.inputs)

    def test_changed_input_rejected(self):
        Path(self.inputs["xo"]["path"]).write_bytes(b"changed")
        with self.assertRaises(ValueError):
            validate_inputs(self.inputs)

    def test_deployment_or_budget_assertion_rejected(self):
        for key, value in [("deployment_authorized", True), ("linux_safe_budget_bytes", 2**32),
                           ("platform", "versal"), ("tools", "2026.1.1")]:
            with self.subTest(key=key):
                sample = copy.deepcopy(self.inputs)
                sample[key] = value
                with self.assertRaises(ValueError):
                    validate_inputs(sample)

    def test_offline_artifact_never_passes_matched_gate(self):
        manifest = new_manifest(self.inputs, Path("a.xclbin"), "0" * 64)
        self.assertFalse(manifest["deployment_authorized"])
        self.assertEqual(manifest["g1"], "NOT_PASSED")
        with self.assertRaises(ValueError):
            validated(manifest)

    def test_only_hardware_link_command(self):
        command = link_command(self.inputs, Path("vadd.xclbin"))
        self.assertIn("--link", command)
        self.assertEqual(command[command.index("--target") + 1], "hw")
        for forbidden in ("--package", "hw_emu", "bootgen", "ssh"):
            self.assertNotIn(forbidden, command)

    def test_no_manifest_overwrite(self):
        path = Path(self.temp.name) / "manifest.json"
        write_new(path, {"a": 1})
        with self.assertRaises(FileExistsError):
            write_new(path, {"a": 2})


if __name__ == "__main__":
    unittest.main()
