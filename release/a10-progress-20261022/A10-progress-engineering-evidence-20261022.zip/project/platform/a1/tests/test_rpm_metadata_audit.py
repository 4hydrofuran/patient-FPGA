from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from audit_rpm_primary import inspect, select_packages


class RPMMetadataTests(unittest.TestCase):
    def sample(self, href="cmake.rpm"):
        return ('''<metadata xmlns="http://linux.duke.edu/metadata/common"
                xmlns:rpm="http://linux.duke.edu/metadata/rpm"><package>
                <name>cmake</name><arch>cortexa72_cortexa53</arch>
                <version epoch="0" ver="3.28.3" rel="r0.0"/>
                <checksum type="sha256">abc</checksum><size package="1"/>
                <location href="''' + href + '''"/><format><rpm:requires>
                <rpm:entry name="libc6"/></rpm:requires></format>
                </package></metadata>''').encode()

    def test_select_preserves_requirements(self):
        rows = select_packages(self.sample())
        self.assertEqual(rows[0]["name"], "cmake")
        self.assertEqual(rows[0]["requires"], [{"name": "libc6"}])
        self.assertTrue(rows[0]["url"].startswith("https://petalinux.xilinx.com/"))

    def test_external_path_or_entities_rejected(self):
        for href in ("../other.rpm", "/other.rpm", "https://other.test/p.rpm"):
            with self.subTest(href=href), self.assertRaises(ValueError):
                select_packages(self.sample(href))
        with self.assertRaises(ValueError):
            select_packages(b'<!DOCTYPE metadata []>' + self.sample())

    def test_bad_input_rejected_before_native_decompress(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bad.zst"
            path.write_bytes(b"bad")
            with self.assertRaises(ValueError):
                inspect(path)


if __name__ == "__main__":
    unittest.main()
