import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import build_preboard_kit as kit


class KitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        (self.root / 'input').write_bytes(b'fixture')
        self.rows = [dict(path='input', sha256=kit.digest(self.root / 'input'), bytes=7, copied=True)]
        self.out = self.root / 'kit'

    def test_roundtrip_never_claims_g1(self):
        kit.build(self.root, self.out, self.rows)
        m = kit.verify(self.out)
        self.assertFalse(m['deployment_authorized'])
        self.assertEqual(m['g1'], 'NOT_PASSED')

    def test_changed_source_blocks_and_preserves_incomplete(self):
        (self.root / 'input').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'source changed'):
            kit.build(self.root, self.out, self.rows)
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            kit.verify(self.out)

    def test_existing_directory_refused(self):
        self.out.mkdir()
        with self.assertRaises(FileExistsError):
            kit.build(self.root, self.out, self.rows)

    def test_path_escape_refused(self):
        for name in ['../input', '/input', 'C:/input', 'a/../../input', 'a\\input']:
            with self.subTest(name=name), self.assertRaises(ValueError):
                kit.safe_file(self.root, name)

    def test_symlink_refused(self):
        (self.root / 'link').symlink_to(self.root / 'input')
        with self.assertRaisesRegex(ValueError, 'symlink'):
            kit.safe_file(self.root, 'link')

    def test_modified_payload_refused(self):
        kit.build(self.root, self.out, self.rows)
        (self.out / 'input').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'kit file changed'):
            kit.verify(self.out)

    def test_false_pass_refused(self):
        kit.build(self.root, self.out, self.rows)
        p = self.out / 'manifest.json'
        m = json.loads(p.read_text())
        m['deployment_authorized'] = True
        p.write_text(json.dumps(m))
        with self.assertRaisesRegex(ValueError, 'approval'):
            kit.verify(self.out)

    def test_external_files_not_copied(self):
        self.rows[0]['copied'] = False
        kit.build(self.root, self.out, self.rows)
        self.assertFalse((self.out / 'input').exists())
        self.assertEqual(len(kit.verify(self.out)['artifacts']), 1)


if __name__ == '__main__':
    unittest.main()
