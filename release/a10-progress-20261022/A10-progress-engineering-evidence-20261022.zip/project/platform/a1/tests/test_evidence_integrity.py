import concurrent.futures
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from record import run
from lease import write_new_provenance


class EvidenceIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_existing_log_prevents_command(self):
        log = self.root / "prior.json"
        log.write_text("original")
        with patch("record.subprocess.run") as launch:
            with self.assertRaises(FileExistsError):
                run(["must-not-execute"], log)
            launch.assert_not_called()
        self.assertEqual(log.read_text(), "original")

    def test_dangling_link_prevents_command(self):
        log = self.root / "link.json"
        try:
            log.symlink_to(self.root / "absent.json")
        except OSError:
            self.skipTest("symlinks unavailable; Linux regression exercises this")
        with patch("record.subprocess.run") as launch:
            with self.assertRaises(FileExistsError):
                run(["must-not-execute"], log)
            launch.assert_not_called()
        self.assertFalse((self.root / "absent.json").exists())

    def test_concurrent_reservation_runs_once(self):
        def attempt(_):
            try:
                return run([sys.executable, "-c", "print('PC_FIXTURE')"], self.root / "shared.json")
            except FileExistsError:
                return 99
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
            outcomes = list(executor.map(attempt, range(6)))
        self.assertEqual(outcomes.count(0), 1)
        self.assertEqual(outcomes.count(99), 5)
        self.assertIn("PC_FIXTURE", json.loads((self.root / "shared.json").read_text())["stdout"])

    def test_interruption_leaves_non_success_reservation(self):
        log = self.root / "interrupted.json"
        with patch("record.subprocess.run", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                run(["fixture"], log)
        record = json.loads(log.read_text())
        self.assertEqual(record["status"], "RESERVED_NOT_COMPLETED")
        self.assertIsNone(record["exit_code"])

    def test_missing_executable_recorded(self):
        log = self.root / "missing.json"
        self.assertEqual(run([str(self.root / "not-an-executable")], log), 127)
        self.assertIn("error", json.loads(log.read_text()))

    def test_provenance_preserved_on_retry(self):
        log = self.root / "command.json"
        write_new_provenance(log, {"owner": "A"})
        with self.assertRaises(FileExistsError):
            write_new_provenance(log, {"owner": "B"})
        self.assertEqual(json.loads(Path(str(log) + ".provenance.json").read_text()), {"owner": "A"})

    def test_prior_command_blocks_new_provenance(self):
        log = self.root / "command.json"
        log.write_text("old")
        with self.assertRaises(FileExistsError):
            write_new_provenance(log, {"owner": "A"})
        self.assertFalse(Path(str(log) + ".provenance.json").exists())


if __name__ == "__main__":
    unittest.main()
