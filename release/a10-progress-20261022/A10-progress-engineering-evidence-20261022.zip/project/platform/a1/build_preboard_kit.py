"""Curated, hash-checked A1 materials. Never boots, installs or approves G1."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil

ROOT = Path(__file__).resolve().parents[2]


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe_file(root, name):
    p = PurePosixPath(name)
    if p.is_absolute() or not p.parts or any(x in ('..', '.') for x in name.split('/')) or '\\' in name or ':' in name:
        raise ValueError('unsafe relative file: ' + name)
    target = root.joinpath(*p.parts)
    if any(q.is_symlink() for q in [target, *target.parents]):
        raise ValueError('symlink forbidden: ' + name)
    target.resolve().relative_to(root.resolve())
    if not target.is_file():
        raise FileNotFoundError(target)
    return target


def read_json(root, name):
    return json.loads(safe_file(root, name).read_text(encoding='utf-8'))


def inventory(root):
    rows = {}

    def add(name, expected=None, copy=True):
        src = safe_file(root, name)
        actual = digest(src)
        if expected is not None and actual != expected:
            raise ValueError('pinned hash mismatch: ' + name)
        row = dict(path=name, sha256=actual, bytes=src.stat().st_size, copied=copy)
        if name in rows and rows[name] != row:
            raise ValueError('conflicting inventory: ' + name)
        rows[name] = row

    host = read_json(root, 'platform/a1/evidence/common-sdk-bo-guard-host-manifest.json')
    status = read_json(root, 'platform/a1/g1_status.json')
    overlay = read_json(root, 'platform/a1/overlay_candidate.json')
    if not (host['paired_offline_xclbin_sha256'] == status['xclbin_sha256'] == overlay['paired_xclbin_sha256']):
        raise ValueError('host/overlay/xclbin pairing differs')
    add(host['repository_copy'], host['sha256'])
    for filename, key in [('host.cpp', 'source_host_sha256'), ('bo_range.hpp', 'source_bo_range_sha256'),
                          ('cases.hpp', 'source_cases_sha256'), ('evidence_file.hpp', 'source_evidence_file_sha256')]:
        add('platform/a1/vadd/' + filename, host[key])
    add('platform/build/offline-link-kv260-vadd-20260928/vadd.xclbin', status['xclbin_sha256'])
    add('platform/build/a1-vadd-20260927/krnl_vadd.xo', status['xo_sha256'])
    for name, sha in overlay['files'].items():
        add(overlay['artifact_directory'] + '/' + name, sha)
    add('platform/local/a1/Qwen2.5-0.5B-Instruct-f16.gguf', status['gguf_sha256'])
    add('platform/local/a1/llama.tar.gz', '06b6a3a1c2d12becc05d02c701274ab1f6d033399b4a20a166b919289e19233c')
    pins = read_json(root, 'platform/a1/pins.json')
    add('platform/local/a1/model/model.safetensors', pins['model']['weight_sha256'], copy=False)
    common = read_json(root, 'platform/a1/common_image_candidate.json')
    kria = read_json(root, 'platform/a1/kria_2026_1_image_candidate.json')
    add(common['filename'], common['sha256'], copy=False)
    add(kria['filename'], kria['sha256'], copy=False)
    add(Path(kria['offline_bootfw']['path']).name, kria['offline_bootfw']['sha256'], copy=False)
    cache = read_json(root, 'platform/a1/native_build_cache.json')
    for pkg in cache['packages']:
        add(cache['directory'] + '/' + pkg['filename'], pkg['sha256'])
    for folder in ['bench/runtime/s0/fixture', 'bench/runtime/s0/metadata']:
        for p in sorted((root / folder).rglob('*')):
            if p.is_file():
                add(p.relative_to(root).as_posix())
    for name in ['bench/runtime/s0/CMakeLists.txt', 'bench/runtime/s0/s0.cpp',
                 'platform/board_registry.json', 'platform/toolchain.lock.json',
                 'platform/a1/lease.py', 'platform/a1/record.py', 'platform/a1/collect_board.py',
                 'platform/a1/build_preboard_kit.py', 'platform/a1/README.md',
                 'platform/a1/pins.json', 'platform/a1/g1_status.json',
                 'platform/a1/memory_review.template.json', 'platform/a1/matched_bundle.template.json',
                 'platform/a1/common_image_candidate.json', 'platform/a1/kria_2026_1_image_candidate.json',
                 'platform/a1/overlay_candidate.json', 'platform/a1/native_build_cache.json',
                 'platform/a1/evidence/common-sdk-bo-guard-host-manifest.json',
                 'platform/a1/evidence/preboard-kit-regression-20260928.json',
                 'platform/a1/evidence/native-db-transaction-test-20260928.json',
                 'platform/a1/preboard_readiness.json', 'docs/handoffs/A1_PREBOARD_20260928.md',
                 'docs/handoffs/A1_to_B.md', 'docs/handoffs/A1_to_C.md']:
        add(name)
    return list(rows.values())


def build(root, out, rows):
    if out.exists() or out.is_symlink():
        raise FileExistsError('output already exists; never overwrite a kit')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir()
    marker = out / 'INCOMPLETE.json'
    marker.write_text('{"status":"INCOMPLETE_NOT_DEPLOYABLE"}\n', encoding='utf-8')
    for row in rows:
        source = safe_file(root, row['path'])
        if digest(source) != row['sha256']:
            raise ValueError('source changed: ' + row['path'])
        if row['copied']:
            dst = out / row['path']
            dst.parent.mkdir(parents=True, exist_ok=True)
            with source.open('rb') as incoming, dst.open('xb') as outgoing:
                shutil.copyfileobj(incoming, outgoing, 4 * 1024 * 1024)
            shutil.copymode(source, dst)
            if digest(dst) != row['sha256']:
                raise ValueError('copy mismatch: ' + row['path'])
    manifest = dict(status='OFFLINE_MATERIALS_ONLY_NOT_DEPLOYABLE', deployment_authorized=False,
                    g1='NOT_PASSED', board_test='NOT_TESTED', linux_safe_budget_bytes=None,
                    pl_safe_budget_bytes=None, artifacts=rows,
                    external_files='copied=false remain in original repository; not present in this kit')
    with (out / 'manifest.json').open('x', encoding='utf-8') as stream:
        json.dump(manifest, stream, indent=2, ensure_ascii=False)
        stream.write('\n')
    # Only our own fixed marker, no recursive cleanup. Failed copies stay recoverable.
    marker.unlink()
    return manifest


def verify(out):
    if (out / 'INCOMPLETE.json').exists():
        raise ValueError('incomplete kit')
    m = read_json(out, 'manifest.json')
    if (m['status'] != 'OFFLINE_MATERIALS_ONLY_NOT_DEPLOYABLE' or m['deployment_authorized'] is not False
            or m['g1'] != 'NOT_PASSED' or m['board_test'] != 'NOT_TESTED'
            or m['linux_safe_budget_bytes'] is not None or m['pl_safe_budget_bytes'] is not None):
        raise ValueError('kit must not claim board approval')
    seen = set()
    for row in m['artifacts']:
        if row['path'] in seen:
            raise ValueError('duplicate manifest path')
        seen.add(row['path'])
        if row['copied']:
            p = safe_file(out, row['path'])
            if p.stat().st_size != row['bytes'] or digest(p) != row['sha256']:
                raise ValueError('kit file changed: ' + row['path'])
    return m


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--verify', action='store_true')
    a = ap.parse_args()
    result = verify(a.out) if a.verify else build(ROOT, a.out, inventory(ROOT))
    print(json.dumps(dict(status=result['status'], files=len(result['artifacts']),
                         copied=sum(r['copied'] for r in result['artifacts']),
                         deployment_authorized=False, g1='NOT_PASSED')))
