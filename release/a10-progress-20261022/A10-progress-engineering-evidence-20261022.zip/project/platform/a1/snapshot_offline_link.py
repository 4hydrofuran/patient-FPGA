"""Exclusive, hash-checked copies of offline link artifacts; never grants deployment."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--binary-out", type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    args.binary_out.mkdir(parents=True, exist_ok=False)
    mapping = {"vadd.xclbin": args.binary_out / "vadd.xclbin",
               "NOT_DEPLOYABLE.json": args.binary_out / "NOT_DEPLOYABLE.json",
               "_x/link/int/address_map.xml": args.out / "address_map.xml"}
    for name in ("route_status.rpt", "drc.rpt", "methodology.rpt"):
        mapping["routed-audit/" + name] = args.out / name
    for name in ("impl_1_MPSoC_ext_platform_wrapper_timing_summary_routed.rpt",
                 "impl_1_full_util_routed.rpt", "impl_1_kernel_util_routed.rpt"):
        mapping["_x/reports/link/imp/" + name] = args.out / name
    manifest = {"status": "OFFLINE_BUILD_ONLY_NOT_DEPLOYABLE", "g1": "NOT_PASSED",
                "deployment_authorized": False, "files": []}
    for relative, target in mapping.items():
        source = args.work / relative
        expected = digest(source)
        with source.open("rb") as src, target.open("xb") as dst:
            shutil.copyfileobj(src, dst)
        if digest(target) != expected or digest(source) != expected:
            raise RuntimeError("copy mismatch or changed source: " + str(source))
        manifest["files"].append({"source": str(source), "copy": str(target),
                                  "sha256": expected, "bytes": target.stat().st_size})
    with (args.out / "manifest.json").open("x", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
