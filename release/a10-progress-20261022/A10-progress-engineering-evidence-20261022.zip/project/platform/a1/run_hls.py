"""Render absolute source paths (HLS changes cwd); keep every attempt separately."""
import argparse
from pathlib import Path
import shutil
from record import run
ROOT=Path(__file__).resolve().parents[2]
ap=argparse.ArgumentParser();ap.add_argument("--mode",choices=["csim","synth","package","cosim"],required=True);ap.add_argument("--label",required=True)
ap.add_argument("--work-root",type=Path,help="Explicit component parent, preferably Linux native storage; reuse only within the same build sequence")
a=ap.parse_args()
if not a.label.replace("-","").replace("_","").isalnum():raise ValueError("unsafe label")
work=(a.work_root or ROOT/"platform/build/a1-hls-fixed").resolve();work.mkdir(parents=True,exist_ok=True)
cfg=work/"hls.cfg"
cfg.write_text((ROOT/"platform/a1/vadd/hls_config.cfg").read_text().replace("@ROOT@",ROOT.as_posix()),encoding="utf-8",newline="\n")
suffix=".bat" if __import__("os").name=="nt" else ""
tool=shutil.which(("v++" if a.mode=="synth" else "vitis-run")+suffix)
if not tool and suffix:tool="D:/AMDDesignTools/2026.1/Vitis/bin/"+("v++" if a.mode=="synth" else "vitis-run")+suffix
if not tool:raise RuntimeError("source the approved 2026.1 tool environment")
args=[tool]+(["-c","--mode","hls"] if a.mode=="synth" else ["--mode","hls","--"+a.mode])
args += ["--config",str(cfg),"--work_dir",str(work/"component")]
raise SystemExit(run(args,ROOT/("platform/a1/evidence/hls_"+a.label+".json"),cwd=work))
