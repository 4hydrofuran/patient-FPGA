"""Preserve actual smoke-build reports and hashes, without approving G1."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--component', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--xo-copy', type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = {'verification_level': 'OFFLINE_HLS_NOT_BOARD', 'g1': 'NOT_PASSED', 'files': []}
    files = [args.component / p for p in (
        'krnl_vadd.xo', 'hls/kernel.xml', 'hls/syn/report/krnl_vadd_csynth.rpt',
        'hls/syn/report/krnl_vadd_csynth.xml', 'hls/sim/report/krnl_vadd_cosim.rpt')]
    files.append(args.component.parent / 'hls.cfg')
    files += [ROOT / 'platform/a1/vadd' / p for p in
              ('krnl_vadd.cpp', 'test_cpu.cpp', 'cases.hpp', 'hls_config.cfg')]
    args.xo_copy.parent.mkdir(parents=True, exist_ok=True)
    for source in files:
        target = args.xo_copy if source.suffix == '.xo' else args.out / source.name
        # Exclusive output avoids clobbering earlier evidence or build products.
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        if digest != hashlib.sha256(source.read_bytes()).hexdigest():
            raise RuntimeError('source changed while copying: ' + str(source))
        manifest['files'].append({'source': str(source), 'copy': str(target), 'sha256': digest,
                                  'bytes': target.stat().st_size})
    with (args.out / 'manifest.json').open('x', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2)
        f.write('\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
