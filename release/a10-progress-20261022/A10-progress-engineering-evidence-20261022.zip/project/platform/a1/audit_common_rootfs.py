"""Read rootfs metadata with debugfs; do not mount or execute guest programs."""
import argparse
from pathlib import Path
from record import run


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image-dir", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    root = a.image_dir / "rootfs.ext4"
    if not root.is_file():
        raise ValueError("expected extracted regular rootfs file")
    queries = {
        "os": "cat /usr/lib/os-release",
        "etc_os": "cat /etc/os-release",
        "modules": "ls -p /lib/modules",
        "usr_modules": "ls -p /usr/lib/modules",
        "opt": "ls -p /opt",
        "usr_lib": "ls -p /usr/lib",
        "xrt_opt": "ls -p /opt/xilinx/xrt",
        "xrt_headers": "stat /usr/include/xrt/xrt_device.h",
        "cmake": "stat /usr/bin/cmake",
        "gxx": "stat /usr/bin/g++",
        "boot": "ls -p /boot",
        "dnf_repos": "ls -p /etc/yum.repos.d",
    }
    for name, query in queries.items():
        run(["debugfs", "-R", query, str(root)], a.out / (name + ".json"))
    print("Raw read-only queries captured; debugfs zero exit is NOT proof of path presence. Review stderr.")


if __name__ == "__main__":
    main()
