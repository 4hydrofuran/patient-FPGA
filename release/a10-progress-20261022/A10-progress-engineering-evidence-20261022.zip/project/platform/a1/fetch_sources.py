"""Acquire immutable public inputs; no installers, model execution or board access."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile
import urllib.request
from file_hash import sha256_file

ROOT = Path(__file__).resolve().parents[2]
PINS = json.loads((ROOT / "platform/a1/pins.json").read_text(encoding="utf-8"))
CACHE = ROOT / "platform/local/a1"
REPORT = ROOT / "platform/a1/evidence/acquisition.json"

def sha(path):
    return sha256_file(path)

def fetch(url, path, records, expected=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and expected and sha(path) != expected:
        bad_hash = sha(path)
        records[str(path.relative_to(ROOT)).replace("\\", "/") + ".REJECTED"] = {
            "url": url, "sha256": bad_hash, "bytes":path.stat().st_size,
            "status":"HASH_MISMATCH_NOT_USABLE"}
        path.rename(path.with_name(path.name + ".rejected-" + bad_hash[:12]))
    if not path.exists():
        part = path.with_suffix(path.suffix + ".part")
        req = urllib.request.Request(url, headers={"User-Agent":"KV260-A1-source-audit"})
        with urllib.request.urlopen(req, timeout=60) as src, part.open("wb") as dest:
            while chunk := src.read(1024 * 1024):
                dest.write(chunk)
        if expected and sha(part) != expected:
            raise ValueError(f"SHA256 mismatch in partial download: {part}; not promoted")
        part.replace(path)
    digest = sha(path)
    if expected and digest != expected:
        raise ValueError(f"SHA256 mismatch: {path}")
    records[str(path.relative_to(ROOT)).replace("\\", "/")] = {
        "url":url, "sha256":digest, "bytes":path.stat().st_size,
        "upstream_hash_verified": bool(expected)}
    print(f"verified {path.name}: {digest}", flush=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", action="store_true")
    args = ap.parse_args()
    records = json.loads(REPORT.read_text(encoding="utf-8")) if REPORT.exists() else {}
    try:
        commit = PINS["llama_cpp"]["commit"]
        archive = CACHE / "llama.tar.gz"
        fetch(f"https://codeload.github.com/ggml-org/llama.cpp/tar.gz/{commit}", archive, records)
        source = CACHE / f"llama.cpp-{commit}"
        if not source.exists():
            with tarfile.open(archive) as tar:
                # Reject links and paths outside the immutable archive root.
                for item in tar.getmembers():
                    if item.issym() or item.islnk() or not (item.name.startswith(source.name + "/") or (item.name == source.name and item.isdir())):
                        raise ValueError("Unsafe archive entry")
                tar.extractall(CACHE, filter="data")
        rev = PINS["model"]["revision"]
        for name in ["LICENSE", "README.md", "config.json", "generation_config.json",
                     "tokenizer_config.json", "tokenizer.json", "vocab.json", "merges.txt"]:
            fetch(f"https://huggingface.co/{PINS['model']['repository']}/resolve/{rev}/{name}",
                  CACHE / "model" / name, records)
        if args.weights:
            fetch(f"https://huggingface.co/{PINS['model']['repository']}/resolve/{rev}/model.safetensors",
                  CACHE / "model/model.safetensors", records, PINS["model"]["weight_sha256"])
        commit = PINS["platform_source"]["commit"]
        for name in ["README.md", "Xilinx_Official_Platforms/kv260_base/README.md",
                     "Xilinx_Official_Platforms/kv260_base/Makefile",
                     "Xilinx_Official_Platforms/kv260_base/platform.mk",
                     "Xilinx_Official_Platforms/kv260_base/hw/xsa_scripts/project.tcl",
                     "Xilinx_Official_Platforms/kv260_base/hw/xsa_scripts/bd.tcl",
                     "Xilinx_Official_Platforms/kv260_base/hw/xsa_scripts/reference_bd.tcl",
                     "Xilinx_Official_Platforms/kv260_base/platform/generate_platform.py",
                     "Xilinx_Official_Platforms/kv260_base/user_dts/system-conf.dtsi",
                     "Xilinx_Official_Platforms/kv260_base/user_dts/system-user.dtsi"]:
            fetch(f"https://raw.githubusercontent.com/Xilinx/Vitis_Embedded_Platform_Source/{commit}/{name}",
                  CACHE / "platform_source" / name, records)
        commit = PINS["xrt_source"]["commit"]
        for name in ["xrt_bo.h", "xrt_device.h", "xrt_kernel.h"]:
            fetch(f"https://raw.githubusercontent.com/Xilinx/XRT/{commit}/src/runtime_src/core/include/xrt/{name}",
                  CACHE / "xrt_headers" / name, records)
    finally:
        REPORT.parent.mkdir(parents=True, exist_ok=True)
        REPORT.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8", newline="\n")

if __name__ == "__main__":
    main()
