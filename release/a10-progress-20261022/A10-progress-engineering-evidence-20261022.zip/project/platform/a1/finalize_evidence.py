"""Check recorded outcomes and hash the A1 handoff. Does not promote G1."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
evidence=ROOT/"platform/a1/evidence"
expected={"vadd_pc_compile":0,"vadd_pc_run":0,"a1_unit_tests_final":0,"a0_regression":0,
          "hls_corrected_paths":1,"device_catalog":0,"s0_pc_configure":0,"s0_pc_build":1,
          "fetch_retry":1,"fetch_weights_retry":1,"fetch_platform":0,"prompt_prepare":0,
          "link_gate_negative":1,"source_audit":0,"metadata_staging":0}
outcomes={}
for name,code in expected.items():
    record=json.loads((evidence/(name+".json")).read_text(encoding="utf-8"))
    if record["exit_code"]!=code:raise ValueError("Unexpected evidence: "+name)
    outcomes[name]={"actual_exit_code":code,"classification":"SUCCESS_LOCAL_ONLY" if code==0 else "EXPECTED_GATE_REJECTION" if name=="link_gate_negative" else "UNRESOLVED_FAILURE"}
status=json.loads((ROOT/"platform/a1/g1_status.json").read_text())
if status["g1"]!="NOT_PASSED" or status["xclbin_sha256"] is not None:raise ValueError("No board evidence permits G1")
tests=json.loads((evidence/"a1_unit_tests_final.json").read_text())
if "Ran 12 tests" not in tests["stderr"]:raise ValueError("A1 count mismatch")
tests=json.loads((evidence/"a0_regression.json").read_text())
if "Ran 17 tests" not in tests["stderr"]:raise ValueError("A0 count mismatch")
paths=[]
for directory in ("platform/a1","bench/runtime/s0","third_party/llama.cpp"):
    paths += [p for p in (ROOT/directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.name!="evidence_index.json"]
paths += [ROOT/p for p in ("platform/toolchain.lock.json","platform/board_registry.json","docs/status/A.md",
                            "docs/handoffs/A1.md","docs/handoffs/A1_to_B.md","docs/handoffs/A1_to_C.md")]
index={str(p.relative_to(ROOT)).replace("\\","/"):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
report={"g1":"NOT_PASSED","outcomes":outcomes,"sha256":index,
        "note":"Expected recorded failures remain failures; hash integrity does not approve hardware or platform compatibility."}
(evidence/"evidence_index.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"files_hashed":len(index),"evidence_consistent":True,"g1":"NOT_PASSED"}))
