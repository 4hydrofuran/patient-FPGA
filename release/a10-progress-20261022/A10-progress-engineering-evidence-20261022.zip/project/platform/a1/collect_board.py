"""Read-only evidence collection. No sudo, downloads, reset, overlay or flash writes."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
from lease import check_board
from record import run

PROC_FILES = (
    "/proc/meminfo", "/proc/cmdline", "/proc/iomem", "/proc/version", "/proc/cpuinfo",
    "/proc/sys/kernel/random/boot_id", "/etc/os-release", "/proc/mounts", "/proc/mtd",
    "/proc/interrupts", "/proc/modules",
)


def collection_commands(out):
    """Read-only diagnostics; each unavailable tool retains its own failure log."""
    return [
        ("uname", ["uname", "-a"]),
        ("devices", ["lsblk", "-b", "-o", "NAME,PATH,SIZE,MODEL,SERIAL,TYPE,MOUNTPOINTS"]),
        ("xrt_smi_version", ["xrt-smi", "--version"]),
        ("xrt_smi_help", ["xrt-smi", "examine", "--help"]),
        ("xrt_smi_examine", ["xrt-smi", "examine", "--report", "all", "--format", "JSON",
                             "--output", str(out / "xrt_smi_all.json")]),
        ("xbutil_version", ["xbutil", "--version"]),
        ("xbutil_help", ["xbutil", "examine", "--help"]),
        ("xrt_examine", ["xbutil", "examine", "--report", "all", "--format", "JSON",
                         "--output", str(out / "xbutil_all.json")]),
        ("zocl", ["modinfo", "zocl"]), ("dmesg", ["dmesg"]), ("cpu", ["lscpu"]),
        ("packages", ["dpkg-query", "-W", "xrt*"]),
        ("packages_rpm", ["rpm", "-qa"]),
        ("boot_files", ["find", "/boot", "-maxdepth", "2", "-type", "f"]),
        ("processes", ["ps", "-eo", "pid,comm,args"]),
    ]


def decode_reg(data,address_cells,size_cells):
    if address_cells not in (1,2) or size_cells not in (1,2):raise ValueError("unsupported DT cells")
    stride=4*(address_cells+size_cells)
    if len(data)%stride:raise ValueError("truncated DT reg")
    result=[]
    for i in range(0,len(data),stride):
        address=int.from_bytes(data[i:i+4*address_cells],"big")
        size=int.from_bytes(data[i+4*address_cells:i+stride],"big")
        result.append({"base":address,"size_bytes":size,"end_exclusive":address+size})
    return result

def cells(node,name,default):
    p=node/name
    return struct.unpack(">I",p.read_bytes())[0] if p.exists() else default

def collect(out):
    out.mkdir(parents=True,exist_ok=False)
    report={"status":"COLLECTED_NOT_MEMORY_APPROVED","linux_allocatable_bytes":None,
            "pl_allocatable_bytes":None,"max_verified_bo_bytes":None,"errors":[]}
    for file in PROC_FILES:
        try:
            text=Path(file).read_text();report[file]=text
        except OSError as e:report["errors"].append({"file":file,"error":str(e)})
    dt=Path("/sys/firmware/devicetree/base")
    report["device_tree"]={};report["memory_reg"]=[];report["reserved_reg"]=[]
    for name in ["model","compatible","serial-number"]:
        try: report["device_tree"][name]= (dt/name).read_bytes().decode(errors="replace").replace("\x00","|")
        except OSError as e:report["errors"].append({"file":str(dt/name),"error":str(e)})
    for node in dt.iterdir():
        if node.name.startswith("memory@") or node.name=="memory":
            try:report["memory_reg"]+=decode_reg((node/"reg").read_bytes(),cells(dt,"#address-cells",2),cells(dt,"#size-cells",1))
            except (OSError,ValueError) as e:report["errors"].append({"node":str(node),"error":str(e)})
    reserved=dt/"reserved-memory"
    if reserved.exists():
        for node in reserved.iterdir():
            if node.is_dir():
                try:
                    raw={p.name:p.read_bytes().hex() for p in node.iterdir() if p.is_file()}
                    decoded=decode_reg(bytes.fromhex(raw["reg"]),cells(reserved,"#address-cells",2),cells(reserved,"#size-cells",2)) if "reg" in raw else None
                    report["reserved_reg"].append({"node":node.name,"raw_hex":raw,"decoded":decoded})
                except (OSError,ValueError) as e:report["errors"].append({"node":str(node),"error":str(e)})
    report["machine_id_sha256"]=hashlib.sha256(Path("/etc/machine-id").read_bytes()).hexdigest()
    for name,argv in collection_commands(out):
        run(argv,out/(name+".json"))
    # Raw topology per render node: parser depends on the exact installed XRT ABI.
    report["xrt_topology_raw"]={}
    for p in Path("/sys/class/drm").glob("renderD*/device/mem_topology"):
        try:report["xrt_topology_raw"][str(p)]=p.read_bytes().hex()
        except OSError as e:report["errors"].append({"file":str(p),"error":str(e)})
    (out/"board.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
    print("Collected; allocation budgets remain null pending DT/XRT/BO reconciliation")

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--registry",required=True);ap.add_argument("--out",required=True);a=ap.parse_args()
    check_board(json.loads(Path(a.registry).read_text()))
    collect(Path(a.out).resolve())
