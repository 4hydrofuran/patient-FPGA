#pragma once
// Linux host only. Reserve evidence before any XRT load/BO/device operation.
#include <cerrno>
#include <fcntl.h>
#include <stdexcept>
#include <string>
#include <system_error>
#include <unistd.h>

class ExclusiveEvidenceFile {
    int fd_ = -1;
public:
    explicit ExclusiveEvidenceFile(const char* path) {
        fd_ = ::open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
        if (fd_ < 0) throw std::system_error(errno, std::generic_category(), "reserve new evidence file");
    }
    ExclusiveEvidenceFile(const ExclusiveEvidenceFile&) = delete;
    ExclusiveEvidenceFile& operator=(const ExclusiveEvidenceFile&) = delete;
    ~ExclusiveEvidenceFile() { if (fd_ >= 0) ::close(fd_); }

    void append(const std::string& text) {
        if (fd_ < 0) throw std::runtime_error("evidence file already closed");
        size_t pos = 0;
        while (pos < text.size()) {
            const auto n = ::write(fd_, text.data() + pos, text.size() - pos);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) throw std::system_error(n < 0 ? errno : EIO, std::generic_category(), "write evidence");
            pos += size_t(n);
        }
        // Outside measured XRT intervals; a failed flush prevents a PASS exit.
        if (::fsync(fd_) != 0) throw std::system_error(errno, std::generic_category(), "flush evidence");
    }

    void finish() {
        if (fd_ < 0) throw std::runtime_error("evidence file already closed");
        const int saved = fd_;
        fd_ = -1;
        if (::close(saved) != 0) throw std::system_error(errno, std::generic_category(), "close evidence");
    }
};
