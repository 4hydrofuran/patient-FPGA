// A-owned platform smoke test, not B's W4A8 kernel. uint32 addition modulo 2^32.
#include <cstdint>
extern "C" void krnl_vadd(const uint32_t *a, const uint32_t *b, uint32_t *c, int n) {
#pragma HLS INTERFACE m_axi port=a bundle=gmem0 depth=4096
#pragma HLS INTERFACE m_axi port=b bundle=gmem1 depth=4096
#pragma HLS INTERFACE m_axi port=c bundle=gmem0 depth=4112
#pragma HLS INTERFACE s_axilite port=a bundle=control
#pragma HLS INTERFACE s_axilite port=b bundle=control
#pragma HLS INTERFACE s_axilite port=c bundle=control
#pragma HLS INTERFACE s_axilite port=n bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control
    for (int i=0; i<n; ++i) {
#pragma HLS PIPELINE II=1
        c[i] = a[i] + b[i];
    }
}
