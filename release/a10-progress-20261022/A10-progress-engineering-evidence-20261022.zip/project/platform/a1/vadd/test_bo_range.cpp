#include "bo_range.hpp"
#include <limits>
static_assert(a1_bo_in_window(0, 1));
static_assert(a1_bo_in_window(0x7fffffff, 1));
static_assert(a1_bo_in_window(0x7ffff000, 4096));
static_assert(!a1_bo_in_window(0, 0));
static_assert(!a1_bo_in_window(0x7ffff000, 4097));
static_assert(!a1_bo_in_window(0x80000000, 1));
static_assert(!a1_bo_in_window(0xc0000000, 1)); // QSPI is not a BO window.
static_assert(!a1_bo_in_window(0x800000000ULL, 4096)); // High reserved DDR.
static_assert(!a1_bo_in_window(1, std::numeric_limits<std::uint64_t>::max()));
static_assert(!a1_bo_in_window(std::numeric_limits<std::uint64_t>::max(), 2));
int main() {
    a1_require_bo_window(0x10000000, 16448);
    try { a1_require_bo_window(0x80000000, 4); }
    catch (const std::runtime_error&) { return 0; }
    return 1;
}
