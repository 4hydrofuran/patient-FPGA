#include "evidence_file.hpp"
#include <iostream>

int main(int argc, char** argv) try {
    if (argc < 2) return 2;
    ExclusiveEvidenceFile file(argv[1]);
    file.append("PC_FIXTURE_ONLY\n");
    file.finish();
    if (argc > 2) file.append("must-fail\n");
    return 0;
} catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
}
