#pragma once
#include <array>
#include <cstdint>
#include <stdexcept>
constexpr int MAX_LENGTH = 4096;
constexpr std::array<int,20> LENGTHS{{1,2,3,7,15,16,31,32,63,64,65,127,128,255,256,511,512,1023,2048,4096}};
inline void validate_length(long long n, size_t capacity) {
    if (n<1 || n>MAX_LENGTH || static_cast<unsigned long long>(n)>capacity)
        throw std::invalid_argument("length outside allocated capacity / [1,4096]");
}
inline uint32_t input_a(int job, int i) { return 0x80000000u + uint32_t(job)*8191u + uint32_t(i)*65537u; }
inline uint32_t input_b(int job, int i) { return 0x7fffffffu - uint32_t(job)*127u + uint32_t(i)*17u; }
