#pragma once
#include <cstdint>
#include <stdexcept>

// A-vadd ONLY: pinned offline xclbin maps all arguments to HP0 [0, 2 GiB).
// This is an addressability ceiling, NOT a tested allocation budget.
constexpr bool a1_bo_in_window(std::uint64_t address, std::uint64_t bytes) {
    constexpr std::uint64_t end = 0x80000000ULL;
    return bytes != 0 && address < end && bytes <= end - address;
}
inline void a1_require_bo_window(std::uint64_t address, std::uint64_t bytes) {
    if (!a1_bo_in_window(address, bytes))
        throw std::runtime_error("BO outside pinned A-vadd HP0 window: no kernel execution; retain lease");
}
