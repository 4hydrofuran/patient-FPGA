#include "cases.hpp"
#include "evidence_file.hpp"
#include "bo_range.hpp"
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <sstream>
#include <string>
using Clock = std::chrono::steady_clock;
static double us(Clock::time_point t) { return std::chrono::duration<double,std::micro>(Clock::now()-t).count(); }
int main(int argc,char**argv) try {
    if(argc!=3) throw std::runtime_error("usage: a1-vadd <xclbin> <new.csv>");
    if(std::getenv("XCL_EMULATION_MODE")) throw std::runtime_error("emulation forbidden");
    if(!std::getenv("A1_BOARD_LEASE")) throw std::runtime_error("run via platform/a1/lease.py under board lease");
    std::ifstream compat("/sys/firmware/devicetree/base/compatible",std::ios::binary);
    std::string id((std::istreambuf_iterator<char>(compat)),{});
    if(id.find("xlnx") == std::string::npos || id.find("kv260") == std::string::npos)
        throw std::runtime_error("KV260 device-tree identity not confirmed");
    for(auto n:{-1LL,0LL,4097LL,9223372036854775807LL}) {
        bool rejected=false;
        try {validate_length(n,4096);} catch(const std::invalid_argument&) {rejected=true;}
        if(!rejected) throw std::runtime_error("invalid parameter admitted");
    }
    bool capacity_rejected=false;
    try {validate_length(16,15);} catch(const std::invalid_argument&) {capacity_rejected=true;}
    if(!capacity_rejected) throw std::runtime_error("short BO admitted");
    std::cout<<"host_invalid_rejections=5 (no device calls)\n";
    ExclusiveEvidenceFile csv(argv[2]);
    csv.append("job,n,alloc_us,group_a,group_b,group_c,address_a,address_b,address_c,bo_bytes,sync_in_us,run_wait_us,sync_out_us,pass\n");
    xrt::device device(0);
    const auto load_start=Clock::now();
    auto uuid=device.load_xclbin(argv[1]);
    std::cout<<"xclbin_uuid="<<uuid.to_string()<<" load_us="<<us(load_start)<<std::endl;
    xrt::kernel kernel(device,uuid,"krnl_vadd");
    int job=0;
    for(int n:LENGTHS) {
        validate_length(n,n);
        const size_t bytes=size_t(n+16)*sizeof(uint32_t);
        const auto alloc_start=Clock::now();
        xrt::bo a(device,bytes,kernel.group_id(0)),b(device,bytes,kernel.group_id(1)),c(device,bytes,kernel.group_id(2));
        const double alloc_us=us(alloc_start);
        for (const auto address : {a.address(), b.address(), c.address()}) {
            std::cout << "preflight_bo_address=" << address << " bytes=" << bytes << std::endl;
            a1_require_bo_window(address, bytes);
        }
        auto pa=a.map<uint32_t*>(),pb=b.map<uint32_t*>(),pc=c.map<uint32_t*>();
        for(int rep=0;rep<50;++rep) {
            for(int i=0;i<n;++i) {pa[i]=input_a(job,i);pb[i]=input_b(job,i);pc[i]=~(pa[i]+pb[i]);}
            for(int i=n;i<n+16;++i) {pa[i]=pb[i]=0;pc[i]=0xdeadbeefu;}
            auto t=Clock::now();
            a.sync(XCL_BO_SYNC_BO_TO_DEVICE); b.sync(XCL_BO_SYNC_BO_TO_DEVICE); c.sync(XCL_BO_SYNC_BO_TO_DEVICE);
            const double sync_in=us(t);
            t=Clock::now();
            auto run=kernel(a,b,c,n);
            if(run.wait(std::chrono::milliseconds(10000))!=ERT_CMD_STATE_COMPLETED)
                throw std::runtime_error("kernel timeout/error: retain lease, no automatic reset/retry");
            const double elapsed=us(t);
            t=Clock::now();c.sync(XCL_BO_SYNC_BO_FROM_DEVICE);const double sync_out=us(t);
            bool pass=true;
            for(int i=0;i<n;++i) if(pc[i]!=pa[i]+pb[i]) pass=false;
            for(int i=n;i<n+16;++i) if(pc[i]!=0xdeadbeefu) pass=false;
            std::ostringstream row;
            row<<job<<','<<n<<','<<alloc_us<<','<<kernel.group_id(0)<<','<<kernel.group_id(1)<<','<<kernel.group_id(2)<<','
               <<a.address()<<','<<b.address()<<','<<c.address()<<','<<bytes<<','<<sync_in<<','<<elapsed<<','<<sync_out<<','<<pass<<'\n';
            csv.append(row.str());
            if(!pass) throw std::runtime_error("readback or guard mismatch");
            ++job;
        }
    }
    csv.finish();
    std::cout<<"REAL_DEVICE_RUN: "<<job<<" whole-vector comparisons, 20 lengths. G1 also requires identity/memory/recovery/S0 evidence.\n";
    return job==1000?0:2;
} catch(const std::exception& e) {std::cerr<<e.what()<<std::endl; return 1;}
