#include "cases.hpp"
#include <iostream>
#include <vector>
#include <limits>
extern "C" void krnl_vadd(const uint32_t*, const uint32_t*, uint32_t*, int);
int main() {
    int rejected=0;
    for (auto n : {-1LL,0LL,4097LL,std::numeric_limits<long long>::max()}) {
        try { validate_length(n,4096); } catch(const std::invalid_argument&) { ++rejected; }
    }
    try { validate_length(16,15); } catch(const std::invalid_argument&) { ++rejected; }
    if(rejected!=5) return 1;
    int job=0;
    for(int n:LENGTHS) for(int rep=0;rep<50;++rep) {
        validate_length(n,n);
        // RTL cosim wrappers transfer the full declared m_axi depth, even for
        // short n. Allocate that depth; retain n as the legal operation length.
        std::vector<uint32_t>a(MAX_LENGTH),b(MAX_LENGTH),c(MAX_LENGTH+16,0xdeadbeefu);
        for(int i=0;i<n;++i) { a[i]=input_a(job,i); b[i]=input_b(job,i); c[i]=~(a[i]+b[i]); }
        krnl_vadd(a.data(),b.data(),c.data(),n);
        for(int i=0;i<n;++i) if(c[i]!=a[i]+b[i]) return 2;
        for(int i=n;i<MAX_LENGTH+16;++i) if(c[i]!=0xdeadbeefu) return 3;
        ++job;
    }
    std::cout<<"PC_TEST ONLY: 20 lengths, "<<job<<" whole-vector comparisons, 5 host rejections; NOT G1\n";
}
