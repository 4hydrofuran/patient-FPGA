#!/usr/bin/env bash
# Offline ARM64 compilation only. Does not open an XRT device or load a bitstream.
set -eo pipefail
if [[ $# != 2 ]]; then
    printf '%s\n' 'usage: bash build_common_vadd.sh <installed-sdk> <new-output-dir>' >&2
    exit 2
fi
sdk=$(realpath -e -- "$1")
out=$(realpath -m -- "$2")
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
test ! -e "$out"
test ! -L "$out"
test -f "$sdk/environment-setup-cortexa72-cortexa53-amd-linux"
source "$sdk/environment-setup-cortexa72-cortexa53-amd-linux"
set -u
test "$OECORE_SDK_VERSION" = '2026.1'
test "$OECORE_TARGET_ARCH" = 'aarch64'
test -s "$SDKTARGETSYSROOT/usr/include/xrt/xrt_device.h"
test -s "$SDKTARGETSYSROOT/usr/lib/libxrt_coreutil.so"
mkdir -- "$out"
read -r -a cxx <<< "$CXX"
read -r -a cxxflags <<< "$CXXFLAGS"
read -r -a cppflags <<< "$CPPFLAGS"
read -r -a ldflags <<< "$LDFLAGS"
"${cxx[@]}" --version
"${cxx[@]}" -dumpmachine
printf 'SDK target sysroot: %s\n' "$SDKTARGETSYSROOT"
sha256sum "$sdk/environment-setup-cortexa72-cortexa53-amd-linux" \
    "$repo/platform/a1/vadd/host.cpp" "$repo/platform/a1/vadd/cases.hpp" \
    "$repo/platform/a1/vadd/evidence_file.hpp" \
    "$repo/platform/a1/vadd/bo_range.hpp" \
    "$SDKTARGETSYSROOT/usr/include/xrt/xrt_device.h" \
    "$SDKTARGETSYSROOT/usr/lib/libxrt_coreutil.so.2.23.0" \
    "$SDKTARGETSYSROOT/usr/lib/libxrt_core.so.2.23.0"
# Override common SDK's mixed A72/A53 tuning for K26's Cortex-A53.
set -x
"${cxx[@]}" "${cxxflags[@]}" "${cppflags[@]}" -std=c++17 -mcpu=cortex-a53 \
    -Wall -Wextra "$repo/platform/a1/vadd/host.cpp" -o "$out/a1-vadd" \
    -lxrt_coreutil -luuid -pthread "${ldflags[@]}"
set +x
file "$out/a1-vadd"
"$READELF" -h -l -d -V "$out/a1-vadd"
sha256sum "$out/a1-vadd"
printf '%s\n' 'ARM64 CROSS_LINK_ONLY; executable not run; no board, emulation or G1 PASS.'
