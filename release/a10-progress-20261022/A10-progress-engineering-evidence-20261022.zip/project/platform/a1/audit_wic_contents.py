"""Read-only queries against extracted regular-file partitions; no guest execution."""
import argparse
import json
from pathlib import Path
import subprocess
from record import run


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--image-dir', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    root = a.image_dir/'partition-3.img'
    boot = a.image_dir/'partition-1.img'
    kdir = '/usr/lib/modules/6.18.10-xilinx-g4f7afe14f724'
    queries = {
        'os': 'cat /usr/lib/os-release',
        'version': 'cat /etc/version',
        'modules_updates': 'ls -p '+kdir+'/updates',
        'modules_dep': 'cat '+kdir+'/modules.dep',
        'xrt_modules': 'ls -p /usr/lib/xrt/module',
        'opt': 'ls -p /opt',
        'rpm_database': 'ls -p /var/lib/rpm',
        'cmake': 'stat /usr/bin/cmake',
        'pkgconfig': 'stat /usr/bin/pkg-config',
        'xrt_headers': 'stat /usr/include/xrt/xrt_device.h',
        'k26_shell': 'cat /usr/lib/firmware/xilinx/k26-starter-kits/shell.json',
        'root_boot_entry': 'cat /boot/loader/entries/edf-linux.conf',
        'dnf_repos': 'ls -p /etc/yum.repos.d',
    }
    for name, query in queries.items():
        run(['debugfs', '-R', query, str(root)], a.out/(name+'.json'))
    for name, path in [('loader', '::/loader/loader.conf'), ('linux_entry', '::/loader/entries/edf-linux.conf'),
                       ('xen_entry', '::/loader/entries/edf-xen.conf')]:
        run(['mtype', '-i', str(boot), path], a.out/(name+'.json'))
    print('Captured raw queries. debugfs can return zero for missing paths; inspect stderr, not just exit codes.')


if __name__ == '__main__':
    main()
