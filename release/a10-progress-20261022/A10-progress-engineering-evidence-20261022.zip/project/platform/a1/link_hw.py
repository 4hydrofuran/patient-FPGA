"""Hardware-only linking, guarded by an A-reviewed matched bundle. No packaging/flashing."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
from record import run
from file_hash import sha256_file
ROOT=Path(__file__).resolve().parents[2]

def validated(bundle):
    if bundle.get("status")!="MATCHED_REVIEWED" or not bundle.get("reviewer"):
        raise ValueError("matched KV260 bundle review missing; not a general EDF/Versal flow")
    if bundle.get("platform")!="kv260_base" or bundle.get("tools")!="2026.1":
        raise ValueError("wrong platform/tool family")
    required=("xpfm","xsa","rootfs","kernel","dtb","boot_manifest","xo","platforminfo")
    for key in required:
        item=bundle.get(key)
        if not isinstance(item,dict):raise ValueError("missing artifact: "+key)
        p=Path(item["path"])
        actual=sha256_file(p)
        if actual!=item.get("sha256"):raise ValueError("hash mismatch: "+key)
    if not bundle.get("memory_source_discrepancies_resolved"):
        raise ValueError("unresolved source/platform memory mismatch")
    return bundle

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--bundle",required=True);ap.add_argument("--label",required=True);a=ap.parse_args()
    b=validated(json.loads(Path(a.bundle).read_text()))
    if platform.system()!="Linux":raise RuntimeError("Linux build host required; not Windows or emulation")
    if not a.label.replace("-","").replace("_","").isalnum():raise ValueError("unsafe label")
    out=ROOT/"platform/build"/("link-"+a.label);out.mkdir(parents=True,exist_ok=False)
    rc=run(["v++","--version"],out/"version.json")
    version=json.loads((out/"version.json").read_text())
    if rc or "2026.1" not in version["stdout"]:raise RuntimeError("actual v++ version check failed")
    rc=run(["v++","--link","--target","hw","--platform",str(Path(b["xpfm"]["path"]).resolve()),
            "--config",str(ROOT/"platform/a1/vadd/link.cfg"),
            "--output",str(out/"vadd.xclbin"),str(Path(b["xo"]["path"]).resolve())],out/"link.json",cwd=out)
    if rc:return rc
    artifact=out/"vadd.xclbin"
    (out/"xclbin_hash.json").write_text(json.dumps({"sha256":hashlib.sha256(artifact.read_bytes()).hexdigest(),"board_test":"NOT_TESTED"})+"\n")
    return run(["xclbinutil","--input",str(artifact),"--info"],out/"xclbin_info.json")

if __name__=="__main__":raise SystemExit(main())
