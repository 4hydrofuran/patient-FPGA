"""Preserve upstream notices and immutable metadata; never accept rejected weights."""
import hashlib
import json
from pathlib import Path
import shutil
from file_hash import sha256_file
ROOT=Path(__file__).resolve().parents[2]
pins=json.loads((ROOT/"platform/a1/pins.json").read_text())
cache=ROOT/"platform/local/a1"
out=ROOT/"bench/runtime/s0/metadata";out.mkdir(parents=True,exist_ok=True)
for src,dst in [(cache/"model/LICENSE",out/"MODEL_LICENSE"),
                (cache/"model/config.json",out/"model_config.json"),
                (cache/"model/tokenizer_config.json",out/"tokenizer_config.json"),
                (cache/("llama.cpp-"+pins["llama_cpp"]["commit"])/"LICENSE",out/"LLAMA_LICENSE")]:
    shutil.copyfile(src,dst)
manifest={"model_revision":pins["model"]["revision"],"llama_cpp_commit":pins["llama_cpp"]["commit"],
          "weight_expected_sha256":pins["model"]["weight_sha256"],"weight_verified":False,
          "gguf_sha256":None,"chat_template_sha256":hashlib.sha256((ROOT/"bench/runtime/s0/fixture/chat_template.txt").read_bytes()).hexdigest(),
          "files":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.name!="manifest.json"}}
path=cache/"model/model.safetensors"
if path.exists():
    digest=sha256_file(path)
    manifest["weight_verified"]=digest==pins["model"]["weight_sha256"]
manifest["rejected_downloads"]=[]
for path in (cache/"model").glob("model.safetensors.*"):
    digest=sha256_file(path)
    manifest["rejected_downloads"].append({"path":str(path.relative_to(ROOT)).replace("\\","/"),"bytes":path.stat().st_size,"sha256":digest,"usable":False})
(out/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"weight_verified":manifest["weight_verified"],"metadata_files":len(manifest["files"]),"rejected_downloads":len(manifest["rejected_downloads"])}))
