# A10：关机后的电脑配套构建与修复记录（2026-10-19）

当前范围：用户确认板子已经关机，要求继续A10并取消时间上限。本轮只做电脑工作，移除电脑构建/模块暂存总时限；不取消板端温度、低负荷、超时和异常停止规则。没有连接串口/SSH、上电、复位、刷写、加载驱动/PL或分配板端BO。此前板IP和温度是历史，不作为本次当前值。

**A10仍NOT_PASSED**；取消20长度/1000次回归的决定继续有效，不补跑。电脑修复/编译/归档成功不证明新内核已可启动或平台恢复安全。

## 实际修复与构建

- 内核仍采用三个已审查的精确Ubuntu源文件补丁，未改数学、模型、语音、频率、CMA或启动DT。完整Image/modules/dtbs已续建成功，独立release `6.8.12-a10irq1`。第一次45分钟限时退出124保留；第二次退出0，不重编已有成功对象。最新脚本取消电脑总时限，当前已完成的进程未被强杀。
- ZOCL新增两个源文件派生修复，原发行包及原文件不动：`zert/zocl_xgq_intc.c`把可睡眠IRQ API移出spinlock；使用已初始化的进程mutex；注册先masked、填callback后enable；释放先free_irq同步再清callback。`common/cu.c`把IRQ注册移到CU初始化后，卸载先排空sysfs读者/IRQ再销毁core，并补irq_name分配失败清理。
- 同样只覆盖正常静止生命周期。不证明活动DMA、任意并发客户端、强卸载或故障注入安全。厂商原显式polling fallback保留，后续IRQ验收必须识别/拒绝非预期回退，不将其当中断路径成功。
- 先完成旧ABI全驱动电脑编译，用于API校验；再针对新内核最终Module.symvers完整重编ZOCL，238个导入符号CRC全部一致。旧ABI候选不部署到原内核以假装内核引用问题已修复。
- 模块暂存v1的make虽然返回0，日志却有签名策略脚本Permission denied；独立验签门禁拒绝缺签名模块。保留v1，核对helper SHA后只恢复电脑私有文件执行位，v2新目录重新暂存。v2共6218个模块：全部ARM64/vermagic/CRC检查通过，6127个CMS签名以候选公钥密码学验证通过，91个按原Ubuntu staging策略不签名。没有关闭签名配置或force-load。候选证书在实板的信任/实际启动仍未验证。
- initramfs使用原备份解析结果：前段1669个旧模块，后段zstd启动用户空间。脚本不执行原archive内的hooks/程序、不按原路径解压；按原模块集合及新依赖闭包生成新版本模块段，保留非模块cpio条目原字节、原KV260 revB DT。完整模块tar只收入显式普通模块/metadata，不跟随build/source链接，不收入签名私钥。
- 首次FIT打包缺dtc返回255（Python包装器1）；失败目录保留。v2使用本次私有构建的dtc，不安装/升级主机包。候选FIT与模块包只在电脑私有目录，不能交付为已验收固件。

## 命令、退出码与分域结果

以下凭据均在本目录，完整命令在其`argv`，完整输出在`stdout/stderr`；不是只记录摘要。

| 凭据文件 | 命令入口 | 退出码/含义 |
|---|---|---|
| `kernel_full_build_01.json` | `bash …/build_full.sh 01` | 124，历史总时限；日志/对象保留 |
| `kernel_full_build_02.json` | `bash …/build_full.sh 02` | 0，完整Image/modules/dtbs |
| `driver_irq_generator_tests_01.json` | `unittest …test_prepare_driver.py` | 0，6方法 |
| `driver_irq_harness_01.json` | `bash …/run_driver_harness.sh` | 1，首次unused变量触发-Werror，保留 |
| `driver_irq_harness_02.json` | `bash …/run_driver_harness.sh` | 0，候选104 IRQ+32 CU=136检查；原版43+38=81缺陷复现；同套ASan/UBSan均通过，不翻倍计用例 |
| `driver_irq_oldabi_compile_01.json` | `bash …/build_driver_oldabi_pc.sh` | 0，旧ABI电脑API检查，非部署候选 |
| `kernel_full_zocl_build_01.json` | `bash …/build_full_zocl.sh` | 0，新内核238 CRC、ELF/版本通过 |
| `kernel_full_module_stage_01.json` | `bash …/stage_full_modules.sh`（当时v1） | 命令0，语义FAIL：内核模块未签名 |
| `kernel_module_stage_unsigned_repro_01.json` | `audit_module_stage.py --stage …/module-stage-v1 …` | 1，准确拒绝缺签名，最小复现保留 |
| `kernel_module_stage_tests_01.json` | `unittest …test_module_stage.py` | 0，6方法：签名尾部/策略/路径/链接 |
| `kernel_full_module_stage_02.json` | `bash …/stage_full_modules.sh`（v2） | 0，6218模块审计，6127签名验证 |
| `kernel_initramfs_layout_01.json` | `inspect_initramfs_layout.py …` | 0，只读结构解析 |
| `kernel_boot_candidate_tests_01.json` | `unittest …test_boot_candidate.py` | 0，7方法 |
| `kernel_boot_candidate_tests_02.json` | 同上，补模块归档范围 | 0，8方法；不与前7重复相加 |
| `kernel_boot_candidate_build_01.json` | `prepare_boot_candidate.py`（v1） | 1，缺dtc，原mkimage255保留 |
| `kernel_boot_candidate_build_02.json` | `prepare_boot_candidate.py`（v2） | 0，候选FIT/完整模块包生成，三组件回读SHA一致 |
| `kernel_boot_candidate_readback_01.json` | `audit_boot_candidate.py --output …/boot_candidate_readback_v1.json` | 0，独立流式读取tar、cpio、gzip，验证6218全模块、1669启动模块及保留原非模块条目/DT |

最终电脑候选：WSL `KV260-A-2204:/home/member-a/a10-kernel-full-20261019-v1/boot-candidate-v2/`。

- `candidate.fit`：65552664B，SHA256 `a393f397a673a2f3636c8b9f85d8a59f7257c24d33c34d28a67b11c410a11b81`。
- `modules.tar.gz`：108698233B，SHA256 `c1ad278f7bcfc4137fc0013a98db593487ea5f22a1eff0acfddaf2e963255cf2`。
- `manifest.json`记录组件摘要及NOT_BOOT_TESTED；归档回读结果为本目录 `boot_candidate_readback_v1.json`。1669模块覆盖未减少；仅移除旧主归档14个模块目录/metadata条目并换为新版本，非模块原条目字节不变。
- 原initramfs来自用户板备份；整个候选保持私有本地，不自动发布到GitHub。实际initramfs RAM放置、试启动/回滚/板上证书信任均未验证，值保持null或NOT_TESTED。

新驱动编译仍有厂商源的未使用变量/缺原型/格式警告，以及无.git提取树的git诊断；完整保留，不称无警告构建。明确设置候选修改文件元数据，不冒充未修改发行版本。新驱动本次已生成BTF；旧头文件独立编译缺vmlinux跳过BTF只是旧证据，不混淆。

## 固定摘要

- 内核补丁：`9a3a695f0c45353ce7c5cfd920af9ccba46218820434372adde7af23d4190a89`
- 新驱动补丁：`565a6f34658be4f9ab16ef64902d5c4cf2db3c9cfda62438debab9e085bc449e`
- 新Image：`dd261f19374ada85873b8b7165b82d36f49515866f9e3cfbe39a88933e083ba2`
- 新Module.symvers：`7e93bbb17224ef84a9641c4fca7481323adf5dca4b3f46329327707003a818b3`
- 新.config：`97a9a28a66ae1466f07667b2c75ab2d3dce0c1451cd51923a3c2bc54ccf2aa8b`
- 新签名/strip后的ZOCL：528257B，`2aa089c3967e8fa72480310fe2cc12aaa7d920135f5322d8596819835ca087cc`
- v2模块完整安装日志：`99abe154c3f698e7935f6f380f71537c15a6751122eb02bd4a6bc35dd8238854`
- 新驱动源码候选：`platform/build/a10-driver-irq-repair-20261019-v1/`（独立原文件/派生文件/manifest）。
- 私有电脑工作根：WSL `KV260-A-2204:/home/member-a/a10-kernel-full-20261019-v1/`；签名私钥留`build/certs/`，绝不打包/打印/提交。

## 未决项与下一步

电脑候选仍非板端放行：实际U-Boot命令与一次性返回原系统的方法需现场核实；保持原FIT/脚本不变，禁止saveenv/QSPI/FWUEN/自动复位。新内核试启动、独立模块目录暂存及低负荷检查需确切目标和恢复步骤确认后专项授权。此前完整原FIT/脚本/组件备份保留；原系统完整模块树和离线恢复演练不是已完成项。

之后才可安排一次空载普通卸载/恢复，确认不再出现新增引用/IRQ错误；通过后做一次最小真实PL输入输出、小额BO地址/同步/资源双账。实板运行次数仍0，BO计算分配0，A10未通过，不能进入模型硬件演示。板已关机，不在本轮要求用户立刻重新上电。

P2：性能优化/压力测试/主动故障注入/并发DMA恢复未实施；不把这些加回本阶段取消的数值回归。
