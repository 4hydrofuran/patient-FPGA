# A10 候选空载入口：电脑准备与测试

状态：`PC_PREPARED_BOARD_NOT_TESTED`；A10 `NOT_PASSED`。
本轮为实际代码/测试/产物增量，不是已验证的板端等待。未连接 UART/SSH，未重启、上传、加载驱动/位流或执行计算。新维护授权仍待用户回复；不重复使用此前已消耗的一次候选试启动授权。

## 设计差距与实际改动

- `platform/qwen35/a10/idle_board_trial.py`：把旧内核/驱动/boot/package/温度和内存门禁改为保留原默认值的实例配置，供新候选入口继承。旧执行/收尾的固定身份仍在，不修改历史证据。
- `platform/qwen35/a10/candidate_idle_trial.py`：固定 `6.8.12-a10irq1`、已暂存的新 ZOCL SHA 和原位流/DTBO/恢复包 SHA。默认仅输出计划；准备模式仅生成电脑包，不能自动上传或获得授权。
- 候选入口要求独立固定包清单 SHA、实际新 boot UUID、同 boot 完整 raw dmesg、每一条既有诊断的逐项理由与审阅决定；重复诊断不去重。初次日志门禁在进入基础部署流程前执行。**本轮没有签发任何真实板端告警豁免/审阅文件**。
- 后续新增告警（即使文本与旧告警相同）、日志截断/换 boot、未知返回态仍停止后续状态变更。未知管理调用保持锁并等待人工核实，不 kill/重试/复位。既有基线 X509、pinctrl、overlay 告警没有因此被解决。
- 仅允许精确驱动 `insmod`、普通 `rmmod`、指定包的装卸及只读列表/日志命令。包中没有 xclbin、计算 host 或模型；本入口没有 compute/BO API。配置加载器自身缓冲不等于计算 BO，仍需板测单独记账。
- `platform/qwen35/a10/test_candidate_idle_trial.py`：14项 PC 方法，覆盖上述身份、包完整性、无覆盖、默认无动作、审阅范围、告警锁止、允许命令和候选父子设备拓扑。
- 候选温度门禁 `<55°C`，MemAvailable 至少 1GiB、CmaFree 至少 32MiB。这是停止条件，不是散热/内存性能结论；没有修改板端频率、DT、CMA、模型或语音参数。

## 失败最小复现及修复

新增包预览回归发现 Python 导入自动生成 `__pycache__`，导致严格清单核验失败。`candidate_idle_cache_repro_20261021_01.json` 保存 14方法中1错误、退出码1及堆栈，未删。

修复为在导入本地辅助模块前禁止写 bytecode，保留严格“无额外文件”门禁；没有把缓存/未知文件加入忽略名单。之后 Windows14、Linux34均通过，且包默认预览后仍能校验。

## 实际命令与退出码

工作目录均为 `C:\Patientqwen`。以下每条外包 `platform/a1/record.py --log <记录> -- <命令>`，完整 argv/stdout/stderr/时间保存在同目录 JSON。

| 命令/范围 | 退出码与证据 |
|---|---|
| `python scripts/release/check_contracts.py` | 0；`candidate_idle_legacy_contracts_20261021_01.json` |
| `python scripts/release/qwen35_config.py` | 0；`candidate_idle_qwen_config_20261021_01.json` |
| Windows `python -m unittest discover -s platform/qwen35/a10 -p test_idle*.py -v` | 11方法通过，0；`candidate_idle_legacy_tests_20261021_01.json` |
| Windows 新入口14方法首次运行 | 0；`candidate_idle_tests_windows_20261021_01.json`，尚不含子进程缓存复现 |
| Windows 增补缓存复现后14方法 | 1；`candidate_idle_cache_repro_20261021_01.json` |
| Windows `python -m unittest discover -s platform/qwen35/a10 -p test_candidate_idle_trial.py -v`，修复后 | 14方法通过，0；`candidate_idle_tests_windows_20261021_02.json` |
| WSL `cd /mnt/c/Patientqwen/platform/qwen35/a10 && python3 -B -m unittest -v test_candidate_idle_trial test_idle_board_trial test_idle_cleanup_only test_idle_trial test_kernel_log_gate` | 34方法通过，0；`candidate_idle_tests_linux_20261021_01.json`；不是34项实板检查，也不与Windows重叠相加 |
| `python platform/qwen35/a10/candidate_idle_trial.py --prepare platform/local/a10-candidate-idle-20261021-v1 --project-root C:/Patientqwen` | 0；`candidate_idle_bundle_prepare_20261021_01.json` |
| 独立读取生成包，调用 `verify_bundle` 并逐文件回读 | 0；`candidate_idle_bundle_verify_20261021_01.json` |

## 电脑产物

本地包：`platform/local/a10-candidate-idle-20261021-v1/`。
清单：`bundle.pending.json`，SHA256：
`2c3985ea79a157882933770f1b616a80cfe26aad74dc3f704eae093453da3d62`。

包括原位流/DTBO、shell.json、候选入口/基础空载执行器/日志门禁共6个载荷文件，另有1个清单。约7.8MB；无权重、系统镜像、私钥、许可证或凭据。逐文件字节数及SHA在清单和独立核验记录内。电脑包未上传，不命名为板验收成品。

拟议板端包名 `a10-vadd-20261021-candidate`，新目录 `/lib/firmware/xilinx/a10-vadd-20261021-candidate`。目标存在即拒绝，不覆盖旧空载包。源码改变后必须另建版本并重新核验，不能继续借用本清单。

默认可安全预览命令：

```powershell
& C:\Patientqwen\platform\local\a1\venv\Scripts\python.exe C:\Patientqwen\platform\qwen35\a10\candidate_idle_trial.py
```

执行模式仍缺实际新 boot 及 raw 日志审阅数据；不能用测试夹具 UUID 或历史 journal 的哈希补填。

## BOARD 未决与下一步

1. 待已提出的明确维护授权；获准后只做一次候选临时启动，重新核实身份/温度/原启动文件与基线。不可使用旧 boot 锁直接重放旧启动脚本。
2. 逐项评审新基线，再决定是否能进入一次空载加载/普通卸载/默认恢复。新增 overlay、IRQ、模块签名等诊断仍会阻断；本包不是“这些问题已解决”的证明。
3. 空载生命周期通过后才进入一次最小真实 PL vector-add、小 BO/同步/实际资源账及最终 B/C 环境交付。本轮这些值仍为 null/NOT_TESTED，实际新计算次数0。

20长度/1000次及重复数值回归保持 `CANCELLED_BY_USER`，不补跑、不改成PASS。P2性能优化、压力和极限分配 `NOT_IMPLEMENTED`；活动DMA故障注入 `NOT_TESTED_SAFETY_EXCLUDED`。A00—A17历史与失败保留，未提交或推送。无性能改善声明。
