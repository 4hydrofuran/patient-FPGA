# MobaXterm 空白窗口后的被动复核

日期：2026-10-18。用户确认已关闭 COM5/COM6 标签，电源灯亮、风扇转（用户报告，非软件验证）。

只读检查命令执行退出码均为 0：

- `Get-PnpDevice -Class Ports -PresentOnly`：COM5/COM6 均 OK；USB 标识分别为 `FTDIBUS\VID_0403+PID_6011+XFL1CYYPZ52YB\0000`、`FTDIBUS\VID_0403+PID_6011+XFL1CYYPZ52YC\0000`。
- 使用 .NET `System.IO.Ports.SerialPort` 顺序打开两口，115200、8N1、Handshake=None、DtrEnable=false、RtsEnable=false；每口最多监听 4 秒，用 BytesToRead/Read 读取原始字节，不调用任何 Write 方法；finally 关闭并释放端口。
- COM5：打开成功，接收 0 字节，发送 0 字节，无异常，已关闭。
- COM6：打开成功，接收 0 字节，发送 0 字节，无异常，已关闭。

结论仅限此次监听窗口：没有收到原始字节，不能将当前空白简单归因为字符显示问题；也不能由被动无输出断言 Linux 未启动、固件损坏或硬件损坏。旧 `kria login:` 是先前观察，不代表当前已登录。

未发送用户名/密码/回车/命令，未复位、刷写、改变网络配置或运行板端计算。A10 系统身份与计算验收仍未通过，BOARD compute=NOT_TESTED。
