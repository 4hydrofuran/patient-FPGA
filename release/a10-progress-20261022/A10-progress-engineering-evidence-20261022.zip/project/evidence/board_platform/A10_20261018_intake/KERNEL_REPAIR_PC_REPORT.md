# A10 内核修复候选电脑验证 — 2026-10-19

结论：`PASS_PC_CANDIDATE_CHECKS / NOT_BOOTABLE / BOARD_NOT_TESTED`。A10 仍未通过，不把源代码修复、stub 通过或对象编译当板上故障消失。本轮没有连接或修改板子，没有负载、重启、驱动/位流加载及计算 BO。

工程根 `C:\Patientqwen`；分支沿用 `member-a/review-n08b-20261018`，保留已有修改，无提交/推送。取消数值回归的用户修订继续有效。

## 修复内容及依据

精确来源 Ubuntu `linux-xilinx 6.8.0-1015.16`，原包与 diff SHA 及各原文件 SHA 在准备脚本/候选 manifest 固定。不是拿其他版本驱动覆盖旧系统。

1. `drivers/of/irq.c`：extended 解析路径临时 parent 引用归还；`irq_of_parse_and_map` 在映射后归还解析所得引用。对应上游 `0cb58d6c7b558a69957fabe159bfb184196e1e8d`、`962a2805e47b933876ba0e4c488d9e89ced2dd29`。本候选采用旧源码既有 goto-out 语义回移，不引入新版 `__free` API；不是声称字节一致 cherry-pick。[第一项上游提交镜像](https://cos.googlesource.com/third_party/kernel/+/ceb4266a78949b33eae760759988043b11c84cc8)、[第二项上游提交镜像](https://android.googlesource.com/kernel/common/+/d67c851e6c76a3d86dd30f9c1dae227a3d9141ef)。
2. `drivers/irqchip/irq-xilinx-intc.c`：A 本地修订，使用 `nr_irq` 固定上界，避免释放时 `mapcount` 递减造成漏清理，也覆盖稀疏 hwirq。没有调整 MMIO/中断屏蔽顺序。
3. `drivers/irqchip/irqchip.c`：A 本地修订 experimental probe 的父节点引用所有权，交 devres 在失败/延迟探测/正常解绑释放；分配失败及 self-parent 独立归还。没有按“多出来64”强行减引用，也没有提前释放后续 callback 仍使用的 parent。

候选 `platform/build/a10-kernel-repair-20261019-v2/` 保存 original、candidate、repair.patch、manifest.json。补丁 SHA256：`9a3a695f0c45353ce7c5cfd920af9ccba46218820434372adde7af23d4190a89`。v1 原样保留。

## 执行命令与结果

以下从工程根运行；Windows Python 简记 `platform/local/a1/venv/Scripts/python.exe`，WSL 为 `KV260-A-2204`。每个 JSON 保留完整 argv、cwd、时间、stdout/stderr、退出码；记录由 `platform/a1/record.py --log <新文件> -- <命令>` 生成。表内路径以本报告目录为基准。

| 命令主体 | 证据 | 退出码 / 分域结果 |
| --- | --- | --- |
| Python `platform/qwen35/a10/kernel_repair/prepare.py --source platform/local/a10-kernel-refaudit-20261019/selected-v2 --output platform/build/a10-kernel-repair-20261019-v2` | `kernel_repair_prepare_v2.json` | 0，三个原文件 SHA 锁定，生成新候选 |
| Python `-m unittest discover -s platform/qwen35/a10/kernel_repair -p test_prepare.py -v` | `kernel_repair_prepare_tests_v2.json` | 0，4 方法 |
| WSL bash `/mnt/c/Patientqwen/platform/qwen35/a10/kernel_repair/run_native.sh` | `kernel_repair_native_v4.json` | 0，真实函数提取后的 PC stub 测试及 ASan/UBSan |
| WSL bash `/mnt/c/Patientqwen/platform/qwen35/a10/kernel_repair/check_patch.sh` | `kernel_repair_patch_checks_v1.json` | 0，正/反向 dry-run、无 fuzz、补丁及六份源 SHA |
| WSL bash `/mnt/c/Patientqwen/platform/qwen35/a10/kernel_repair/build_arm_objects.sh` | `kernel_repair_arm_objects_v3.json` | 0，三个完整 ARM64 翻译单元，52.85秒（电脑） |

Native：原版 100+208=308 检查验证预期缺陷可复现，**不是原内核正常**；候选 100+204=304 检查通过。相同检查各再用 ASan/UBSan 通过，不重复计为独立用例。涵盖 extended/legacy、解析/映射失败、32×2枚举、稀疏/稠密/空映射、父节点存在/不存在/自指、分配与 action 注册失败、延迟探测和正常移除。旧引用模型中的 1+64=65 与板日志相符，但不是完整动态根因排他证明。

Native 产物 `/home/member-a/a10-kernel-repair-native-20261019-v4`。ARM 产物 `/home/member-a/a10-kernel-repair-arm-20261019-v3`（均 PC WSL 本地）：

| ARM ELF relocatable | SHA256 |
| --- | --- |
| `drivers/of/irq.o` | `40e770b58df31f99531661e45870551b0d7e61df99eb39a654b8f9574e595a26` |
| `drivers/irqchip/irq-xilinx-intc.o` | `ff193d781d3db9e21ed31a584ab8ae857c64f7544cadd934d2aab1f54cf20c00` |
| `drivers/irqchip/irqchip.o` | `a0ba8d5a49afc5d7ca61a726391a28fdaed31ef517929b834d1f98787bffd8a8` |

精确头文件 `.config` 与 `Module.symvers` 在编译前后哈希一致。最终仍有工具链版本提示：原内核 Ubuntu GCC13.3，候选 SDK GCC13.4；这项差异保留，不声称 ABI 已完全证明。未使用开发机 `-march=native`，未改变板上库。

## 原失败与修正保留

- native_v1 exit1：真实内核 int/u32 在 standalone -Werror 下 sign-compare；测试编译采用内核同类 `-Wno-sign-compare`，不改真实类型。
- native_v3 exit1：baseline 未使用候选所需 stub 导致 unused-function；按 FIXED 条件限定 stub，未删测试或改内核修复语义。
- arm_objects_v2 exit0 但有输入未来0.11秒和 clock-skew 警告；只对新生成 PC 构建输入规范 mtime，不改系统/板时钟。v3 完整重编无 clock-skew；编译器版本差异依然如实保留。
- earlier v1/v2 原候选、日志、生成物不覆盖；后续检查不重复模型、200轮或板1000轮。

## 仍需完成与下一步

1. 完整内核/配套模块、独立 KERNELRELEASE、新版本 ZOCL 重编、initramfs/FIT 尚未完成；三个 `.o` 不是可启动内核，不能上板安装。
2. 真实 IRQ/device-core 并发、在途 DMA 停止与卸载同步未证明。当前只验证正常静止路径的所有权，不能拿它作为故意故障注入的安全依据。
3. 回退草案 `platform/qwen35/a10/kernel_repair/ROLLBACK_PLAN.md` 已明确 FIT 启动事实和缺件：既有读启动脚本失败 exit127、原 FIT 整包 SHA/备份、实际一次性启动方法尚缺。不得说“回滚已可用”。先在电脑准备完整包；实际原件备份和一次性试启动需专项确认。
4. A10 一次最小 PL 输入输出、小 BO/同步及干净恢复仍 `NOT_TESTED/NOT_PASSED`；数值回归 `CANCELLED_BY_USER_NOT_PASS`，不复活。P2 压测、性能优化、极限探测 `NOT_IMPLEMENTED_SAFETY_EXCLUDED`。

本轮无板指标变化。最近默认恢复的板观察沿用旧证据，不假定本轮已重新验证在线状态。项目状态、角色状态、设计差距、测试矩阵及 AI 记录已更新；保留 A00—A17 历史。
