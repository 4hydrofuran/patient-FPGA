# A10：人工电源循环后的原系统恢复核对

用户先暂停并拒绝非正常断电风险，随后明确接受一次人工电源循环；本次又明确取消关机目标，要求正常推进 A10。历史正常重启卡死记录不改写为成功。

## 本次 BOARD_READONLY

- COM5 身份固定为板载 FTDI 的 `XFL1CYYPZ52YB` 接口；只在已登录 `ubuntu@kria` 的 shell 发送固定只读命令，结束释放 COM5。
- 新 boot ID：`bf3796f0-9785-4afd-a617-3ad578a24d10`，不同于发生 Oops 的旧启动。
- 原内核：`6.8.0-1015-xilinx`；设备树型号 `ZynqMP KV260 revB`。
- 默认 overlay 可见：`k26-starter-kits_image_1`；FPGA manager 为 `operating`，ZOCL 未加载。此状态不证明计算可用。
- 温度 29.236 / 29.593 / 27.658°C；MemAvailable 3587836 KiB、CmaFree 814444 KiB。不得相加作为总可用内存，不是峰值测量。
- 根分区 `/dev/mmcblk1p2 ext4 rw,relatime`；能挂载不等于完成离线文件系统完整性检查。
- tainted=8704；用户提供的原系统启动日志仍有 `x509_load_certificate_list` WARNING，以及旧固件不支持部分 pinctrl 功能、默认 overlay 属性释放警告。未屏蔽或判作全部健康通过。
- 普通 `dmesg` 权限拒绝；`sudo -n true` 返回 1，未发送密码。随后通过当前用户可读的 `journalctl -k -b -p warning -n 120` 成功取得最近警告。该有界日志不代表完整内核日志。
- 本次没有安装/加载驱动或位流、没有重启、没有运行计算、没有分配显式计算 BO；未改板端网络或持久配置。eth0 UP，但没有 IP。

## 命令和证据

工作根 `C:\Patientqwen`。

- `powershell.exe -NoProfile -ExecutionPolicy Bypass -File platform/qwen35/a10/collect_readonly_uart.ps1 -Phase driver_preflight -OutputPath evidence/board_platform/A10_20261018_intake/recovered_preflight_20261021_v1.json`：主脚本 0；其中 sudo 探测 1，dmesg 单项失败保留，不被末命令 0 掩盖。
- 同脚本 `-Phase recovery_readback -ValidateOnly`：0、无板端访问；实际 `-Phase recovery_readback -OutputPath .../recovered_boot_20261021_v1.json`：0，三个命令组完成。
- 用户启动日志原文 `manual_powercycle_boot_20261021.txt`，SHA256 `6bc38a52b8fb8583d1933176b84490ed9d79b5ef787385a5279eda85880f0f51`，与附件逐字节复制哈希一致。保留板上原有时间，不用其错误时钟推断电脑日期。
- `scripts/release/check_contracts.py` 与 `scripts/release/qwen35_config.py`：均退出 0，分别为历史静态保护和新版 PC 配置校验，不是 BOARD 验收。

## 电脑端继续工作与边界

独立 `6.8.12-a10irq2` 候选修复设备树私有数据的重复释放；旧 irq1 候选保持 REJECTED。本轮构建使用 `build_irq2.sh resume1`，日志 `build-resume1.log`，不覆盖被用户暂停的 `build.log`；receipt 为 `irq2_build_20261021_03.json`，必须读取实际退出码后才能判断结果。

打包门禁验证构建成功标记、指定脚本/尝试和 Image 哈希；不接受旧的退出 15 的中断记录。新增负例与已有隔离/归档/签名单测共 26 项，`irq2_parameter_tests_20261021_03.json` 退出 0；`bash -n build_irq2.sh` 同次退出 0。

A10 仍 NOT_PASSED。用户取消的 1000 次回归保持 CANCELLED_BY_USER；不做压力、峰值或长稳测试。原系统恢复与新候选的生命周期、最小计算及恢复验收分开记账；当前没有新的候选上板授权执行记录。

## 本轮结束：电脑构建与打包已完成

- `wsl.exe -d KV260-A-2204 -u member-a -- bash /mnt/c/Patientqwen/platform/qwen35/a10/kernel_repair/build_irq2.sh resume1`：退出 0，电脑耗时 555.07 秒。原先退出 15 的中断 receipt 保留。
- `wsl.exe -d KV260-A-2204 -u member-a -- bash -c 'source /mnt/c/Patientqwen/platform/qwen35/a10/kernel_repair/full_build_env.sh && python3 -B /mnt/c/Patientqwen/platform/qwen35/a10/kernel_repair/package_irq2.py'`：退出 0，电脑耗时 654.08 秒；不是板卡运行时间。
- 新 Image SHA256：`f35c225d1d62b99ad82cd36056a40b4bdf8d1502ed4afd24fb72ca45f73f0376`。
- 新 FIT：65555004 bytes，SHA256 `e60d7f49033ef8efbd2396fafbe94a3bc684a478d5f5e31676626d1bc5f6ae2b`。
- 模块包：108755861 bytes，SHA256 `da96f92d8be1c0dfb498efec34dc8b7f041e4698e53ea90041760f1aca0d817d`。
- 完整模块 6218 项，按既有策略要求的签名验证 6127 项；其余 91 项遵循既有 vendor staging 例外策略，不能写成全部模块已签名。initramfs 模块 1669 项。ARM64/版本/符号与对应新内核匹配，原非模块 CPIO 内容及设备树相同；归档不包含私钥或指向源码的链接。
- 审计副本：`irq2_pc_package_20261021_v1/`。实际大文件位于 WSL `/home/member-a/a10-kernel-irq2-20261021-v1/boot-candidate-v2/`，没有复制到板卡。
- 新增/修改电脑工具：`collect_readonly_uart.ps1`（只读恢复阶段）、`kernel_repair/build_irq2.sh`（独立续建日志）、`package_irq2.py`（成功 receipt 与 Image 匹配门禁）、`test_irq2_parameters.py`（新增拒绝中断/陈旧产物测试）、`IRQ2_NEXT_WINDOW.md`、`IRQ2_PC_CANDIDATE.json`。状态登记仅新增本轮结果，不抹去历史阶段和失败。

下一步先准备与 irq2 哈希匹配的暂存检查、重核本次启动与原备份，再取得新候选专项板端窗口授权。此次不执行旧 irq1 的部署器、不更改默认启动，不宣称 A10 通过。P2 压力/长稳等仍排除，模型、语音及性能参数未修改。
