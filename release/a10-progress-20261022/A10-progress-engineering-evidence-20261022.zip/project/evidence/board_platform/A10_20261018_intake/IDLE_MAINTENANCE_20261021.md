# A10 候选维护窗口：默认配置已恢复，A10 未通过

最新结果：`DEFAULT_RESTORED_DIAGNOSTICS_OPEN_A10_NOT_PASSED`。
本次只执行获准的一次正常重启/临时候选启动及空载维护。没有运行
vector-add、分配计算 BO、压力测试、QSPI/FWUEN/RESET、保存 U-Boot
环境或修改默认启动包。数值回归仍为 `CANCELLED_BY_USER`。

## 板上实际状态

- 当前内核 `6.8.12-a10irq1`，boot ID `751e617d-c003-4b99-be03-bb5c78235d24`。
- 默认 `k26-starter-kits_image_1` 为 applied，FPGA manager 为 operating；
  ZOCL、计算设备绑定/节点/持有者均不存在；活动租约已归档而非遗失。
- 最后独立读回温度 29.617 / 30.246 / 31.738°C；
  MemTotal 3997488、MemAvailable 3553984、CmaTotal 819200、CmaFree 814444 KiB。
  CMA 属于 MemTotal，不能与 PSS/BO重复加总；BO地址/同步/分配峰值仍 null。
- 原 `image.fit` 和 `boot.scr.uimg` SHA 与备份一致。**恢复默认 PL 配置不等于
  已返回原内核**；当前仍为临时候选内核，本窗口没有第二次重启。
- 临时 eth0 `192.168.2.2/24` 保留；NetworkManager save-no，未改默认路由、
  DNS、电脑网络或持久文件。SSH结束，COM5释放。

## 实际执行与退出码

完整 argv/回显以对应 JSON/JSONL 为准。`record.py` 收据的 exit_code 是被包装命令退出码。

| 分域/命令 | 结果 | 证据 |
|---|---|---|
| COM5只读重接 | 首次占用失败保留，用户关闭后0 | `idle_window_readback_20261021_01/02.json` |
| `boot_candidate_once.ps1 -ExpectedBootId ...` | 0；正常重启1次、候选boot1次 | `idle_window_candidate_boot_20261021_01.json`、`idle_window_candidate_login_20261021_01.json` |
| 临时NM连接 | 创建/激活0；后续只读FILENAME查询124 | `idle_window_temp_network_20261021_01.json` |
| 独立网络读回 | 0，地址/无默认路由/Unsaved=true | `idle_window_network_readback_20261021_01.json` |
| raw内核日志采集 | raw+color冲突1；修复后0 | `idle_window_raw_kernel_20261021_01/02.json` |
| v2/v3用户目录上传及所有文件哈希 | 均0，无系统安装 | `idle_window_upload_20261021_01/02.json` |
| v2空载入口预检 | 1，未创建租约、未变更硬件 | `idle_window_trial_v2_raw_20261021_01.jsonl` |
| v3空载入口 | 1，外部模块提示触发日志门禁 | `idle_window_trial_v3_raw_20261021_01.jsonl` |
| `dfx-mgr-client -remove 0` | 0，独立移除读回成功；约24.2ms | v3原始JSONL |
| `insmod .../6.8.12-a10irq1/extra/zocl.ko` | 0，新增外部模块标记后停止 | v3原始JSONL |
| cleanup v1 | 1，哈希常量录入错误；操作前停止 | `idle-window-closeout-v1/a10-candidate-idle-cleanup-20261021.jsonl` |
| `rmmod zocl`（普通卸载） | 0，约30.2ms；独立读回无模块 | cleanup v2原始JSONL |
| `dfx-mgr-client -load k26-starter-kits` | 0，约202.5ms；默认状态恢复，但新增2条属性告警 | cleanup v2原始JSONL |
| cleanup v2总体 | 非通过；工具外层退出1，内部代码诊断分支返回2（未单独捕获SSH的LASTEXITCODE）；不能以命令0冒充干净通过 | `idle-window-closeout-v1/a10-candidate-idle-cleanup-20261021-v2.jsonl` |
| 最终SSH只读状态/原启动SHA/四份原始日志SHA | 0；下载件与板端逐份一致 | `idle_window_final_readback_20261021_01.json` |
| 电脑派生审计 | 0 | `idle_window_audit_command_20261021_01.json` |

以上毫秒值是单次管理命令的单调时钟墙时间，**不是计算性能/负荷时长/可靠性统计**。
第一次SSH停留在认证后连接关闭（外层1），再次只读确认没有执行记录才继续；
一次手工启动路径将 `candidate-idle` 写成 `idle-candidate`，`cd` 退出1，未执行程序。
这些操作失误不计成硬件测试次数，也不掩盖为成功。

## 本次发现与修复

1. 板端 dmesg 拒绝 `--raw --color=never`。改为单独 `--raw`，保留优先级。
2. 固件日志包含41个CR，`subprocess text=True` 的通用换行转换破坏了原始SHA。
   v2在第一门禁停止；修复为字节读取+严格UTF-8解码，不规范化/放宽SHA。
   真实失败日志与基线比较可精确复现，不是新增硬件告警。
3. 新增候选boot固定身份的UART计划、准确包/目的目录上传校验、仅收尾命令白名单。
   旧入口/历史身份不改为新版；v1/v2失败与v3产物分别保存。
4. cleanup最初手抄raw SHA多一字符，操作前拒绝。修正后加入真实捕获文件测试，
   不再仅用共享错误常量的模拟夹具验证。
5. 保留完整raw日志，收尾终端仅打印短事件；最终审计校验所有下载SHA。

## 分域测试

- PC历史/新版契约：已有本日有效exit0，未重跑/修改契约。
- 启动保护30断言、UART计划35动作：exit0，收据单独列出，不与方法数混加。
- Linux日志门禁/候选/历史空载/收尾：最终37方法全部exit0；
  中途3个旧mock仍返回str的测试错误保留，已按字节接口修复。
- 新候选仅收尾：最终5方法exit0，包含真实板日志SHA/诊断回归。
- Windows上传计划：4方法exit0，覆盖v2保留、v3路径一致、越界与篡改拒绝。
- 电脑证据审计：3方法exit0，使用真实已核对哈希的日志，拒绝未结束/重复结束，
  不把只读命令算为装卸、不隐藏非零退出码。
- BOARD：候选启动、默认移除、驱动空绑定加载/卸载、默认恢复状态有证据。
  **测试位流加载0次、计算0次、计算BO分配0次**；新IRQ teardown没有被执行，
  不能宣称修复板测通过。

测试收据：`idle_window_boot_guard_tests_20261021_01.json`、
`idle_window_uart_plans_20261021_02.json`、
`idle_window_raw_bytes_tests_20261021_01/02.json`、
`idle_window_cleanup_tests_20261021_01/02.json`、
`idle_window_final_pc_tests_20261021_01.json`、
`idle_window_audit_tests_20261021_01.json`。

## 仍未解决

- 外部模块标记：精确候选源码 `kernel/module/main.c:2014` 在缺 `intree`
  元数据时发出该提示；不是模块加载失败，也不是IRQ成功。仅为本次普通收尾
  审阅该确切日志，没有给计算或未来日志设通用豁免。
- 默认恢复出现 `/fpga-region/firmware-name` 与 `resets` 两条属性生命周期告警。
  源码 `drivers/of/overlay.c:360` 对非overlay节点的属性更改发出告警。
  不将其与先前真实 expected-refcount 1/actual65 缺陷混为一谈；保留OPEN，
  没有压制打印、删日志或反复装卸验证。
- 原启动X509信任链/旧固件pinctrl兼容性限制仍OPEN；本次186条原始基线逐项
  审阅仅适用于这次空载尝试，不代表生产验收或允许新错误。
- 最小真实PL输入输出、metadata BO地址/同步/双账、测试IRQ正常卸载仍未测。
  A10不能因取消1000轮而自动通过，也不能进入模型硬件演示。
- P2性能/并发/压力/极限分配优化 `NOT_IMPLEMENTED`；不作为本次P0补测要求。

## 交付及下一步

机器结果 `idle_window_audit_20261021.json`；增量profile
`board_profile.idle_20261021.json`；双账
`memory_accounts.idle_20261021.json`。四份板上原始日志及完整argv保留。
此前A00—A17/N任务状态和用户现有修改保留，没有提交/推送。

下一步先在电脑端处理外部模块与overlay属性告警的分级/生命周期限制，
让下一份受控计划能区分“预期提示”与真实引用错误，不能仅清空日志门禁。
当前维护窗口已收尾，不再次自动重启/加载。之后仍需一次获准的真实测试位流
空载生命周期；干净恢复或明确评审的安全限制成立后，才安排修订A10要求的
单次小输入和小BO，不恢复已取消的回归。
