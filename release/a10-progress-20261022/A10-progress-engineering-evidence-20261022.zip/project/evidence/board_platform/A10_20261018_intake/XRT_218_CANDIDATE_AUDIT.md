# 同源 XRT 2.18 ZOCL 候选包核验（仅电脑）

日期：2026-10-18。状态：PACKAGE_FOUND_HASH_MATCHED_NOT_BUILT_NOT_INSTALLED。

## 用户提供的已安装包元数据

`dpkg-query -s xrt` 输出显示：install ok installed，arm64，Source=xilinx-runtime，Version=2.18.0-0ubuntu1，Installed-Size=105398；Provides=xrt-embedded (=202420.2.18.0-0ubuntu1)，Depends 包括 libxaiengine (>=2024.2)，不含 xrt-dkms/dkms。描述为 MPSoC 的库、头文件和工具。退出码未记录（null）。该元数据本身不证明最初下载地址，也不能证明驱动已安装。

## 新找到的官方文档所列 SDK 仓库

AMD UG1630 将 xilinx-runtime 列在 ubuntu-xilinx/sdk PPA，而不是此前查询的 default PPA：

https://docs.amd.com/r/en-US/ug1630-kria-som-apps-developer-ubuntu/Starter-Kit-Ubuntu-rootfs-PPA-and-Packages

该指南是旧版，故不把其安装步骤直接套用于本板；此次实际读取该仓库 noble ARM64 当前索引，确认两个包同时存在：

https://ppa.launchpadcontent.net/ubuntu-xilinx/sdk/ubuntu/dists/noble/main/binary-arm64/Packages.gz

索引压缩大小4368字节，HTTP读取/内存解压成功。包项如下：

| 包 | 版本 | 字节数 | SHA256（索引） |
| --- | --- | --- | --- |
| xrt | 2.18.0-0ubuntu1 arm64 | 11158000 | 98d0404fa721416b40ff1472bda71a8bf36062ba8ddf54325685f36ac05bfab6 |
| xrt-dkms | 2.18.0-0ubuntu1 arm64 | 159044 | 096cb3c25a2f6885bfc615746aba0cdcd74075b724207f0e02ba3dc05ba54297 |

只下载了 xrt-dkms，未下载/替换板端用户态包。实际下载文件 SHA256 与索引一致：

`platform/local/a10-xrt-2.18-audit/xrt-dkms_2.18.0-0ubuntu1_arm64.deb`

下载地址：
https://ppa.launchpadcontent.net/ubuntu-xilinx/sdk/ubuntu/pool/main/x/xilinx-runtime/xrt-dkms_2.18.0-0ubuntu1_arm64.deb

这是 HTTPS 与文件哈希核验；尚未独立验证 InRelease/GPG 签名链，不能标记为完成发布信任链验证。也未证明该文件就是用户先前安装系统时使用的同批交付。

## 静态安装风险（未执行任何安装脚本）

用 Windows tar 列目录、解出 control.tar.zst/data.tar.zst 并读取 control、postinst、dkms.conf、Makefile；文件只解在电脑独立 inspect 目录，未执行包内脚本。

- control：同源 xilinx-runtime，2.18.0-0ubuntu1，arm64，描述 ZOCL DKMS，Depends=dkms。
- `dkms.conf`：PACKAGE_NAME=xrt-zocl、PACKAGE_VERSION=2.18.0、AUTOINSTALL=yes；MAKE 为 `cd driver/zocl; make -j KERNEL_SRC=${kernel_source_dir}; cd ../..`。未限定并行数，不适合直接在本次受限板端触发。
- postinst：尝试 rmmod zocl、删除 /lib/modules 下特定 zocl.ko 文件并 depmod，调用 DKMS common.postinst，然后可能 modprobe zocl/更新 udev。因此安装并非只复制驱动文件，需单独变更授权与回滚计划。
- postinst 的 DKMS 操作使用名称 xrt，而 dkms.conf 声明 xrt-zocl；该静态差异需要隔离验证，不能直接断言必定失败或是现板缺失原因。
- postinst 末尾 exit 0；即便出现 DKMS 错误提示也不能仅以软件包安装命令成功就认定驱动验收通过。

## 实际电脑命令与结果

- PowerShell HttpClient：读取 SDK Packages.gz 并解析包项成功；同调用中的 OEM archive HTTPS 查询发生 SSL 错误，保留该失败，不关闭 TLS 校验，未用其作为来源证据；聚合命令退出0不代表所有 URL 成功。
- Invoke-WebRequest 下载159044字节 DEB，Get-FileHash 与索引匹配。随后同一调用 `wsl.exe --list --running` 返回1/未列出运行实例，因此聚合退出1；下载核验成功但没有运行 WSL 编译。
- Windows tar ar成员列表成功；同一调用找不到 gpg.exe，聚合退出1；未完成签名验证。
- Windows tar 提取包内两个归档并查看control/postinst/配置/Makefile成功，退出0。
- 没有执行 dpkg -i、apt install、DKMS、make、modprobe 或板端命令；没有 PC/BOARD 计算验证。

## 验收边界与下一步

已找到版本相同的驱动源码包，不再把“找不到同版本下载”作为阻断。仍未验证：6.8.0-1015-xilinx 下编译/符号/vermagic、包安装路径、实际DT节点/中断/内存拓扑、XRT2.18与既有2026.1平台/应用的兼容性，以及板端设备枚举/BO/核执行。

下一步优先在电脑隔离环境中取得并核验准确内核头文件/配置/符号版本，限制编译线程后预编译并审查。不能将2026.1 SDK的内核头文件直接视作当前Ubuntu内核头文件。驱动源码/数学/核不在本次修改。安装和加载之前需明确获批，准备只针对本次新增文件的恢复路径。无压力测试、无固件刷写、无主版本降级。
