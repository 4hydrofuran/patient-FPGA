# A10 候选首次启动与用户重新上电后的原系统核验

状态：`CANDIDATE_LINUX_BOOT_VERIFIED_ORIGINAL_RETURN_VERIFIED_A10_NOT_PASSED`。
这次有实质进展，不重做 A00—A09、200轮或取消的数值回归。报告覆盖候选并存/一次试启动授权，以及用户中断后“已上电、已登录并关闭”的只读重接。A10 的最小 PL/BO 与正常卸载验证仍未通过。

## 板端事实与安全边界

- 原模块树已只读备份到电脑，6,232项、归档110,837,760B。SHA256 `f4a85bedad3d9510f56463b7023028b21be22553b27fa61dd68dbba814fb78d9`；逐项内容/类型/权限/来源板与boot核验完成。备份在 `platform/local/a10-boot-backup-20261020/modules-v1/`，不上传系统镜像或私钥；未执行离线还原。
- 真实新增 `/usr/lib/modules/6.8.12-a10irq1` 和 `/boot/firmware/a10-candidate-20261020.fit`；原release、`image.fit`、`boot.scr.uimg`不覆盖。候选6,218模块/6,231文件/389,973,937B逐文件读回通过。
- 暂存单线程nice19、8MiB/s节流。板上暂存/读回106.702秒，1,283次健康采样最高36.432°C，最低MemAvailable3,537,688KiB。采样过密造成串口采集超容量；不是计算/压力测试，见下方修复与保留失败。
- Agent只发送一次正常软件重启、一次候选bootm。实际U-Boot2020.01验证kernel/ramdisk/DT三个SHA256，临时bootargs；没有saveenv、QSPI、FWUEN、硬复位或计算。
- 候选确实登录：kernel `6.8.12-a10irq1`，boot `41cd1765-c29c-4e74-8b3f-e7e5178fb3f6`；ARM64，默认overlay applied，FPGA operating，ZOCL未加载；温度31.863/33.806/33.495°C。modinfo读取匹配vermagic和签名者；**不是驱动加载或信任链通过**。
- 用户中断后重新上电；只读重接确认原kernel `6.8.0-1015-xilinx`，boot `2c0b1cbe-e330-440f-84eb-88a230f09326`；默认overlay、ZOCL未加载、原FIT/脚本SHA不变。候选FIT和新ZOCL哈希仍匹配。温度30.052/32.718/32.096°C；MemTotal3,996,396、MemAvailable3,584,032、CmaTotal819,200、CmaFree814,444KiB。
- 这证明本次用户重新上电返回原默认包；不声称故障自动回滚、断电故障注入或在途DMA恢复经过测试。COM5已释放；没有发送第二次重启。
- 当前没有IPv4地址。前次临时NM连接已证明Unsaved=true、无默认路由变更；本次重接不恢复网络、不修改电脑网络或持久配置。

## 命令与退出码

完整argv/命令、输出、主机接收时间和退出码在以下同目录JSON；不能把执行器退出失败掩盖为整轮PASS。

| 操作/入口 | 退出码与证据 |
|---|---|
| `uart_sudo_prepare_network.ps1 -AuthorizedTemporaryNetwork` | 板124：地址已激活，末尾nmcli查询超时；`uart_candidate_temp_network_01.json` |
| `driver_board_step.ps1 -Step candidate_network_readonly` | 0；独立确认IP/Unsaved=true/无默认路由，`uart_candidate_network_readback_01.json` |
| `kernel_repair/download_original_modules.py` | SSH0，全部归档核验通过；local模块备份目录 `download.json`、`original-backup-proof.json` |
| `kernel_repair/upload_candidate.py` | 建目录/SCP各0，远端校验1；Windows远端路径错误保留于local传输目录 `upload.json` |
| `kernel_repair/inspect_upload_paths.py` 和 `verify_upload_diagnosis.py` | 0；SCP实际正确到目标，5文件SHA一致，不重传；`upload_path_diagnosis_01.json`、local `upload-readback.json` |
| `uart_sudo_prepare_network.ps1 -AuthorizedCandidateStage` | 外层采集失败、板退出码null；`uart_candidate_stage_01.json`，未中断或重复执行 |
| `inspect_upload_paths.py --stage-state` | SSH0；取回完整板JSONL，最后STAGED_ONLY_NOT_BOOTED且进程已结束，原/新哈希正确；`candidate_stage_independent_readback_01.json` |
| `boot_candidate_once.ps1 -AuthorizedOnce` | 执行器2，iminfo解析格式保守停止；候选boot次数0；`candidate_boot_once_01.json` |
| `continue_candidate_boot.ps1 -AuthorizedOnce` | 执行器2：一次bootm后100秒捕获无登录提示；Linux/rootfs已启动，无自动重启；`candidate_boot_continue_01.json` |
| `resume_original_boot.ps1 -LoginOnly -AuthorizedCandidateReadback` | 登录成功，系统检查通过到modinfo，最后journalctl超时124；`candidate_login_readback_01.json` |
| `resume_original_boot.ps1 -LoginOnly -AuthorizedReconnectReadOnly` | 首次COM5被占用，未发命令；用户关闭后第二次板0；`power_resume_readback_20261020_01/02.json` |
| `driver_board_step.ps1 -Step previous_candidate_log` | 0，1.722秒；按确切历史boot只读补回完整候选日志，`previous_candidate_kernel_log_01.json` |
| `kernel_repair/audit_candidate_boot_evidence.py` | 0；原始来源SHA、事实分账及日志解压校验，`candidate_boot_and_return_audit.json` |

`candidate_kernel_archived.txt` 44,979B与`power_resume_kernel.txt` 44,985B为完整journalctl查询结果的哈希核验解压件，不以UART慢传导致的原半截日志代替。

## 已修缺陷及测试

1. Windows `Path`远端字符串反斜杠：改为`.as_posix()`；3项路径/只读回读测试通过。错误额外创建的空目录 `/home/ubuntu/homeubuntua10-kernel-trial-20261020-v1` 保留，未删除；不影响启动。
2. 暂存器健康检查在每个小文件限速等待时反复fsync日志，导致外层131KiB接收上限：实际板流程完成，完整源日志经独立取回。PC已修为最多每2秒采样、仍在等待中检查温度；外层上限改1MiB且超限保存部分输出。**该节流修订未再上传/重跑板安装**；板运行源码SHA仍为`50e265b232344fa56d7b2c5713caa9cd11f44138bc88b730a2d93d75d0113a8e`。
3. 旧U-Boot `iminfo`使用逐Image `sha256+`，不输出新格式的`Verifying Hash Integrity ... OK`。补真实失败捕获回放及坏哈希反例，继续同一已加载候选，不再重启或重复计算。
4. journalctl直接经过115200串口输出超过5秒：原exit124保留。改在板内短时压缩后输出，并核验解压字节上限、SHA和流完整性；3项PC反例测试通过，本次旧候选历史日志和当前日志均实测取回0。
5. Linux最新27方法通过（备份11、暂存13含Linux原子不覆盖、上传路径3），`candidate_increment_linux_tests_01.json`。Windows暂存13方法有1项Linux专属skip，不以它代替Linux通过。
6. 候选启动安全23断言有记录；新增重接保护后共42安全断言、32动作计划均exit0（`power_resume_original_guard_tests_02.json`、`candidate_resume_plan_tests_01.json`）。不把多轮相加成独立覆盖数。

## 未解决的基线警告：不得等同“干净系统”

候选和重新启动的原包都存在：

- `x509_load_certificate_list`返回-22及WARNING/Call trace，`aes_ce_cipher`签名/所需key不可用，taint8704。PC签名核验不等于板内核信任链生效；新ZOCL尚未加载。
- 2020.2固件不支持部分pinctrl特性（日志要求2023.1+）、Invalid IO Standard及dummy regulator。
- 默认overlay firmware-name/resets移除时的泄漏警告。
- 以太网驱动曾报无效硬件地址；本次IP尚未配置。

以上不由“原系统也有”自动豁免。新内核的IRQ生命周期修复仍需一次空载加载/正常卸载实证；新诊断必须先停止并审查。没有改数学、固件、DT/CMA、频率或性能参数来掩盖平台问题。

## 剩余A10与下一步

1. 在新的明确维护窗口临时再启动候选，先读健康/日志，准备一次空载驱动/位流加载及普通卸载恢复，验证IRQ引用问题是否确实消失。上次单次试启动已使用，不暗自循环重启。
2. 上项通过后，一次小输入真实PL vector-add与受控小额BO地址/同步/内存双账；无规模扫描或长循环。
3. 完成实际profile、恢复限制、版本哈希和B/C环境交接。原数值回归保持CANCELLED_BY_USER，不补跑1000次。

P2：性能优化/压力/极限分配/活动DMA故障注入NOT_IMPLEMENTED或NOT_TESTED_SAFETY_EXCLUDED，不做不实性能结论。原A00—A17和失败记录保留，无代理、提交或推送。当前实际模型设置未能核实，记unknown。
