# A10 新板 Linux / XRT 只读接收记录

日期：2026-10-18。来源为用户实际手动串口命令输出、用户上传截图；不是助手直接 SSH 执行。退出码未采集，全部记为 null，不补写成功退出码。未修改板卡。

## 已观察信息

| 项目 | 实际值 / 限制 |
| --- | --- |
| 提示符 | `ubuntu@kria:~$`；已进入 Linux shell |
| `/etc/os-release` | Ubuntu 24.04.2 LTS，noble |
| `uname -m` | aarch64 |
| DT model | ZynqMP KV260 revB；仅设备树声明，不代替 EEPROM/FRU 核验 |
| `uname -r` | 6.8.0-1015-xilinx |
| `MemTotal` | 3996396 kB |
| `MemAvailable` | 3591720 kB，当时快照 |
| `CmaTotal` / `CmaFree` | 819200 / 814444 kB，当时快照，不与总内存重复相加 |
| `eth0` | UP，无 IPv4；IPv6 `fe80::20a:35ff:fe0f:2d70/64`；未验证 SSH |
| XRT | dpkg 显示 `ii xrt 2.18.0-0ubuntu1 arm64` |
| ZOCL | `modinfo zocl` -> `ERROR: Module zocl not found.` |
| 模块与源码查找 | `find /lib/modules/$(uname -r) /usr/src -iname '*zocl*' -print` 无输出 |
| 内核配置查询 | `grep -i zocl /boot/config-$(uname -r)` 无输出；不能由此单独否定所有外置驱动形式 |
| 当前 DRM | 只有 card0，driver 路径 `/sys/bus/platform/drivers/zynqmp-display`；不是已确认的 XRT 加速设备 |

用户名、提示符、内存数据不能代替完整平台兼容验收。先前 `ZynqMP>` 环境与 HDMI 图像变化原因仍未解释；不把时间先后写成 Micro-USB 导致复位的因果证据。

## 用户原样提供的 APT 关键输出

```text
ubuntu@kria:~$ apt-cache policy xrt xrt-dkms
xrt:
  Installed: 2.18.0-0ubuntu1
  Candidate: 2.18.0-0ubuntu1
  Version table:
 *** 2.18.0-0ubuntu1 100
        100 /var/lib/dpkg/status
     2.8.743-0ubuntu9 500
        500 http://ports.ubuntu.com/ubuntu-ports noble/universe arm64 Packages
xrt-dkms:
  Installed: (none)
  Candidate: 2.8.743-0ubuntu9
  Version table:
     2.8.743-0ubuntu9 500
        500 http://ports.ubuntu.com/ubuntu-ports noble/universe arm64 Packages
```

解释：2.18.0 在本机当前缓存中只见已安装状态，不能据此证明原始安装来源或断定官方从未提供下载。不能直接安装 2.8 驱动到 2.18 用户态环境；真实兼容性未验证。

## 电脑端官方资料核对（不在板上执行）

- Ubuntu noble `xrt-dkms` 公共包页为 2.8.743：https://packages.ubuntu.com/noble/xrt-dkms
- AMD KV260 Ubuntu24.04 文档区分系统启动与示例加速应用支持，注明示例应用尚未支持该版本；这不是所有自定义设计绝对不能运行的证明：https://xilinx.github.io/kria-apps-docs/kv260/2022.1/linux_boot/ubuntu_24_04/build/html/docs/boot.html
- 按上述官方指南列出的三个 PPA，在电脑通过 HTTPS 读取 noble/main/binary-arm64/Packages.gz：ubuntu-xilinx/default、xilinx-apps/xilinx-drivers、xilinx-apps/ppa；响应解压成功，按 Package 名包含 xrt 或 zocl 搜索均无匹配。此前未压缩 Packages URL 返回404，保留失败，不误称整个仓库不存在。压缩索引大小分别15319、971、2669字节。查询命令退出0，不安装包、不修改板端源。检查范围不包括全部 OEM 仓库，不能声称官方无匹配包。

## 边界与下一步

同日后续：用户已提供 xrt 的 dpkg 元数据；电脑端已在 AMD 文档所列 ubuntu-xilinx/sdk 的 noble ARM64 索引找到同源2.18.0驱动包，下载SHA256匹配，尚未构建/安装。此前“未找到匹配来源”为历史阶段。具体安装脚本风险、失败及命令结果见 `XRT_218_CANDIDATE_AUDIT.md`，不能仅凭包版本相同宣布平台配套完成。

状态：LINUX_SHELL_CONFIRMED_XRT_ZOCL_DEPLOYMENT_BLOCKED。BOARD compute、BO分配、vector-add、ARM交叉程序实际运行、恢复、完整A10均NOT_TESTED/NOT_PASSED。

保留现有2026.1工程，不为迁就板端静默降级工具。不执行apt install/upgrade、modprobe、xmutil loadapp、位流加载、内核/DT调整、QSPI/SD写入或复位。下一步取得已装XRT的包元数据，锁定官方来源后评估同版本驱动/内核/DT/应用ABI；重编译尽量在电脑完成，不在板上跑长负载。任何系统写入须另获授权。
