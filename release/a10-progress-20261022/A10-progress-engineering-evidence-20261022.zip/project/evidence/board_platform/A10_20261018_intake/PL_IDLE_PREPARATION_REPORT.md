# A10：配置恢复审查与空载试验准备（2026-10-19）

**状态：有新进展；尚未加载测试 PL，A10 未通过。等待一次空载配置验收的单独授权。** 前轮临时 IP、v3 单次 ARM 链接通过不等于新版 v4、PL、BO 或恢复通过。原阶段与失败证据不改写。

## 实际发现及修复

1. 已读取官方固定版本 [dfx-mgr 2024.2.0](https://github.com/Xilinx/dfx-mgr/tree/839e8e646c54a63326e36c48a7bd879f5e8efa31)、[libdfx 2024.2.0](https://github.com/Xilinx/libdfx/tree/af8d735fae286e7bc94c830a86c960598a4ac014)，电脑保留完整源码及摘要。上游 `dfx_cfg_remove` 不检查删除 overlay 的 `system()` 返回值；XRT_FLAT 也不能沿用 SIHA 的隔离流程来声称 DMA 已停止。
2. 为避免只依赖其他版本源码，额外从板上**只下载**实际 67512 字节 `libdfx.so.1.0`，与先前板上读取 SHA256 `5cea36c40a1c0617e84e6a06a3e535f71ee24732b2f42bbc3531430cc6162651` 一致；未在电脑执行此库，未改板库。实际 AArch64 `dfx_cfg_remove` 反汇编：`0x386c` 和 `0x38ac` 调用 system，后续没有检查调用返回，`0x38b4` 将 w0 设为 0。**这直接支持“退出码不足以确认卸载”**，不表示已测试真正卸载或故障恢复。反汇编原始命令/输出在 `libdfx_actual_remove_disassembly_v1.json`。
3. Launchpad kria 历史 dfx-mgr 源包版本匹配板上 `2024.2.0-0ubuntu1~xlnx1`；公开 libdfx 源包为 `2024.2.0-0ubuntu1~24.04.1~xlnx1`，与板上无 `24.04.1` 的版本仍不同。DSC 所列归档 SHA256/大小已核验，DSC 签名本次**未验证**，只作源码审查，不用于安装。源包补丁仅分别涉及安装头文件、符号版本；不把这些近似来源宣称为板上完整二进制的可复现构建。见 `dfx_source_audit_v1.json`。
4. 修复真实短测主机初始化阶段缺取消/健康/软时限检查的问题：生产路径使用 `checked_init`，在打开设备、load_xclbin、开 kernel、每个 BO 分配、map/run 创建前后核对；各步骤开始和完成写独立 trace。它不能强行中断挂住的驱动 ioctl，不能作为硬超时保证。正常初始化不启动计算；提交后的 BO 保留规则未弱化。
5. v4 PC **72 控制断言 + 同 72 ASan/UBSan + 4 信号夹具**与 Cortex-A53/XRT2.18 真交叉链接通过，构建/审计退出 0。v4 文件 345616 字节，SHA256 `88adf01921d3f19d60b9eff6c7611e9d233df72db0d0dce11d5e40e05c7b662b`；**未上传或板跑 v4**。原 v3 文件、源码构建快照和一次板上链接结果保留。

## 新板只读证据

`dfx_recovery_readonly.py` 从电脑经固定主机公钥 SSH 执行，整体设 6 秒限时，实际读取 **0.093786848 秒**，退出 0；温度 **31.008/33.697/32.345°C**，boot ID 与前次相同。无 FPGA 节点打开、驱动加载或 PL 调用。

实际恢复材料：

- `/etc/dfx-mgrd/default_firmware`：`k26-starter-kits`，保持原文件。
- 默认 bit.bin：1871196 字节，SHA256 `f9dfe95d14881a2768b2c0e6a36fc363635e8ae7882ecad9725d270490395d3e`。
- 默认 dtbo：526 字节，SHA256 `1e998ffd5d33a05da3746df3603e65603e1628006bc878209a836cc9bd3c4ae1`。
- `/dev/fpga0` 存在（仅 stat，不打开）。默认材料存在不等于恢复成功。
- 普通用户 `dfx-mgr-client -listPackage` 因 socket 权限拒绝，退出 255，未改权限。带本地 Tee 管道的 sudo 提示被行缓冲，取消的仅是本次待认证只读会话，退出 1，没有发送 sudo 密码或加载命令；随后移除管道，确认精确提示后使用已获用户授权的瞬时认证，查询退出 0。实际列表：k24 未激活、k26 `slot->handle 0->0`；以后执行前必须重新查询，不硬编码槽位。见 `dfx_listpackages_tool_observations.json`（明确人工转录工具输出），两个失败 stdout 文件保留。未记录凭据。

## 下一步空载配置范围——尚未授权/执行

电脑候选包 `platform/build/a10-idle-trial-20261019-v1/` 只含原固定 SHA 的 bit.bin、dtbo、shell.json、待授权计划；**没有计算程序、xclbin 或驱动安装脚本**。生成器 `prepare_idle_trial.py` 不连接板子；4 项单测通过，包含已有输出拒绝、错误退出码与残留 overlay/设备/引用拒绝。`confirm_removed` 目前只是 PC 验收判定函数，后续执行器仍须接入真实读回，不能把单测当已部署门禁。

授权请求已明确范围：暂存约 8 MB 配置包，临时加载已核验驱动及一次空载位流，核对后卸载并恢复默认。计算次数和计算 BO 均为 0；配置加载器自身需约 8 MiB 配置 DMA 缓冲。预计操作 1–2 分钟，不是挂起 ioctl 的硬上限承诺。

实施顺序必须独占中央板租约/共享锁，复核本次 boot、温度、模块 SHA、默认恢复 SHA、无设备持有者及新目录无覆盖；按实际 handle 卸载默认，独立读回，再临时加载驱动/空载位流；无 host/no xclbin，禁止启动核；读回 overlay、ZOCL 绑定/节点；按实际 handle 卸载测试，确认节点/绑定消失与引用为 0 后普通卸载驱动，再加载默认并读回。包中无 xclbin，dfx-mgr 的 update_env 不应写 vart.conf，但仍须前后摘要确认。libdfx 会临时复制 dtbo 到 `/lib/firmware`，需要纳入精确目标检查；不覆盖既有同名文件。

任何失败/未知状态停止后续变更，保留记录与租约，不自动重试、强制卸载、复位、断电或刷写。**空载卸载不证明运行中 DMA 故障恢复**；实际计算前还要审查并确认该路径。QSPI、SD 启动配置、默认固件及系统库均不在修改范围。正常清理必须先核实状态，不递归删除宽泛目录。

## 执行命令与退出码

完整 argv/输出见同名 JSON；工作目录 `C:\Patientqwen`。

| 动作 | 结果与文件 |
|---|---|
| 固定 tag 两次 `git clone --depth 1 --branch 2024.2.0` | 0/0，`dfx_mgr_source_acquire_v1.json`、`libdfx_source_acquire_v1.json` |
| `vadd_short/build_pc.sh .../a10-vadd-short-20261019-v4` | 0，`vadd_short_build_v4.json` |
| `vadd_short/audit_candidate.py ...` | 0，`vadd_short_audit_v4.json` 与 `vadd_short_candidate_v4.json` |
| SSH 有界 `dfx_recovery_readonly.py` | 0，`ssh_dfx_recovery_inventory_01.json` |
| SCP 精确下载 `/usr/lib/aarch64-linux-gnu/libdfx.so.1.0` 到 PC 新文件 | 0，67512 字节；独立 SHA 匹配，工具记录，不改远端 |
| PC `aarch64-linux-gnu-objdump -d --disassemble=dfx_cfg_remove .../board-libdfx.so.1.0` | 0，`libdfx_actual_remove_disassembly_v1.json` |
| 只读 DFX 列表，普通/缓冲取消/明确 sudo 提示重试 | 255 / 1 / 0，`dfx_listpackages_tool_observations.json` |
| `test_idle_trial.py` | 0，4 项，`idle_trial_tests_v1.json` |
| `prepare_idle_trial.py --root C:/Patientqwen --out platform/build/a10-idle-trial-20261019-v1` | 0，`idle_trial_prepare_v1.json` |
| `audit_dfx_review.py ...` | 0，`dfx_source_audit_run_v1.json` 与 `dfx_source_audit_v1.json` |

改动范围：`platform/qwen35/a10/vadd_short/{control.hpp,host.cpp,test_control.cpp,audit_candidate.py}`，新增只读采集、PC 包生成/判定/测试和来源核验脚本，新增本目录证据及状态增量。无模型、语音、计算核数学或性能参数改动，无提交/推送。

P0/P1 剩余：空载配置真测授权与闭环、实际计算和超时/恢复、20 长度与累计 1000 次真实比较、受控 BO 范围/同步和内存归属账。P2 优化/极限内存/长期压测不做。实际 BOARD_compute 仍 NOT_TESTED、0 次比较，不通过缩小 A10 范围结项。
