# A10 2026-10-20 上电重接（只读）

用户报告已上电登录并要求继续A10，随后确认已接好直连网线。本轮不推断为候选内核部署或软件重启授权；未上电/断电/复位、加载PL/模块、写启动文件、配置网络、分配BO或运行计算。COM5每次结束均关闭释放。

## 实际板状态

- 固定USB标识匹配COM5；已登录`ubuntu@kria`。machine-id SHA与原板一致。
- 新boot ID：`0b6e8bb1-2219-4f67-b4f2-0a3e9718eaa1`，KV260 revB、ARM64、原`6.8.0-1015-xilinx`。
- 默认`k26-starter-kits_image_1`仍在、FPGA operating，ZOCL未加载。内核taint 8704为本次采集前状态。
- MemTotal3996396KiB、MemAvailable3585328KiB、CmaTotal819200KiB、CmaFree814444KiB（首次重接快照）。
- 末次温度31.257/30.806/28.622°C。本轮各快照约28–31.4°C，不作为后续执行前的实时读数。
- 根`/dev/mmcblk1p2` ext4可用23503208KiB；启动`/dev/mmcblk1p1` vfat可用969470KiB。
- 原FIT SHA `b007246e409140c73485a057a0e7ccc1fac7116c14699837e4066e74be7532a9`、原启动脚本SHA `690fe1225a017a63796df1517b8b203fe9b7500597b2c5a61a0f524875ea2efc`与电脑备份一致，无重下载。
- 首次eth0 DOWN；用户接网线后UP/LOWER_UP、carrier1、1000Mbps；仅IPv6 link-local，无IPv4，无IPv4默认路由。未恢复旧内存临时连接。
- Linux chosen下两个候选bootloader版本属性均未读出内容，不等于U-Boot不存在/损坏。fw_printenv程序存在但未执行；kexec未在PATH找到；systemctl/journalctl存在。sudo缓存不可用，未发送密码。
- journalctl只读末80行包含本次正常开机默认overlay的两个既有警告：`/fpga-region/firmware-name`和`resets`卸载时可能泄漏。不是本轮加载测试引入，不当作“无警告内核”；该尾部也不是完整错误基线。

## 命令与结果

完整命令、原始串口和退出码均保存在本目录：

| 证据 | 结果 |
|---|---|
| `resume_20261020_contracts_01.json`：历史契约检查 | exit0 |
| `resume_20261020_config_01.json`：新版配置/契约检查 | exit0 |
| `uart_resume_20261020_01.json`：`driver_board_step.ps1 -Step resume_preflight` | 板命令exit0，0.389秒 |
| `resume_20261020_plan_tests_01.json` | exit0，27动作PC计划检查，无板执行 |
| `uart_boot_resume_20261020_01.json`：新boot锁定只读存储/启动哈希/网络 | 板命令exit124，6.302秒；最后nmcli状态查询3秒超时。前述哈希/存储/网线结果已有完整输出，不重跑；后续段未执行，不伪记整项PASS |
| `resume_20261020_plan_tests_02.json` | exit0，28动作PC计划检查；新增缺件采集禁止nmcli/变更 |
| `uart_resume_tools_20261020_01.json`：工具是否存在、sudo缓存、有限日志尾部和温度 | 板命令exit0，1.422秒；不重试nmcli，不声称NetworkManager故障已修复 |

改动：`platform/qwen35/a10/driver_board_step.ps1`新增两个本次boot锁定只读步骤；`test_driver_step.ps1`新增只读边界/长度/身份/温度/时限检查；状态与本报告更新。保留既有动作、失败及A00—A17进度。无模型/语音/数学/HLS/性能参数修改，无提交推送。

## 边界与下一步

A10仍NOT_PASSED；取消的20长度/1000次与重复数值回归不恢复。

下一步需要用户单独确认一次正常软件重启与串口启动日志采集，必要时在自动启动倒计时处暂停，仅查询真实U-Boot版本、命令和原启动环境。此动作会中断当前Linux会话；本轮未执行。没有核实真实U-Boot能力前不猜启动命令、不更改/保存环境、不写QSPI、不按FWUEN/RESET、不加载候选或自动循环重启。确认原系统启动路径后再决定如何返回原系统；若提示符/命令异常，停止发送进一步命令。

候选暂存及一次候选启动是后续另一项确切目标操作，不能由本次只读重接自动获得权限。之后仍需干净空载恢复与一次最小PL/小额BO证据。P2性能/压力/故障注入本轮未开展。
