# A10 接续：只读身份审计与短测主机程序

日期：2026-10-18。工程根 `C:\Patientqwen`，不是不存在的 `D:\patient-qwen`。原 A00—A17、旧板、原驱动实测、失败日志和未提交修改均保留。本增量 **A10 NOT_PASSED**，新板 vector-add 比较数仍为 0。

## 本次重新连接

用户返宿舍并重新接线后，电脑枚举到原 USB 标识的 COM5/COM6。对 COM5 只发送一个回车，3 秒未收到 Linux 登录 shell；没有发送密码或诊断命令，立即释放端口。`uart_resume_preflight_01.json` 中 `exit_code=null`、`handshake=""`、`closed=true`。主机包装命令退出 1；这不代表板端命令退出 1，也不证明板子损坏或已启动。当前启动 ID、温度、内存和网络均 **待本次上电重新观测**，不得沿用旧样本当实时值。

没有复位、关机、刷写、EEPROM 写入、驱动加载、PL 加载、BO 分配或计算。已请用户用 COM5 查看最后一行；不盲发密码，也不尝试 U-Boot 命令。

## 暂停前已取得、此次完成电脑分析的证据

`uart_fru_kernel_readonly_01.json`：板端只读命令退出 0，用时 1.1555541 秒；温度 30.394/33.013/33.339°C，MemAvailable 3569628 KiB、CmaFree 814444 KiB。各 EEPROM 仅读取前 1024 字节，没有全片读取或写入。身份区均为偏移 8、长度 96 字节，共同头和身份区校验均正确：

| 来源 | 产品 | 序号 | 零基字节偏移处保留的问题 |
|---|---|---|---|
| 1-0050 | SMK-K26-XCL2G-ED | XFL11QVRFBRL | 137：链指向 `ff ff ff ff ff`，头校验/格式不合法 |
| 1-0051 | SCK-KV-G | XFL1CYYPZ52Y | 122：链指向 `ff ff ff ff ff`，头校验/格式不合法 |

新增 `audit_fru_capture.py` 独立验证来源 SHA256、实际 BEGIN/END 输出、数据大小、共同头、身份区和有界记录链；命令回显不能冒充结果。不越过坏链寻找“看起来正确”的后续记录，不修补原字节，不把身份区通过升级为整个 EEPROM 通过。结果和来源 SHA 见 `fru_identity_audit_v1.json`。10 个 PC 单元测试通过，包括手算多记录校验、截断、坏校验、越界、无结束标志和真实失败样本。

[Intel FRU 定义第 8/11/13/16 节](https://www.intel.com/content/dam/www/public/us/en/documents/specification-updates/ipmi-platform-mgt-fru-info-storage-def-v1-0-rev-1-3-spec-update.pdf)用于解析。 [AMD 已知问题](https://xilinx-wiki.atlassian.net/wiki/plugins/viewsource/viewpagesrc.action?pageId=3040313416)说明部分 Starter Kit 的制造记录字节可触发较新工具的相同错误。**本板表现与该类问题相符，但制造原因未经独立证明**；不据此判物理损坏，也无须为继续身份审查而写 EEPROM。没有运行忽略错误选项来制造 PASS。

已安装 vmlinuz 的 SHA1 `b136ee87dcb9fa293e1a9f212ea2f5564a71c532` 与 `uart_boot_fit_xrt_origin_01.json` 中 FIT kernel-1 的摘要一致，字节数同为 20278816。证明这两份文件内容摘要一致；不证明此刻实际选中的启动配置或固件版本。PMUFW API/旧固件功能警告仍保留，QSPI 元数据字符串不当成精确当前版本。

## 暂停前已实现的短测程序（此次接续，不重复构建）

路径 `platform/qwen35/a10/vadd_short/`；实际 ELF 在 `platform/build/a10-vadd-short-20261018-v3/a10-vadd-short`，277392 字节，SHA256 `d25040172f0bb67b04e2e85233a2ae4a27e85cc6314de4beb9994b60d4f0243d`。复用既有 Cortex-A53 SDK、准确 XRT 2.18 头和库进行真实 ARM64 链接；无工具重装。

- 保持资源所有者在异常处理范围外；提交前即进入在途状态。超时/异常/未知终态停止消费输出、不重试，保留进程及 BO，不能因 C++ 栈展开释放可能仍活动的缓冲。
- 只有明确 COMPLETED 后才允许同步回读，校验真实输入推导的输出和尾部哨兵。使用 metadata `group_id`；不使用 CPU 假算替代 FPGA。
- 默认审批为 false；准确启动/机器标识、库和位流哈希、中央租约、独占锁、温度和内存门禁未满足时不启动。
- 单次 1—20 项，项间休息 100 ms；计算批次软限时 10 s、提交轮询软限时 1 s，3 个 16448 字节 BO。温度 60°C 保守停止门禁，不是额定温度声明。没有自动执行 1000 次。
- 原 `platform/a1/vadd/host.cpp` 保留，**不得运行其旧长测入口**。

PC 60 项控制断言及同 60 项 ASan/UBSan 通过；4 种信号保留测试通过（纯 PC 子进程，无 XRT/BO）。v1 编译因缩进告警失败、v2 因缺 uuid 链接失败，修复后 v3 退出 0；三份快照和失败日志均保留。详见 `vadd_short_build_v1.json`、`...v2.json`、`...v3.json` 和 `vadd_short_candidate.json`。这些不是板端计算或恢复证据。

限制：用户态超时不能保证中断卡住的 ioctl；保留 BO 不等于 PL 已停止；SIGKILL/断电不受该机制保护。精确平台恢复尚未验收，禁止外部 timeout/kill 包裹真实 XRT 测试，也不自动 abort/reset。完整主机初始化与取消路径还需复核；PC 控制替身测试不覆盖所有真实驱动故障。

## XRT 来源差异仍独立待核验

已签名索引中的 `xrt_2.18.0-0ubuntu1_arm64.deb`（11158000 字节）SHA256 `98d0404fa721416b40ff1472bda71a8bf36062ba8ddf54325685f36ac05bfab6`。只在电脑解包、未安装板端。

板上与下载包版本号相同，但 coreutil/core 实际哈希不同；各自均匹配自己的 dpkg MD5 清单，version.h 构建日期字段也不同。因此不能仅凭版本号证明相同构建，亦不能据此断言文件损坏。证据 `uart_userspace_dependencies_01.json`、`uart_boot_fit_xrt_origin_01.json`、`uart_userspace_origin_followup_01.json`。内核、工具链、XRT 与既有位流的实际组合仍未通过计算验证。

## 执行命令、退出码和分域结果

工作目录 `C:\Patientqwen`；Python 为 `platform/local/a1/venv/Scripts/python.exe`。

| 命令/证据 | 域与结果 |
|---|---|
| `python scripts/release/check_contracts.py` | 本次 PC 退出 0，历史契约保护通过 |
| `python scripts/release/qwen35_config.py` | 本次 PC 退出 0，新契约配置通过；不是 runtime PASS |
| `test_driver_step.ps1` | 本次 PC 17 动作计划通过；`driver_step_plan_tests_v7.txt` |
| `driver_board_step.ps1 -Step resume_preflight -OutputPath .../uart_resume_preflight_01.json` | 主机退出 1；板端未执行，退出码 null，串口关闭 |
| `python platform/qwen35/a10/test_fru_capture.py` | PC 退出 0，10 方法；`fru_parser_tests_v1.json` |
| `python platform/qwen35/a10/audit_fru_capture.py .../uart_fru_kernel_readonly_01.json --output .../fru_identity_audit_v1.json` | PC 审计运行退出 0；扩展记录失败仍保留；`fru_parser_run_v1.json` |
| `driver_board_step.ps1 -Step fru_kernel_readonly ...`（暂停前） | BOARD_READONLY 退出 0，非计算；原 JSON 完整命令/原始串口/SHA |
| `boot_fit_and_xrt_origin` / `userspace_origin_followup`（暂停前） | 127 / 0：板端缺 strings 命令，后用有界 Python 只读提取；原失败保留 |
| `wsl ... bash .../vadd_short/build_pc.sh ...-v1` / `...-v2 arm-only` / `...-v3`（暂停前） | 1 / 1 / 0；准确 argv 与输出在三个 build JSON |
| 真板 ARM 用户程序、PL、BO、vector-add、DMA 恢复 | NOT_TESTED；未以 PC/驱动加载代替 |

## 下一步和设计分账

P0/P1：恢复本次登录提示并核对新 boot ID/健康；补 XRT 同构建/ABI 核验、完整短测主机及精确平台停止恢复审查；完成这些后就准确产物和有界首次 PL 测试另行请求授权。先最小单次，再短批次累计 20 长度/1000 真比较；累计要求未取消，但绝不直接运行长时高负荷循环。BO 范围/同步/安全重新加载仍待实测。CMA/PSS/BO 不重复累加；3200 MiB 包络未验证。

已解决差距：独立身份区校验、错误链定位、FIT/安装内核摘要对应、活动 BO 所有权控制候选和 PC 负路径。尚无性能提升或实板计算指标，值保持 null/NOT_TESTED。

P2：自动联网部署、持久驱动安装、吞吐/并行/AXI 优化、持续温度看板均未实施，不为这些增加板上负荷。无提交、推送或模型/语音/计算核/数学修改。
