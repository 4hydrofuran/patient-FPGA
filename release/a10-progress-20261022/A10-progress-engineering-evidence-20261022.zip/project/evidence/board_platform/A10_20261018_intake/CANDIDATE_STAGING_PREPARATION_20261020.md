# A10 候选并存暂存准备（尚未上板写入）

2026-10-20接续持久目标。上一轮完成原系统真实返回，本轮取得新的PC暂存演练和板只读目标核验，属于进展；不是等待已停止的构建，也不是A10通过。

## 已完成

- 当前实际板boot仍`eb429b2f-66aa-4959-8610-bfcfabcf0202`，原6.8.0-1015-xilinx、默认overlay、ZOCL未加载、FPGA operating。身份核验通过。
- 末次31.179/34.319/33.448°C；无本轮板计算或压力任务。只读采集结束COM5已释放。
- 原`/usr/lib/modules/6.8.0-1015-xilinx`占用119104KiB；唯一列出的符号链接build指向原headers。**这是清单和占用，不是完整备份成功。**
- 三个拟议新增目标均不存在：`/home/ubuntu/a10-kernel-trial-20261020-v1`、`/usr/lib/modules/6.8.12-a10irq1`、`/boot/firmware/a10-candidate-20261020.fit`。
- 根分区可用23490716KiB，启动分区969470KiB。SSH监听22，NetworkManager D-Bus只读查询返回`u 20`；不将该值当作联网成功。
- Windows现有以太网接口index15，IPv4含192.168.2.1/24，IPv6 link-local。固定SSH主机公钥的IPv6单次探测5秒超时exit255；没有发送凭据、修改IP/防火墙/电脑网络或循环重连。此前可用的临时IPv4尚未恢复。

## 新代码与测试

`platform/qwen35/a10/kernel_repair/stage_candidate_board.py`：

- 默认只打印计划，必须显式execute-authorized才可能执行。ARM64/root/原内核/固定boot/板身份/默认配置、磁盘余量、原启动文件哈希门禁。
- 仅新增独立候选模块目录和不同名FIT；部分失败保留`.partial`，不清理、不覆盖、不自动重试，不加载模块、不重启、不调用PL。
- 固定candidate.fit与modules.tar.gz的大小/SHA。拒绝绝对/穿越/错误版本路径、重复条目、软硬链接、设备节点及额外文件；限定6500文件、单文件32MiB、总512MiB。
- 单线程nice19，限速8MiB/s，温度55°C门禁、MemAvailable至少1GiB；逐文件回读，显式Linux renameat2 NOREPLACE发布和目标文件系统flush。不改变原release、DT/CMA/频率或数学。
- 无“自动回滚成功”承诺。此程序尚未真实板运行；受保护写入入口的板侧完整行为尚未验证。

`test_stage_candidate_board.py`最新12方法：路径、链接/特殊文件、大小、计数、重复、预算、禁止覆盖、真实Linux原子不覆盖、完整读回损坏拒绝、热门禁保留部分文件、限速不漏等待及默认计划边界。

`rehearse_candidate_stage.py`在WSL电脑以真实固定SHA的包解包到全新`/home/member-a/a10-kernel-full-20261019-v1/pc-stage-rehearsal-20261020-v1`：6218模块、6231文件、389973937字节逐文件回读匹配，驱动SHA匹配。没有运行板root安装入口或复制至板。这是新暂存器的实包验证，不是重复重编译。

`driver_board_step.ps1`和`test_driver_step.ps1`新增固定当前boot的只读模块/目标/容量/服务清单，PC动作计划增至29。

| 证据（本目录） | 实际命令/结果 |
|---|---|
| `uart_candidate_preflight_20261020_01.json` | `driver_board_step.ps1 -Step resume_preflight`，板exit0，0.360秒 |
| `candidate_stage_tests_01.json`、`_02.json` | WSL `python3 -m unittest -v test_stage_candidate_board`，9方法exit0 |
| `candidate_stage_tests_03.json` | 同入口补健康/限速/损坏检查，12方法exit0 |
| `candidate_stage_rehearsal_01.json` | WSL `python3 …/rehearse_candidate_stage.py`，exit0，14.549秒（含宿主启动开销） |
| `candidate_inventory_plan_tests_01.json` | PowerShell `test_driver_step.ps1`，29动作计划exit0，无板写入 |
| `uart_candidate_inventory_20261020_01.json` | `driver_board_step.ps1 -Step candidate_inventory_readonly_20261020`，板exit0，1.658秒 |
| `ssh_ipv6_pinned_probe_01.json` | Windows SSH固定公钥、BatchMode、5秒连接；exit255，连接超时保留 |

记录器均`platform/local/a1/venv/Scripts/python.exe platform/a1/record.py --log <全新证据> -- <上述命令>`；完整argv/stdout/stderr保留。不把多轮测试相加为独立覆盖，不把PC0称为板安装通过。旧/新契约检查复用本阶段此前成功证据，本轮未改契约。

## 拟议下一步范围与尚缺门禁

已向用户提出专项确认：新增上述准确目标，保持原image.fit/boot.scr.uimg不变；正常重启一次，用U-Boot临时参数试启动候选，只查系统/温度/驱动，不做计算；不保存U-Boot环境、不刷QSPI。**本报告写入时尚未收到本次专项回复，不能执行新候选板写入/启动。**

拟议输入沿用已核验包：

- FIT65552664B，SHA `a393f397a673a2f3636c8b9f85d8a59f7257c24d33c34d28a67b11c410a11b81`。
- 模块包108698233B，SHA `c1ad278f7bcfc4137fc0013a98db593487ea5f22a1eff0acfddaf2e963255cf2`。

执行前还须恢复已授权类型的仅内存板端直连IPv4（重新核实本次boot/路径），完成原模块树只读备份和电脑核验，再绑定上传源/目标、工具SHA与串口维护窗口。新的暂存入口必须由该门禁流程调用，不能单凭脚本存在直接执行。

候选bootm前要先验证实际旧U-Boot能解析/校验候选FIT的SHA256；不从原包SHA1成功推断新包必然可加载。默认bootcmd保持原包；候选如回到U-Boot可审查后恢复原包；若完全无响应，不自动复位，可能需要用户现场协助。这不是已经实测的候选回滚。

A10仍NOT_PASSED：候选启动/干净空载恢复/一次最小PL与小BO/最终交付未完成。原固件pinctrl兼容警告仍OPEN。取消的20长度/1000数值回归不恢复。P2性能、压力、极限内存、在途故障注入均未做。无模型/语音/计算核改动、无提交推送。
