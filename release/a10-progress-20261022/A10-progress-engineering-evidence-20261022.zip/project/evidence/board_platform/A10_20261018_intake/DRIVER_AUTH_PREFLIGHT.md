# A10 驱动加载授权后预检（未加载）

2026-10-18用户批准独立目录暂存和一次短时驱动加载，并要求安全推进A10。该授权不扩大到PL/DTBO加载、刷写、复位、强制卸载或压力测试。

## 实际结果

- 新采集uart_readonly_06_driver_preflight.json：Linux6.8.0-1015-xilinx、ubuntu uid1000；温度34.023/32.516/31.435°C，MemAvailable3578232KiB、CmaFree814444KiB。
- 模块加载禁用值0，lockdown为[none]；未改变任何安全策略。ZOCL仍未加载。
- 加载前内核taint=8704，尚须读取特权内核日志解释，不能把原有taint记作本次驱动造成。普通dmesg读取被拒绝。
- sudo -n true真实退出1，提示需要密码。已请用户手动验证；用户随后明确授权代做本次验证，但串口单次CR/等待未确认Linux shell，因此停止，没有发送密码或驱动命令。端口在finally关闭，未继续试密码、自动登录或发送中断；终端当前状态待用户确认。
- 没有创建板端暂存目录、没有网络下载到板端、没有insmod/rmmod、没有PL/BO/计算，也未启动电脑HTTP传输服务。

## 电脑准备

- 现有SDK objcopy --strip-debug仅去调试信息，保留完整原件。候选464752字节，SHA256=545df42c8b66396dd847ccd6a280f19d9a0051d36e2e75c1ec84437caca328a9；再次检查ARM64/vermagic及238符号CRC通过（zocl_stripped_audit.json）。这是待传输候选，不是已上板文件。
- driver_board_step.ps1提供固定preflight/stage/load/post/unload动作，每步独立执行、单独证据、未知状态停止。load校验内核、温度、lockdown、modules_disabled、模块缺席和文件哈希；unload禁止force并先查refcnt/holders/DT节点。未执行任何变更动作。
- serve_driver_once.py仅拟在电脑直连网卡IPv6开放单个固定哈希文件、限制板端已知IPv6来源、单次请求/40秒窗口；不开放目录、不改防火墙、不改板端IP。未启动。
- test_driver_step.ps1：5个动作静态计划/语法检查通过，exit0；Python语法检查exit0；读取计划和哈希不构成板测通过。

下一步先恢复明确的已登录shell并取得sudo验证，再读取特权日志；若原有严重故障原因不明，则不加载。A10整体NOT_PASSED。密码不写入工程文件、日志或仓库。
