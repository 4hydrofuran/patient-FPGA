# irq2 已授权试启动：启动前门禁停止，实际未重启

用户允许一次正常软件重启、临时启动 irq2 并检查启动/内核/温度/日志，不加载测试位流、不计算、不改默认启动或 QSPI，异常停止不自动重试。本次没有发送重启或 bootm，授权的实际启动次数尚未使用；没有删除或更改板端文件。

## 命令与证据

所有路径相对于 `C:/Patientqwen`，证据均在本目录。

1. `powershell.exe -NoProfile -ExecutionPolicy Bypass -File platform/qwen35/a10/collect_readonly_uart.ps1 -Phase recovery_readback -OutputPath evidence/board_platform/A10_20261018_intake/irq2_preboot_readonly_20261021_01.json`：退出 0；原系统 `6.8.0-1015-xilinx`、boot `bf3796f0-9785-4afd-a617-3ad578a24d10`、默认 overlay 仍在，原固件/overlay 警告保留。
2. `powershell.exe -NoProfile -ExecutionPolicy Bypass -File platform/qwen35/a10/boot_candidate_once.ps1 -Candidate irq2 -ExpectedBootId bf3796f0-9785-4afd-a617-3ad578a24d10 -AuthorizedOnce -OutputPath evidence/board_platform/A10_20261018_intake/irq2_boot_once_20261021_01.json`：工具记录退出 1；脚本设计失败出口为 2，实际进程码以工具记录为准。板端 preflight marker=1。status=STOPPED_BEFORE_REBOOT，reboot_commands_sent=0、candidate_boot_commands_sent=0。
3. `collect_readonly_uart.ps1 -Phase irq2_preboot_diagnose -OutputPath .../irq2_preboot_diagnose_20261021_01.json`：退出 0。原 FIT/脚本、新 FIT/驱动四个 SHA256 均匹配，stage-result 最终事件正确；`/var/lock/kv260-a1/active` 确实存在。
4. `collect_readonly_uart.ps1 -Phase lease_identity -OutputPath .../irq2_preboot_lease_20261021_01.json`：退出 0。只输出租约身份白名单字段，不输出 token。部分附带只读命令如 readlink 可能权限受限，复合命令最终 0 不代表每条均成功。

## 原因与安全判断

租约 owner=A、scope=A10_MINIMAL_IDLE_THEN_ONE，identity 指向旧 irq1 启动 `751e617d-c003-4b99-be03-bb5c78235d24`，pid=5743 当前不存在，compute_authorized=false；SHA256=`ac3392c1a2a98d738445c10009bcabad464c2c68ed2017f43a9f223f58173ebd`。此前失败明确保留 active 租约，当前阻断与该历史一致。不是新候选文件损坏，不是已发生 irq2 启动失败。

另见 PID1445 是 snap.kria-dashboard.service.service 下的 python3，不是租约 PID，不能杀掉它或据此断定运行着旧试验。当前 ZOCL 缺席，默认配置保留；没有用状态文件本身当作进程活跃证据。

本次温度 28.575/30.479/30.479°C；无计算或压力测试。串口已释放。`collect_readonly_uart.ps1` 新增两个固定只读诊断阶段，未新增板端修改入口。

## 下一步

由于授权明确“异常停止、不自动重试”，本次停止在此。需用户确认：只归档上述精确旧启动租约（保留原字节及失败证据，不删除），重新验证无当前持有者，再继续尚未实际执行的那一次 irq2 试启动。不允许通过忽略 active 检查、改为成功或强制重启推进。

A10=NOT_PASSED；irq2 boot、生命周期、一次小计算与恢复仍未完成。已取消的回归和压力测试不恢复。
