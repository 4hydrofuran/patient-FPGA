# A10 安全修订及剩余工作（2026-10-19）

**A10 尚未通过。20长度/1000次及重复数值回归已由用户取消，不是PASS，也不自动延期补跑。** 新验收条件见 `docs/A10_ACCEPTANCE_SAFE_20261019.md`。保留最小真实通路、受控小BO/同步、正常恢复；不做压力、极限分配或真实故障注入。

## 已完成的增量

- 状态/决策/测试矩阵明确覆盖历史数值门槛；历史CSV、失败、A00—A17证据不改。
- 新内核日志门禁已接入PC执行器：每次状态变更前后读取完整内核日志，核对boot和日志连续性；新增错误/警告、截断、读取失败会锁住后续状态变更。无默认白名单，无自动修复/卸载/复位。旧板上脚本不变，新版本尚未部署。
- 新门禁9项测试、受影响原idle/cleanup 11项测试通过；引用路径/卸载循环模型8项测试通过，共28方法，均PC、exit0，不是数值回归或BOARD计算。
- 精确Ubuntu源码包 `linux-xilinx 6.8.0-1015.16` 已下载、按公开SHA核对，仅在电脑解出13个相关文件并无fuzz应用该版本补丁。没有重编译/安装内核、修改板端DT或驱动。
- 板上只执行一次无需sudo的配置grep（exit0），确认 `CONFIG_OF_DYNAMIC=y`、`CONFIG_OF_OVERLAY=y`、`CONFIG_IRQCHIP_XILINX_INTC_MODULE_SUPPORT_EXPERIMENTAL=y`。SSH已退出。没有新PL加载/计算/BO/复位/刷写。

## 内核源码定位：不是仅凭65猜测

来源：[Ubuntu精确源码包](https://launchpad.net/ubuntu/+source/linux-xilinx/6.8.0-1015.16)。本地原包SHA `26512115972bdf017a4ac826cc7d3e9b0ba397d4f85cd330e4e4ff54c78061c8`，发行补丁SHA `2f73ef45d2ddbb70e540fc657bf3c74a7c45d3b0663c10e0a6e45f723c332954`。本次核对公开SHA，不声称新验证了DSC签名链或运行中内核二进制；沿用此前FIT/安装内核来源证据。

1. 精确源码 `drivers/of/irq.c:342` 的 `of_irq_parse_one()`：`interrupts-extended` 成功分支获取phandle引用后直接返回 `of_irq_parse_raw()`；后者入口再获取一个引用，直接控制器成功路径不释放原引用。`of_irq_get()` 和 `of_link_property()` 各只释放调用者返回的一个引用。旧 `interrupt-parent`/`interrupts` 路径则有额外的父节点put。
2. 当前固定DT确有32项 `interrupts-extended`，与原PC合并DT审计相符。所有权模型每次完整枚举额外32引用，两次枚举得到基准1+64=65，与真板错误一致。**模型能解释观察，但没有对真实内核逐次调用做追踪，不能声称唯一原因已动态证明。** 先前“of_irq_count可能负责”的猜想不作为结论：实际平台分配代码未使用该旧计数路径。
3. 另发现精确源码 `drivers/irqchip/irq-xilinx-intc.c:282` 的卸载循环用会变化的 `root_domain->mapcount` 作上界，而 `irq_dispose_mapping()` 对应释放路径会减小它。模型在映射0..31时只清理0..15；稀疏映射也可能遗漏。板配置启用了这一experimental实现。**这是实际版本源码的独立风险，不等于已经读出板上残留16个映射。** 固定上界的PC模型可清空，但不是已编译或部署的内核补丁。

因此不能只把引用错误加入白名单、把32改小、强行put64次，或用反复加载试错。也不能只改DT绕过第一条就宣称卸载安全。板上当前默认配置读回成功不等于加速配置可安全反复重载。

## 分域状态与资源账

| 域 | 当前结论 |
|---|---|
| 身份/系统 | KV260 revB、aarch64、Ubuntu24.04.2、6.8.0-1015-xilinx、XRT2.18；FRU身份区已验证，扩展记录告警保留 |
| ARM程序 | 已有一次真实linkage-only退出0；不打开FPGA，复用证据不重跑 |
| PL空载 | 已有一次真实加载，后续检查失败保留；默认已正常恢复，但新增内核错误未解决 |
| 数值回归 | CANCELLED_BY_USER，不计通过/缺件、不自动补跑 |
| 单次最小PL输入输出 | NOT_TESTED（0次），等待平台风险解除 |
| BO实际地址/分配/sync | NOT_TESTED/null；DT银行范围不是实测可达范围 |
| 正常恢复 | 默认状态恢复已读回；无错误恢复验收未通过 |
| 故意故障注入/压力/P2性能 | NOT_TESTED_SAFETY_EXCLUDED / NOT_IMPLEMENTED，不执行 |

最后完整恢复快照：MemTotal3996396KiB、MemAvailable3558424KiB、CmaTotal819200KiB、CmaFree814444KiB，温度28.824/30.122/29.531°C。这是 `cleanup-result.jsonl` 中的历史恢复快照，不伪装成本轮新测温。

- 物理归属账：CMA属于物理内存集合的一部分，不加到MemTotal；已用CMA不等于本工程BO。
- 进程观测账：真实计算进程尚未启动，PSS/RSS/页驻留/工作区峰值均null；不能写0或借用电脑值。
- 小额测试计划：现有候选3个16448字节BO，共49344字节（未测）；配置加载缓冲、运行时内部BO/内核对象另计，不能把该逻辑BO总量称全部物理峰值。
- 不验证最大可分配量/全部低高地址；3200MiB包络仍未证实。不得通过调DT/CMA掩盖不足。

## 命令、退出码和失败保留

工程根 `C:\Patientqwen`；PY=`platform/local/a1/venv/Scripts/python.exe`。下列命令通过 `platform/a1/record.py --log ... -- ...` 独占记录完整argv/stdout/stderr/退出码：

| 命令/步骤 | 退出码 | 记录（本目录） |
|---|---:|---|
| curl下载精确orig/diff，核对SHA | 0 / 0 | `kernel_source_orig_download_v1.json`、`kernel_source_diff_download_v1.json` |
| `extract_kernel_refaudit.py` 首次错误假定git diff格式 | 1 | `kernel_source_extract_v1.json`，无输出目录生成 |
| 修为发行统一diff格式，提取第一/扩展子集 | 0 / 0 | `kernel_source_extract_v2.json`、`kernel_source_extract_v3.json` |
| `patch --batch --forward --fuzz=0 -p1 -i selected-package.patch` 两个独立子集 | 0 / 0 | `kernel_source_patch_v1.json`、`kernel_source_patch_v2.json` |
| `python -m unittest discover -s platform/qwen35/a10 -p test_kernel_log_gate.py -v` | 0 | `kernel_log_gate_tests_v1.json`，9项 |
| 同命令 `-p test_idle*py` | 0 | `idle_after_log_gate_tests_v1.json`，11项 |
| 源码提取函数首轮误匹配注释，审计拒绝 | 1 | `kernel_refs_pc_audit_v1.json`，未生成成功报告 |
| 补注释回归后 `-p test_kernel_refs_pc.py` | 0 | `kernel_refs_pc_tests_v2.json`，8项；初版7项也保留 |
| `audit_kernel_refs_pc.py --source .../selected-v2 --dt-audit .../actual_dt_overlay_pc_audit_v2.json --output .../kernel_refs_pc_report_v1.json` | 0 | `kernel_refs_pc_audit_v2.json`，9条源路径断言 |
| 板上配置grep，只读 | 0 | `ssh_irq_config_readonly_v1.json` |

辅助只读探路曾遇git.launchpad HTTP403、Windows GBK解码错误、WSL无rg/dtc裸命令、错误通配符；未安装工具，通过明确UTF8/现有SDK绝对路径读取解决。解码的独立overlay仍有原有dtc警告，不将它称无警告验收；合并父节点格式沿用原静态审计。

## 剩余与下一步

不需要用户按RESET/FWUEN、重新刷卡或继续测电。暂不重新加载测试PL。

下一项是**电脑侧制定匹配内核的引用/IRQ卸载修复和回退方案**，确认补丁及实际映射所有权；涉及板端换内核、启动介质或重启时另行确认具体范围，不能从取消数值回归推断刷写授权。风险解决后才做一次最小通路/小BO同步和正常恢复。不能以安全性名义把这两个已知风险改成PASS。

B/C当前可使用环境说明做电脑适配，**尚未开放该板PL测试租约**。历史1000次门槛取消不等于开放模型演示；A11/A12独立要求不变。
