# A10 新板连接接续：等待用户手动登录

2026-10-18，用户确认SD在板上、通电、网线直连电脑、用户名ubuntu。该声明不等于型号/系统/刷机内容已验证。本轮保留短时、低负载、无刷写/无复位限制。

真实读取：Windows PnP显示COM5/COM6；COM5设备标识FTDIBUS VID0403 PID6011 XFL1CYYPZ52YB，COM6为同设备C通道。以太网链路Up，1Gbps；电脑地址192.168.2.1/24、192.168.1.20/24，已有邻居表没有确认的板子单播IP。未扫描子网、未改IP/DHCP/ICS。

此前纯接收每口5秒均0字符。此次COM5在115200 8N1、无流控、DTR/RTS均false下打开，先接收300ms，无输出后仅发送一个CR，等待5秒。命令退出0，返回15字符：`\r\r\nkria login: `。未发送用户名、密码、shell或U-Boot命令。串口已经关闭。

这证明COM5能收到登录提示，不证明实际发行版/版本、CPU架构、KV260 FRU、XRT、DT、内存或温度。不要把用户名ubuntu写成Ubuntu系统已确认。

PC检查：旧check_contracts.py、新qwen35_config.py均退出0。准备手动终端前检查a1 Python环境，`import serial`退出1，`serial.tools.miniterm --help`退出1，缺少pyserial；未安装新包，保留该失败。改用已有.NET SerialPort的PC手动交互桥，脚本不自动登录，不记录密码或会话内容，不运行板端测试。此脚本仅用于本次已核实的COM5 USB身份，变更即拒绝。

手动入口：`platform/qwen35/a10/manual_uart_login.ps1`；Ctrl+]关闭电脑串口终端，不向板子发退出/重启命令。五分钟只是在电脑等待人工输入，不是板端计算负载。

该脚本PowerShell AST语法检查退出0，SHA256 `d74cb618279e6582345ffd3aa7e4a769278f0fb4684fa3de56607eebb4b7af40`。电脑执行策略原值RemoteSigned，未修改。实际执行`Start-Process powershell.exe -ArgumentList '-NoProfile','-File','C:/Patientqwen/platform/qwen35/a10/manual_uart_login.ps1' -WindowStyle Normal`打开供用户亲自输入的窗口，启动命令退出0，返回PID19364；仅证明已启动进程，不证明登录成功。没有捕获或记录该窗口的密码/会话输出。

分域：PC契约PASS；BOARD连接为LOGIN_PROMPT_RECEIVED；实际系统采集、ARM64执行、BO/vector-add/恢复、A10完整验收均NOT_TESTED/NOT_PASSED。不执行旧1000次测试，不以提示符证明板测通过。

下一步：用户手动登录，释放串口后，进行一次有时限的只读OS/DT/内存/温度/XRT采集。实际平台匹配与安全调用门禁闭环前不加载位流。设备供电、复位、固件、SD与网络配置未改变；仅在电脑添加说明/交互工具/状态记录，未commit或push。

## 同日再次接续（用户“重新进行一下A10”）

重新核对COM5/COM6的PnP身份不变，旧手动终端进程未在运行，以太网邻居表仍无确认的板子IP。COM5在相同115200/8N1、DTR/RTS false下仅发送一次CR，2秒后ReadExisting返回单个`?`，命令退出0；该文本不是可确认的登录/shell提示，不能以旧`kria login:`冒充此次状态。随后被动接收3秒没有新增字节，未继续尝试命令或变更波特率。再次打开人工终端PID34552（启动退出0），等待用户查看界面；没有自动登录。可能的串口编码/通信状态原因未确定，不诊断为板卡损坏。板端系统采集和全部计算测试仍NOT_TESTED。
