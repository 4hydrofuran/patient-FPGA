# A10 新板短时只读采集：PARTIAL，尚未通过计算验收

2026-10-18；用户明确授权“已关闭，可以只读采集”。PROJECT_ROOT=C:/Patientqwen。本次没有安装驱动、加载位流、执行计算测试、网络配置、复位、刷写或主动板端文件写入；正常交互shell自身可能记录命令历史。COM5每次finally关闭，现已释放。未获取密码或自动登录。

## 实测与限制

- 真实Linux串口：Ubuntu24.04.2 LTS，aarch64，6.8.0-1015-xilinx；DT为ZynqMP KV260 revB，FRU/实物序列号独立核验未完成。
- CPU part0xd03，features=fp asimd evtstrm crc32 cpuid，cpu0观察频率1333333kHz；未运行项目ARM程序，不能证明其指令兼容。
- MemTotal3996396KiB，MemAvailable3578496KiB，CmaTotal819200KiB，CmaFree814444KiB。CMA是保留/子集，不能与MemTotal、进程PSS或BO重复相加。3200MiB模型包络未验收。
- hwmon/ams三个温度33.246、32.065、30.798°C。thermal_zone路径没有返回温度不等于没有传感器。已给采集工具增加hwmon门禁，电脑模式测试通过；不为这一修改重跑板端已有效采集。
- DT根address/size各2 cells，memory reg为低区0起2146435072字节、高区0x800000000起2147483648字节。仅描述CPU启动内存，不证明PL/BO任一区可达。实际BO预算/带宽/同步成本均null。
- XRT2.18.0-0ubuntu1存在；xrt-dkms未安装；modinfo zocl失败；card0是zynqmp-display。fpga_manager的operating状态不能替代ZOCL设备/计算验证。
- 内核headers 6.8.0-1015.16及Module.symvers在板上，配置/符号表SHA256已记录。未使用sudo读取root-only的完整FDT。DT按名称搜索无zocl命中不等于已穷尽compatible属性审计。
- eth0只有IPv6 link-local，无IPv4/默认路由；ssh.service inactive但ssh.socket active且22端口监听，不能简单断言SSH未开启。未改网络或尝试账户登录。

## 改动与可复现命令

以下从C:/Patientqwen运行；PY指platform/local/a1/venv/Scripts/python.exe。原始日志不可覆盖。

| 命令 | 退出码/结果 |
| --- | --- |
| `scripts/release/check_contracts.py`（PY -X utf8） | 0，历史契约保护通过 |
| `scripts/release/qwen35_config.py`（PY -X utf8） | 0，新版契约校验通过 |
| `platform/qwen35/a10/collect_readonly_uart.ps1 -Phase initial -OutputPath .../uart_readonly_01.json` | 0，5组BOARD只读记录 |
| 同脚本 `-Phase sensors_dt -OutputPath .../uart_readonly_02.json` | 0，3组BOARD只读记录 |
| 同脚本 `-Phase package_metadata -OutputPath .../uart_readonly_03.json` | 0，2组BOARD只读记录 |
| `PY -X utf8 -m unittest discover -s platform/qwen35/a10 -p test_profile_from_uart.py -v` | 0，9测试通过；profile_tests.txt |
| `platform/qwen35/a10/test_readonly_plan.ps1` | 0，3阶段/10命令组、语法、无板dry-run和2种温度路径；readonly_plan_tests.txt |
| `PY -X utf8 platform/qwen35/a10/profile_from_uart.py --output evidence/board_platform/A10_20261018_intake/board_profile.json evidence/board_platform/A10_20261018_intake/uart_readonly_01.json evidence/board_platform/A10_20261018_intake/uart_readonly_02.json evidence/board_platform/A10_20261018_intake/uart_readonly_03.json` | 0，带3份原始SHA256的平台观察profile |

注意：每组subshell退出码只是最后一条命令的退出码，不能覆盖中间modinfo/dpkg-query失败。所有原始错误保留；解析器只接收匹配BEGIN/END、完整且已释放端口的证据，不把命令回显当结果，不把缺数据填0。单组采集耗时均不足1秒；没有后台持续采样。实际采集后新增的hwmon停止门禁只经过PC测试。

## 电脑端驱动准备与失败保留

匹配2.18的SDK PPA驱动包已经下载并核对索引SHA256，见XRT_218_CANDIDATE_AUDIT.md。但尚未核验签名链/编译/安装。板上APT缓存虽知道已安装headers的版本，却未给出Filename/SHA256，uart_readonly_03.json保留该结果，未猜下载来源。

电脑查询Launchpad API遇SSL EOF；ports.ubuntu.com的两个main/linux-xilinx目录查询404，未关闭TLS验证或使用第三方驱动替代。WSL现有KV260-A-2204可启动，已有aarch64-linux-gnu-gcc11.4、make及gpg；未重装环境、改MAC或重启WSL。由于电脑缺准确头文件副本，本轮驱动编译NOT_TESTED，而不是编译失败或成功。

现有2026.1 SDK用户库为XRT2.23，板上为2.18；版本差异本身不证明必然不兼容，但不能直接视为匹配。须核对用户态依赖/符号、准确内核模块、DT和既有xclbin。原vadd长测入口含20长度×50轮且超时后BO安全生命周期仍需审查，不在本次短时授权内直接运行。

## 分域验收及下一步

| 域 | 结论 |
| --- | --- |
| PC契约/采集解析/计划安全检查 | PASS（仅所列范围） |
| BOARD登录与只读平台信息 | COLLECTED，来源可追溯 |
| 驱动准确内核编译、签名链、用户态/DT匹配 | NOT_TESTED/未闭环 |
| ARM项目小程序、真实vadd、BO和同步 | NOT_TESTED |
| 超时/重新加载/安全恢复 | NOT_TESTED |
| 真实板上1000比较 | 0次执行，不继承PC历史次数 |
| A10整体 | NOT_PASSED |

必要下一步：先在电脑取得与板上配置/Module.symvers匹配的头文件并做限线程编译和ABI核验；梳理只针对新增文件的恢复方案，再向用户确认驱动安装/加载的明确范围。随后才安排少量短时计算与BO验证；原1000次数要求仍单列，不以缩短测试自动判全通过。P2优化、模型/语音性能调参本轮未实施，也不作为当前只读采集通过条件。无需用户按RESET/FWUEN或重新刷卡。
