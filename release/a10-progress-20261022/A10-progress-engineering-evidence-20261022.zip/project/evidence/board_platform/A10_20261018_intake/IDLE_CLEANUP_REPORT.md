# A10 授权收尾：默认配置已恢复，内核引用泄漏未决

2026-10-19，用户明确允许仅收尾恢复默认配置。**恢复读回已完成；A10 未通过，不能标记为无异常恢复。** 未运行计算、分配计算 BO、重新加载测试位流、复位、断电或刷写。此前检查失败保留。

## 实际结果

- 仍为 boot `d07af077-84c9-4910-8529-95757a09106d`。预检确认原执行 PID 已退出、原中央租约/失败文件 SHA 相符，独占双锁后检查无 render/legacy card/uio/vfio 持有者，ZOCL 引用0。
- 普通 `dfx-mgr-client -remove 0` 退出0；overlay、两个ZOCL绑定、renderD128/card1独立读回均消失。
- 普通 `rmmod zocl` 退出0；模块不存在。
- `dfx-mgr-client -load k26-starter-kits` 退出0；默认overlay `k26-starter-kits_image_1=applied`、FPGA manager `operating`，DFX列表默认 `0->0`、测试包 `-1`，默认材料哈希未变。
- 最后温度28.824/30.122/29.531°C；MemAvailable3558424KiB，CmaFree814444KiB，与最初CMA空闲快照一致。但这**不证明无泄漏**，不与PSS/BO叠加计算。
- 首个收尾读回至完成记录约0.719秒，属于管理/检查流程，不是计算耗时或硬实时上限。全程无长负载。
- active租约已精确归档至 `/var/lock/kv260-a1/history/a10-idle-20261019-cleanup.json`，原active小文件/空目录移除，历史副本可恢复；候选包、用户目录、原日志都保留。最后只读检查active不存在和ZOCL不存在均退出0。SSH会话已退出0，无后台测试。

## 内核异常（必须保留）

事后对比完整内核日志发现新增：

```text
[ 4988.494649] OF: ERROR: memory leak, expected refcount 1 instead of 65, of_node_get()/of_node_put() unbalanced - destroy cset entry: attach overlay node /axi/interrupt-controller@80020000
```

另有默认overlay的firmware-name/resets两条memory leak警告，以及中断子设备正常remove消息。**执行器当时只对退出码和独立sysfs状态设门禁，未自动分类内核日志，错误是在完成恢复后电脑复核发现**；不声称看到此错误后当场停止了后续命令。日志诊断门禁是后续待修缺口，不追认当前“干净恢复PASS”。不能仅根据65推断准确泄漏字节、耗尽风险或唯一责任模块。实际影响、IRQ映射与引用释放路径待电脑审查，禁止用反复装卸或压力测试定位。

## 证据及执行命令

工作根 `C:\Patientqwen`。两脚本暂存于板端新目录 `/home/ubuntu/a10-idle-cleanup-20261019-v1/`，原失败执行目录未覆盖。运行前独立SHA核对：

- `idle_cleanup_only.py`: `c6361570e1c69788327b29a2d144613d898bc77d35688a2d0dab26964b2d33d5`。
- `idle_board_trial.py`（仅被导入，未调用试验run）：`e88b0a7ff136fa6572d0a69e52f7ab991258e2566e63eed82ed5f0d343f4ca95`。

实际板端命令：`python3 -B /home/ubuntu/a10-idle-cleanup-20261019-v1/idle_cleanup_only.py --execute-user-confirmed-cleanup-only`，退出 **0**。控制台与JSONL独占创建；两个文件相同SHA `20115e40a834532971b95dc51f24addf3e554e70f244f17533cd50105e985d29`，SCP下载后与板端核对一致。所有子命令完整argv、退出码、开始/结束、原始dmesg和读回位于 `cleanup-result.jsonl`，控制台 `cleanup-console.txt`。

租约副本 `a10-idle-20261019-cleanup.json` SHA `4790c0cf62dd5fb21f94b2f2aca75aacb1383bb1380d05557e2b906397934316`，与原lease一致。上传SCP/下载SCP均退出0，准确授权提示后交互认证，没有凭据落盘或sudo策略改动。

复用此前11项电脑单测exit0；本轮未重跑板测或既有PC套件。下一步先在电脑定位设备树/IRQ引用泄漏并补内核日志门禁；进一步板操作需明确范围。真实比较仍0，BO可达/同步、20长度1000次、计算超时与恢复等A10要求均未通过，P2长测/性能/极限内存不实施。
