# A10 单次正常重启、U-Boot只读核实与原系统返回

2026-10-20。用户对“正常软件重启一次，采集日志、暂停自动启动只读核实，不按复位/刷写/保存环境/加载候选”回复允许。本轮按该具体范围执行，不把“全部允许”解释为任意刷写权限。

## 结果与当前位置

**原系统返回与只读核实完成；A10仍NOT_PASSED。** 一次`sudo -n /usr/bin/systemctl reboot`，一次倒计时空格，一次经审阅的`run bootcmd`继续同次启动。没有第二次重启、物理RESET/FWUEN、QSPI/SD镜像写入、候选上传/加载、主动PL配置、BO或计算。取消的20长度/1000次回归保持CANCELLED_BY_USER。

最后处于已登录`ubuntu@kria:~$`，COM5关闭释放，无后台板端测试。没有改变sudo策略、电脑/板网络、默认启动文件。正常Linux启动会自行写日志并加载既有默认配置，不能称作整次启动绝对零写入。

- 新boot ID：`eb429b2f-66aa-4959-8610-bfcfabcf0202`；原boot `0b6e8bb1-2219-4f67-b4f2-0a3e9718eaa1`。
- 同板machine-id摘要通过；内核仍`6.8.0-1015-xilinx`，ARM64。
- 默认overlay `k26-starter-kits_image_1`，FPGA operating；ZOCL不存在；taint8704与前值相同，但不是“无错误”证明。
- 最后温度29.928/32.655/32.935°C；MemTotal3996396KiB、MemAvailable3565756KiB、CMA819200/free814444KiB。这是不同含义的观测，不叠加作总占用。
- 原FIT SHA `b007246e409140c73485a057a0e7ccc1fac7116c14699837e4066e74be7532a9`；原脚本SHA `690fe1225a017a63796df1517b8b203fe9b7500597b2c5a61a0f524875ea2efc`；重启前后与电脑备份完全一致。
- eth0 UP，仅IPv6 link-local，无IPv4；没有恢复临时IP。

## 真实启动信息与返回路径

串口固定USB身份`FTDIBUS\VID_0403+PID_6011+XFL1CYYPZ52YB\0000`，115200 8N1，DTR/RTS false。

FSBL Release2020.2、构建2021-04-22；BL31 v2.2 xilinx-v2020.2.2-k26；U-Boot2020.01、构建2021-04-22；启动Reset reason SOFT。这不是2026.1固件，不因SD系统版本推断QSPI版本。历史`version/help unknown`不能覆盖本次完整成功输出。

实读的默认调用链：

`bootcmd=run som` → SOM名称匹配starter → `cc_boot`在RAM中设置`boot_targets=mmc1` → distro扫描SD1可启动分区 → `/boot.scr.uimg` → 原`image.fit`。

这里只查询环境，没有执行`saveenv`。继续原启动脚本本身会设置其正常RAM环境变量；不得写成“启动全过程没有任何RAM环境变化”。

`part list mmc 1`确认DOS分区表，p1启动分区UUID de90fb12-01，p2 de90fb12-02。FAT根目录仅meta-data、network-config、64453664B image.fit、8000B boot.scr.uimg及System Volume Information目录；无extlinux、Image、user-override.dtb、system.bit覆盖项。原脚本电脑备份全文已审阅，没有进入其非mmc分支。

实际原FIT路径：

- FIT加载0x10000000，脚本0x20000000；KV260 revB配置`conf-smk-k26-revA-sck-kv-g-revB`。
- kernel、ramdisk、DT三项SHA1校验OK；内核解压入口0x00200000。
- 原ramdisk实际搬移`0x7661f000..0x78fff546`；DT最终`0x0fff2000..0x0ffffb0a`。这仅是本次原包，不当作候选initramfs位置。
- U-Boot DRAM区间0..0x7fefffff与0x800000000..0x87fffffff不是已实测可分配BO范围。
- 内核挂载原根分区并进入Ubuntu；最后登录后重新读取内核/默认配置/启动SHA通过。

官方命令语义参考：[U-Boot bootd](https://docs.u-boot.org/en/latest/usage/cmd/bootd.html)、[env命令](https://docs.u-boot.org/en/v2024.07/usage/cmd/env.html)。实际决定使用的是本板`help`和逐级`printenv`，不是凭通用文档猜测。

## 失败、修复与命令证据

命令均从`C:\Patientqwen`执行。PowerShell脚本入口使用`powershell.exe -NoProfile -ExecutionPolicy Bypass -File`，仅当前进程，不改系统执行策略。

| 入口/证据（本目录） | 实际结果 |
|---|---|
| `test_inspect_boot_once.ps1`，`boot_inspection_safety_tests_01.json` | PC22检查exit0 |
| `inspect_boot_once.ps1 -AuthorizedOnce`，`uart_boot_inspection_20261020_01.json` | 运行器exit1，脚本失败路径exit2；只发CR。提示符含ANSI bracketed-paste控制字符，初版没认出；重启0次，原始失败保留 |
| 修复ANSI识别，`boot_inspection_safety_tests_02.json` | PC24检查exit0，包含原始提示符最小复现 |
| 同入口新证据`uart_boot_inspection_20261020_02.json` | 实际仅重启1次。身份/温度预检0、sudo认证0，截停成功；version/help成功。查询不存在的可选环境变量时停止，运行器exit1、脚本失败路径2；不是重启失败，不重试重启 |
| `uboot_readonly_step.ps1 -Step som/carrier/distro/boot_files`，四份`uart_uboot_*_20261020_01.json` | 四次PC执行器exit0；分别保存som/内存信息、载板、distro链及分区/文件查询。U-Boot没有采集独立命令退出码，不能将PC0冒充其数值返回码 |
| `boot_inspection_safety_tests_03.json` | PC36检查exit0，加入只读计划及原系统继续启动计划 |
| `resume_original_boot.ps1 -AuthorizedResumeOriginal`，`uart_original_resume_20261020_01.json` | `run bootcmd`仅1次，原FIT验证/原内核启动/根分区挂载已捕获；100秒内未捕获登录提示，运行器exit1、脚本失败路径2。该旧回执status误留NOT_STARTED，须以resume_commands_sent=1及完整事件为准；已修正代码，不改旧回执 |
| `capture_serial.ps1 -Ports COM5 -DurationSeconds 40 -MaxBytesPerPort 131072` | exit0，`passive_original_boot_20261020_01/`。仅接收，0字节不是失败或启动成功证明 |
| `boot_inspection_safety_tests_04.json` | PC37检查exit0；LoginOnly计划不含启动/重启 |
| `resume_original_boot.ps1 -AuthorizedResumeOriginal -LoginOnly`，`uart_original_login_20261020_01.json` | 单次CR获得`kria login:`；确认真实密码提示后瞬时认证。执行器exit0、板只读后检exit0；原系统返回实证补齐。没有再执行启动命令 |

没有将“100秒内未捕获提示符”写成板挂死，也没有据此复位。提示符后来可用的具体原因未诊断，不假称已修复串口服务。

新增程序：

- `platform/qwen35/a10/inspect_boot_once.ps1`
- `platform/qwen35/a10/uboot_readonly_step.ps1`
- `platform/qwen35/a10/resume_original_boot.ps1`
- `platform/qwen35/a10/test_inspect_boot_once.ps1`

只读计划检查、提示符/授权挑战识别、零值倒计时拒绝、内核启动后禁止截停、独占新证据路径、无DTR/RTS、原内核后检均为PC测试，不当作硬件故障注入。凭据不写源码/报告/原始日志，仅在已核实挑战时使用。保留所有既有改动，无提交推送。

## 尚未解决，下一步

1. 原内核启动仍报告固件不支持部分pinctrl特性（日志要求2023.1以上），以及Invalid IO Standard/dummy regulator等；关机有watchdog timeout/USB提示，默认overlay有两条memory-leak警告。均保留，不能称整体平台兼容性通过；不因此擅自刷QSPI。
2. 本轮只证明**原系统**可从该U-Boot继续启动。候选6.8.12-a10irq1、配套模块/ZOCL尚未板端暂存或试启动，候选失败后的实际回退能力仍未测试；完整原模块树离线恢复验证仍缺。
3. 下步先完善候选并存目标、原模块必要备份及单次启动/返回原包的明确计划，再对准确文件和目标授权；不覆盖原FIT/脚本，不保存U-Boot环境。原包恢复成功不证明内核IRQ修复有效。
4. 干净空载配置/卸载恢复、一次最小PL输入输出、小BO地址/同步与双账仍未通过；真实计算0、计算BO0。数值回归取消；P2性能优化、压力、极限内存、在途故障注入均NOT_IMPLEMENTED/NOT_TESTED且不执行。
