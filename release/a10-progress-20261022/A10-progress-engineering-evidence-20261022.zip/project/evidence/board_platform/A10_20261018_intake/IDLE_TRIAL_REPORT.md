# A10 单次空载配置：原失败与后续收尾记录

最新结论：用户随后授权的收尾已完成，默认配置已恢复、ZOCL/测试节点已消失、租约已归档。但完整日志复核发现中断控制器节点引用泄漏，不能记干净恢复通过。详见 `IDLE_CLEANUP_REPORT.md` 和 `cleanup-result.jsonl`；下方“待确认/仍加载”为收尾前历史快照，保留不改。

2026-10-19。用户明确允许一次空载配置验收，不含计算、计算 BO、QSPI/启动介质、电源或长时间负载。**A10 未通过；不要重跑试验入口。** 原 A00—A17 状态保留。

## 实际操作与当前状态

- 固定 SSH 公钥连接，核对 boot `d07af077-84c9-4910-8529-95757a09106d`、内核、machine-id、恢复文件及驱动 SHA。暂存用户目录 `/home/ubuntu/a10-idle-once-20261019-v1`，SCP 退出 0；未传 xclbin 或计算主机。
- 独占中央租约 `/var/lock/kv260-a1/active/lease.json`，范围 `A10_IDLE_PL_ONCE`；执行时同时持有 deployment/shared flock。新建候选目录 `/lib/firmware/xilinx/a10-vadd-20261019`，仅 bit.bin、dtbo、shell.json。未覆盖已有文件。
- `dfx-mgr-client -remove 0` 退出 0，独立读回默认 overlay 消失；`insmod` 固定驱动退出 0、未绑定引用 0。
- `dfx-mgr-client -load a10-vadd-20261019` 退出 0，约 0.364 秒（命令开始/结束日志间隔，非计算耗时）。测试 overlay applied、FPGA manager operating、`renderD128` 出现。
- 检查脚本把 ZOCL 模块的全部绑定误当成单一主设备，发现两项后按规则停止，整个脚本退出 **1**。没有继续卸载、恢复或重试加载。没有启动计算核、没有调用计算 BO 分配 API。
- 停止后仅只读检查退出 0：温度 29.119/30.666/31.225°C；无加速设备持有者，模块引用 0。`CmaFree=808656 KiB`，初始 814444 KiB；差值仅为快照变化，不宣称全部归属配置缓冲或泄漏，不与 PSS/BO 重复相加。

**截至本报告，测试配置和 ZOCL 仍在；默认配置尚未恢复，中央 active 租约保留。执行器已退出，flock 已释放，不能把留存租约描述为仍有进程持锁。** 已单独询问用户是否允许仅收尾恢复，不授权重新加载测试或计算。历史 pending 计划不改写为执行成功。

收尾仅关闭了本次 SSH 根 shell，会话退出 0；没有关闭板子。停止后原始日志已下载，SHA256 `234bb2c713527d4bb0636e1a116a66f2f5945e29b70b73548bc9ef96b9dddbf8` 与板端一致。项目状态 JSON 解析和 `git diff --check -- docs/status/A.md` 均退出 0。用户暂存包、固件候选目录及租约均保留，未删除材料。

## 最小失败与分析

首版实际脚本快照 `idle_board_trial.executed_v1.py` SHA256 `9ecb264866d8f7bd7d2a0345e0b88bce82dcbdf4b5855a403b56370be7849b84`。原始板端 JSONL `idle_board_attempt_v1.jsonl` SHA256 `278f3efc3e45e1772b3720c09ae27e4eb4e3f4bf7ff9c2238ab59ab740fd337a`，下载后与远端 SHA 一致。

真实绑定：

- `axi:zyxclmm_drm` → `zocl-drm`；
- 其子设备 `ZOCL_CU_INTC.2.auto` → `zocl_irq_intc`。

准确编译源 XRT 2.18 的 `common/zocl_drv.c:1144` 明确创建 CU 中断子设备，`zert/zocl_xgq_intc.c:179` 注册该名称。两文件 SHA 分别为 `16336c0e7cefb21017fad686bfdee256b4866261a25f70cef5bb18dee179ce74`、`6faec55907a1854d108e9344f57e9e729635c7de41b2cc65957d1d6abf52a089`；源位于 WSL `/home/member-a/a10-driver-audit-20261018/source/usr/src/xrt-2.18.0/driver/zocl/`。只读源码检查，无驱动源码修改。

内核 `IRQ index 32 not found` 与同文件 `1136` 开始的枚举循环遇负值即结束相符，随后 DRM 初始化成功；**不是实际 IRQ 功能通过**。overlay 内存泄漏警告、外部模块 taint 全部保留；不忽略警告、不通过反复装卸试验消除它们。

电脑检查已修成严格主/子设备驱动名称和父子路径核对，而非放宽为任意两项。修订版未上传或重新执行。首版测试遗漏真实子设备结构，新增回归涵盖父子路径错误、未知驱动/设备及缺失绑定拒绝。

## 命令与证据

工作根 `C:\Patientqwen`，Python 为 `platform/local/a1/venv/Scripts/python.exe`。

| 执行 | 退出码 | 证据 |
|---|---:|---|
| `test_idle_board_trial.py` 首版/修订版 | 0 / 0，3 方法 | `idle_board_gate_tests_v1.json`、`idle_board_gate_tests_v2.json` |
| 精确 SCP 上传四个文件 | 0 | 工具传输记录；板端脚本/产物哈希门禁 |
| 板端 `python3 -B .../idle_board_trial.py --execute-authorized-idle-once` | 1 | `idle_board_attempt_v1.jsonl`，独占原始日志 |
| 停止后只读 snapshot、绑定路径、DFX 列表、dmesg | 0 | `idle_board_poststop_v1.jsonl` |

电脑累计比较审计另已完成：`test_vadd_batches.py` 9 方法退出 0，`vadd_batch_audit_tests_v2.json`；当前真实索引为空，审计退出 **2（预期未通过）**，见 `real_vadd_batch_accounting_v1.json`、`vadd_batch_current_audit_v1.json`。夹具中的 1000 项只测试计数规则，不是板测；真实比较仍为 **0**。

P0/P1 未决：本次正常收尾和默认读回、IRQ/固件组合、受控 BO/同步、20 长度与累计 1000 真比较、计算超时与恢复。P2 性能/极限内存/长时间压测未实施。没有模型、语音、数学、性能参数改动，没有提交或推送。

## 后续电脑准备：仅收尾入口，未执行

新增 `platform/qwen35/a10/idle_cleanup_only.py` 与 `test_idle_cleanup_only.py`。入口只接受与本次原始失败日志/源码 SHA、boot/machine-id、中央租约相符的状态；重新获取双锁，核对原执行 PID 已退出、无设备持有者、引用为0、恢复材料未变。命令白名单仅允许普通移除当前 handle、`rmmod zocl` 和加载原 `k26-starter-kits`，拒绝测试加载、强卸载、复位及不匹配租约。未知命令状态继续保留锁，不杀管理进程、不重试。成功读回后才把精确租约文件归档；保留所有候选包和原失败材料。独立收尾确认仍待用户回复，**入口未上传、未执行**。

同时补充 ZOCL legacy `card*` FD 占用检查（不限于 renderD），不把显示用 card0 一概当作加速器；模块引用严格区分整数0和布尔False。当前 live/sysfs 读回未重跑，新逻辑仅电脑验证。

实际命令 `python -m unittest discover -s platform/qwen35/a10 -p test_idle*py -v`，退出 **0**，11方法；全量 argv/stdout/stderr 在 `idle_cleanup_only_tests_v1.json`。本增量没有 SSH/串口连接，板端状态仅引用上一轮最后只读记录，不作为新测温。A10真实比较仍0，完整目标不变。
