# Shutdown check — 2026-10-21 (Asia/Shanghai)

User requests safe shutdown after pausing A10 and rejecting power-cycle risk.

- Passive COM5 capture: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File platform/qwen35/a10/capture_serial.ps1 -Ports COM5 -OutputDirectory evidence/board_platform/A10_20261018_intake/shutdown_check_20261021_v1 -DurationSeconds 15 -MaxBytesPerPort 1048576`; exit 0, zero received bytes, port released. No serial transmission, BREAK, DTR/RTS assertion, reset, or power operation.
- Pinned SSH connection to ubuntu@192.168.2.2, bound to 192.168.2.1, BatchMode=yes, ConnectTimeout=5, requested read-only `uname -r`: client exit 1, connection refused during banner exchange. Remote command did not execute.
- Prior normal reboot remains unverified; last prior serial evidence was systemd-shutdown waiting for udev workers and issuing SIGKILL. No evidence of completed filesystem unmount or final power-off.
- Safe removal of board power is NOT_VERIFIED. No second shutdown/reboot, emergency SysRq, forced unmount, or forced power cut attempted.
- A10 remains paused and NOT_PASSED. PC build remains stopped. Do not equate zero UART bytes or unavailable SSH with successful shutdown.
