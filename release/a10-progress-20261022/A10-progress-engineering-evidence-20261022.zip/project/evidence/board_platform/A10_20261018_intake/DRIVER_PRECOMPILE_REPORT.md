# A10：同版驱动PC预编译与真实DT静态核验

日期2026-10-18；A10总体仍NOT_PASSED。本轮PC准备完成；BOARD仅再次获准只读，COM5已释放。无驱动安装/加载、位流加载、复位、刷写、网络改动或负载测试。

## 本轮消除的缺口

1. 取得准确Ubuntu头文件6.8.0-1015.16，不用升级板端内核。官方快照 https://snapshot.ubuntu.com/ubuntu/20250425T000000Z/ ，下载路径见driver_input_hashes.json。Ubuntu InRelease用WSL现有Ubuntu归档公钥验证成功；Release→Packages.xz→两个DEB的SHA256/长度均通过。
2. 头文件.config及Module.symvers与此前板上读取的两个SHA256完全一致。头文件仅在PC隔离目录解包，没有dpkg安装或运行维护脚本。
3. SDK PPA InRelease签名验证成功，指纹803DDF595EA7B6644F9B96B752150A179A9E84C9；密钥来自Ubuntu keyserver，且与Xilinx官方Kria-PYNQ源码中的固定指纹一致（只读取，不执行安装脚本）：https://github.com/Xilinx/Kria-PYNQ/blob/main/install.sh 。Launchpad说明同团队PPA共用密钥：https://ubuntu.com/docs/launchpad/user/reference/packaging/ppas/ppa/ 。未把公钥加到板端或WSL全局APT信任；隔离GPG keyring保留TRUST_UNDEFINED，不伪造web-of-trust。首次gpg列包自动创建WSL用户空.gnupg目录，后续均使用任务专用homedir。
4. 未改驱动C/H/Makefile或数学。现有2026.1 SDK GCC13.4交叉编译ARM64 ZOCL2.18；原kernel编译器13.3，版本差异警告保留。仅重建PC需要的fixdep/modpost/genksyms宿主可执行工具，配置/符号表不变；make -j2、编译子步骤120s上限，板上不编译。
5. zocl.ko为ARM64 ELF，9435840字节，SHA256=`c03f868797e16302fda8946c223e2119878c29f5975ce65cd17e18f67d9d6896`；vermagic=`6.8.0-1015-xilinx SMP preempt mod_unload modversions aarch64`，238个导入CRC全部匹配。只在电脑暂存：platform/local/a10-xrt-2.18-audit/zocl-2.18-kernel-6.8.0-1015-PC_ONLY.ko。模块未签名，板端签名/lockdown策略仍须现场检查；不禁用安全策略强行加载。
6. 真实只读核对123个compatible节点，没有zocl系列平台节点；当前fpga-region固件为k26-starter-kits.bit.bin。安装驱动本身不等于具备计算通路。
7. 获取1638个DT属性快照，约9.89秒串口传输。在电脑用现有SDK dtc重建DTB；这是/proc/device-tree属性重建，不是root-only原始/sys/firmware/fdt的逐字节副本。1411个非name属性全部逐字节验证，227个proc生成name属性单列。dtc对原始字节属性缺源级phandle标记等发出警告，完整保留，未静默抹除或称零警告。
8. 使用既有a1-vadd.dtbo在电脑fdtoverlay合并成功，复用A1静态检查，内存/保留内存/bootargs未变；CU为0xb0000000、0x10000跨度，父节点/axi为2/2 cells。CU中断1/2与ZOCL中断扩展等沿用既有值，没有改触发语义迎合测试。运行时IRQ/时钟/AXI/BO仍未验证。

## 实际命令与退出码

工作根C:/Patientqwen；Python=platform/local/a1/venv/Scripts/python.exe；Linux命令经WSL KV260-A-2204。

| 命令/入口 | 退出码和证据 |
| --- | --- |
| check_contracts.py、qwen35_config.py | 各0，原契约保护通过 |
| verify_driver_inputs.py --cache platform/local/a10-xrt-2.18-audit --output .../driver_input_hashes.json | 0，3包及2索引哈希链通过 |
| gpgv --keyring /usr/share/keyrings/ubuntu-archive-keyring.gpg headers.InRelease | 0，archive_signature_and_staging.txt |
| 隔离gpg --verify sdk.InRelease（导入前） | 1，NO_PUBKEY；导入固定公钥后0，driver_extract_and_signature.txt |
| dpkg-deb -x（3包） | 0，只解包；driver_extract_and_signature.txt |
| bash platform/qwen35/a10/build_zocl_pc.sh，v1 | 1，宿主modpost错误混入内核include，driver_build_pc_v1.txt |
| 修复上述宿主include路径后，同命令v2 | 0，driver_build_pc_v2.txt；编译器差异、源代码警告、缺vmlinux跳过BTF、包无.git时git查询提示均保留 |
| PC modprobe --show-modversions zocl.ko | 工具报Invalid argument，非加载；宿主不识别该Ubuntu变长版本记录，不能当驱动损坏依据 |
| audit_zocl_module_v1_failed.py | 1，错误假设旧固定64B格式；旧脚本和module_parser_failure_v1.txt保留最小复现 |
| audit_zocl_module.py（修正为该准确内核的next/crc/name格式） | 0，zocl_module_audit.json；238/238 CRC匹配，没有放宽容差 |
| python -m unittest discover -s platform/qwen35/a10 -p test_driver_audit.py -v | 首版6项0；新增变长记录边界后8项0，driver_audit_tests_v2.txt |
| test_readonly_plan.ps1 | 0，5阶段14命令组、2类温度路径；readonly_plan_tests_v3.txt |
| collect_readonly_uart.ps1 -Phase binding -OutputPath .../uart_readonly_04_binding.json | 0；3组只读，最大2.75秒；温度33.448/32.080/30.744°C |
| collect_readonly_uart.ps1 -Phase dt_snapshot -OutputPath .../uart_readonly_05_dt.json | 0；1组只读，9.89秒，25秒采集上限；无计算测试 |
| summarize_binding.py capture output | 0，board_binding.json |
| reconstruct_dt_pc.py capture /home/member-a/a10-driver-audit-20261018/board-dt-fs | 0，dt_reconstruction.txt |
| SDK dtc -I fs -O dtb；fdtoverlay -i base -o merged a1-vadd.dtbo | 均0，dt_overlay_pc.txt（警告保留） |
| audit_board_overlay_pc.py capture base merged output | 0，actual_dt_overlay_pc_audit.json/.txt |
| python -m unittest discover -s platform/qwen35/a10 -p 'test_*.py' -v | 0，最终17项PC测试；all_a10_pc_tests.txt |
| 修正路径构造不删除节点名中点号后复测overlay audit | 0，actual_dt_overlay_pc_audit_v2.json/.txt，与首版结果一致 |

模块版本结构直接核对准确包include/linux/module.h及scripts/mod/modpost.c：SHA256分别701819ae137893232314afc4c66a55f772a2e0c78506a91efe455766e7d26236、fe494a096e57a011d95b5eb62a3c8eaa7db1048cf7a596e5822ba5a0cc004372。解析采用明确Ubuntu格式，不自动猜测、吞错或退回固定布局。

## 分域和未决

- PC输入真实性/哈希、同内核交叉编译、ELF与238符号CRC：PASS，仅上述范围。
- BOARD只读信息：COLLECTED，原始4/5两份UART记录与摘要有哈希；现COM5释放。
- PC实际DT重建/静态合并：PASS_STATIC_WITH_RETAINED_WARNINGS；不是动态overlay验收。
- BOARD驱动加载、XRT枚举、ARM项目程序、BO范围/同步、vector-add、超时与恢复：NOT_TESTED，0次实际计算，不继承PC1000次。
- 内存3200MiB包络、进程/物理占用账、硬件误差/带宽：null/未验证。
- XRT2.18用户态与现有SDK2.23应用ABI：尚未闭环，不能混用后直接运行。
- FRU独立身份、模块签名策略/taint、现有默认overlay卸载/恢复、PL超时安全生命周期仍需核验；不自动rmmod、强制解绑或改变DT。
- P2性能优化本轮NOT_IMPLEMENTED，不改模型/语音/计算核性能参数。

下一步需要用户明确授权：仅把固定哈希验收文件暂存到板上独立目录，核对签名策略/依赖后做一次不含位流/BO/计算的驱动加载观察。若策略拒绝或异常立即停止，不绕过验证。该授权不包括PL加载；PL须另行审查与授权，不能将已编译候选称为可部署成品。
