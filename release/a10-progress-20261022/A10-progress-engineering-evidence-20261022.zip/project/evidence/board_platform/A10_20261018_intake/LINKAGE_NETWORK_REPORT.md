# A10 接续：ARM64 链接与临时直连网络

记录于 2026-10-19（Asia/Shanghai）；本次板端操作始于 10-18 夜间。工程 `C:\Patientqwen`，保留原分支、脏树、原 A00—A17 及所有失败证据。此次仅局部通过，**A10 NOT_PASSED**；真实 vector-add 比较数仍为 **0**。

## 已完成及授权边界

- 用户登录并关闭 COM5 后，只读复核新 boot ID `d07af077-84c9-4910-8529-95757a09106d`；此前无 shell 的 `uart_resume_preflight_01.json` 原样保留。
- 用户单独批准的 277392 字节程序复制与一次 `--check-linkage` 已完成。SHA256 `d25040172f0bb67b04e2e85233a2ae4a27e85cc6314de4beb9994b60d4f0243d`，目标 `/home/ubuntu/a10-linkage-check-20261018-v1/a10-vadd-short`。压缩传输 93325 字节/122 ACK，13.7995296 秒；仅新用户目录写入，不覆盖系统文件。
- `LD_BIND_NOW=1`、干净子进程环境、3 秒上限，实际执行一次返回 `LINKAGE_ONLY_NO_DEVICE_OPEN`，退出 0，耗时 **0.031481525 秒**。未打开 FPGA 计算设备、未分配 BO、未加载位流；不证明所有 XRT/PL 功能或未来调用不会出现非法指令。该次授权已使用，不重复无变化检查。
- 用户单独批准后，只添加 `eth0 192.168.2.2/24`，读取前后默认路由均为空。PC `192.168.2.1/24` 保持不变；未改 PC 网络、Wi-Fi、DNS、防火墙、板上配置文件或 SSH 服务。可撤销命令（**未执行**）：`sudo ip -4 addr del 192.168.2.2/24 dev eth0`；重启后临时地址消失。
- 从可信串口获得 SSH 公钥，首次 SSH 即使用独立已知主机文件和 `StrictHostKeyChecking=yes`；未自动接受未知主机。指纹 `SHA256:J0iRAOd0Yua9NTSV1ww1XdSX1xEFAEUf2rmQIxgmOIQ`。WSL 直连超时，Windows 原生 SSH 成功，未因此修改任何网络/防火墙规则。
- SSH 只读平台采集实际耗时 **0.114346723 秒**，温度 **32.096 / 35.655 / 33.370°C**。MemTotal 3996396 KiB、MemAvailable 3550472 KiB、CMA 819200 KiB、CmaFree 814444 KiB；CMA 不再与 PSS、BO 或 MemTotal 叠加。均为离散观测，不是持续监控或峰值测试。
- 默认 `k26-starter-kits_image_1` overlay 仍 applied、FPGA manager 为 operating；这表示原配置状态，不是我们的核通过。只读发现 dfx-mgr 服务 active、默认 k26 恢复文件及 XRT_FLAT shell.json 存在；未调用 load/remove/pwrctl、未停止服务、未把文件存在视作恢复验证。
- 瞬时凭据使用遵循用户既有明确授权，只在匹配认证提示后输入；不在工程、脚本、证据中保存密码，不更改 sudo 策略。一次 sudo 提示匹配受 ANSI/CR 影响，未发送密码，取消的仅是本次待输入的 `sudo -v`，正常 shell 确认后再认证；没有计算进程被中断，也没有复位板卡。

## XRT 差异：范围已缩小，未冒充全兼容

板上与签名下载包均为 2.18.0，完整库哈希不同，各自匹配自己的包清单。独立 ELF64/AArch64 节解析证明两份库的 `.text`、符号/版本/重定位等已记录节相同，差异节为 `.note.gnu.build-id`、`.rodata`、`.gnu_debuglink`；完整哈希和逐节结果见机器摘要。

日期替换只在读入的内存副本中进行，未写板上库；仅替换构建日期后 `.rodata` 仍不一致，**差异尚未完全解释**。第一轮错误秒值命中 0 次，第二轮仍非一致，均保留。不得据此替换板库、降级 XRT，或宣称 2026.1 位流与板上 2.18 整体兼容。

## 命令、退出码和证据

以下路径相对工程根；完整原始命令见对应 JSON 的 command/argv。Python 使用 `platform/local/a1/venv/Scripts/python.exe`，PC 历史/新版契约本次接续已通过，未重复模型/200 轮/Csim。

| 实际执行 | 退出码 / 结果 | 原始证据（本目录） |
|---|---|---|
| `driver_board_step.ps1 -Step resume_preflight` | 0，只读新 boot | `uart_resume_preflight_02.json` |
| `transfer_driver_uart.ps1 -PayloadKind linkage` | 0，传输不执行 | `uart_linkage_transfer_01.json` |
| `driver_board_step.ps1 -Step linkage_once` | 0；子进程 0，0.03148s | `uart_linkage_once_01.json` |
| `driver_board_step.ps1 -Step xrt_section_hashes` | 0，只读逐节摘要 | `uart_xrt_sections_01.json` |
| PC `elf_sections_readonly.py` 对签名包解出库 | 0 | `xrt_package_sections_v1.json` |
| `driver_board_step.ps1 -Step xrt_date_proof` 两轮 | 0/0 是采集成功，**不是比较一致** | `uart_xrt_date_proof_01/02.json` |
| `driver_board_step.ps1 -Step network_and_dates` | 124，5 秒限时退出；部分输出保留，未重跑全文件正则 | `uart_network_dates_01.json` |
| `driver_board_step.ps1 -Step temporary_ip_add` | 0，0.54126s，地址读回 | `uart_temporary_ip_add_01.json` |
| 前序 Windows 单包 ICMP 连通检查（本增量未取得完整 argv） | 先前工具返回 0，单包约 1ms；未另存原始 ping 文件，不作带宽指标 | 前序工具记录；SSH 为后续独立连通证据 |
| WSL `ssh ... ubuntu@192.168.2.2 uname -r` | 外层 1；5 秒连接超时，未认证、未执行板端命令 | 本报告人工转录工具结果 |
| Windows `ssh.exe -T ... ubuntu@192.168.2.2 uname -r` | 0，输出 `6.8.0-1015-xilinx` | 本报告人工转录工具结果 |
| Windows SSH 执行 `platform_inventory_readonly.py` 的 base64 原字节，经 `timeout 6s python3 -B -` | SSH 0；两项只读子命令各 0；采集 0.11435s | `ssh_platform_inventory_01.json` |
| `test_elf_sections.py` | 0，9 方法 | `elf_section_tests_v4.json` |
| `test_linkage_payload.py` | 0，4 方法 | `linkage_payload_tests_v2.json` |
| `test_driver_step.ps1` | 0，22 动作仅计划测试，不执行板操作 | `driver_step_plan_tests_v11.txt` |
| `test_linkage_network_summary.py` | 0，5 方法，含失败/boot/地址缺失拒绝 | `linkage_network_summary_tests_v1.json` |
| `summarize_linkage_network.py ... --output .../linkage_network_summary.json` | 0，仅电脑解析，独占输出不覆盖 | `linkage_network_summary_run_v1.json` |

SSH 精确选项：`-T -o UserKnownHostsFile=C:/Patientqwen/platform/qwen35/a10/board_ssh_known_hosts -o StrictHostKeyChecking=yes -o UpdateHostKeys=no -o ConnectTimeout=5 -o ConnectionAttempts=1 -o NumberOfPasswordPrompts=1 -o PubkeyAuthentication=no ubuntu@192.168.2.2`。密码只经终端交互，不在 argv。采集 stdout 通过 `Tee-Object` 保存在电脑，未发送到板上文件。

采集脚本 SHA256：`29b3fed438ae95e36895000aa88aa4fdac004b9bca4ef0922d365d0fa1b6547a`；SSH 公钥文件 SHA256：`bae7538088ef5e66d6fb3619bdd04e1b1d2676c60f1b3025f8ae25b5f574ae42`；采集原始 JSON SHA256：`b605e486fa6cca7029fdc78f3f89e2e302fd06527e5e5dc2aee038de6d3d3a7f`。其余源 SHA 在 `linkage_network_summary.json`。

首轮 PC ELF 测试夹具偏移错误、嵌入脚本文本复制错误（上板前被测试拦截）、Windows 路径断言错误均保留失败记录及快照，修复后才执行；没有改历史输入、删失败或放宽板端数学门槛。

收尾电脑文档校验首次因 Windows 默认 GBK 解码 UTF-8 失败（Python 1，后续 git 命令使外层返回 0，**不计校验通过**），记录 `final_validation_encoding_failure.json`。改显式 UTF-8 并传播子命令退出码后重验；未触碰板子或改写源证据。

## 变更与下一步

本次接续修改/新增 `platform/qwen35/a10/{elf_sections_readonly.py,test_elf_sections.py,linkage_serial_payload.py,test_linkage_payload.py,transfer_driver_uart.ps1,driver_board_step.ps1,test_driver_step.ps1,platform_inventory_readonly.py,board_ssh_known_hosts,summarize_linkage_network.py,test_linkage_network_summary.py}`；新增原始证据、机器摘要、本报告，更新项目状态/差距/矩阵/AI记录。旧板 profile 与过去阶段保留原始快照，当前新增观测由本增量摘要引用。

P0/P1 未决：位流/DTBO/XRT/固件组合及默认配置恢复路线，活动 BO 停止后释放的真实确认，最小单次 PL 专项授权，20 长度/累计 1000 真比较、受控 BO 范围与同步成本。保持短批次间歇，不执行旧长循环，不以超时杀死仍可能持有 DMA 的进程。未加载 PL，也未获本次 PL 授权；不进入模型硬件演示。

下一步先完成准确恢复路径与首次最小 PL 测试计划审查，再申请该范围授权。P2 持久安装/自动部署、吞吐优化/极限探测、持续看板未实施，不阻塞本次临时网络动作；没有性能收益结论。COM5 与 SSH 会话均已释放，无后台测试；无提交/推送，无模型、语音、核数学或性能参数更改。
