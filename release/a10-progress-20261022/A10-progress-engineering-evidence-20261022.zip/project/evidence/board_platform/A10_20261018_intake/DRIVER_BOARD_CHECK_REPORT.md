# A10 新板：短时驱动实测增量（2026-10-18）

结论：**无绑定设备条件下，ZOCL 2.18 真板加载、检查、普通卸载通过；A10 整体仍 NOT_PASSED。** 本轮没有加载 PL/DTBO、分配 BO、运行向量加/模型或压力测试。没有重启、按恢复键、写 QSPI/EEPROM/SD 启动区、安装系统驱动、修改网络/防火墙。COM5 已释放，PC 临时传输服务已结束。

本报告覆盖先前 `DRIVER_AUTH_PREFLIGHT.md` 的“尚未加载”当前状态，原文件留作历史，不修改旧 profile 和失败原件。机器汇总为 `driver_board_check.json`，包含 15 份真实原始采集的 SHA256；基础身份/DT 仍引用 `board_profile.json`，不是第二块板或旧板计数。

## 实际操作与边界

- 用户本人完成 sudo 认证并关闭 COM5；脚本确认 shell 后只用 `sudo -n`，没有发送或保存密码。
- 板端内核 `6.8.0-1015-xilinx`，XRT `2.18.0-0ubuntu1`。复用已完成的电脑交叉构建及 238 个导入符号 CRC 核验，未重编已有效模块。
- 实测模块：464752 字节，SHA256 `545df42c8b66396dd847ccd6a280f19d9a0051d36e2e75c1ec84437caca328a9`；version `2.18.0`，srcversion `97E8D4CCD40C7980154D120`。
- 检查 9 个实际驱动 OF compatible、平台设备名称及 driver_override：123 个 compatible 属性、83 个平台设备中未发现绑定候选。加载后引用计数 0、无使用者，正常 `rmmod` 后模块和驱动目录均不存在。只证明未绑定驱动的生命周期，不证明 FPGA probe/BO/DMA 安全恢复。
- UART 压缩传输 127580 字节、167 个有序确认块，完成后校验原文件 SHA256；传输用时 18.867 秒。加载整组检查 0.773 秒、检查 1.186 秒、卸载整组 0.806 秒、收尾检查 0.672 秒；这些是整条命令墙钟时间，不是纯加载性能或计算性能。
- 收尾离散温度 31.140/34.272/32.640°C，不宣称连续峰值；MemAvailable 3571512 KiB、CmaFree 814444 KiB。CMA 不与 PSS/BO/MemTotal 重复相加，3200 MiB 包络未验证。
- 默认 overlay 仍为 `k26-starter-kits_image_1`。用户目录保留 `/home/ubuntu/a10-driver-check-20261018-v2/zocl.ko` 和 `zocl.ko.gz.part`（完成的压缩源，127580 字节）。v1 失败暂存目录保留，未删除任何文件。没有写 `/lib/modules` 或设置自动加载。

## 失败、既有告警与修复

1. HTTP 单次传输：板端 curl 退出 7；后续只读路由检查退出 2，显示 Network is unreachable。没有放开防火墙或修改网络；改用有界 UART 传输。PC 临时服务到期关闭、退出 0。不能把网络仍不通描述为已修复。
2. UART 首次接收器 READY 以裸 CR 为边界，主机旧正则未匹配；0 块确认，主机退出 2，板端最终退出码未收到，保持 null。接收器有 8 秒空闲超时并恢复终端；后续确认 shell 后改新 v2 目录重试。最小复现 `test_serial_ready.ps1`、v1 两份源码和失败 JSON 全部保留。修复 CR 边界、末块 ACK 与完成消息同包处理后，第二次真实传输通过。
3. 初次非特权读取 vmlinuz 退出 1（权限不足）；随后限定 `sudo -n` 的只读核验退出 0。`dpkg -V linux-image-6.8.0-1015-xilinx` 无差异输出；文件 SHA256 为 `b0b4434dc32f6d6662ff91d0b35b835fd2f523ee8c51d58c5651cde24d3092dc`。这只验证已安装文件，不证明它就是 `image.fit` 中正在启动的内核，FIT 对应性仍待核实。
4. 加载前 taint 已是 8704（W=512、E=8192），日志已有 X.509 导入警告和 `aes_ce_cipher` 签名警告。此次外部模块增加 O=4096，变为 12800；卸载后仍保留历史标记，不伪称清零。保存的增量日志未见新 Oops/Panic，但不作整机可靠性承诺。[Linux taint 定义](https://docs.kernel.org/admin-guide/tainted-kernels.html)
5. 只读 `image_update -p` 显示 Image A/B Bootable、最近启动 A，元数据字符串 `XilinxSom_QspiImage_v1.1_20210422`，A/B revision 均 Not defined。不能仅据该制造镜像字符串断定当前 PMUFW 的精确版本。启动日志确有 pinctrl 功能不被固件支持、要求 2023.1+ 的警告；先审查实际启动组合，不直接更新固件。[AMD Ubuntu 24.04 固件说明](https://xilinx.github.io/kria-apps-docs/kv260/2022.1/linux_boot/ubuntu_24_04/build/html/docs/fwupdate.html)
6. `xmutil boardid` 读出载板 `SCK-KV-G` / `XFL1CYYPZ52Y` / `5066-01ED` 后因 multirecord checksum invalid 退出 1。完整 FRU/SOM 身份未验收。不能把错误忽略为 PASS，也不能据此断言板子损坏；未写 EEPROM。
7. 短验收源脚本原只读 thermal_zone，漏掉本板 hwmon；新测试还暴露混合正常值与 NaN 时门禁未拒绝。修复后同时读取 thermal/hwmon，枚举上限/读取失败/非有限/不可信温度均阻止后续 CPU 测试。旧 `quick_check_hwmon_before.txt` 保留退出 1（14 方法中 2 ERROR、1 FAIL）；修复后 17 方法通过。旧已发布验收包不改；新源脚本此次只在 PC 测试，未运行板端 CPU 小样。

## 执行命令、退出码和分域结果

工作目录 `C:\Patientqwen`；下表 Python 均指 `platform\local\a1\venv\Scripts\python.exe`。板端动作由 `platform/qwen35/a10/driver_board_step.ps1 -Step <动作> -OutputPath <对应JSON>` 执行；JSON 保存完整实际命令、原始串口、退出码及时间。执行非零时 PowerShell 包装器返回 2；表内 BOARD 列为板端命令实际退出码，不将两者混淆。

| 域/命令或动作 | 退出码/结果 | 原始证据 |
|---|---|---|
| PC 旧/新契约检查 | 0 / 0；本轮开工已完成，不重复 | `scripts/release/check_contracts.py`、`scripts/release/qwen35_config.py`；原契约未改 |
| BOARD privileged_preflight / kernel_baseline | 0 / 0 | `uart_driver_privileged_preflight_01.json`、`uart_driver_kernel_baseline_01.json` |
| BOARD firmware_inventory / kernel_integrity | 1 / 0，失败保留 | `uart_driver_firmware_inventory_01.json`、`uart_kernel_integrity_01.json` |
| BOARD bootfw_readonly | 1，FRU 部分读取，未通过 | `uart_bootfw_readonly_01.json` |
| BOARD unbound_preflight | 0 | `uart_unbound_preflight_01.json` |
| BOARD stage / 两次 transfer_diagnostics | 7 / 0 / 2 | `uart_driver_stage_01.json`、`uart_transfer_diagnostics_01.json`、`...02.json` |
| PC `serve_driver_once.py` 单次服务器 | 0，服务已结束 | `driver_transfer_server_01.txt` |
| `transfer_driver_uart.ps1 -OutputPath ...01.json` / `...02.json` | 主机 2 / 0；板端 null / 0 | `uart_driver_serial_transfer_01.json`、`...02.json` |
| BOARD load / post / unload / closed_check | 0 / 0 / 0 / 0 | 同名 `uart_driver_*_01.json` |
| PC `python platform/qwen35/a10/test_driver_serial_payload.py` | 0，6 方法（含真实候选文件 PC 往返） | `serial_payload_tests_v3.txt`；v1/v2 亦保留，不叠加独立计数 |
| PC `test_serial_ready.ps1` | 0，原失败复现、3 正则检查及语法解析 | `serial_ready_boundary_tests.txt` |
| PC `test_driver_step.ps1` | 0，12 动作只生成计划，未接板 | `driver_step_plan_tests_v2.txt` |
| PC `python platform/qwen35/a10/acceptance/test_quick_check.py` | 修复前 1，后 0 / 17 方法 | `quick_check_hwmon_before.txt`、`quick_check_hwmon_after.txt` |
| PC `python platform/qwen35/a10/test_driver_board_summary.py` | 0，4 方法；命令回显不能当运行输出 | `driver_board_summary_tests.txt` |
| PC `python platform/qwen35/a10/summarize_driver_board.py evidence/board_platform/A10_20261018_intake --output evidence/board_platform/A10_20261018_intake/driver_board_check.json` | 0；15 份来源 SHA256 与观察串核验 | `driver_board_check.json` |
| ARM64 用户程序 / FPGA / BO / vector-add / DMA 恢复 | NOT_TESTED；新板 vadd 比较数 0 | 未用模块加载冒充这些域通过 |
| Csim / Cosim / 综合 / 实现 / 模型语音 | 本增量未执行；已有证据不重做 | 原阶段结果保留 |

## 设计差距、实际改动与指标

- D09/D11：已把模块签名策略、九类绑定候选、有效温度、原始 taint、引用者及普通卸载纳入真实短检查，新增全程来源哈希。之前“模块无法加载”已缩小为“PL/DT/固件运行配套与计算路径仍未验收”。不更改公共数学。
- 实际代码：`driver_board_step.ps1`、`driver_serial_payload.py`、`transfer_driver_uart.ps1`、对应 3 个测试入口；短验收 `acceptance/quick_check.py` 及测试；离线 `summarize_driver_board.py` 及测试。`serve_driver_once.py` 是本轮失败后已关闭的受限传输入口，不是常驻服务。
- 温度门禁：修复前新增测试 3 项失败；修复后 17 方法通过。传输：首次未确认，第二次固定文件 167/167 ACK 和 SHA 一致。没有计算吞吐/性能提升数据，相关值为 null/NOT_TESTED。
- 更新 `docs/PROJECT_STATUS.json`、`docs/status/A.md`、设计差距/测试矩阵/AI 辅助记录，保留 A00—A17 历史及原失败。未 commit/push。

## 未决项与下一步

必要 P0/P1（不是可忽略的 P2）：(1) 完整身份/FRU 读取错误与启动 FIT、固件/API 的对应性；(2) 2026.1 平台产物、XRT 2.23 SDK 与板上 2.18 的真实兼容性；(3) PL overlay 切换/匹配/恢复的精确方案；(4) 旧 vadd host 超时仍可能释放活动 BO 的生命周期问题，修复并电脑验证前禁止运行旧 1000 次入口；(5) 有界 ARM 小样、真实 metadata BO 分组、最小 vadd、BO 预算/同步及恢复。必须先小样，再讨论带休息的短批次，不能取消原要求而称 A10 全通过，也不能无视用户“不长时高负荷”的更新约束。

下一步先在电脑完成启动组合/接口及超时隔离审查；必要时只补少量只读板端信息。PL/DTBO 加载不在已批准的一次驱动检查中，必须提交准确产物哈希、短测/停止条件、恢复方案并另获授权；不自动刷 QSPI、不采用复位试错、不扩大内存试探。

P2 单列：自动联网部署、持久 DKMS/自动加载、持续温度看板、吞吐/线程/AXI 优化、极限内存探测均 NOT_IMPLEMENTED/NOT_TESTED。当前不为优化增加板端负荷，也不把这些建议算已实现。
