# A10 完整内核电脑准备、原启动备份及临时网络

2026-10-19。**A10 NOT_PASSED。** 数值回归仍为 `CANCELLED_BY_USER`；本轮真实计算0次、计算BO分配0次。原A00—A17与历史失败不改写。

## 板上已完成的有限动作

用户分别确认上电/风扇/串口已关闭、登录、sudo验证，授权临时IP和只读启动备份，随后单独授权NetworkManager内存静态连接。当前boot ID `31582feb-665b-49ad-a289-1cfe8e2ee4f1`；身份与原板机器摘要一致。

直接 `ip addr add` 曾成功，但原NetworkManager DHCP每45秒失败重试并清掉地址。原失败与短时只读诊断保留，没有循环修改。新临时连接：

- `a10-temp-20261019`，UUID `7423b8d4-31b0-4f1f-ae1b-4c265047a101`，eth0 `192.168.2.2/24`。
- 通过 `nmcli connection add save no` 建立；首次创建/激活成功，后续属性查询超时exit124；没有重建连接。独立D-Bus读回 `Unsaved = true`，exit0、0.415秒。
- 无网关/DNS、never-default、autoconnect关闭；不改电脑VPN、路由、Wi-Fi、防火墙或永久网络文件。Windows SSH指定本地源地址 `192.168.2.1`，严格固定板端SSH公钥。电脑默认选路曾指向既有VPN；不能把全部连接失败归因于VPN，IP被NM清除也有直接证据。
- 最后只读温度30.767/32.407/31.723°C、负载0.03/0.05/0.09，默认 `k26-starter-kits_image_1` 仍在，ZOCL不在。没有PL装卸、驱动加载、重启、复位、FWUEN或QSPI/启动介质写入。COM5、SCP会话均已关闭。
- 临时连接当前保留以备后续传输；重启消失。若主动撤销，在串口执行 `sudo nmcli connection delete uuid 7423b8d4-31b0-4f1f-ae1b-4c265047a101`；会中断该SSH网络。不得删除原netplan连接。

## 原启动材料备份与更正

原 `/boot/firmware/image.fit` 64453664B，SHA256 `b007246e409140c73485a057a0e7ccc1fac7116c14699837e4066e74be7532a9`。本地 `platform/local/a10-boot-backup-20261019/fit-v2/image.fit` 与原端一致；SCP exit0，传输显示约11秒，包含认证等待的下载包装器26.03秒。首次SCP255保留在fit-v1，不覆盖失败。

原 `boot.scr.uimg` 8000B，SHA256 `690fe1225a017a63796df1517b8b203fe9b7500597b2c5a61a0f524875ea2efc`。本地 `script-v1/` 保存二进制、只读解码与manifest；uImage头/数据CRC与单脚本边界通过，8项解析单元测试exit0。**未执行脚本内容。**

更正此前回退草案：“脚本内容没有获得”遗漏了 `uart_userspace_origin_followup_01.json` 的成功读取。另一份日志strings失败exit127仍真实，但不能据此判定全部证据都缺件。本轮完整二进制备份再次证实选择逻辑：SCK-KV-G revB/1/2对应KV260 revB配置，而不是盲用FIT的SOM-only默认项。

启动分区为板端 `/dev/mmcblk1p1`，根分区 `/dev/mmcblk1p2`；启动分区可用969470KiB。该设备名不能代入电脑读卡器操作。

电脑从备份提取原组件，没有修改备份或板文件：

| 组件 | SHA256/结果 |
|---|---|
| kernel.gz | `b0b4434dc32f6d6662ff91d0b35b835fd2f523ee8c51d58c5651cde24d3092dc`，与原安装内核摘要一致 |
| ramdisk | `cdfd3b01230944d912f66475b38283bfdb576f516cbb38fd0da4077354b48a94` |
| KV260 revB DTB | `32dc08a08a87aba2ab0ca68bc5292c735943c20ecd0dc7472690bd152fb7c7a3`，model/compatible读回符合KV260 revB |
| initramfs清单 | 2499行，SHA `1386de324f98f5aee0f19f8695ba5b37e1aacef4cfc9998bad881e2578cf32a8`；包含旧版本模块，不是候选的匹配模块 |

备份成功不是还原实测、整盘镜像或原模块树完整备份；这些未做的事情不标PASS。只读组件检查结果在 `kernel_full_fit_inspection_02.json`、`kernel_full_initramfs_inventory_01.json`。

## 电脑构建与实际改动

新建私有工作目录 `/home/member-a/a10-kernel-full-20261019-v1`，原Ubuntu源码包和修复补丁SHA锁定，原/候选三文件再次精确核对。使用完整Ubuntu发行补丁而非仅三个对象，目标独立版本 `6.8.12-a10irq1`，不冒充 `6.8.0-1015-xilinx`。Ubuntu原树SUBLEVEL为12；独立版本命名不是更换了另一个来源包。

使用已有2026.1交叉工具，GCC13.4与原13.3差异保留。原内核配置继承后仅明确设置LOCALVERSION/版本签名；olddefconfig产生的工具能力差异在 `kernel_full_configure_01.json`完整记录，包括GCC_PLUGINS能力启用而具体插件关闭、未启用的Rust能力变化等。BTF/DWARF5、模块签名、原公开证书未静默关闭；新私有签名密钥仅在私有电脑构建目录中，不放入工程交付或日志。

主机依赖通过 `apt-get download` + `dpkg-deb -x` 置于私有目录，无全局安装/升级。启动工具首次下载因旧APT索引引用已移除u-boot-tools .7包而404、exit100；改用Ubuntu签名索引的**私有APT目录**，取得索引选定的.8包，exit0。其他已成功包不重下载，原失败保留。

完整构建在电脑执行 `timeout 2700s nice -n 10 make ... -j8 Image modules dtbs`。**当前完整构建仍运行，最终退出码尚未产生；不是PASS。** 详细原始日志 `/home/member-a/a10-kernel-full-20261019-v1/logs/full-build-01.log`，最终包装器会写 `kernel_full_build_01.json`。编译工作不在板子上进行。

新增 `build_full_zocl.sh` 与 `audit_full_zocl.py`，要求完整内核成功凭据、全新XRT源码解包、独立候选vermagic和最终Module.symvers逐符号CRC；**仅准备，尚未运行驱动重编译。** 新增5项元数据拒绝测试通过，包括旧vermagic、错误架构/版本与重复字段。原旧版审计工具没有被改成接受新版本。

## 新发现的计算前门禁

`irq_driver_context_risk_01.json` 记录5份精确源/metadata SHA和行号，审查脚本exit0只表示证据采集成功，不表示驱动安全。固定vadd metadata开启中断，CU probe由此注册handler；XRT2.18的 `zocl_xgq_intc.c` 在irqsave自旋锁区调用request_irq/free_irq/disable_irq；匹配内核包含GFP_KERNEL分配、mutex或等待路径。这是**静态上下文风险，未在板上触发/复现**，也不是已观察到板故障。

当前三文件内核修复不修复该驱动路径；单改scheduler polling也不能证明CU probe不注册IRQ。必须先在电脑继续评审并修复/验证适用路径，不能修改xclbin数学/metadata来假装通过，也不在旧板上做危险复现。并发IRQ、在途DMA恢复仍未证明。

## 命令、退出码与证据

工作目录 `C:\Patientqwen`；完整argv/stdout/stderr见各JSON。Windows包装器统一为 `platform/local/a1/venv/Scripts/python.exe platform/a1/record.py --log <新记录> -- <命令>`。

| 命令/动作 | 退出码/证据 |
|---|---|
| 历史契约/新版配置校验 | 0/0，`kernel_full_contracts_01.json`、`kernel_full_config_01.json` |
| WSL `prepare_full_tree.sh` / `prepare_full_deps.sh` / `configure_full.sh` | 均0，`kernel_full_tree_01.json`、`kernel_full_deps_01.json`、`kernel_full_configure_01.json` |
| WSL `build_full.sh` | RUNNING，`kernel_full_build_01.json`尚为预留状态 |
| PowerShell串口动作计划测试 | 最新26动作exit0，`kernel_full_uart_plan_tests_07.json`；03正则误判exit1保留后已修复 |
| Python `test_boot_backup.py` / `decode_boot_backup.py` | 8方法0 / 解码0，`kernel_full_boot_backup_tests_01.json`、`kernel_full_boot_backup_decode_01.json` |
| WSL `inspect_original_fit.sh` | 首100/修复后0，`kernel_full_fit_inspection_01.json`、`02.json` |
| WSL `inventory_original_initramfs.sh` | 0，`kernel_full_initramfs_inventory_01.json`；电脑27.11秒，不是板耗时 |
| Python `test_full_zocl.py` | 5方法0，`kernel_full_zocl_metadata_tests_01.json` |
| 三个新/改Shell脚本语法检查 | 逐文件0，`kernel_full_script_syntax_01/03/04.json`；中间WSL命令字符串的变量被外层展开、exit126保留在02，改为无变量的直接脚本参数后通过，未执行板命令 |
| WSL `audit_irq_callpath.py` | 0，`kernel_full_irq_callpath_01.json`，结果为OPEN风险而非驱动PASS |
| UART重接 | 第一次登录提示未发命令，第二次0；`uart_resume_kernel_full_01/02.json` |
| UART启动只读备份/IP添加 | 0/0，`uart_boot_recovery_readonly_01.json`、`uart_temporary_ip_resume_01.json` |
| UART网络诊断 | 124/2，`uart_boot_network_readonly_01/02.json`；超时/末尾不存在目录保留，NM DHCP失败日志已采集 |
| 内存连接建立/独立验证 | 124（建立激活已成功，尾部查询超时）/0，`uart_temporary_nm_connection_01.json`、`uart_temp_connection_unsaved_01.json` |
| SCP原FIT | 首255/后0，`platform/local/a10-boot-backup-20261019/fit-v1/download.json`、`fit-v2/download.json` |

## 未决与下一步

1. 等完整电脑构建真实结束；失败保留最小错误/日志再修，不覆盖失败凭据。
2. 匹配新内核的ZOCL、模块目录、initramfs/FIT仍未完成；源级中断上下文风险须先评审处理。原件不覆盖，不把可编译候选标为可部署。
3. 确认实际U-Boot能力和独立候选一次性启动/回退后，向用户申请精确的板文件写入与一次试启动；当前没有此授权。
4. 干净恢复闭环之前，不做单次PL计算。最小I/O、约49KiB小BO/同步与实际内存双账仍NOT_TESTED；旧20长度/1000及重复数值回归不补跑。

P2：长期负载、极限内存、性能优化、故障注入均未实施。本轮不改模型、语音、HLS数学或频率参数，无提交/上传。
