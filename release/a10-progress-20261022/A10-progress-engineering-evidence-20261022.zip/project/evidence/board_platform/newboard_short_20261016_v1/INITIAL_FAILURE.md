# 首次真实构建失败（保留）

2026-10-16，命令：

`wsl -d KV260-A-2204 -- bash /mnt/c/Patientqwen/platform/qwen35/a10/acceptance/build.sh /mnt/c/Patientqwen/evidence/board_platform/newboard_short_20261016_v1/build`

当时build.sh使用`-static`。PC原生4MiB单次写读与dot=16通过，耗时0.008765秒（仅电脑，不是板速）。随后2026.1 SDK链接报错：`ld: cannot find -lc: No such file or directory`，`collect2: error: ld returned 1 exit status`。整体退出码1。

原因：该现有SDK未提供静态libc。修复为显式使用相同SDK的动态libc链接，仍固定Cortex-A53，不重装依赖、不静默换编译器。首次build目录保留，不覆盖；动态重建使用build-dynamic-v2。实际板上动态库兼容性与执行仍NOT_TESTED。
