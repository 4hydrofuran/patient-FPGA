# A10 首次到板前置检查

2026-10-08（Asia/Shanghai）。用户确认已拿到板卡；这不是已核实板身份或平台通过。当前 **WAITING_PHYSICAL_IDENTIFICATION_AND_CONNECTION**，A10未通过，BOARD各项NOT_TESTED。

## 已执行

- 读取当前AGENTS、PROJECT_STATUS、N02状态/最近提交，A09收口报告、部署清单、公共SP_LINEAR/W4A8及voice协议概要、设计D09/D11。
- 复用A09通过及既有2026.1平台/交叉构建证据，不重装工具、不重新迁移或重跑200轮。
- 从`53b4666`建立`member-a/a10-bringup-20261008`，原27项tracked修改保留。
- `check_contracts.py`退出0（旧契约DRAFT保留）；`qwen35_config.py`退出0（静态配置，不是板端或应用运行通过）。完整命令见同目录两个command.json。
- 电脑只读`Win32_SerialPort`查询退出0，无条目。不能据此断定板卡损坏；可能尚未连接、线缆或驱动未就绪。没有打开串口，没有扫描网络/猜IP。
- 复核现有A-vadd源码，SHA与既有BO-guard交叉构建记录一致。已有metadata group_id和地址范围检查，但超时throw会展开栈上的run/BO；在未证实静止时不满足资源保留要求。**修复并验证该路径前禁止运行该旧主机**。本轮尚未修复，也未宣称安全恢复通过。

## 当前门槛

1. CONNECT01：等待板子全貌/接口/散热与电源铭牌照片、microSD现状、数据线及网线连接。
2. BOOT01：原Common平台、Kria EDF候选和固件仍不能随意拼接。优先保存已有可启动系统身份和串口日志；如需新写SD，先确认准确盘号/唯一ID/容量、镜像hash、原数据备份与恢复方案，再单独请求授权。QSPI不顺带更新。
3. MEM01：实际DT、MemTotal/CMA、XRT拓扑、BO可达范围/预算未读到，全部null；3200MiB仅规划，不能启动探尽内存的试验。
4. SAFE01：A-vadd超时资源隔离需要修复；中央板卡租约尚未登记，不能填假身份、主机key或释放确认。

## 现在用户需要做的事

先不要接12V电源；如果已上电，先说明现状，不为本流程突然拔电。发两张照片：板子全貌（看清接口与风扇散热）、电源铭牌；说明microSD是否由卖家预装系统。

确认是标准KV260后：用**可传数据的Micro-USB线连接J4 UART/JTAG与本电脑USB口**；网线接开发板与路由器/交换机，电脑在同一网络。microSD若已插在正在运行的板上不要拔；空闲卡可准备读卡器，Windows弹出格式化提示时取消。先等待串口确认/日志捕获准备，再按已确认电源规格上电。

KV260官方电源要求12V/3A、中心正极，J12为电源口；J4为USB UART/JTAG。以实物板身份和铭牌核验为准，不把USB调试连接当成主电源。来源：

- [AMD UG1089 电源要求](https://docs.amd.com/r/en-US/ug1089-kv260-starter-kit/Powering-the-Starter-Kit-and-Power-Budgets)
- [AMD UG1089 接口表](https://docs.amd.com/r/en-US/ug1089-kv260-starter-kit/Interfaces)
- [AMD官方KV260工作坊接线](https://github.com/Xilinx/Xilinx_Kria_KV260_Workshop/blob/main/Part%201%3A%20Setup%20Board.md)

## 后续顺序（尚未执行）

识别实物/电源 → 串口捕获 → 保留现有启动或审定介质 → 只读平台采集/SSH身份 → 中央租约与安全主机 → 小BO小长度回环 → 20长度/1000次真实比较 → 有界BO同步/内存归属 → 经授权的重载/恢复。

仅在采集到真实信息后生成验证版board_profile.json，不以待定配置充作实际profile。日志默认本地保存，不上传SSH凭据或许可证。今天没有刷SD/QSPI、登录板卡、加载位流、分配BO或执行模型，原A00—A09/N01—N02结论不变。
