# 首次恢复按键后：待核实，不判成功

2026-10-08，21:13起检查。用户报告按键完成、风扇停止。电脑ifIndex15当前Disconnected，COM4/COM3设备枚举仍OK。

原采集从20:40:40设置1800秒窗口，到本次检查时已过期；会话11839不再存在，events.jsonl没有end记录，进程真实退出码未知。因此无法证明用户本次按键期间的启动输出，不能把日志空白解释为板故障或恢复成功。最后保留的旧日志是20:44:49的U-Boot提示符。

旧脚本finally依赖Get-FileHash，而此前Windows PowerShell子进程曾缺失该命令；这是可能的封存缺陷，不把它断言为原会话退出原因。已改为.NET SHA256，原数据未改。不存在端口COM9998的负向测试单独记录，预期exit1且events有error/close/end，只测PC清理，不发起板命令。

已重新启动仅接收COM4/COM3采集：evidence/board_platform/A10_20261008_uart02，最多3600秒，每端口8MiB，session71504。实际返回两端口READY；未发送任何UART命令、未修改网卡、未写SD/QSPI。新开串口不能找回未采集的旧启动输出。

请用户确认FWUEN和RESET均已释放、PWR IN灯状态；先不再次复位。需要时拍当前板子指示灯/按键照片。官方UG1089说风扇默认恒速，因此不凭“进入恢复模式”推定停转正常。若有异味、冒烟等异常应立即停止供电；尚无此类用户报告。冷却未核实前不运行模型或计算负载。

来源：https://docs.amd.com/r/en-US/ug1089-kv260-starter-kit/Fan-and-Heat-Sink

恢复界面未观察，Linux/BOARD计算/内存/恢复验证仍NOT_TESTED，G1/A10未通过。授权仍限恢复模式只读查看。
