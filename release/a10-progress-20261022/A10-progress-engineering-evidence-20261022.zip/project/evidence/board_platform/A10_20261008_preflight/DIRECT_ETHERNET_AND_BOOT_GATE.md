# A10 直连与启动门槛更新

2026-10-08。用户确认风扇在转、网线另一端为电脑。电脑只读查询证明Realtek物理以太网ifIndex15为Up/1Gbps，已有手动IPv4地址192.168.2.1/24和192.168.1.20/24。没有修改地址、共享上网、VPN、防火墙或WSL，也没有扫描网段。详见ethernet-direct-command.json（退出0）。本机静态地址不意味着本机提供DHCP，不能据此假定板子获得地址。

串口截至12:44:49Z在BOOTP重试后停于`ZynqMP>`，并保留`Unknown command`文本；A被动采集器没有发送任何字节，不猜测错误来源。这是U-Boot提示符，不是Linux shell。主日志继续保留。

## 官方匹配核查

- 2026.1 KV260专用README确实列Ubuntu和Embedded Linux/Yocto为软件选项；不将Versal的启动方法套用到KV260。
- 当前AMD Kria Wiki REST content1641152513/version180明确2026.1 WIC要求该系列新固件，KV260项为01.07，旧固件不兼容。此前Version178历史页未找到01.07的问题已定位为引用旧页面，不能使用历史页证明当前要求。
- 板端实测FSBL/PMUFW 2023.2、U-Boot2023.01与新固件需求不同，尚未验证正式发布包号；没有因为有启动输出就准许写卡/运行PL。
- 本地KV260候选BOOT-k26-smk-kv-sdt-multidomain-20260609231841.bin重验1939796字节，SHA256为`d08a66ba5c04c713ce663ecc74ffb4d34bc0f7e4885c6d0875c7961ce6e8e678`，与离线审查一致。它不是任意carrier通用的整片QSPI镜像，不做raw擦写。
- 官方旧式Kria Boot Image Recovery支持在Linux不可用时通过以太网页面管理A/B启动分区。官方说明MultiBootOffset0x40对应A，符合本次串口；这仅是活动镜像指示，尚未核对恢复页面/持久状态和B槽，不保证B已有可恢复备份。

## 下一小步与授权边界

先请求用户同意**仅进入恢复模式并只读查看状态**，不上传BOOT.BIN、不点击更新、不改A/B状态、不写SD。恢复模式需要用户按实体FWEN/RESET或进行受控上电，操作前核对准确按键。进入模式后，以实际串口确认恢复地址；不要把网页示例地址当已发现设备。

如需电脑增加临时地址，单独说明准确网卡、当前地址、拟加地址及撤销方案，请用户确认；保留其他地址，不开启ICS或关闭防火墙。真正升级另行提供目标槽/地址、旧固件保留或备份、镜像hash、恢复步骤、失败停止点并请求针对性授权。目前SD/QSPI写入均未授权，A10/G1未通过。

## 证据与失败保留

boot-compatibility-current-command.json退出1：子进程Windows PowerShell未找到Get-FileHash，本次无板卡操作。改为独立官方页面查询后，完整重试保存在boot-compatibility-current-retry-command.json；本地固件hash由Python hashlib独立读取核对。初次失败不删除。网页工具部分URL抓取失败，未把失败当作“文档无此要求”，改读官方REST返回的当前页面。

来源：

- https://raw.githubusercontent.com/Xilinx/Vitis_Embedded_Platform_Source/f7bdd9f5c8ef52636b138f3bbe751148d9690de1/Xilinx_Official_Platforms/kv260_base/README.md
- https://xilinx-wiki.atlassian.net/wiki/rest/api/content/1641152513?expand=body.storage,version
- https://docs.amd.com/r/en-US/ug1089-kv260-starter-kit/Boot-Image-Recovery-Tool
- https://xilinx.github.io/kria-apps-docs/bootfw/build/html/docs/bootfw_overview.html
- https://xilinx.github.io/kria-apps-docs/bootfw/build/html/docs/bootfw_image_recovery.html
