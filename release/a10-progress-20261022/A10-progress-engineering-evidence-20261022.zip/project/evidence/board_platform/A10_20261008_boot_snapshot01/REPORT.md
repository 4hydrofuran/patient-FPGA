# A10 首次真实上电观察

2026-10-08。用户接通已确认中心正极的12V/3A适配器和网线，A仅被动接收串口。**已到U-Boot，未进入Linux；A10/G1未通过。**

## 已证实

- COM4为主控制台；COM3输出Pegasus Splitter日志，不将它当Linux控制台。
- U-Boot识别`ZynqMP KV260 revB`、芯片`xck26`。SOM FRU为SMK-K26-XCL2G，carrier为SCK-KV-G/revision2；carrier序列号与电脑FTDI枚举一致。详细身份仅存本地OBSERVATION.json。
- FSBL/PMUFW显示2023.2，U-Boot显示2023.01（2024-05-10构建）。这不是2026.1固件已安装的证据；正式发布包号及活动槽未核实，不能只按年份猜版本号。
- SD卡仍在电脑读卡器，板上没有系统卡。日志显示SD探测失败，随后尝试BOOTP网络启动并重试，快照中没有获得IP或Linux提示。
- `DRAM: 2 GiB (effective 4 GiB)`原文保留；Linux MemTotal/CMA、PL可达范围及预算仍null。

## 错误与限制

完整保留`PHY reset timed out`、后续`auto negotiation ... done`、SD -110、`SMK-K26-XCL2G: No match`及BOOTP重试。网络协商完成不等于SSH可用，SD未插时的报错不据此判定卡槽损坏。首字节及COM3存在非UTF-8字节，原始.bin保留，.txt仅供查看。

现有2026.1镜像/固件离线审计与Common平台匹配缺口仍未消失。Kria专用官方说明确认2026.1采用UEFI启动流程，但不能凭此直接刷写或把已有旧U-Boot与新镜像宣布兼容。旧审计引用的Wiki历史页本轮打开显示Version178/旧内容且未找到01.07；其历史引用不能替代当前版本匹配核验。

- 官方Kria流程：<https://xilinx.github.io/kria-apps-docs/yocto/build/html/docs/yocto_kria_support.html>
- 当前Kria入口：<https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/1641152513/Kria+SOMs+Starter+Kits>

## 证据和命令

`platform/qwen35/a10/snapshot_uart.py evidence/board_platform/A10_20261008_uart01 evidence/board_platform/A10_20261008_boot_snapshot01`退出0；完整argv/时间/输出见`../A10_20261008_preflight/uart-snapshot01-command.json`。SNAPSHOT.json记录原始字节SHA256并在复制后重读核对。快照为运行中采集文件的顺序读取，不宣称原子快照或完整会话封存，`capture_end_observed=false`。原始采集仍在最多1800秒窗口内。

没有发送串口命令，没有SSH登录/扫描网络，没有刷SD/QSPI、复位、PL加载、BO分配或vector-add执行。真实回环累计仍为0次（未执行，不是性能0）。安全主机修复、Linux启动、平台内存核查、租约和恢复验证均仍待完成。
