
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
struct drm_zocl_dev { int marker; } private_data;
struct device_private { int knode_bus; } priv;
struct device_node { int refs; } node;
struct device { int refs; void *data; struct device_private *p; struct device_node *of_node; };
struct platform_device { struct device dev; } target;
struct bus_type { int unused; } platform_bus_type;
struct subsys_private { int klist_devices; } subsys;
struct klist_iter { int visited; struct device *held; };
static int present, releases, get_calls, put_calls;
#define container_of(ptr,type,member) ((type *)((char *)(ptr)-offsetof(type,member)))
static void platform_device_release_test_double(struct device *d) {
    /* Exact kernel release ownership edge: platform_device_release -> of_node_put. */
    assert(d->of_node->refs > 0); d->of_node->refs--; releases++;
}
static struct device *get_device(struct device *d) { assert(d && d->refs>0); d->refs++; get_calls++; return d; }
static void put_device(struct device *d) { assert(d && d->refs>0); put_calls++; if (!--d->refs) platform_device_release_test_double(d); }
static void platform_device_put(struct platform_device *p) { put_device(&p->dev); }
static struct subsys_private *bus_to_subsys(const struct bus_type *b) { return b ? &subsys : NULL; }
static void subsys_put(struct subsys_private *s) { (void)s; }
static void klist_iter_init_node(int *list, struct klist_iter *i, int *start) { (void)list;(void)start;i->visited=0;i->held=NULL; }
static struct device *next_device(struct klist_iter *i) {
    if(i->held) { put_device(i->held); i->held=NULL; }
    if(i->visited++ || !present) return NULL;
    i->held=get_device(&target.dev); return i->held;
}
static void klist_iter_exit(struct klist_iter *i) { if(i->held) put_device(i->held); }
static int match_name(struct device *d, const void *name) { (void)name; return d==&target.dev; }
static void *platform_get_drvdata(struct platform_device *p) { return p->dev.data; }

struct device *bus_find_device(const struct bus_type *bus,
			       struct device *start, const void *data,
			       int (*match)(struct device *dev, const void *data))
{
	struct subsys_private *sp = bus_to_subsys(bus);
	struct klist_iter i;
	struct device *dev;

	if (!sp)
		return NULL;

	klist_iter_init_node(&sp->klist_devices, &i,
			     (start ? &start->p->knode_bus : NULL));
	while ((dev = next_device(&i)))
		if (match(dev, data) && get_device(dev))
			break;
	klist_iter_exit(&i);
	subsys_put(sp);
	return dev;
}

struct platform_device *zocl_find_pdev(char *name)
{
	struct device *dev;
	struct platform_device *pdev;

	dev = bus_find_device(&platform_bus_type, NULL, (void *)name,
	    match_name);
	if (!dev)
		return NULL;

	pdev = container_of(dev, struct platform_device, dev);
	return pdev;
}

static inline struct drm_zocl_dev *
zocl_get_zdev(void)
{
	struct platform_device *pdev = zocl_find_pdev("zyxclmm_drm");
	if(!pdev)
		return NULL;
	return platform_get_drvdata(pdev);
}

static inline struct drm_zocl_dev *
fixed_zocl_get_zdev(void)
{
	struct platform_device *pdev = zocl_find_pdev("zyxclmm_drm");
	struct drm_zocl_dev *zdev;

	if (!pdev)
		return NULL;
	zdev = platform_get_drvdata(pdev);
	/* Return borrowed drvdata; caller must retain its bound-device lifetime. */
	platform_device_put(pdev);
	return zdev;
}

static void reset(int exists, int has_private) {
    present=exists; releases=get_calls=put_calls=0; node.refs=2;
    target.dev=(struct device){.refs=1,.data=has_private?&private_data:NULL,.p=&priv,.of_node=&node};
}
static void scenario(const char *name, int calls, int fixed, int exists, int has_private) {
    reset(exists,has_private);
    for(int i=0;i<calls;i++) {
        struct drm_zocl_dev *got=fixed?fixed_zocl_get_zdev():zocl_get_zdev();
        assert(got == ((exists && has_private)?&private_data:NULL));
    }
    int expected=(!fixed && exists)?calls:0;
    assert(target.dev.refs==1+expected);
    /* Simulate unregister after all file, DRM, child and iterator refs are gone. */
    put_device(&target.dev);
    assert(target.dev.refs==expected);
    assert(node.refs==(expected?2:1));
    assert(releases==(expected?0:1));
    printf("%s: device_refs=%d node_refs_at_changeset_check=%d release_calls=%d\n",name,target.dev.refs,node.refs,releases);
}
int main(void) {
    scenario("original_no_client",0,0,1,1);
    scenario("original_observed_8_open_8_close",16,0,1,1);
    scenario("proposal_observed_8_open_8_close",16,1,1,1);
    scenario("original_single_XRT_open_close",2,0,1,1);
    scenario("proposal_single_XRT_open_close",2,1,1,1);
    scenario("original_null_private",1,0,1,0);
    scenario("proposal_null_private",1,1,1,0);
    scenario("proposal_missing_device",1,1,0,0);
    return 0;
}
