
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <errno.h>
#define DRM_INFO(...) ((void)0)
#define DRM_ERROR(...) ((void)0)
#define DRM_WARN(...) ((void)0)
#define ERT_CU_INTC_DEV_NAME "intc"
#define IRQ_DISABLED 0
#define MAX_SOFT_KERNEL 256
#define task_pid_nr(x) 1
#define task_ppid_nr(x) 1
struct device { int unused; };
struct platform_device { struct device dev; void *data; int refs; };
struct xrt_cu { struct { int intr_enable,intr_id; } info; };
struct zocl_cu { struct xrt_cu base; unsigned long flag[1]; int lock; };
struct drm_device { int unused; };
struct drm_file { int unused; };
struct drm_zocl_sk_create { uint32_t cu_idx; int handle; };
enum drm_zocl_scu_state { ZOCL_SCU_STATE_DONE=1,ZOCL_SCU_STATE_READY=2,ZOCL_SCU_STATE_CRASH=3 };
struct drm_zocl_sk_report { uint32_t cu_idx; enum drm_zocl_scu_state cu_state; };
struct zocl_ov_dev { void *timer_task; struct platform_device *ppdev; };
static struct platform_device target,scu;
static struct zocl_cu zcu;
static int present,has_scu,has_data,operation_rc,put_count,stop_count,check_stop;
static struct platform_device *zocl_find_pdev(const char *name) { (void)name;if(!present)return NULL;target.refs++;return &target; }
static void platform_device_put(struct platform_device *p) { assert(p->refs>1);if(check_stop)assert(stop_count==1);p->refs--;put_count++; }
static void *platform_get_drvdata(struct platform_device *p) { return p->data; }
static void __set_bit(int bit,unsigned long *p) { *p|=1UL<<bit; }
static int __test_and_set_bit(int bit,unsigned long *p) { int old=!!(*p&(1UL<<bit));__set_bit(bit,p);return old; }
static int __test_and_clear_bit(int bit,unsigned long *p) { int old=!!(*p&(1UL<<bit));*p&=~(1UL<<bit);return old; }
static void spin_lock_init(int *p) { *p=0; }
static int cu_isr(int i,void *p) { (void)i;(void)p;return 1; }
static int ucu_isr(int i,void *p) { return cu_isr(i,p); }
static void zocl_ert_intc_remove(struct platform_device *p,int id) { (void)p;(void)id; }
static int zocl_ert_intc_add(struct platform_device *p,int id,int(*cb)(int,void*),void *arg) { (void)p;(void)id;(void)cb;(void)arg;return operation_rc; }
static void zocl_ert_intc_config(struct platform_device *p,int id,bool b) { (void)p;(void)id;(void)b; }
static struct platform_device *zert_get_scu_pdev(struct platform_device *p,int i) { (void)p;(void)i;return has_scu?&scu:NULL; }
static int zocl_scu_create_sk(struct platform_device *p,int pid,int ppid,struct drm_file *f,int *handle) { (void)p;(void)pid;(void)ppid;(void)f;*handle=42;return operation_rc; }
static int zocl_scu_wait_cmd_sk(struct platform_device *p) { (void)p;return operation_rc; }
static void zocl_scu_sk_ready(struct platform_device *p) { (void)p; }
static void zocl_scu_sk_crash(struct platform_device *p) { (void)p; }
static void zocl_ov_fini_sysfs(struct device *d) { (void)d; }
static void kthread_stop(void *task) { assert(task);stop_count++; }
static void reset(int exists,int child,int data,int result) {
    assert(target.refs==0 || target.refs==1);
    present=exists;has_scu=child;has_data=data;operation_rc=result;
    put_count=stop_count=check_stop=0;
    target=(struct platform_device){.refs=1};
    scu=(struct platform_device){.refs=1,.data=data?&zcu:NULL};
    zcu=(struct zocl_cu){0};
}
static int user_manage_irq(struct xrt_cu *xcu, bool user_manage)
{
	struct zocl_cu *zcu = (struct zocl_cu *)xcu;
	struct platform_device *intc;
	int ret = 0;

	intc = zocl_find_pdev(ERT_CU_INTC_DEV_NAME);
	if (!intc) {
		DRM_INFO("%s: finding platform device - %s failed\n", __func__, ERT_CU_INTC_DEV_NAME);
		return -ENODEV;
	}

	if (xcu->info.intr_enable)
		zocl_ert_intc_remove(intc, xcu->info.intr_id);

	/* Do not use IRQF_SHARED! */
	if (user_manage)
		ret = zocl_ert_intc_add(intc, xcu->info.intr_id, ucu_isr, zcu);
	else
		ret = zocl_ert_intc_add(intc, xcu->info.intr_id, cu_isr, zcu);
	if (ret) {
		DRM_INFO("%s: request_irq() failed\n", __func__);
		goto out_put_intc;
	}

	if (user_manage) {
		__set_bit(IRQ_DISABLED, zcu->flag);
		spin_lock_init(&zcu->lock);
		zocl_ert_intc_config(intc, xcu->info.intr_id, false); // disable irq
	}

out_put_intc:
	platform_device_put(intc);
	return ret;
}

static int configure_irq(struct xrt_cu *xcu, bool enable)
{
	struct zocl_cu *zcu = (struct zocl_cu *)xcu;
	struct platform_device *intc;

	intc = zocl_find_pdev(ERT_CU_INTC_DEV_NAME);
	if (!intc) {
		DRM_INFO("%s: finding platform device - %s failed\n", __func__, ERT_CU_INTC_DEV_NAME);
		return -ENODEV;
	}

	if (enable) {
		if (__test_and_clear_bit(IRQ_DISABLED, zcu->flag))
			zocl_ert_intc_config(intc, xcu->info.intr_id, true); // enable irq
	} else {
		if (!__test_and_set_bit(IRQ_DISABLED, zcu->flag))
			zocl_ert_intc_config(intc, xcu->info.intr_id, false); // disable irq
	}

	platform_device_put(intc);
	return 0;
}

int
zocl_sk_create_ioctl(struct drm_device *dev, void *data, struct drm_file *filp)
{
	struct drm_zocl_sk_create *args = data;
	uint32_t cu_idx = args->cu_idx;
	struct platform_device *zert;
	struct platform_device *scu_pdev = NULL;
	struct zocl_cu *scu = NULL;
	int boHandle = -1;
	int ret = 0;
	
	if (cu_idx >= MAX_SOFT_KERNEL) {
		DRM_ERROR("Fail to create soft kernel: CU index %d > %d.\n",
			  cu_idx,MAX_SOFT_KERNEL);
		return -EINVAL;
	}

	zert = zocl_find_pdev("ert_hw");
	if (!zert) {
		DRM_ERROR("ERT not found!");
		return -EINVAL;
	}
	scu_pdev = zert_get_scu_pdev(zert, cu_idx);
	if (!scu_pdev) {
		ret = -EINVAL;
		goto out_put_zert;
	}
	scu = platform_get_drvdata(scu_pdev);
	if (!scu) {
		DRM_ERROR("SCU %d does not exist.\n", cu_idx);
		ret = -EINVAL;
		goto out_put_zert;
	}

	ret = zocl_scu_create_sk(scu_pdev,task_pid_nr(current),task_ppid_nr(current), filp, &boHandle);
	if (ret) {
		DRM_WARN("%s Failed to create SK command BO handle: %d\n",
			 __func__, ret);
		boHandle = 0xffffffff;
	}
	
	args->handle = boHandle;
out_put_zert:
	platform_device_put(zert);
	return ret;
}

int
zocl_sk_report_ioctl(struct drm_device *dev, void *data,
		struct drm_file *filp)
{
	struct drm_zocl_sk_report *args = data;
	struct zocl_cu *scu = NULL;
	uint32_t cu_idx = args->cu_idx;
	enum drm_zocl_scu_state state = args->cu_state;
	int ret = 0;
	struct platform_device *zert = zocl_find_pdev("ert_hw");
	struct platform_device *scu_pdev = NULL;
	
	if(!zert) {
		DRM_ERROR("ERT not found!");
		return -EINVAL;
	}
	scu_pdev = zert_get_scu_pdev(zert, cu_idx);
	if (!scu_pdev) {
		DRM_ERROR("SCU %d does not exist.\n", cu_idx);
		ret = -EINVAL;
		goto out_put_zert;
	}

	scu = platform_get_drvdata(scu_pdev);
	if (!scu) {
		DRM_ERROR("SCU %d does not exist.\n", cu_idx);
		ret = -EINVAL;
		goto out_put_zert;
	}

	switch (state) {

	case ZOCL_SCU_STATE_DONE:

		ret = zocl_scu_wait_cmd_sk(scu_pdev);
		break;

	case ZOCL_SCU_STATE_READY:

		zocl_scu_sk_ready(scu_pdev);
		break;

	case ZOCL_SCU_STATE_CRASH:

		zocl_scu_sk_crash(scu_pdev);
		break;

	default:
		/*
		 * More soft kernel state will be added as the kernel
		 * is not completed but ready to take another run.
		 */
		ret = -EINVAL;
		goto out_put_zert;
	}

out_put_zert:
	platform_device_put(zert);
	return ret;
}

static int zocl_ov_remove(struct platform_device *pdev)
{
	struct zocl_ov_dev *ov = platform_get_drvdata(pdev);

	zocl_ov_fini_sysfs(&pdev->dev);

	if (ov && ov->timer_task)
		kthread_stop(ov->timer_task);

	/* The cached parent lookup is owned until its worker is stopped. */
	if (ov && ov->ppdev) {
		platform_device_put(ov->ppdev);
		ov->ppdev = NULL;
	}

	return 0;
}

int main(void) {
    int cases=0;
    for(int exists=0;exists<2;exists++)for(int fail=0;fail<2;fail++)for(int manage=0;manage<2;manage++) {
        reset(exists,1,1,fail?-EIO:0);
        int rc=user_manage_irq(&zcu.base,manage);
        assert(rc==(exists?operation_rc:-ENODEV));assert(target.refs==1);assert(put_count==exists);cases++;
    }
    for(int exists=0;exists<2;exists++)for(int enabled=0;enabled<2;enabled++) {
        reset(exists,1,1,0);
        assert(configure_irq(&zcu.base,enabled)==(exists?0:-ENODEV));assert(target.refs==1);cases++;
    }
    for(int exists=0;exists<2;exists++)for(int child=0;child<2;child++)for(int data=0;data<2;data++) {
        reset(exists,child,data,0);
        struct drm_zocl_sk_create args={.cu_idx=1};
        assert(zocl_sk_create_ioctl(NULL,&args,NULL)==(exists&&child&&data?0:-EINVAL));
        assert(target.refs==1);assert(put_count==exists);cases++;
    }
    reset(1,1,1,0);struct drm_zocl_sk_create invalid={.cu_idx=MAX_SOFT_KERNEL};
    assert(zocl_sk_create_ioctl(NULL,&invalid,NULL)==-EINVAL);assert(put_count==0 && target.refs==1);cases++;
    reset(1,1,1,-EIO);struct drm_zocl_sk_create failed={.cu_idx=1};
    assert(zocl_sk_create_ioctl(NULL,&failed,NULL)==-EIO);assert(target.refs==1 && put_count==1);cases++;
    for(int exists=0;exists<2;exists++)for(int child=0;child<2;child++)for(int data=0;data<2;data++)for(int state=0;state<5;state++) {
        reset(exists,child,data,0);
        struct drm_zocl_sk_report args={.cu_idx=1,.cu_state=state};
        assert(zocl_sk_report_ioctl(NULL,&args,NULL)==(exists&&child&&data&&state>=1&&state<=3?0:-EINVAL));
        assert(target.refs==1);assert(put_count==exists);cases++;
    }
    reset(1,1,1,0);target.refs=2;
    struct zocl_ov_dev ov={.timer_task=&ov,.ppdev=&target};scu.data=&ov;check_stop=1;
    assert(zocl_ov_remove(&scu)==0);assert(stop_count==1 && target.refs==1 && !ov.ppdev);cases++;
    reset(1,1,1,0);ov=(struct zocl_ov_dev){0};scu.data=&ov;
    assert(zocl_ov_remove(&scu)==0);assert(put_count==0);cases++;
    reset(1,1,1,0);scu.data=NULL;assert(zocl_ov_remove(&scu)==0);assert(put_count==0);cases++;
    printf("OWNERSHIP_BRANCHES_PASS cases=%d\n",cases);
    return 0;
}
