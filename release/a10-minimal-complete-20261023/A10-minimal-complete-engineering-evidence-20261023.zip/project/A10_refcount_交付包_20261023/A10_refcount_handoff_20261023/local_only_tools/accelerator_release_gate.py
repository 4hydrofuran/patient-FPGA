"""Quiescence gate: descriptors, surviving VMAs and module references all count.

This is only an additional pre-remove check. It never clears a failed kernel
gate, authorizes computation, kills a worker, unmaps library memory or loads PL.
The XRT worker must finish normally before a successful post-compute teardown.
"""
from pathlib import Path
import os


def accelerator_path(path, cards):
    name=path.removesuffix(' (deleted)')
    return name.startswith(('/dev/dri/renderD','/dev/zocl','/dev/uio','/dev/vfio/')) or name in cards


def mapped_accelerators(text,cards):
    result=[]
    for line in text.splitlines():
        fields=line.split(None,5)
        if len(fields)==6 and accelerator_path(fields[5],cards):
            result.append(line)
    return result


def collect(proc_root=Path('/proc'),cards=()):
    """Root caller; inability to inspect any process is retained as uncertainty."""
    result=dict(device_holders=[],device_mappings=[],scan_denied=[])
    for proc in proc_root.iterdir():
        if not proc.name.isdecimal():continue
        try:
            for fd in (proc/'fd').iterdir():
                try:target=os.readlink(fd)
                except FileNotFoundError:continue
                if accelerator_path(target,cards):
                    result['device_holders'].append(dict(pid=int(proc.name),fd=fd.name,target=target))
            for line in mapped_accelerators((proc/'maps').read_text(),cards):
                result['device_mappings'].append(dict(pid=int(proc.name),map=line))
        except PermissionError:result['scan_denied'].append(int(proc.name))
        except (FileNotFoundError,ProcessLookupError):pass
    return result


def require_release(snapshot,module_refcount,kernel_gate_allowed):
    if not kernel_gate_allowed:raise RuntimeError('KERNEL_GATE_ALREADY_BLOCKED')
    if snapshot.get('scan_denied'):raise RuntimeError('PROCESS_SCAN_INCOMPLETE')
    if snapshot['device_holders']:raise RuntimeError('ACCELERATOR_DESCRIPTOR_STILL_OPEN')
    if snapshot['device_mappings']:raise RuntimeError('ACCELERATOR_VMA_STILL_MAPPED')
    if module_refcount!=0:raise RuntimeError('MODULE_REFERENCE_STILL_HELD')

