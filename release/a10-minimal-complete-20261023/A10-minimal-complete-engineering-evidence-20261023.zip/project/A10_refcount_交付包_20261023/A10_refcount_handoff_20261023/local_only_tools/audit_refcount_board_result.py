"""Independently audit actual captured board outputs and the new release gate."""
import hashlib,json,sys
from pathlib import Path
from accelerator_release_gate import mapped_accelerators,require_release
E=Path('D:/KV260-A10/evidence/board_platform/A10_20261022_refcount_fix')
rows=[json.loads(l) for l in (E/'lifecycle_stopped.jsonl').read_text().splitlines()]
actual=json.loads((E/'actual_output.json').read_text())
# Independent arithmetic directly from captured inputs, not the embedded golden.
expected=[(a+b)%4294967296 for a,b in zip(actual['input_a'],actual['input_b'])]
assert len(expected)==32 and expected==actual['actual_output']
assert actual['guard_words_checked']==4080 and not actual['changed_guard_indices']
assert sum(r['event']=='SINGLE_SUBMISSION_BEGIN' for r in rows)==1
assert sum(r['event']=='POSITIVE_COMPLETION' and r['state']==4 for r in rows)==1
assert sum(r['event']=='FULL_IDLE_LIFECYCLE_PASS' for r in rows)==1
g=[r for r in rows if r['event']=='KERNEL_LOG_GATE'][-1]
assert not g['allowed'] and len(g['rejected_diagnostics'])==1
assert 'expected refcount 1 instead of 2' in g['rejected_diagnostics'][0]['text']
(E/'postcompute_failure.exact.raw.txt').write_bytes(g['raw_log'].encode())
profile=json.loads((E/'final_fault_profile.json').read_text())
stop=profile['postcompute_stop']
maps=mapped_accelerators(stop['maps'],['/dev/dri/card1'])
assert len(maps)==1 and not stop['all_accelerator_holders'] and stop['refcnt'].strip()=='1'
tests=[]
def check(name,state,ref,gate,expected_reason):
    try:require_release(state,ref,gate);reason='ALLOWED'
    except RuntimeError as error:reason=str(error)
    assert reason==expected_reason,(name,reason)
    tests.append(dict(name=name,reason=reason,expected=expected_reason,pass_check=True))
check('actual_closed_FDs_surviving_deleted_render_VMA',dict(device_holders=[],device_mappings=maps,scan_denied=[]),1,True,'ACCELERATOR_VMA_STILL_MAPPED')
check('actual_VMA_released_but_kernel_fault_latched',dict(device_holders=[],device_mappings=profile['closer_guard_snapshot']['device_mappings'],scan_denied=[]),0,False,'KERNEL_GATE_ALREADY_BLOCKED')
idle=next(r for r in rows if r.get('phase')=='idle_default_restored' and r['event']=='READBACK')
assert idle['module_refcount'] is None and not idle['device_holders'] and not idle['zocl_bound']
check('clean_unbound_module_before_idle_PL_load',dict(device_holders=[],device_mappings=[],scan_denied=[]),0,True,'ALLOWED')
result=dict(status='BOARD_NUMERIC_AND_IDLE_PASS_POSTCOMPUTE_TEARDOWN_FAILED',
 boot_id=stop['boot_id'],kernel='6.8.12-a10irq2',idle_lifecycle_pass=True,controlled_idle_open_close=True,
 real_compute_submissions=1,additional_compute_submissions=0,n=32,pass_numeric=True,
 values_checked=32,guard_words_checked=4080,first=expected[0],last=expected[-1],
 actual_output_sha256=hashlib.sha256((E/'actual_output.json').read_bytes()).hexdigest(),
 failure_raw_sha256=hashlib.sha256(g['raw_log'].encode()).hexdigest(),
 module_sha256='388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c',
 release_gate_checks=tests,
 observed_mechanism='XRT handles closed and descriptor inventory empty, but one 65536-byte deleted render register VMA remained. Releasing completed process removed VMA and module ref1->0; delayed OF cleanup diagnostic retained.',
 step5_complete=False,normal_restore='PENDING_COLD_BOOT',overall_A10='NOT_PASSED',
 future_gate_status='PC_EVIDENCE_CHECKED_NOT_DEPLOYED',process_isolation_status='NEXT_WINDOW_REQUIRED_NO_COMPUTE_REPLAY')
(E/'board_result_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
