# A10 refcount 简洁交付包

整理日期：2026-10-23。先读本文件，再读根目录 `HANDOFF.md`；当前结论以 `STATUS.json` 及最终恢复/关机收据为准。HANDOFF原文逐字节收入，内含按时间保留的旧状态。

## 本轮结论

修复驱动后：**空载生命周期PASS；唯一一次N=32数值PASS；计算后卸载FAILED；正常1036恢复PASS，随后按用户要求正常关机。** 最后观测为2026-10-22 23:47 Power down；本次打包没有连接板子，不能把关机前boot ID当作下一次启动标识。

## 内容与部署边界

| 路径 | 内容与状态 |
|---|---|
| `HANDOFF.md` | 最新完整交接原文，未修改 |
| `local_only_tools/` | 未部署的设备fd/VMA/模块引用/内核门禁组合检查，以及本机证据审计脚本；原件未改动 |
| `driver_source/` | 已修订的完整ZOCL源码、5文件补丁及版权说明；这部分**已传板、编译并验证过**，作为可复用基线收入 |
| `reference_artifact/` | 已测试的467504字节模块；未覆盖系统原默认驱动 |
| `build_context/` | 精确irq2运行配置、完整符号CRC表及差异检查；不是完整内核构建目录或SDK |
| `pc_component_checks/` | 真实修订函数生成的C组件检查源码与既有结果；不是实板计算证据 |
| `evidence/01_original_idle_failure/` | 修复前空载卸载的原始dmesg及完整原始JSONL |
| `evidence/02_repaired_trial/` | 修复后试验原始JSONL、计算后错误原始dmesg、真实输出、设备映射快照、延迟释放错误UART原件；原字节保留 |
| `evidence/recovery/` | 正常恢复、租约归档及最终关机收据 |
| `reports/` | 引用排查与修复/断点报告 |
| `SOURCE_MAP.json` / `MANIFEST.json` | 每个原件的来源、部署状态、包内全部文件长度与SHA256 |

### 尚未完成的部分

独立XRT工作进程编排**尚未实现**，并不存在“已修好但尚未传板”的完整下一版执行器。未部署工具仅是新增检查，不会自动结束工作进程、卸载PL、修复内核错误或解除已失败的内核门禁。

`audit_refcount_board_result.py` 是原本机脚本，保留D:/KV260-A10绝对路径及既有输出行为；不要在解压目录直接重跑它。可移植的包内只读核验使用下方 `verify_package.py`。

补丁基于此前IRQ修订基线，完整 `driver_source/zocl-refcount-v1` 为准；不要将补丁盲用于任意上游版本。原 `source_fix_manifest.json` 的NOT_BUILT/NOT_BOARD和中间审计的PENDING_COLD_BOOT均为历史记录，最终状态已在STATUS中说明。

## 三段关键原始证据

1. 原空载卸载：`evidence/01_original_idle_failure/failure_dmesg.exact.raw.txt`，SHA256 `949fc8e0efbb9136ae12879809eb91d45a6f8b72c8c0add33368b63b83723643`。
2. 修复后计算完成再卸载：`evidence/02_repaired_trial/postcompute_failure.exact.raw.txt`，SHA256 `684bf26f65594929bb82a49adac1260bb214d63c0d5d9ce2a4340d0a71481a8d`；含expected refcount1 instead of2。
3. 释放残留映射时：`evidence/02_repaired_trial/31_close_completed_guard.raw.txt`，原UART中保留 `memory leak before free overlay changeset`。`final_fault_profile.json` 保存原进程无设备fd、仍有64KiB deleted render VMA，以及后续映射消失/module refcount0的快照。

下一次：新干净irq2窗口，先实现“XRT工作进程正常退出→全进程fd/VMA清零、module refcount0、内核门禁未失败→卸载”；优先做不提交计算的加载/关闭覆盖验证。已成功的N32不自动重跑。历史租约、PID、窗口、原执行包清单均不可作为新窗口执行依据。

## 离线核验

Python 3.9及以上，在解压目录执行：

```text
python verify_package.py
```

只校验包内文件摘要、原始日志、HANDOFF副本、驱动修订和一次计算结果，并用真实失败快照检查新门禁；不访问串口、网络或设备，不执行任何旧板端入口。包内不含登录密码、私钥、临时文件桥凭据、模型、位流、完整SDK或一键部署脚本。
