"""Offline integrity and captured-result checks; never touches a board."""
import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
files=manifest['files']
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
assert actual==set(files)|{'MANIFEST.json'},'Package inventory differs'
for name,row in files.items():
 p=root/name
 assert not p.is_symlink() and p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],name
e=root/'evidence/02_repaired_trial'
r=json.loads((e/'actual_output.json').read_text())
expected=[(a+b)%4294967296 for a,b in zip(r['input_a'],r['input_b'])]
assert len(expected)==32 and r['actual_output']==expected
assert r['real_submissions']==1 and r['guard_words_checked']==4080 and not r['changed_guard_indices']
rows=[json.loads(l) for l in (e/'lifecycle_stopped.jsonl').read_text().splitlines()]
assert sum(x['event']=='SINGLE_SUBMISSION_BEGIN' for x in rows)==1
assert sum(x['event']=='POSITIVE_COMPLETION' and x['state']==4 for x in rows)==1
assert sum(x['event']=='FULL_IDLE_LIFECYCLE_PASS' for x in rows)==1
gate=[x for x in rows if x['event']=='KERNEL_LOG_GATE'][-1]
assert not gate['allowed'] and 'expected refcount 1 instead of 2' in gate['new_text']
assert gate['raw_log'].encode()==(e/'postcompute_failure.exact.raw.txt').read_bytes()
source=json.loads((root/'evidence/build/source_fix_manifest.json').read_text())
for row in source['changes']:
 p=root/'driver_source/zocl-refcount-v1/driver/zocl'/row['file']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['after_sha256']
sys.path.insert(0,str(root/'local_only_tools'))
from accelerator_release_gate import mapped_accelerators,require_release
profile=json.loads((e/'final_fault_profile.json').read_text())
stop=profile['postcompute_stop'];maps=mapped_accelerators(stop['maps'],['/dev/dri/card1'])
assert not stop['all_accelerator_holders'] and len(maps)==1 and stop['refcnt'].strip()=='1'
def rejects(snapshot,ref,kernel_ok,reason):
 try: require_release(snapshot,ref,kernel_ok)
 except RuntimeError as error: assert str(error)==reason;return
 raise AssertionError('Expected gate rejection')
rejects(dict(device_holders=[],device_mappings=maps,scan_denied=[]),1,True,'ACCELERATOR_VMA_STILL_MAPPED')
rejects(dict(device_holders=[],device_mappings=[],scan_denied=[]),0,False,'KERNEL_GATE_ALREADY_BLOCKED')
assert 'memory leak before free overlay changeset' in (e/'31_close_completed_guard.raw.txt').read_text()
assert json.loads((root/'evidence/recovery/shutdown_receipt.json').read_text(encoding='utf-8-sig'))['status']=='LINUX_POWER_DOWN_CONFIRMED'
print(json.dumps(dict(status='OFFLINE_PACKAGE_VERIFIED',files=len(files),source_changes_verified=5,
 original_evidence_bytes_verified=True,real_compute_submissions=1,numeric_values_checked=32,
 guard_words_checked=4080,postcompute_teardown='FAILED_PRESERVED',release_gate_cases=2,
 board_access=False,worker_process_implementation='NOT_IMPLEMENTED'),ensure_ascii=False,indent=2))
