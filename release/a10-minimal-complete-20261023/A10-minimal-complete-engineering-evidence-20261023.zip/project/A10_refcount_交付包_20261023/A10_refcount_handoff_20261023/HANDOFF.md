## 今日开发结束：板载Ubuntu已正常关机（2026-10-22 23:47）

用户明确要求暂时关闭Ubuntu和板子。已重新核对正常1036/bootID24ce9a69-bef3-450a-8490-d8c88d6734d0、安装身份、默认PL，无active租约、ZOCL、计算fd或VMA；双锁可排他取得。只提交一次正常poweroff，串口已实际观测 `reboot: Power down`，COM4已释放。板子现在处于系统已关机、可断开外部电源的状态，不再以此前running状态作为当前状态。

本机WSL未安装，未发现运行中的Ubuntu虚拟机进程。第五步冻结结果保持不变；下次接续先正常上电并重新核对新boot ID、默认系统和资源所有权，不复用历史PID/窗口。

关机证据：`D:/KV260-A10/evidence/board_platform/A10_20261022_end_of_day_shutdown/`。

---

# 2026-10-22 23:40前收尾：空载与一次计算通过，计算后卸载仍失败

## 冻结终点：正常1036恢复已核验

2026-10-22本轮已在23:40截止前停止新增验证并冻结进度。用户操作断电上电后，正常内核 `6.8.0-1036-xilinx`，boot ID `24ce9a69-bef3-450a-8490-d8c88d6734d0`；默认 `k26-starter-kits_image_1=applied`，FPGA operating，ZOCL未加载、无计算render节点/设备fd/设备VMA；gdm active，系统running、failed unit0。

正常/候选启动文件、原驱动、XRT库及默认PL源文件摘要与冻结基线完全一致。恢复boot-only租约原字节已归档（SHAefd287d0a2c451a6f4044775f86266b6374ba0109bfb66ff7b7093f40fe608ff），独立回读active不存在、双维护锁无持有者。临时文件桥已停止，sudo缓存已清除，COM4已释放。

本轮结论：**空载PASS，一次N32数值PASS，计算后卸载FAILED，正常系统恢复PASS；第五步整体尚未完成，整体A10未通过。** 旧诊断与软件重启限制仍保留。冻结收据：`D:/KV260-A10/evidence/board_platform/A10_20261022_refcount_fix/freeze_receipt.json`；正常恢复证据：同目录 `normal_restore/`。

未完成的独立工作进程编排和卸载门禁实板验证留到下次新窗口。未再次提交计算、未修改默认启动或QSPI、未扩大回归。

本轮截止时间由用户暂定为北京时间23:40。当前先冻结硬件验证范围，完成正常系统恢复核对和交接；不新增计算或扩大回归。

- **已完成的实板里程碑**：修复引用的ZOCL模块已原生构建并核验；干净irq2启动后，首次加载前停止gdm；一次受控render打开/关闭后，测试PL卸载、rmmod及默认PL恢复全部通过。空载生命周期PASS。
- **唯一真实计算**：job7/N=32仅提交1次，XRT正向完成state4，32项与独立整数求和参考全部一致，4080个保护字未改写。首项56447，末项2088621。3个BO各16448字节，实际group=[3,3,3]；不代表内存容量或性能测量。
- **未通过项**：计算后卸载出现 `/axi/zyxclmm_drm` expected refcount1 instead of2。原执行器虽然关闭了XRT句柄、文件描述符，但仍存在64KiB render设备映射，module refcount仍为1。卸载检查漏掉VMA，是本轮执行工具的缺陷，不能据此认定驱动又有同一查找引用泄漏。
- 已确认正向完成和普通XRT资源释放后，受控结束确切计算进程；残留映射消失，module refcount1→0，但新增延迟设备树清理错误 `memory leak before free overlay changeset`。两条错误均保留，不作豁免，不在该故障内核继续加载/卸模块。
- 原计算PID2603/start55793、接续收口守卫PID3254/start108305均已退出；pidfd复制同一双锁OFD保证受控交接，原租约字节归档至 `history/a10-refcount-step5-20261022-v1-completed-compute-teardown-fault`，SHA2104a745cf0e57ba0794cc3bcb2c28c81b1f9d109e01cac9e3a12a4c53200d6a。N32不重放。
- 图形服务恢复active后正常关机；正常1036默认文件没有修改。正常1036冷启动、默认PL、文件摘要和资源收口已核验通过，详见最上方冻结终点。
- **第五步仍未全部通过，整体A10仍NOT_PASSED。** 一次正确PL计算已经取得，剩余为可靠释放/卸载顺序的修订与新窗口验证。

当前证据：`D:/KV260-A10/evidence/board_platform/A10_20261022_refcount_fix/`。独立审计 `board_result_audit.json`；输出 `actual_output.json`（SHA806cc1cb3971cfbf1cf4b8450e220e8b326e87edc50d00b07765806d7cf0339e）；计算后错误原始日志 `postcompute_failure.exact.raw.txt`（SHA684bf26f65594929bb82a49adac1260bb214d63c0d5d9ce2a4340d0a71481a8d）。旧第五步失败原件未改写。

## 下一次从断点接续

1. 首先读取本节、最终normal_restore收据及实际当前boot/锁/租约，不使用已消费的历史入口、旧PID或旧manifest。
2. 保留已通过的独立驱动修订 `work/zocl-refcount-v1`（新模块SHA388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c）。暂不重建位流、整个内核或安装SDK。
3. 修订编排：计算放在独立工作进程，管理进程独占租约与双锁。只有真实正向完成、数值通过且工作进程正常退出，才允许检查卸载；未知/超时保持隔离，不强杀或自动重试。
4. 卸载前必须同时核对所有进程的设备fd、设备VMA（含deleted路径）、ZOCL模块refcount0及未失败的内核门禁。新增 `tools/accelerator_release_gate.py` 已用实际失败快照和内核失败保持检查验证；**尚未部署，独立工作进程编排尚未实现/实板验证**。
5. 新的干净irq2维护窗口，首次加载前隔离图形服务；先以“不提交计算”的XRT加载/关闭及进程退出覆盖残留映射路径，再验证完整卸载/默认PL恢复。已成功的N32不自动重跑；需要额外计算时先明确次数/范围。
6. 所有新内核错误继续阻止下一硬件动作。保留本次空载PASS、一次数值PASS和卸载FAILED三个独立结果，不合并为一次干净生命周期PASS。

下方为本轮较早的构建、故障关闭和待启动记录，仅按时间留档；当前状态以上方与最终收据为准。

---

# 当前正在推进：引用修复模块已构建，旧故障窗口已收口

2026-10-22，用户已明确授权修复并完成第五步；只可使用本机和板子。

- 独立修订源码 D:/KV260-A10/work/zocl-refcount-v1，5文件引用配对修复，原IRQ补丁保留。PC实际C函数组件检查通过（65所有权分支、CU检查46条、查找8场景）。
- 板端私有native工具已下载解包，未全局安装。重建外部模块头文件使用确切运行.config（8e235a...）和与irq2原构建逐字节一致的完整Module.symvers（7e93bb...）。单核低优先级构建第5次尝试成功；前4次工具/路径失败日志保留。实际成功构建约108秒、最高31.35°C、MemAvailable最低3121408KiB。
- 新驱动 zocl.refcount.ko：467504字节，SHA388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c；srcversion15F2AC2306CB3CB7257CFCB；ARM64、irq2 vermagic、238导入CRC全部核验通过；尚未加载，尚未计算。原/lib/modules驱动389928...保持不变。
- 已实际用pidfd复制原双锁OFD、审查PID6818/start538561停止/无设备fd/无XRT/无子进程/无提交后，仅结束该非计算守卫，原lease字节原样归档 history/a10-irq2-step5-20261022-refcount-fault-closed。双锁连续到归档完成，收口后释放。旧active已不存在（后续启动守卫将新建boot-only lease）；当前仍旧irq2、overlay空、旧zocl加载无绑定，默认PL未恢复。
- 证据 D:/KV260-A10/evidence/board_platform/A10_20261022_refcount_fix/。fault_close_receipt.json、stripped_module_audit.json、build_result.final.json为当前里程碑。所有旧执行器已消费，不重放。
- 接下来准备新控制器control_refcount_boot.ps1和新poweroff守卫，需人工断电上电才能干净临时启动irq2。运行前另查controller_state.json，不能重复提交poweroff。软件重启问题仍不依赖。尚未加载PL/驱动或计算；第五步未通过。

---

# 最新接续：设备查找引用泄漏已定位，板端修复仍待验证

2026-10-22排查报告：`D:/KV260-A10/reports/REFCOUNT_AUDIT_20261022.md`。

- 确切XRT2.18源码：`bus_find_device()` 返回带引用设备，`zocl_get_zdev()` 取私有数据后没有归还引用；创建/关闭客户端都调用它。实际日志8次打开、8次关闭，与主设备最终release不发生、节点计数仍为2的机制吻合。
- PC以确切C函数体+设备测试替身复现，8种组件场景通过；不是实板kref测量，也不是完整ARM64模块构建/板端修复通过。`primary_helper_proposal`仅是帮助函数草案，不是完整可部署包；直接find调用者（尤其CU）及并发生命周期还须修订审查。
- 当前实际串口只读回读：仍为原irq2/boot ID；overlay为空、ZOCL refcount0/无绑定/render，gdm running；PID6818 T+，原租约摘要不变。未重新root审计全部fd/双锁；未归档租约、未发信号、未加载/计算/重启。
- 接下来：完成配对修复及匹配irq2的ZOCL交叉构建 → 受控收口当前窗口 → 干净临时irq2启动 → 首次加载前图形隔离 → 空载含一次受控open/close卸载验证 → 唯一N=32及计算后卸载 → 恢复1036/默认PL并收口证据。
- 暂不需要重建HLS/位流/整个内核；本机WSL不可用，Windows GCC只用于组件实验。可复用原irq2 Linux构建环境，不能把已有helper草案当作已编译模块。旧执行器/continuation已消费不可重放，当前故障对象不能手工减引用。
- A10第五步仍FAILED，N=32仍NOT_TESTED，第六步仍待执行。下方第五步故障交接是原事实记录，继续保留。

---

# A10 第五步故障交接：空载卸载引用计数未通过

日期：2026-10-22（Asia/Shanghai）。用户请求完成第五步，另明确允许临时停止并恢复图形登录服务。第五步已实际执行但未通过；最新报告 `D:/KV260-A10/reports/STEP5_MINIMAL_20261022.md`。

- 核心阻断：测试overlay首次卸载，管理命令返回0，但内核报 `OF: ERROR: memory leak, expected refcount 1 instead of 2 ... /axi/zyxclmm_drm`。门禁未豁免，没有执行rmmod、默认PL重载、再次加载或N=32。完整空载生命周期FAILED，计算NOT_TESTED，整体A10 NOT_PASSED。
- 本任务真实核提交0、显式计算BO分配0、新调用工具真实XRT设备打开0；compute_submission.json与actual_output.json均不存在。不能用CPU检查或固定golden冒充硬件数值通过。
- 第一次测试加载后systemd/logind/gnome-shell自动打开计算card1，门禁先停。用户许可后临时停止gdm.service；确认持有者为空、模块refcount0，再继续同一已加载配置的首次卸载，未重复加载。实际32条IRQ DT/绑定通过，枚举终止提示仅按原精确动作规则分类；新的refcount错误没有豁免。
- 原非计算守卫PID5952检查为stopped、starttime446954，无XRT映射/设备fd/子命令，仅持日志和双锁。通过pidfd_getfd复制同一OFD并验证排他后，结束确切的非计算守卫，交接给PID6818；双锁连续。原日志、原租约和独立CPU锁生命周期检查保留；没有终止未知ioctl或在途计算。
- 当前仍是6.8.12-a10irq2，bootID30f5664b-4d24-430e-831b-5f5d139d0157。**不是正常默认PL终点：overlay集合为空，ZOCL仍加载、refcount0，但无绑定/render计算节点。** FPGA manager operating不能代替默认PL恢复。
- active仍在 `/var/lock/kv260-a1/active/lease.json`，scope A10_IRQ2_STEP5_IDLE_AND_ONE_N32，PID6818 stopped，compute_authorized=false；SHA2784bab775f4805ec0dc0ccd18c60bdd0617ab6d97747121a9c4333334b96d1b。部署锁 `/var/lock/kv260-a1/deployment.lock` 和共享锁 `/run/lock/patient-qwen-linear.lock` 都实际排他。未归档/释放，即使租约时间到期，也不能忽略实际持锁进程或套用历史孤儿租约工具。
- 错误后只读确认测试节点消失、无绑定、计算0，单独恢复用户授权的gdm.service，最终active/running；没有为此加载PL或卸驱动，不声称原桌面应用会话恢复。系统running、failed units0。
- 正常1036 FIT23a0ad...、script f1eb9e...、irq2FIT e60d7f...、驱动389928...、XRT库及默认PL源文件与前置摘要一致。**默认PL尚未重新加载，也未返回1036系统。** 本轮无重启/电源动作，软件重启仅FSBL片段的问题未解决；恢复仍考虑人工电源限制。
- 最终MemAvailable3236640KiB、CmaFree812432KiB，温度28.746～31.117°C。只作观测；计划显式BO49344字节，实际地址、group、数值均null。
- 证据 `D:/KV260-A10/evidence/board_platform/A10_20261022_step5/`：step5_receipt.json、board_profile_step5_failed.json、30_final_quarantine.json、evidence_manifest.json。不要覆盖第二或第四步profile。
- failure_lifecycle.jsonl、failure_continuation.jsonl是板端原字节日志；failure_dmesg.exact.raw.txt SHA949fc8e0efbb9136ae12879809eb91d45a6f8b72c8c0add33368b63b83723643。UART/完整journal已保存。180秒等待超时是门禁主动park后未结束，不是计算超时；后来的148是作业停止，不是验收退出码。
- A新包提交015af071ec408359ebb296c9d7eebcf59c778b17，738文件已核验；快照位于upstream/a10_progress_20261022_015af071。原host源码/精确输入已取得，独立golden在本轮bundle。tools/single_xrt_call.py为仅此次最小验证的XRT C ABI调用工具，真实计算分支未执行。
- tools/run_irq2_minimal.py和continue_irq2_step5.py均已消费，绑定本轮停止点/PID/清单，不可重放。uart_paced.ps1负责分段发送与实时本地读回；COM4/115200。准备期CRLF、大传输及Windows缺fcntl失败均保留，后续采集/分块/Linux CPU检查成功。
- 已做旧/新契约静态检查、6种新调用工具PC防错场景、20项原门禁板端CPU替身检查、独立锁生命周期CPU检查；这些不是BOARD数值证据。未安装SDK/编译器、未改HLS/数学/频率，未恢复取消的回归/压力/故障注入，无邮件/自动任务/对外消息。
- 根因未定位：已证明节点多一份引用，不能直接归因桌面或某一驱动函数。首次加载曾有桌面探测背景，其触发作用仍未知。应收集确切源码的引用获取/释放证据，形成独立修订候选；禁止对refcount错误加豁免。
- 后续新启动/加载前，先受控收口当前故障隔离窗口及核验正常恢复；不能把当前当作第五步通过后直接计算。正常1036冷启动和754.4MiB恢复资产可复用，第六步仍NOT_TESTED，B05/模型硬件消费不解锁。
- 最终sudo-k、串口释放。未操作MobaXterm UI，不声称已打开COM4标签。桌面清单、README、计划、执行说明和缺件说明已更新；原文档在history_handoff/before_step5_*。
