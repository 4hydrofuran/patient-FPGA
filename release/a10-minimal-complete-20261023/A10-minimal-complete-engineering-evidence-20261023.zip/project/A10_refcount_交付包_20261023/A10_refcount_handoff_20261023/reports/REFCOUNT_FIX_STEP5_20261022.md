## 今日开发结束：板载Ubuntu已正常关机（2026-10-22 23:47）

用户明确要求暂时关闭Ubuntu和板子。已重新核对正常1036/bootID24ce9a69-bef3-450a-8490-d8c88d6734d0、安装身份、默认PL，无active租约、ZOCL、计算fd或VMA；双锁可排他取得。只提交一次正常poweroff，串口已实际观测 `reboot: Power down`，COM4已释放。板子现在处于系统已关机、可断开外部电源的状态，不再以此前running状态作为当前状态。

本机WSL未安装，未发现运行中的Ubuntu虚拟机进程。第五步冻结结果保持不变；下次接续先正常上电并重新核对新boot ID、默认系统和资源所有权，不复用历史PID/窗口。

关机证据：`D:/KV260-A10/evidence/board_platform/A10_20261022_end_of_day_shutdown/`。

---

# 2026-10-22 23:40前收尾：空载与一次计算通过，计算后卸载仍失败

## 冻结终点：正常1036恢复已核验

2026-10-22本轮已在23:40截止前停止新增验证并冻结进度。用户操作断电上电后，正常内核 `6.8.0-1036-xilinx`，boot ID `24ce9a69-bef3-450a-8490-d8c88d6734d0`；默认 `k26-starter-kits_image_1=applied`，FPGA operating，ZOCL未加载、无计算render节点/设备fd/设备VMA；gdm active，系统running、failed unit0。

正常/候选启动文件、原驱动、XRT库及默认PL源文件摘要与冻结基线完全一致。恢复boot-only租约原字节已归档（SHAefd287d0a2c451a6f4044775f86266b6374ba0109bfb66ff7b7093f40fe608ff），独立回读active不存在、双维护锁无持有者。临时文件桥已停止，sudo缓存已清除，COM4已释放。

本轮结论：**空载PASS，一次N32数值PASS，计算后卸载FAILED，正常系统恢复PASS；第五步整体尚未完成，整体A10未通过。** 旧诊断与软件重启限制仍保留。冻结收据：`D:/KV260-A10/evidence/board_platform/A10_20261022_refcount_fix/freeze_receipt.json`；正常恢复证据：同目录 `normal_restore/`。

未完成的独立工作进程编排和卸载门禁实板验证留到下次新窗口。未再次提交计算、未修改默认启动或QSPI、未扩大回归。

本轮截止时间由用户暂定为北京时间23:40。当前先冻结硬件验证范围，完成正常系统恢复核对和交接；不新增计算或扩大回归。

- **已完成的实板里程碑**：修复引用的ZOCL模块已原生构建并核验；干净irq2启动后，首次加载前停止gdm；一次受控render打开/关闭后，测试PL卸载、rmmod及默认PL恢复全部通过。空载生命周期PASS。
- **唯一真实计算**：job7/N=32仅提交1次，XRT正向完成state4，32项与独立整数求和参考全部一致，4080个保护字未改写。首项56447，末项2088621。3个BO各16448字节，实际group=[3,3,3]；不代表内存容量或性能测量。
- **未通过项**：计算后卸载出现 `/axi/zyxclmm_drm` expected refcount1 instead of2。原执行器虽然关闭了XRT句柄、文件描述符，但仍存在64KiB render设备映射，module refcount仍为1。卸载检查漏掉VMA，是本轮执行工具的缺陷，不能据此认定驱动又有同一查找引用泄漏。
- 已确认正向完成和普通XRT资源释放后，受控结束确切计算进程；残留映射消失，module refcount1→0，但新增延迟设备树清理错误 `memory leak before free overlay changeset`。两条错误均保留，不作豁免，不在该故障内核继续加载/卸模块。
- 原计算PID2603/start55793、接续收口守卫PID3254/start108305均已退出；pidfd复制同一双锁OFD保证受控交接，原租约字节归档至 `history/a10-refcount-step5-20261022-v1-completed-compute-teardown-fault`，SHA2104a745cf0e57ba0794cc3bcb2c28c81b1f9d109e01cac9e3a12a4c53200d6a。N32不重放。
- 图形服务恢复active后正常关机；正常1036默认文件没有修改。正常1036冷启动、默认PL、文件摘要和资源收口已核验通过，详见最上方冻结终点。
- **第五步仍未全部通过，整体A10仍NOT_PASSED。** 一次正确PL计算已经取得，剩余为可靠释放/卸载顺序的修订与新窗口验证。

当前证据：`D:/KV260-A10/evidence/board_platform/A10_20261022_refcount_fix/`。独立审计 `board_result_audit.json`；输出 `actual_output.json`（SHA806cc1cb3971cfbf1cf4b8450e220e8b326e87edc50d00b07765806d7cf0339e）；计算后错误原始日志 `postcompute_failure.exact.raw.txt`（SHA684bf26f65594929bb82a49adac1260bb214d63c0d5d9ce2a4340d0a71481a8d）。旧第五步失败原件未改写。

## 下一次从断点接续

1. 首先读取本节、最终normal_restore收据及实际当前boot/锁/租约，不使用已消费的历史入口、旧PID或旧manifest。
2. 保留已通过的独立驱动修订 `work/zocl-refcount-v1`（新模块SHA388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c）。暂不重建位流、整个内核或安装SDK。
3. 修订编排：计算放在独立工作进程，管理进程独占租约与双锁。只有真实正向完成、数值通过且工作进程正常退出，才允许检查卸载；未知/超时保持隔离，不强杀或自动重试。
4. 卸载前必须同时核对所有进程的设备fd、设备VMA（含deleted路径）、ZOCL模块refcount0及未失败的内核门禁。新增 `tools/accelerator_release_gate.py` 已用实际失败快照和内核失败保持检查验证；**尚未部署，独立工作进程编排尚未实现/实板验证**。
5. 新的干净irq2维护窗口，首次加载前隔离图形服务；先以“不提交计算”的XRT加载/关闭及进程退出覆盖残留映射路径，再验证完整卸载/默认PL恢复。已成功的N32不自动重跑；需要额外计算时先明确次数/范围。
6. 所有新内核错误继续阻止下一硬件动作。保留本次空载PASS、一次数值PASS和卸载FAILED三个独立结果，不合并为一次干净生命周期PASS。

下方为本轮较早的构建、故障关闭和待启动记录，仅按时间留档；当前状态以上方与最终收据为准。

---

# A10 引用修复与第五步接续执行记录

状态：**驱动修复及构建核验完成；旧故障窗口已收口；已正常关机，等待人工断电上电以开始干净 irq2 板测。第五步尚未通过，真实N=32提交仍为0。**

本轮用户授权修复引用问题，并按断点接续方法完成第五步；用户确认目前只能使用本机和板子。

## 已完成的修复

独立源码：`D:/KV260-A10/work/zocl-refcount-v1/`。精确来源为已校验的 `xrt-dkms 2.18.0-0ubuntu1`，保留此前 `cu.c` 和 `zocl_xgq_intc.c` 的IRQ修复。

- `include/zocl_drv.h`：在取得借用的主设备私有数据后，归还设备查找引用。借用指针仍要求调用者具有有效设备绑定、文件或父子生命周期；不承诺支持并发强制移除。
- `common/cu.c`：为IRQ管理、配置、注册、移除及 `ert_hw` 探测补齐正常和失败分支的引用归还。
- `common/zocl_drv.c`：明确查找API交付带引用设备，为主探测中的ERT查找归还引用。
- `zert/zocl_sk.c`：查找后各提前返回统一释放，避免无效CU下提前取得引用，并检查缺失SCU。
- `zert/zocl_ospi_versal.c`：在停止使用缓存父设备的工作线程后归还所持父设备引用。

没有在overlay删除处强行减设备树引用，没有放宽内核诊断门禁，也没有修改公共数学、HLS或位流。原失败快照保持不变；两次本机源码准备锚点检查失败的部分目录保留在 `work/zocl-refcount-v1.partial-preparation-01/02`。

## 检查与构建证据

PC测试使用实际修订C函数体和设备测试替身：查找实验8种场景、CU探测/删除46条检查、所有权分支65种场景通过。新执行入口的CU拓扑校验11种接受/拒绝场景通过。这些不是完整内核或实板计算测试。

本机没有可用WSL。板上已有Ubuntu1015头文件的完整 `Module.symvers` SHA256为 `7e93bbb17224ef84a9641c4fca7481323adf5dca4b3f46329327707003a818b3`，与A的irq2原完整构建记录逐字节一致，原驱动238个导入CRC也全部数值匹配。运行 `.config` 从 `/proc/config.gz` 取回，SHA256 `8e235a3d714656b56fedb80eb86786f117139649be933f6b837c297d452d5993`。头文件配置的8处差异已逐项记录，集中在构建能力、编译器、插件支持和版本字符串。

在 `/home/ubuntu/a10-refcount-build-20261022-v1/` 私有下载、解包native GCC13.3、binutils、make及依赖，没有apt install/upgrade或修改系统工具。私有复制头文件，按确切运行配置生成外部模块构建所需配置头，修改私有构建路径及irq2 release；原 `/usr/src` 不改。GCC13.3与原内核GCC13.4差异警告保留；不能用版本接近代替CRC和上板验证。

前4次编译因私有环境配置而停止：auto.conf字符串引号、cc1路径、native assembler别名、Kbuild路径重复。均在加载新模块前发生，日志保留；逐项定位后第5次构建返回0。成功构建约108秒，单核、nice19、`-j1`，最高31.35°C、MemAvailable最低3121408KiB。没有构建整个内核或重建PL。

新模块：

| 项目 | 值 |
|---|---|
| 最终文件 | `evidence/board_platform/A10_20261022_refcount_fix/zocl.refcount.ko` |
| 字节 | 467504 |
| SHA256 | `388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c` |
| srcversion | `15F2AC2306CB3CB7257CFCB` |
| vermagic | `6.8.12-a10irq2 SMP preempt mod_unload modversions aarch64` |
| ELF和导入CRC | ARM64，238项全部匹配 |
| 未剥离副本 | 9450280字节，SHA256 `95375d1febd9a5fd19717e6e8a0e20134dbe0b2743b3c92a44de8e2a817cfa43` |

去调试信息后的 `.text`、`.modinfo`、`__versions` 与未剥离副本一致。原 `/lib/modules/6.8.12-a10irq2/extra/zocl.ko` 仍为原摘要389928...，没有替换默认安装；新驱动仍未加载。

串口一次较大的只读源码材料输出超过55秒采集窗口，未重放该命令；已从完整收到的独立JSON字段恢复并核验运行配置，完整符号表改用限范围的临时HTTP文件桥取回。文件桥无命令执行接口、仅接受本机有线IP和临时路径，已结束。

## 已完成的旧故障窗口收口

新root快照确认：原boot ID `30f5664b-4d24-430e-831b-5f5d139d0157`，PID6818/starttime538561为停止的同一个守卫；无XRT映射、设备fd、子进程或提交文件。所有测试设备持有者为空，overlay空，ZOCL无绑定/refcount0。

通过pidfd复制原双锁的同一open file description并验证排他后，仅结束该确切的非计算守卫。原租约字节原样归档至 `/var/lock/kv260-a1/history/a10-irq2-step5-20261022-refcount-fault-closed/lease.json`，摘要仍为 `2784bab775f4805ec0dc0ccd18c60bdd0617ab6d97747121a9c4333334b96d1b`；双锁连续保持到归档读回通过后才释放。没有尝试对悬留内核对象手工释放引用，也没有在旧故障内核现场卸模块或加载PL。

## 当前干净启动等待点

新启动守卫重新核对了正常1036默认启动文件、irq2 FIT、原驱动、新驱动及默认PL源文件摘要。新的boot-only租约：

- window：`a10-refcount-boot-20261022-v1`
- scope：`A10_REFCOUNT_REVALIDATION_BOOT`
- 原boot ID：`30f5664b-4d24-430e-831b-5f5d139d0157`
- 租约SHA256：`a4c523eb7d5b2ce5e9399c06e5729a297b6ef3b4437827f3a8b7e71fb1a82382`
- 候选启动上限1，计算/PL加载授权均为false；后续第五步须取得新维护租约。

正常关机命令返回0，串口已观测 `reboot: Power down`。默认PL在关机前尚未恢复，不能把旧窗口收口当作第五步或正常系统恢复通过。关机期间的USB超时/显示桥信息保留在串口原件，不纳入新启动基线豁免。

当前记录器 `tools/control_refcount_boot.ps1`，运行会话1501，证据 `.../refcount_fix/clean_boot/`。它等待一次人工上电，见到全新的U-Boot启动横幅才中断自动启动；分阶段复核后仅RAM选择固定irq2 FIT，不保存环境，不修改默认启动或QSPI。启动控制器900秒窗口，原执行器不可重放；后续须先读 `controller_state.json` 与 `controller_done.json` 判断是否仍在监听。

## 尚待执行

人工断电约10秒再上电 → 核验新irq2 boot ID、配置和默认PL → 收口boot-only租约 → 新维护窗口内首次加载前停止图形服务 → 新驱动空载及一次受控render打开/关闭后的完整卸载 → 唯一N=32输入同步/真实提交/正向完成/输出与独立golden核对 → 计算后卸载及默认PL恢复 → 恢复图形服务并归档新租约。

新入口准备工具 `prepare_refcount_step5_bundle.py` 会绑定实际新boot ID和新原始基线，生成独立bundle；不得运行历史 `run_irq2_minimal.py` 或 `continue_irq2_step5.py`。入口另核验加载模块srcversion，并严格识别xclbin加载后可能保留的唯一CU子设备，拒绝未知绑定、错误父设备或外部占用。完整A10回归/压力任务仍不恢复。
