# A10 外部交接接收与剩余工作（2026-10-23）

## 最新结论：材料缺口已补，卸载缺陷仍未关闭

用户随后提供完整包，并要求“先通过串口登录，浏览下文件”。现已完成 COM5 登录和只读浏览，接收/核验实际执行器与原始证据。**原始包证明空载生命周期通过、一次真实 N32 数值正确、计算后卸载失败；A10 仍 NOT_PASSED。** 不再把这些结果仅记为 REPORT_ONLY，也不重跑正确的 N32。

- 工程根 `C:/Patientqwen`；接收包 `A10_refcount_交付包_20261023/A10_refcount_handoff_20261023/` 使用现有目录，未重复解压、未修改原包。130 文件、5 个驱动源修改、原始日志哈希通过离线核验。MANIFEST SHA256 `1474816a0844b78528b38484b94f452da4fcb8f196938a2f01acc3f36b1a4a58`。
- 一次计算：32 项输出与独立求和参考一致，4080 个保护字未改写，真实提交 1。它不是本轮新增计算，也不是被取消的 1000 次回归。模块 SHA `388c45...` 与实际输出 SHA `806cc1...` 均与板上文件匹配。
- 已在板上定位实际修订执行目录 `/var/lib/kv260-a10/a10-refcount-step5-20261022-v1/`，以及 `/home/ubuntu/a10-refcount-build-20261022-v1/` 的源码与执行归档。没有把旧 `/home/ubuntu/a10-irq2-step5-20261022/` 当作修订后的入口。
- 从执行归档只读向串口标准输出提取两份 Python 源码；电脑解码后核验长度与 SHA，连同原始 actual/golden 保存于 `evidence/board_platform/A10_20261023_peer_intake/received_board_files/`。**这些是历史证据，未执行，不可重放。**
- 当前采集到的板为 `ZynqMP KV260 revB`、`6.8.0-1036-xilinx`，boot `549452c7-1381-4d31-b959-b40c66a93343`；默认 overlay 目录存在、FPGA operating、ZOCL 未加载、gdm active。末次传感器 28.770—30.479°C，load 0.01/0.02/0.06。该轮没有读 overlay 的 applied 属性，也未完成新 boot 的全量租约/双锁审计，不冒充完整新维护前置已通过。
- 本轮没有重启、驱动/PL 装卸、BO、计算、刷写、服务停止或持久配置修改。普通登录记录及临时 sudo 认证不等于系统完全零写入；未改 sudo 策略、未保存凭据。COM5 已释放，板上保持登录和运行。

## 电脑端实际修订与未接入边界

`xrt_worker_boundary.py` 和 `accelerator_release_gate_v2.py` 实现独立子进程退出/身份回执、禁止超时强杀和自动重试、缺字段/拒绝访问即停止的 fd/VMA/refcount/内核检查；管理方保留租约与双锁，工作进程不继承锁。新组件没有 PL/module 操作，也没有计算分支。

实际失败快照在设备 fd 已空、仍有 deleted render VMA 的情况下被拒绝；后来即使映射消失，内核失败也仍拒绝。原 `MinimalGate` 及内核诊断规则未修改，不豁免 refcount 或延迟 changeset 错误。

**这只是 PC 组件，不是完整新执行器。** 无计算 native worker、当前 boot 的身份/锁守卫、完整控制器接入仍未实施；未上传/部署，板端验证 NOT_TESTED。具体协议及接入要求见 `platform/qwen35/a10/WORKER_BOUNDARY_PC.md`。不能据此说残留映射问题已在板上解决。

## 执行命令、退出码与分域结果

以下命令从 `C:/Patientqwen` 或注明目录执行，均有 `platform/a1/record.py` 保存完整 argv/输出/退出码；证据统一在 `evidence/board_platform/A10_20261023_peer_intake/`。

| 域 | 命令/操作 | 结果与证据 |
|---|---|---|
| PC 历史保护 | `python scripts/release/check_contracts.py`、`python scripts/release/qwen35_config.py` | 各退出0；`legacy_contracts.json`、`qwen35_config.json`；契约不变 |
| PC 接收 | `python -B <接收包>/verify_package.py` | 退出0，130文件、1提交/32输出/4080保护字，失败保留；`package_verify_01.json` |
| PC 串口安全计划 | `test_readonly_plan.ps1` | 17阶段48命令组通过，退出0；`readonly_plan_tests_v7.json` |
| BOARD 只读 | `collect_readonly_uart.ps1` 的7个 peer 阶段 | `uart_peer_*.json`；初次受保护目录列举exit1保留，之后准确只读查询完成；不是装卸/计算测试 |
| PC 文件恢复 | `python -B platform/qwen35/a10/import_peer_captures.py --evidence <证据目录> --package <接收包>` | 退出0，4文件字节/哈希匹配；`capture_import.json` |
| PC Windows 新组件 | `python -B -m unittest discover -s platform/qwen35/a10 -p test_xrt_worker_boundary.py -v` | 最终退出0，18方法中16通过/2 POSIX明确跳过；`worker_boundary_pc_03.json` |
| PC Linux 相关回归 | 在 `platform/qwen35/a10` 运行 `/usr/bin/python3 -B -m unittest -v test_xrt_worker_boundary test_minimal_gate test_kernel_log_gate test_peer_capture` | WSL退出0，44方法全通过，含18个新组件方法和真实flock子进程检查；`worker_boundary_wsl_02.json` |

首轮 Windows 新组件退出1（`worker_boundary_pc_01.json`）：venv redirector 另起解释器导致 PID 不一致，被身份门禁正确拒绝。修测试为直接启动实际解释器后通过；未放宽 PID 条件。原失败记录保留。

当前接收收据：`verified_intake_receipt.json`。本轮没有性能基准，P2优化 NOT_IMPLEMENTED；1000轮/20长度仍 CANCELLED_BY_USER，压力/内存极限/故障注入仍 SAFETY_EXCLUDED。

## 下一步（不需重新做 A00—A09 或重编整个内核）

1. 在电脑完成独立**无计算** native worker 与新控制器接入、测试，保留旧执行入口只读且禁止重放。
2. 新维护窗口前只读确认当前 boot、active lease/双锁、1036 恢复资产哈希，明确正常软件重启仍有未解决限制。
3. 取得精确范围确认后，先短时无计算生命周期验证。通过也不能自动把“计算后卸载 FAILED”改成 PASS；若仍需一次极小计算来证明完整闭环，应先解释必要性并另定次数。

下面是初次只收到两份报告时的历史快照，材料缺件与板状态 unknown 已由本节覆盖；原件与初始收据不删改。

## 初次接收：仅有两份报告（历史）

结论：交付报告表明平台已经取得一次正确的真实计算，但明确记载“计算后卸载 FAILED，整体 A10 未通过”。本次只收到两份 Markdown，未收到新代码与原始记录，不能将报告里的 PASS 直接升级为本工程已独立验收。既有通过项保留，不重跑 N32 或已取消的 200/1000 轮任务。

## 本次实际完成

- 实际工程根仍为 `C:/Patientqwen`。环境提供的 `D:/patient-qwen` 与对方的 `D:/KV260-A10` 在本机均未找到。输入所在的 THz 项目仅作为文档来源，不作开发仓库、不修改。
- 已完整读取两份文档，按最终 23:40 冻结、23:47 正常关机记录解读；下文旧“待启动”“会话 1501”等不是当前状态。
- 两份输入已逐字节复制至 `evidence/board_platform/A10_20261023_peer_intake/received/`；原路径、长度及 SHA256 见同目录 `intake_receipt.json`。
- 修改前六份状态文件保存于同目录 `before/`。保留全部旧修改，创建 `member-a/a10-peer-intake-20261023` 分支；不提交、不推送、不覆盖已发布 A10 包。
- 本地指定目录及常用下载目录未找到新的 A10 工程/证据包。`git ls-remote --heads origin` 退出 0；A10 发布分支仍为此前的 `015af071ec408359ebb296c9d7eebcf59c778b17`，不是对方后续的第五步交付。没有据此断言其他远程分支绝无材料。
- 旧契约检查、新版配置检查均退出 0，日志分别为 `legacy_contracts.json`、`qwen35_config.json`。这只是 PC 静态检查，不代表新驱动或实板通过。
- 本轮未打开串口/SSH、未启动或重启板子、未加载驱动/PL、未分配 BO 或提交计算，当前板子是否上电未知。

## 报告中的进展与不能合并的结论

| 项目 | 对方最新报告结论 | 本次接收核验状态 |
|---|---|---|
| irq2 启动 | `6.8.12-a10irq2` 已启动 | 缺原始启动记录，REPORT_ONLY |
| 修订 ZOCL | 原生编译、238 项 CRC 匹配 | 缺修订源码/模块/构建收据 |
| 空载打开关闭及卸载 | PASS | 缺原始窗口日志 |
| 一次真实 N32 | 1 次提交；32 项及 4080 保护字正确 | 保留 PASS_REPORTED，不重放；缺输出与独立审计 |
| 计算后卸载 | FAILED；残留 64 KiB 设备映射，继而延迟 OF 清理错误 | OPEN，不能以管理命令退出 0 或冷恢复通过代替 |
| 正常系统冷恢复 | 正常 `6.8.0-1036-xilinx`、默认 PL、无占用 | 缺恢复收据/新基线哈希，REPORT_ONLY |
| 最后状态 | 2026-10-22 23:47 正常 poweroff | 只是历史状态，不复用为当前状态 |
| 软件重启路径 | 未成功到达 U-Boot/Linux | 限制保留，不自动重试 |

报告称句柄/fd 关闭后 VMA 仍在，支持“执行器释放判定不足”的定位线索；这不等于已经独立证明所有驱动引用路径均无缺陷。进程结束后才出现的内核错误仍是失败，不作豁免。

## 最小补交材料（可直接转给对方）

请从 `D:/KV260-A10` 导出以下 A10 增量，保留目录层次、原始字节和 SHA256，不需要重新上板测试：

1. `docs/handoff/HANDOFF.md`，当前执行入口/包清单，最终恢复基线及启动报告。
2. `work/zocl-refcount-v1/` 的最终修改源码、来源/补丁记录和对应测试；无需整个 GCC/SDK 或无关构建缓存。
3. `tools/accelerator_release_gate.py` 及测试、`tools/prepare_refcount_step5_bundle.py`、实际第五步执行器与必要本地依赖。不要仅提供历史入口名称。
4. `evidence/board_platform/A10_20261022_refcount_fix/`：至少包含 `actual_output.json`、`board_result_audit.json`、`postcompute_failure.exact.raw.txt`、VMA/fd/refcount 快照、构建/CRC记录、`freeze_receipt.json`、`normal_restore/`、实际执行代码快照及 `zocl.refcount.ko`。
5. `evidence/board_platform/A10_20261022_end_of_day_shutdown/`、`board_profile.json`、正常 1036 恢复备份的清单/哈希及对应报告。

报告给出的三个待核摘要：

- 新模块：`388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c`
- 实际输出：`806cc1cb3971cfbf1cf4b8450e220e8b326e87edc50d00b07765806d7cf0339e`
- 计算后错误原始日志：`684bf26f65594929bb82a49adac1260bb214d63c0d5d9ce2a4340d0a71481a8d`

无需系统盘/SD/WSL 镜像、模型权重或全部 754 MiB 备份来开始代码审查；后续恢复所需原件另核实可用性。不得包含密码、私钥、令牌或许可证正文。若原始记录含秘密，保留原件于对方本地，另交明确标注且带原始/脱敏哈希的副本，不能覆盖原件。

## 接续顺序与安全边界

1. 先核对新材料的哈希、来源和一次计算的完整记录，将 reported 与 verified 分开。不能把旧 A10 包中的 `389928...` 模块当作新的 `388c45...` 模块。
2. 在电脑审阅实际执行器并实现独立 XRT 工作进程：管理进程保留独占租约和双锁；工作进程不继承这些锁的文件描述符；仅真实正常退出且状态完整才考虑释放完成。超时、未知或内核错误保持隔离，不强杀、不自动重试。
3. 卸载门禁同时要求正确 boot/租约、进程退出、完整的设备 fd/VMA（包括 deleted 路径）占用核查、模块引用为零、连续且无新增错误的内核记录；权限不足、采集不完整或归属不明均拒绝卸载。不得为了通过检查放宽内核诊断。
4. 完成 PC 测试后，再提出一次明确范围的无计算加载/退出/卸载验证；先确认当前物理连接、boot 和 1036 恢复基线。文档中的 COM4/旧 boot ID/PID 不能直接在本机沿用，原 1015 启动脚本也不能直接使用。
5. 不自动重复 N32；无计算生命周期通过不能冒充计算后生命周期已经通过。若仍需追加一次极小计算才能关闭缺陷，应先说明必要性、次数与风险并单独确定范围。
6. 最后汇总实际 profile、代码/库/位流哈希、命令和退出码、分域证据、恢复限制，形成最小 A10 结论。A11/A12、完整模型和性能验收不被本次结果替代。

1000 次/20 长度数值回归保持 `CANCELLED_BY_USER`，压力、内存极限和在途故障注入保持 `SAFETY_EXCLUDED`。P2 性能优化 `NOT_IMPLEMENTED`；本轮无性能收益声明。

当前边界：继续到“材料接收及 PC 准备”，不能在缺新执行器/驱动/恢复基线的情况下安全执行剩余板测。下一输入是上述交接包的本机路径，而不是重新从 A00 开始。
