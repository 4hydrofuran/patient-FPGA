# A10 隔离空载修复窗口（已收尾，A10未通过）

后续PC增量：[81项联调与v4候选报告](../../evidence/board_platform/A10_20261023_controller_integration_pc_v1/REPORT.md)。静稳修复已经电脑打包、未部署；没有新增板接触或实时状态，尚待新空载授权。下方73方法/未打包是已结束窗口的原记录，不覆盖其原始BOARD证据。

最新结果见 [本轮最终报告](../../evidence/board_platform/A10_20261023_isolated_idle_v1/FINAL_REPORT.md)（从本文件应使用下述仓库相对位置：`evidence/board_platform/A10_20261023_isolated_idle_v1/FINAL_REPORT.md`）。irq2启动已确认；两次控制器启动均在PL/XRT之前停止，本轮驱动/PL/XRT/计算0。用户另行批准仅收尾后，等待进程已受控终止、GDM恢复、维护锁归档，独立只读核验通过。当前仍为irq2+默认PL，29.663–32.096°C；未返1036、未再重启。静稳修复73项PC测试通过但未上板。下文保留本轮前半程快照，旧“正在启动/尚待确认”不代表当前状态。

工程根 `C:/Patientqwen`；分支 `member-a/a10-peer-intake-20261023`。原A00—A17、peer原件、一次N32输出和失败均保留，不改模型/语音/数学/内核或性能参数，不提交推送。

## 当前判定

**A10 NOT_PASSED**。已确认历史唯一N32正确，但计算后卸载失败不能取消。新的进程隔离方案电脑测试通过，实板空载生命周期尚未验证；即便空载通过，也不替代计算后的卸载证明。20长度/1000及长负荷取消不变，P2 NOT_IMPLEMENTED。

证据根：`evidence/board_platform/A10_20261023_isolated_idle_v1/`。以下状态是本次窗口记录，后续看同目录新收据，不复用旧1015内核/boot/租约。

## 故障定位与改动

历史manager在同一进程加载XRT，句柄关闭后仍留64KiB设备VMA，模块引用未归零；其后卸载及延迟OF清理失败，不能只等PID退出就解除已锁存的内核故障。

- `isolated_idle_worker.py`：七个真实XRT空载API；独立解释器打开/关闭设备与kernel上下文，验证UUID与metadata分组。无BO、RunStart或寄存器写入接口。结果文件不代替真实退出。
- `isolated_idle_trial.py`、`isolated_idle_policy.py`、两个`isolated_idle_*entry.py`：新窗口身份/hash/根目录权限/租约/双flock/GDM隔离，原有连续内核门禁，等待实际worker正常退出后再核验完整fd+VMA+整数refcount0，正常卸载并恢复默认PL。失败/超时保留manager与双锁，不强杀、不重试。
- `accelerator_release_gate_v2.py`：修复真实Linux扫描自身临时scandir fd的消失问题；保持扫描器存活，比较前后fd到目标映射，其他不完整/权限/竞争继续拒绝。
- `prepare_isolated_idle.py`、`upload_isolated_idle.py`、`stage_isolated_idle.py`：独占新目录、固定manifest与全部16文件回读，无自动执行；`isolated_prepare_uart.ps1`仅准许临时网络、受控root副本、正常1036关机等独立动作。
- `cold_boot_irq2_once.ps1`：被动等待本次人工上电，识别新U-Boot倒计时才发一个空格，三个组件SHA校验后只一次临时启动。没有保存环境、写QSPI、软件循环重启或加载PL。

## PC 命令与结果

所有完整argv、输出和退出码在下列JSON；相对位置从工程根起。

| 证据 | 实际测试/命令 | 退出码 |
|---|---|---:|
| `legacy_contracts.json` / `qwen35_config.json` | 历史接口保护 / 新版配置校验 | 各0 |
| `idle_components_wsl_03.json` | `/usr/bin/python3 -B -m unittest -v test_isolated_idle test_xrt_worker_boundary test_minimal_gate test_kernel_log_gate test_peer_capture`，62方法全部通过 | 0 |
| `idle_components_windows_02.json` | 相同组合不含POSIX旧入口`test_minimal_gate`，54方法中50通过/4 POSIX跳过 | 0 |
| `readonly_plan_02.json` | PowerShell只读计划，19阶段55组 | 0 |
| `upload_plan_01.json` | 3方法，默认无连接/固定主机key/新目录/拒绝注入boot | 0 |
| `poweroff_plan_03.json` | 6个准备/暂存/正常关机计划检查 | 0 |
| `cold_boot_plan_01.json` | 11个倒计时、临时启动、组件哈希正反例 | 0 |
| `prepare_bundle_01.json` | PC打包并核验15 payload文件+manifest，16,164,498 payload字节 | 0 |

失败保留：`idle_components_wsl_01.json`自身扫描临时fd导致不完整，修复后通过；`idle_components_windows_01.json`旧Linux入口导入fcntl在Windows失败，完整8项最小门禁在WSL通过，未宣称Windows覆盖该域。没有放宽生产门禁。

## 已执行的板端准备

1. `uart_preflight_01.json`：boot `549452c7-1381-4d31-b959-b40c66a93343`、正常`6.8.0-1036-xilinx`、默认PL applied、无ZOCL/活动租约，约29.4–32.5°C；扫描只读不是连续监控。
2. `uart_boot_assets_01.json`：原FIT/boot脚本/irq2 FIT、XRT两库、默认PL均与审计SHA相同，SSH公钥匹配；sudo缓存不足exit1保留，没有发送变更。
3. 用户专项授权后`network_prepare_01.json`退出0，`192.168.2.2/24`、NetworkManager `Unsaved=true`、无默认路由，不改电脑/VPN/DNS/永久配置。认证只瞬时使用。
4. `user_upload_01.json`三步退出0；`root_stage_01.json`退出0，独立root目录 `/var/lib/kv260-a10/a10-isolated-idle-20261023-v1`，16文件SHA回读通过，暂存温度29.555/32.469/30.837°C。manifest SHA `8ea3600e469aee3ba5daaae3ea7c472cc534826143daf0e87b80d3ff16844ad2`；尚无授权review.json，不能执行。
5. `normal_poweroff_01.json`只一次正常systemctl poweroff，实见`reboot: Power down`，不是SSH断开即判成功。随后用户明确回复已断电再上电。
6. `cold_boot_irq2_01.json`正在记录该唯一启动：已识别新倒计时、三个FIT组件哈希通过、只发送一次bootm；结果尚待Linux确认。无PL加载/计算/默认启动改写。

## 仍需完成

本次候选登录后的只读实际profile/新鲜完整内核基线与租约/消费者审阅 → 一次已授权空载隔离生命周期 → 记录真实退出与干净恢复。若新错误或未知状态出现，保留最小复现，不自动复位或继续装卸。

计算后的释放验证仍独立OPEN；不得重放旧N32脚本，不得把空载通过改写为完整A10通过。正常软件reboot历史挂起也未解决；当前使用用户现场配合的正常关机/冷启动路径，不宣称自动回滚已验收。板端PSS/RSS/BO地址与同步的新实测没有发生，指标仍null，CMA不得与PSS/BO重复加总。
