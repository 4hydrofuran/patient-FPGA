# A10 最小平台交付给B/C（2026-10-23）

状态：**PASS_MINIMAL_WITH_LIMITATIONS**，仅用户安全精简后的A10。
主报告 `evidence/board_platform/A10_20261023_isolated_single_v1/REPORT.md`；机器清单
`A10_ACCEPTANCE.json`、`board_profile.json`、`resource_ledger.json`在同目录。
不更改B/C候选状态，不代验A11/MLP或A12/模型。

确定环境：ZynqMP KV260 revB，ARM64，当前Linux6.8.12-a10irq2，XRT2.18.0。
本次boot c5baeabe-273d-447e-b323-ff07dd7af201只是已结束窗口标识，不可作为下一窗口默认值。
MemTotal3997488 KiB、CmaTotal819200 KiB；不能将CMA+PSS+BO叠加。
精确驱动/位流/xclbin/库/FIT SHA统一读`board_profile.json`，不按名称猜兼容。

一次32元素/4080保护字正确；groups3/3/3，3×16448字节，实际地址0x445b0000/0x445b8000/0x445c0000。
其他低/高地址和大BO未证实，3200MiB整体包络未证明。15.228秒维护，最高采样32.624°C；
同步API小样本不是DMA峰值或性能比较。P2压力/长稳/最大预算/功耗/故障注入不实施。

生命周期必须是：新boot/身份/恢复资产/温度与独占租约核对 → GDM受控隔离 → 独立XRT子进程 →
正向完成/正常退出 → FD/VMA完整扫描和refcount0/内核门禁 → 普通卸载 → 默认PL/GDM → 独立读回。
只有API关闭/fd关闭不够。未知完成/退出或故障时保留所有权与现场，不强杀/强卸载/重试。
本次manager12055、worker12162均已结束，禁止用这些历史PID收尾新进程。

当前默认PL/GDM恢复，ZOCL/render/活动租约/双锁占用均无；COM5及SSH已释放，eth0临时IP仍192.168.2.2/24。
板仍irq2，原image.fit/boot.scr.uimg和默认1036启动不改；正常1036冷恢复历史证据保留。
软件reboot可靠性未验证，不自动重启或电源循环。已知启动/overlay属性/IRQ枚举提示保留，
不是零告警/零泄漏或可无限反复切换资格。每个后续实板任务仍需确认新的范围。

下阶段只建议先做A11电脑侧匹配审查；不得在此交付下自行运行全模型或压力回归。
