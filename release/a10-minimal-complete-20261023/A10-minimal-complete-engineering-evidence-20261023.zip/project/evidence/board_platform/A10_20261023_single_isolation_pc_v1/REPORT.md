# A10 单调用隔离流程：电脑准备证据

新流程通过27项Linux单元/实际子进程及锁编排测试，7项Windows host/冻结包/PS计划测试。
旧/新契约各exit0；exact XRT2.18头文件签名及hash见`abi_01.json`。默认入口PLAN_ONLY。
单次N32范围、独立协议及新授权记录不接受旧空载review；只允许一次提交/49344字节显式BO。
native失败、未知完成、超时、错误值/保护字、残余FD/VMA/refcount、lease篡改及内核新诊断均拒绝继续释放。
无自动强杀、强卸载或硬件重试。PC算术替身只在测试文件，不入分发包。

`tests_01.json`26方法通过；新增parent baseline负向检查后`tests_02.json`27方法通过。
`host_tests_01.json`保留unittest参数顺序错误exit2，`host_tests_02.json`修复后7方法exit0。
`package_01.json`21文件/16204416字节payload，SHA ae21f1acacadbf5ceaeed85384cade0c575fbe8a5a88012530c911ebfce7cfb7。
所有记录保留argv/时间/退出码/完整输出；既有v4测试按原报告复用，不重复执行或混计。

`readonly_preflight_01.json`是随后新授权窗口的BOARD短时只读串口检查，不能归为PC仿真；
没有由该条检查提交计算。真正板端执行、最终44方法分域汇总与A10最小验收结果在
`../A10_20261023_isolated_single_v1/REPORT.md`。本目录测试本身不授予部署或判定板测通过。
