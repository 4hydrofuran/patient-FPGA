# A10 历史小BO与资源账恢复、剩余验收审计

结论：在电脑上从已校验原始日志恢复了历史唯一N32任务的小BO、包围同步调用的耗时及进程/物理内存双账，不需要为补这些字段重新计算。A10仍NOT_PASSED，真实计算后卸载失败未关闭。本轮板连接、部署、驱动/PL操作、计算、重启均0。

## 来源与实际改动

- `platform/qwen35/a10/recover_peer_resource_ledger.py`：固定交接manifest SHA，验证所用原始文件及实际执行的native/logger源码哈希，只解析、不导入或执行捕获源码。派生输出使用exclusive create，缺失内存计数保持null，重复/混boot/篡改/非有限值拒绝。
- `platform/qwen35/a10/test_peer_resource_ledger.py`：7项PC测试，覆盖原始来源/行号、单位、null、重复记录、错误boot、结果矛盾、源码篡改和禁止覆盖。
- 当前派生账：`historical_resource_ledger_v2.json`；`historical_resource_ledger.json`保留为尚未附独立logger哈希的首版，数据相同，不覆盖。原始包、原日志、既有N32和失败记录均不改。
- 更新阶段状态、设计差距、测试矩阵及当前最小验收文件的顶部接续说明；不修改生产代码、v4候选、内核、驱动、模型、语音、数学、性能参数。保留原A00—A17，无commit/push/子代理，实际模型设置unknown。

来源为已验130文件包`A10_refcount_交付包_20261023/A10_refcount_handoff_20261023/`，manifest SHA256 `1474816a0844b78528b38484b94f452da4fcb8f196938a2f01acc3f36b1a4a58`。生命周期原始记录`evidence/02_repaired_trial/lifecycle_stopped.jsonl`，boot `0e2f466a-87a3-4f5e-9cf4-50d6b7756832`，内核irq2。不是本轮板上boot。所有来源SHA、原始一基行号和执行源码路径已写入派生账provenance。

## 可复用的历史实测与边界

| 项 | 原始证据 | 解释 |
|---|---|---|
| 分组/BO | lifecycle第99行：groups=[3,3,3]，每个16,448字节，显式请求共49,344字节 | 3次成功分配在释放前同时存在；不是物理分配峰值，也不含XRT内部管理分配 |
| BO起始地址 | `0x445b0000`、`0x445b8000`、`0x445c0000` | 仅覆盖账中3个半开区间，不证明中间空隙或全部低/高地址可达 |
| 包围输入同步的计时 | 第123行，23,650.489 μs | 包含3个同步调用、每次日志emit/flush/fsync及Python开销，不是纯DMA成本 |
| 包围输出同步的计时 | 第123行，3,828.937 μs | 包含完成事件日志emit/flush/fsync及1个输出同步，不是纯DMA成本 |
| 数值 | 已有独立接收验真：32输出/4080保护字，1次提交 | 本轮不重算或补跑，真实提交总数不增加 |

`run_refcount_step5.py`第69—76行确认emit会fsync；`single_xrt_call.py`第103—106/129—133行确认上述计时包围范围。两份执行源码与已消费包清单对应哈希逐字节一致。因此纯同步延迟/吞吐仍null，不用这两个混合计时编写性能结论。

| 原始阶段/行号 | smaps PSS KiB | smaps RSS KiB | status VmRSS KiB | CmaFree KiB |
|---|---:|---:|---:|---:|
| before_device_open / 78 | 25,470 | 33,456 | 33,360 | 808,656 |
| explicit_bos_live / 100 | 29,704 | 37,720 | 37,584 | 808,596 |
| after_normal_release / 124 | 29,776 | 37,792 | 37,584 | 808,596 |

三个采样的MemTotal均3,997,488 KiB，CmaTotal均819,200 KiB。采样不是原子快照，status与smaps值不要求相等；PSS/RSS、CMA、BO视角有重叠，绝不相加。60 KiB的CmaFree变化不独立证明所有权或物理分配峰值。

原日志在三个阶段都写了`explicit_bo_live_max_bytes=49344`：这是声明的显式请求包络，不能解释为三个时刻当前均占用49,344字节。`VmHWM=85560 KiB`是整个进程生存期高水位、包含之前活动，不是本次compute窗口或模型峰值。`after_normal_release`只是历史程序标签，残留设备VMA和后续内核错误明确否定了“已完全释放”；派生账对此记false，不美化。

## 命令及退出码

完整argv、输出和退出码保存在本目录JSON，由`D:/Python/Python314/python.exe -B platform/a1/record.py --log <新文件> -- <命令>`记录。

```text
D:/Python/Python314/python.exe -B -m unittest discover -s platform/qwen35/a10 -p test_peer_resource_ledger.py -v

D:/Python/Python314/python.exe -B platform/qwen35/a10/recover_peer_resource_ledger.py --package A10_refcount_交付包_20261023/A10_refcount_handoff_20261023 --native-source evidence/board_platform/A10_20261023_peer_intake/received_board_files/single_xrt_call.py --output evidence/board_platform/A10_20261023_resource_recovery_v1/historical_resource_ledger_v2.json
```

`tests_01.json`和最终`tests_02.json`均7/7 exit0；`export_01.json`和补充logger来源后的`export_02.json`均exit0。前一窗口的81项控制器回归及旧/新契约继续复用；没有改它们覆盖的生产源，不重复执行。新的7项是数据恢复测试，不能加成88次板测或声称新的控制器板验。

## 当前最小验收逐项结论

| 必需项 | 证据判定 | 真正剩余 |
|---|---|---|
| KV260身份、IRQ2启动、ARM64/XRT与资产来源 | 既有profile、接收收据、上一窗口真实IRQ2启动及SHA已证明；原启动不改 | 下一板窗口短查身份/boot/温度/占用，不重做完整身份采集或构建 |
| 最小真实计算/metadata BO | 原始唯一N32结果及本次资源账已证明所测范围 | 不为数值或资源记录重放；不能据此掩盖计算后卸载失败 |
| 小BO范围、显式包络、双账 | 本次恢复的历史原始记录可复用；纯同步成本/内部BO/广泛可达范围未测 | 未测项保持null/安全限制，不追加极限探测 |
| 新进程隔离方案的空载释放 | 81项PC通过、新v4已封存；尚无该版本BOARD退出/卸载证据 | 新授权后短时实板核验；不会用旧流程idle PASS代替新流程验证 |
| 计算后完整释放/恢复 | 旧窗口明确FAILED，残留VMA、refcount与延迟OF错误；当前PC方案未证明板上修复 | 先过空载；再另行确定必要的最小计算后释放验证，不自动补跑N32 |
| 正常默认配置与恢复记录 | 历史正常1036冷恢复可复用；最近仅收尾后irq2/default PL/GDM正常，无manager/lease | 新试验结束的独立读回和恢复收据；当前IRQ2未返回1036，不能伪称已返回 |
| 交付 | 实际profile、哈希、日志、候选及本次双账已有 | BOARD剩余项完成后才能整合最终PASS_MINIMAL_WITH_LIMITATIONS交付 |
| 已取消/安全排除 | 20长度/1000数值循环、压力/极限/故障注入/重复重启不做 | 无补跑义务，不能改写成PASS；P2 NOT_IMPLEMENTED |

D09/D11：填补的是历史资源证据汇总及计时解释缺口；没有性能改善或新硬件资格结论。原软件reboot挂起、候选既有告警和故障后人工恢复风险仍保留。

## 授权边界与目标状态审计

最近明确答复只有“允许这次仅收尾恢复”，已完成。之后结束收尾、PC联调/打包、本次历史账恢复这三个连续目标回合均未收到新的板端试验确认；自动goal continuation不等于新的硬件授权，也没有确认活着的测试进程可供等待。本轮仍完成了有价值的PC证据恢复，不把它说成已获授权或板测推进。

到此已有证据可恢复的工作和相关电脑准备完成，下一项是新的实板窗口，无法在缺少用户确认时执行。A10不能complete；目标应按阻塞审计置为blocked，等待用户对已经说明风险/范围的一次短时空载验收答复。该状态不是用户暂停，也不是取消完整A10目标。不重新执行已消费的v1/v2/v3入口或旧PID收尾工具。
