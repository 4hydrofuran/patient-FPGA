# 单次 N32 计算后释放检查：执行前审阅

本窗口依据用户最新“允许，继续推进A10”，接续上一窗口提出的一次32元素计算后释放检查；
不恢复已取消的数值回归，不扩展压力、复位、重启、QSPI或默认启动修改权限。

电脑27项新流程测试、7项host测试通过；首次host runner参数顺序失败保留在
`../A10_20261023_single_isolation_pc_v1/host_tests_01.json`，修复后exit0。
旧/新契约各exit0，XRT 2.18本地头文件和35个C API动作的类型/顺序已核对。

板端独立用户/root暂存21文件哈希一致，manifest
`ae21f1acacadbf5ceaeed85384cade0c575fbe8a5a88012530c911ebfce7cfb7`。
未载入新驱动/位流，未提交计算。只读确认同boot
`c5baeabe-273d-447e-b323-ff07dd7af201`、`6.8.12-a10irq2`、目标machine SHA一致。
默认overlay applied、GDM active、无ZOCL/活动租约/双锁占用；完整进程扫描无FD/VMA用户。
候选采样29.213–31.847°C，MemAvailable3296340 KiB，CmaFree810604 KiB。

本次完整原始内核SHA为
`79e2f2229502fca93f22bfe9b2bcc6c34d56851d65c17653babba516ccef2255`，
与已审阅的v4空载恢复后独立读回逐字节相同。202条历史诊断并非零告警，原启动、
外置模块taint、确切overlay属性和IRQ枚举终止提示原样保留；本轮没有新诊断。
因此只接受上述确切baseline字节，任何变化拒绝启动，不自动追加豁免。

执行边界：独立child一次xrtRunStart；N=32，3×16448字节显式BO，元数据groups3/3/3，
不探最大BO/CMA。仅在正向完成、32值/4080保护字一致、句柄正常关闭、真实waitpid、
全进程FD/VMA扫描完整且refcount0及内核门禁通过后，普通卸载并恢复默认PL/GDM。
任何异常保持进程/锁、保留最小复现，不强杀/强卸载、不自动重试。
检查通过仍需独立最终读回及证据审计，不能仅凭执行器退出标A10通过。
