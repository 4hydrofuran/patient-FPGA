# A10 最小验收完成：PASS_MINIMAL_WITH_LIMITATIONS

2026-10-23。工程根 `C:\Patientqwen`，分支 `member-a/a10-peer-intake-20261023`。
保留原A00—A17进度、旧失败/原始交接包及脏工作树；没有提交或推送。
通过的是用户安全修订后的A10最小平台通路，不是原1000次回归、A11/A12、长期稳定或产品验收。

## 真实结果

- 一次32元素真实PL vector-add，32输出与独立uint32参考一致，4080保护字未改。
  新提交**1次**；另一个人的历史1次单独保留，旧电脑1000次不混计。
- 显式BO为3×16448=49344字节，metadata groups=3/3/3；起始地址
  `0x445b0000`、`0x445b8000`、`0x445c0000`，只证明这些区间可用。
- 新worker PID12162正常关闭API后实际退出，manager PID12055正常waitpid。
  退出后完整扫描170进程，无设备FD/VMA、refcount=0；才普通移除测试配置、卸载ZOCL，恢复默认PL/GDM。
- 全控制流程15.227869792秒；native worker事件跨度0.315188242秒。均非性能基准。
  控制器采样28.606–32.624°C，最低MemAvailable3299796 KiB，CmaFree808596 KiB。
- 控制器结束47.174429708秒后的独立完整内核读回通过，随后UART再次确认无manager/活动租约/双锁。
  最终UART温度28.832–30.852°C、默认PL applied、GDM active、ZOCL absent。
- 无重启、RESET/FWUEN、QSPI/默认启动修改，无循环、压力或故障注入，异常强杀/强卸载0。
  COM5/SSH已释放。板仍为**6.8.12-a10irq2**，没有声称已返回1036；原启动包哈希未变。

验收机器记录：`A10_ACCEPTANCE.json`。独立生命周期审计：`audit_01.json`。
实际平台及位流/驱动/库/启动包SHA：`board_profile.json`。
原始记录：`result_readback_01/`；回执逐文件哈希和压缩原字节保留，不能用摘要替代。

## 设计差距、实际改动、验证与指标边界

D09旧缺陷为“API关闭不等于进程映射消失”；原计算后卸载FAILED保留。
新实现把XRT和BO限制在独立child，管理进程不加载XRT；必须正常退出、严格FD/VMA/refcount检查和连续内核门禁通过，才开始卸载。
超时/未知结果保留进程与双锁、不再提交、不自动释放。一次新计算验证的是该失败场景的修复，不是重跑数值回归。

实现路径 `platform/qwen35/a10/`：`single_compute_policy.py`、`single_compute_worker.py`、
`single_compute_boundary.py`、两个entry、`isolated_single_trial.py`；新增独立包/上传/暂存/单次启动/只读回取工具。
旧v4生产控制器、驱动、位流、内核、公共接口、模型、语音、数学及性能参数未修改。
冻结包 `platform/local/a10-isolated-single-20261023-v1`，21文件，manifest SHA
`ae21f1acacadbf5ceaeed85384cade0c575fbe8a5a88012530c911ebfce7cfb7`。
授权review在真实窗口核验后才生成，电脑分发包不含review。

D11双账见`resource_ledger.json`，每条保留原始行号和来源SHA。三次样本如下（KiB）：

| 阶段 | PSS | smaps RSS | CmaFree | 显式当前BO字节 |
|---|---:|---:|---:|---:|
| 设备打开前 | 16482 | 24676 | 808656 | 0 |
| 三个BO同时存活 | 28376 | 36600 | 808596 | 49344 |
| API关闭后、进程退出前 | 20816 | 29040 | 808596 | 0 |

三样本均Threads=1、VmSwap=0；样本不等于全程峰值。CMA/PSS/RSS/BO不能重叠相加。
API关闭后的0只是显式对象账，完整释放另由后续waitpid与扫描证明。
输入三个sync原生API合计100.631μs，输出sync原生API71.841μs，排除事件写盘但仍含软件开销；
不是纯DMA带宽。旧同步计时包含fsync，不能据此宣称加速。隐式XRT/配置缓冲、物理BO峰值、
全低/高地址范围、3200MiB模型包络和性能提升均null/未证明，不追加极限探测。

## 执行命令、退出码与分域证据

工作目录为工程根。Python为`D:/Python/Python314/python.exe -B`；PowerShell仅本进程
`-NoLogo -NoProfile -ExecutionPolicy Bypass -File`，没有修改系统策略。
固定boot=`c5baeabe-273d-447e-b323-ff07dd7af201`。下表省略公共路径前缀
`platform/qwen35/a10/`；完整argv和输出在对应JSON。

| 域/命令 | 退出码 | 结果/原始证据 |
|---|---:|---|
| PC旧`check_contracts.py`与新`qwen35_config.py` | 0/0 | `../A10_20261023_single_isolation_pc_v1/contracts_01.json` |
| WSL `python3 -B -m unittest -v test_single_compute test_single_integration_pc` | 0 | 27方法，`../A10_20261023_single_isolation_pc_v1/tests_02.json` |
| PC `unittest discover -s platform/qwen35/a10 -p test_single_host.py -v` | 0 | 7方法含3PS计划，`../A10_20261023_single_isolation_pc_v1/host_tests_02.json` |
| PC `prepare_isolated_single.py --project-root C:/Patientqwen --output platform/local/a10-isolated-single-20261023-v1` | 0 | `../A10_20261023_single_isolation_pc_v1/package_01.json` |
| `upload_isolated_single.py --boot-id <boot> --execute-authorized-upload --receipt .../upload_01.json` | 0，3子命令均0 | `upload_01.json`，21文件逐项SHA |
| `single_prepare_uart.ps1 -Step root_stage -ExpectedBoot <boot> -AuthorizedOnce -OutputPath ...` | 0 | `root_stage_01.json` |
| 同上 `-Step candidate_readonly`及`import_isolated_readonly.py` | 0 | `candidate_readonly_01.json`、`candidate_review_01/`、`BASELINE_REVIEW.md` |
| 同上 `-Step execute_single`（仅一次） | 0 | `execute_single_01.json`，35个有界C API动作；PL管理8条和GDM stop/start均0 |
| `fetch_single_result.py --execute-readonly --output .../result_readback_01` | 0 | `fetch_receipt.json`，独立延迟读回 |
| `collect_readonly_uart.ps1 -Phase isolated_preflight -OutputPath .../final_preflight_01.json` | 0 | 最终UART状态/锁/温度，三个诊断组均0 |
| PC `audit_single_result.py --output .../audit_01.json` | 0 | 独立审计实板原始记录，不是新板测 |
| PC `unittest discover ... -p test_single_result_audit.py -v` | 0 | 10方法，`audit_tests_01.json`；迟到内核错误/假输出/残余VMA/重复提交均拒绝 |
| PC `closeout_single.py --write-artifacts` | 0 | `closeout_command_01.json`，要求清单/profile/资源账 |

电脑27+7+10=44方法不是44次板测。旧空载81项PC/真实v4空载及原1036恢复证据复用，未重复执行。
首次host测试命令将`-v`放在`discover`前，参数解析exit2：
`../A10_20261023_single_isolation_pc_v1/host_tests_01.json`原样保留；修runner后通过，未放宽门禁。

## 限制、缺陷与下一步

- 计算后残留映射/卸载失败：**本次独立进程方案的最小场景已通过**，原历史失败不覆盖；不证明所有驱动路径或长期反复装卸安全。
- 已知10条本窗口overlay属性/核验32路IRQ后的枚举终止提示保留。没有新的未审查诊断、refcount/Oops。
  不写“零告警/零泄漏”；未知后续诊断仍必须停止。
- 软件reboot可靠性仍未验证，本次没有重启；原1036正常冷恢复证据复用。
  未来不得直接套用已消费窗口/旧PID；任何电源恢复须先确认状态和专项授权。
- 20长度/1000次回归：CANCELLED_BY_USER。P2：NOT_IMPLEMENTED/SAFETY_EXCLUDED，包括压力、最大BO/地址、持续带宽、功耗、在途DMA故障和循环装卸。不把取消写PASS。
- 测试文件暂存在独立用户/root目录和`/lib/firmware/xilinx/a10-isolated-single-20261023-v1`；当前未加载，无材料删除。
- 下一步可进行A11电脑侧准备、审查真实MLP核和调用边界；A11/A12/全模型实板尚未验收，需新范围授权，**本轮到A10结束，不自动继续上板**。

给B/C的确定平台信息和安全边界：`docs/handoffs/A_A10_MINIMAL_COMPLETE_20261023.md`。
归档一致性与源码/文档/证据SHA见`seal_01.json`。凭据不入库，不改永久sudo权限。
