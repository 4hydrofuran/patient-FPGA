# A10 收尾后的电脑端联调与候选封存

结论：PC联调通过；A10仍NOT_PASSED。本增量没有连接COM5/SSH、上传文件或执行任何板端命令。最新用户授权仍为“允许这次仅收尾恢复”，其结果已在上一窗口独立核验；没有把该授权扩大成新测试。

工程根`C:/Patientqwen`，分支`member-a/a10-peer-intake-20261023`，基准HEAD`53b4666`，保留全部既有修改、原A00—A17、peer包和失败记录。未提交或推送。实际模型设置unknown，无子代理。

## 实际改动及覆盖范围

新增`platform/qwen35/a10/test_idle_integration_pc.py`，8个Linux PC方法贯通实际构造器、run/main、租约与双flock、guard、日志fsync、内核增量门禁、service/command编排、真实短命PC子进程waitpid、释放判断、归档与receipt。

板身份/权限、温度及拓扑观测、进程全局扫描、DT和systemctl/dfx/insmod/rmmod的外部行为全部为显式状态化夹具。未打开设备节点或加载XRT；实际执行的子进程只允许已知无硬件Python夹具。正常流程及失败流程的断言不等于真实硬件验收，也不是真实ARM64或硬件恢复测试。

新增方法覆盖：正常退出后释放及恢复的顺序；PL前暂态扫描保留、连续两次完整读；新内核错误；错误worker身份；退出后已删除设备VMA；非零引用；租约被改；GDM停止超时。失败时不卸载、不自动恢复、不写成功收据，真实PC锁一直保留到测试断言结束；测试清理只关闭电脑临时锁，不改变生产隔离策略。

本增量没有修改生产控制器、驱动、内核、数学、语音、模型、计算核或性能参数。上一窗口的`wait_prepl_quiet`修复首次封装进独立v4候选。旧v1/v2/v3、原始BOARD报告和旧封存清单不改、不重放。

## 命令与结果

所有精确argv、cwd、完整输出、时间和退出码保存在同目录JSON；外层均由`D:/Python/Python314/python.exe -B platform/a1/record.py --log <新JSON> -- <以下argv>`记录。

| 域 | 命令/证据 | 结果 |
|---|---|---|
| 首次PC联调 | `integration_01.json`，下方单模块命令 | exit1；8方法中4过、2失败、2错误；夹具拓扑顺序不符合真实snapshot的排序保证 |
| 修正后PC联调 | `integration_02.json`，同一命令 | 8/8，exit0；只修夹具排序，不放宽生产门禁 |
| Linux PC相关回归 | `components_01.json`，下方完整命令 | 81/81，exit0，测试体3.420s；不是板性能指标 |
| PC候选打包 | `package_01.json`，下方命令 | exit0；15 payload + 1 manifest；payload 16,170,354字节，未部署 |
| 旧/新契约 | 上一窗口`legacy_contracts.json`、`qwen35_config.json` | 均exit0；契约未改，复用有效证据，没有重复计算 |
| BOARD | 无 | 本增量0连接、0驱动/PL/XRT/计算，不更新板测计数 |

```text
wsl.exe -d KV260-A-2204 --cd /mnt/c/Patientqwen/platform/qwen35/a10 /usr/bin/python3 -B -m unittest -v test_idle_integration_pc

wsl.exe -d KV260-A-2204 --cd /mnt/c/Patientqwen/platform/qwen35/a10 /usr/bin/python3 -B -m unittest -v test_idle_integration_pc test_prepl_quiet test_idle_checkpoint test_ps_display_release test_isolated_idle test_xrt_worker_boundary test_minimal_gate test_kernel_log_gate test_peer_capture

D:/Python/Python314/python.exe -B platform/qwen35/a10/prepare_isolated_idle.py --project-root C:/Patientqwen --output C:/Patientqwen/platform/local/a10-isolated-idle-20261023-v4
```

## 候选、证据连续性与设计差距

新候选`platform/local/a10-isolated-idle-20261023-v4/manifest.json` SHA256：
`726723f471aa6bb3f6902b5a65a543402be0cf94202c25e169f89b9703867b06`。

没有review.json/attempt.json/执行收据，未赋予执行授权；不含PC测试夹具。新维护必须重新核对真实boot、状态、授权、基线及新包。旧固定v3上传/执行/收尾入口已经消费，不可套用或重放。

D09/D11差距：之前多数编排测试替换了日志/子进程边界，现增加8方法实际接线验证；相关PC覆盖由73增至81。该改善是测试覆盖变化，不是速度/内存/功耗改善。真实native空载退出、计算后释放、当前窗口原1036返回、软件reboot挂起及启动既有告警仍待处理。BO范围/分配峰值/同步及模型PSS/性能继续null。P2 NOT_IMPLEMENTED；20长度/1000数值回归仍CANCELLED_BY_USER。

最近板状态只能引用上一窗口`final_readback_01/state.json`（irq2、默认PL/GDM正常、无ZOCL/等待者/active lease），不是本次实时观察。下一步等待用户对新的一次短时空载维护窗口的明确答复；未获答复不再连接板子。空载通过后仍需独立判断计算后释放与原系统恢复，不能据PC结果宣称A10通过。
