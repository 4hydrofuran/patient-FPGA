"""Root bootstrap for the one scoped idle trial, NOT a generic board executor.

Exact reviewed current-boot kernel bytes must still match before an exclusive
review is created. No baseline auto-approval and no retry or automatic cleanup.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/var/lib/kv260-a10/a10-isolated-idle-20261023-v3')
BOOT = 'c5baeabe-273d-447e-b323-ff07dd7af201'
MANIFEST_SHA = 'b8d9c8761602422661104492c317a456507684dfc04b65cb2a116173fefa8b9a'
BASELINE_SHA = '31a92d866823966bde73ed5d2beec35028a7f92e013e7e93aa00a9c3a2b352b7'


def verify_fresh_log(proc):
    if (proc.returncode != 0 or proc.stderr or
            hashlib.sha256(proc.stdout).hexdigest() != BASELINE_SHA):
        raise RuntimeError('BASELINE_CHANGED_REVIEW_REQUIRED_NO_TRIAL')
    return proc.stdout


def main():
    if len(sys.argv) != 2 or sys.argv[1] != BOOT or os.geteuid() != 0:
        raise RuntimeError('EXACT_AUTHORIZED_BOOT_AND_ROOT_REQUIRED')
    if (ROOT.is_symlink() or ROOT.stat().st_uid != 0 or ROOT.stat().st_mode & 0o022 or
            hashlib.sha256((ROOT / 'manifest.json').read_bytes()).hexdigest() != MANIFEST_SHA):
        raise RuntimeError('ROOT_BUNDLE_PIN_DIFFERS')
    sys.path.insert(0, str(ROOT))
    from isolated_idle_policy import (KERNEL, MACHINE, SCOPE, digest, need,
                                      trusted_file, validate_review, verify_bundle)
    from accelerator_release_gate_v2 import collect, require_no_users
    need(os.uname().machine == 'aarch64' and os.uname().release == KERNEL, 'exact ARM64 kernel required')
    need(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == BOOT and
         digest('/etc/machine-id') == MACHINE, 'board/boot changed')
    manifest = verify_bundle(ROOT, MANIFEST_SHA)
    for name in manifest['files']:
        trusted_file(ROOT / name)
    need(not os.path.lexists('/var/lock/kv260-a1/active') and
         not Path('/sys/module/zocl').exists(), 'active maintenance or module: no takeover')
    need(not Path('/var/lib/kv260-a10/a10-isolated-idle-20261023-v1/attempt.json').exists(),
         'earlier idle attempt: do not replay')
    failed = Path('/var/lib/kv260-a10/a10-isolated-idle-20261023-v2')
    need(digest(failed / 'review.json') == '38280aecacc853dbe33410003f856aaae4b02f6b14fe27e107e468474eb07994'
         and (failed / 'lifecycle.jsonl').stat().st_size == 0
         and not (failed / 'worker-result.json').exists(), 'pre-lock failure record changed')
    for name in ('baseline.raw.txt', 'review.json', 'attempt.json'):
        need(not os.path.lexists(ROOT / name), 'authorization/attempt already reserved')
    scan = collect(allow_ps_display=True)
    # Pre-mutation scan. This does not override the manager's later kernel gate.
    raw = verify_fresh_log(subprocess.run(['dmesg', '--raw'], capture_output=True, timeout=3))
    read_ns = time.monotonic_ns()
    require_no_users(scan, True, boot_id=BOOT)
    review = validate_review(dict(schema='A10_ISOLATED_IDLE_REVIEW_V1', scope=SCOPE,
                                   compute_authorized=False, authorized=True, allow_gdm_stop_restore=True,
                                   boot_id=BOOT, kernel=KERNEL, machine_sha256=MACHINE,
                                   window_id=ROOT.name, baseline_sha256=BASELINE_SHA,
                                   bundle_sha256=MANIFEST_SHA, baseline_read_uptime_ns=read_ns,
                                   authorization='USER_SINGLE_IDLE_XRT_AND_DEFAULT_PL_RECOVERY_20261023'))
    os.umask(0o077)
    with (ROOT / 'baseline.raw.txt').open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    with (ROOT / 'review.json').open('x', encoding='utf-8') as stream:
        json.dump(review, stream, sort_keys=True); stream.flush(); os.fsync(stream.fileno())
    review_sha = digest(ROOT / 'review.json')
    print(json.dumps(dict(event='ONE_IDLE_REVIEW_RESERVED', boot_id=BOOT,
                          review_sha256=review_sha, baseline_sha256=BASELINE_SHA)), flush=True)
    os.execv('/usr/bin/python3', ['/usr/bin/python3', '-B', '-I',
             str(ROOT / 'isolated_idle_manager_entry.py'), '--execute-authorized-idle-once',
             '--source', str(ROOT), '--review-sha256', review_sha])


if __name__ == '__main__':
    main()
