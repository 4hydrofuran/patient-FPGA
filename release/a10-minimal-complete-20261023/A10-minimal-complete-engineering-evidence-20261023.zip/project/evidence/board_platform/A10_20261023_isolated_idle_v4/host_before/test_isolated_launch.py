import hashlib
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import launch_isolated_idle_once as launch


class BootstrapTests(unittest.TestCase):
    def test_review_pin_is_exact_original_raw_not_new_observation(self):
        root = Path(__file__).resolve().parents[3]
        raw = (root / 'evidence/board_platform/A10_20261023_isolated_idle_v1/candidate_review_02/baseline.raw.txt').read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), launch.BASELINE_SHA)
        self.assertEqual(launch.verify_fresh_log(SimpleNamespace(returncode=0, stdout=raw, stderr=b'')), raw)
        for item in (SimpleNamespace(returncode=0, stdout=raw+b'new warning\n', stderr=b''),
                     SimpleNamespace(returncode=1, stdout=raw, stderr=b''),
                     SimpleNamespace(returncode=0, stdout=raw, stderr=b'error')):
            with self.assertRaisesRegex(RuntimeError, 'REVIEW_REQUIRED_NO_TRIAL'):
                launch.verify_fresh_log(item)

    def test_wrong_boot_never_opens_bundle_or_executes(self):
        with patch.object(launch.sys, 'argv', ['helper', 'old']), \
                patch.object(Path, 'read_bytes', side_effect=AssertionError('read forbidden')), \
                patch.object(launch.os, 'execv', side_effect=AssertionError('exec forbidden')):
            with self.assertRaisesRegex(RuntimeError, 'EXACT_AUTHORIZED_BOOT'):
                launch.main()


if __name__ == '__main__':
    unittest.main()
