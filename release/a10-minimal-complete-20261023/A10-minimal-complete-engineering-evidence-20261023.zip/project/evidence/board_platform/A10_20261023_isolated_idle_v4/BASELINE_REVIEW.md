# v4 current-boot baseline review — one idle lifecycle only

User renewed authorization: one short idle XRT lifecycle, temporary graphical isolation,
default-PL and graphical restoration. No compute, explicit compute BO, reboot, QSPI,
default-boot change, stress loop or automatic retry. Historical cleanup-only approval is
not reused. This is a new, additive v4 directory with preserved v1/v2/v3 evidence.

Current boot: `c5baeabe-273d-447e-b323-ff07dd7af201`, `6.8.12-a10irq2`.
The freshly captured `candidate_review_01/baseline.raw.txt` has SHA256
`f7e39b399f7357d4cb2ddd9abe6bed8f1358357904244fd900d0d46661518ca1`.
It is byte-identical to the independently read post-cleanup log in the previous window
(`A10_20261023_isolated_idle_v1/final_readback_01/kernel.raw.txt`). Relative to the original
reviewed boot baseline, only two retained informational rfkill lines were appended:
input handler enabled at 1450.481873 and disabled at 1974.558819. No new diagnostic is
being silently accepted. Existing boot warnings and taint remain known limitations;
see the previous `BASELINE_REVIEW.md`. This is not clean-kernel or production approval.

Read-only reconnection confirms default PL applied, GDM active, ZOCL absent, no active
lease or lock owner. Current temperatures are approximately 29–32 C. Original boot
files and XRT libraries retain their pinned hashes. All new diagnostics remain gated.
The bootstrap rereads the exact raw log before reserving this one attempt; a mismatch
stops execution rather than automatically changing the accepted baseline.

The v3 cleanup receipt and archived lease are separately pinned. No old attempt,
cleanup signal, numeric executor or result is replayed. The v4 bundle manifest is
`726723f471aa6bb3f6902b5a65a543402be0cf94202c25e169f89b9703867b06`.
