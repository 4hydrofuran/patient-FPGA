# A10 v4：一次真实空载生命周期通过，计算后恢复仍待验证

2026-10-23（本地）。PROJECT_ROOT=`C:\Patientqwen`；分支
`member-a/a10-peer-intake-20261023`，未提交/推送，原有修改与A00—A17进度保留。
本窗口的新授权仅一次短时空载验收；没有复用旧的“仅收尾”权限或旧执行器。

## 结果与安全边界

**BOARD空载通过，有已知限制；A10仍为NOT_PASSED_POSTCOMPUTE_RELEASE_OPEN。**
本次控制器日志跨度16.230秒，native worker观测跨度0.143秒；这些不是性能基准。
控制器采样温度29.430–32.997°C，最低MemAvailable 3,291,484 KiB、CmaFree 808,656 KiB。
零计算提交、零显式计算BO；配置/XRT内部缓冲未量化，不能写为零。
没有重启、RESET/FWUEN、QSPI或默认启动更改，没有压力循环和自动重试。

XRT设备/内核正常开关，metadata groups=3/3/3。worker PID9718实际正常退出并由
manager PID9612回收；随后172个进程的FD/VMA完整扫描无加速设备用户或映射，
模块refcount=0，才普通移除测试overlay、卸载ZOCL、恢复默认PL与GDM。
独立读回在控制器完成52.468秒后仍无新的未审查内核诊断；串口再次确认无active
lease和双锁占用。原启动包/XRT库哈希未变。COM5/SSH均释放。

默认overlay=`k26-starter-kits_image_1: applied`，GDM active，无ZOCL/render节点或管理进程。
板子仍运行irq2候选内核，并未声称回到1036。新增16文件用户/root暂存目录及测试
固件目录保留供追溯，**文件存在不代表当前加载**；未删除既有文件。

已知告警原样保留：外置模块taint、确切overlay属性生命周期提示，以及经32路DT核对的
IRQ枚举终止提示。不是“零告警/零泄漏/适合长期反复装卸”的证明。未新增refcount错误、
Oops或未知诊断；最终原始内核SHA见`audit_01.json`。

## 设计差距、改动与验证

- D09/D11：已封存v4控制器首次上板，GDM停止后取得两次相同的完整进程集合（第3次
  有界读取达成），再进入PL。未削弱native退出后的严格释放门禁。
- 本轮只更新电脑端上传/暂存/只读/单次启动/独立回读的v4路径、SHA及已恢复旧窗口证明，
  加串口4094字节行上限检查；旧host文件完整快照在`host_before/`。
- 新增`audit_isolated_idle_result.py`及6个PC测试，核验原始哈希、waitpid、扫描时序、
  正常恢复及延迟日志；注入晚到refcount错误、残余VMA、活进程/锁和假A10通过均拒绝。
- 原81项Linux控制器测试复用有效证据，未重跑；本轮13项PC host/证据测试及8个
  PowerShell计划检查通过，绝不计入板上运行次数。生产v4包、驱动、内核、模型、语音、
  数学和性能参数未改。包SHA=`726723f471aa6bb3f6902b5a65a543402be0cf94202c25e169f89b9703867b06`。
- 历史N32正确及小BO/PSS/RSS/CMA账继续复用，历史计算后卸载FAILED不被空载PASS覆盖。
  P2：NOT_IMPLEMENTED（压力、长稳、最大地址/BO、带宽/功耗、故障注入），本轮不实施。

## 命令、退出码和证据

以下从PROJECT_ROOT运行，Python为`D:\Python\Python314\python.exe -B`，PowerShell
为Windows系统`powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File`，仅本次进程策略。
固定boot参数：`c5baeabe-273d-447e-b323-ff07dd7af201`，kernel参数`6.8.12-a10irq2`。
真实认证仅于已核对主机的隐藏挑战中瞬时输入，不写入证据或持久权限配置。

| 命令/阶段 | 退出码 | 原始证据 |
|---|---:|---|
| `collect_readonly_uart.ps1 -Phase isolated_preflight -OutputPath .../preflight_01.json` | 0 | `preflight_01.json` |
| `upload_isolated_idle.py --boot-id <boot> --execute-authorized-upload --receipt .../upload_01.json` | 0，3子命令均0 | `upload_01.json`，16文件SHA |
| `isolated_prepare_uart.ps1 -Step root_stage -ExpectedBoot <boot> -ExpectedKernel <kernel> -AuthorizedOnce -OutputPath .../root_stage_01.json` | 0 | `root_stage_01.json` |
| 同上 `-Step candidate_readonly` | 0 | `candidate_readonly_01.json`、`candidate_review_01/` |
| `import_isolated_readonly.py <capture> <output>` | 0 | `BASELINE_REVIEW.md`，原始字节与上次收尾日志相同 |
| `verify_isolated_host_pc.py .../host_pc_tests_02.json` | 0 | 13方法+8计划，完整argv/stdout/stderr |
| `isolated_prepare_uart.ps1 -Step execute_idle ...`（一次） | 0 | `execute_idle_01.json`、`result_readback_01/lifecycle.jsonl` |
| `fetch_isolated_result.py --execute-readonly --output .../result_readback_01` | 0 | `fetch_receipt.json`、逐文件SHA与原始日志 |
| `collect_readonly_uart.ps1 -Phase isolated_preflight -OutputPath .../final_preflight_01.json` | 0 | 最终UART锁/温度/默认配置 |
| `audit_isolated_idle_result.py --output .../audit_01.json` | 0 | `audit_01.json`（PC核验BOARD证据，不是新板试验） |

PL相关8个命令（含2次只读list）及GDM stop/start均退出0，具体argv在audit/lifecycle内。
归档一致性、源码/文档/证据清单见`seal_01.json`。当前观察profile为
`board_profile.observed_irq2.json`；历史原始CSV、旧失败和原始交接包均未修改。

## 剩余项与下一步

只剩关键的**计算后资源释放与默认恢复验证**，以及成功后的A10最终证据收口。旧N32的
数值结果已有效，无需重跑200/1000轮或补资源数据；但旧故障正发生在计算后卸载，不能
用这次零计算空载流程推定已修好。需要独立计算worker/电脑测试后，另获一次极小的
32元素单调用范围授权，验证进程退出后释放与正常恢复。并非性能测试；异常即停止，
不得自动强杀、强卸载、重启或重试，仍不能保证不会挂起。

本窗口到此不再新增板动作。未开启A11/A12、模型硬件演示、性能优化或发布。
