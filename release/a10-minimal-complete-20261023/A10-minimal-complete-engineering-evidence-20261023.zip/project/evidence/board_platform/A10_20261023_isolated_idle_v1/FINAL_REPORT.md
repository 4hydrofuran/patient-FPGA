# A10 本轮结果：仅收尾已完成，A10仍未通过

工程 `C:/Patientqwen`，分支 `member-a/a10-peer-intake-20261023`，原A00—A17及peer原件保留。无提交/推送，不改模型、数学、语音、驱动、内核源码、HLS或性能参数。本目录是全部证据根。

## 当前状态及边界

- 唯一临时irq2启动已确认，boot `c5baeabe-273d-447e-b323-ff07dd7af201`，内核`6.8.12-a10irq2`。原1036启动包/默认启动配置未改；本轮未返1036。
- 最终只读`final_readback_01/state.json`：默认`k26-starter-kits_image_1=applied`，GDM active，无ZOCL/render节点/测试固件目录，无等待进程及active lease。29.663–32.096°C为当次观察，不是持续监控。
- 本轮驱动加载0、PL装卸0、XRT调用0、计算0。安全收尾PASS不等于空载XRT或A10 PASS。历史唯一N32正确继续复用，计算后卸载失败仍OPEN。
- 用户最后授权是“允许这次仅收尾恢复”；没有据此再次开始测试。20长度/1000回归仍CANCELLED_BY_USER，P2 NOT_IMPLEMENTED。

## 实际过程、失败与修复

1. `cold_boot_irq2_01.json`保留host原判失败：误把`mtdoops:`匹配成`Oops:`。原始启动已到Linux登录；词边界修复及实际捕获测试17项通过（`cold_boot_plan_02.json`），后续irq2只读独立确认。**没有重试启动**。
2. `candidate_review_02/`保存完整基线58,893字节，SHA256 `31a92d866823966bde73ed5d2beec35028a7f92e013e7e93aa00a9c3a2b352b7`。X509/固件pinctrl/TPM/RT等启动诊断保留，审阅边界见`BASELINE_REVIEW.md`，不是无警告/生产验收结论。
3. card0实际为PS显示设备，PID1/logind/桌面持有。新增严格driver、sysfs设备路径、设备号、inode前后证明，仅单独分类该节点；未知/其他card、已删除render映射、非零引用继续拒绝。`irq2_review_03.json`证明板上分类后无加速器占用。
4. v2在初始日志记录时重复传入`action`，`idle_execution_01.json`远端exit1。补真实logger/gate测试又找到READBACK的`boot_id`同类冲突，两处修复。首次新增测试错误保留在`idle_checkpoint_pc_01.json`，随后通过。`irq2_prelock_failure_readback_01.json`证明v2 lifecycle 0字节、无维护锁/ZOCL、默认PL未改、内核基线不变。
5. v3 manifest SHA `b8d9c8761602422661104492c317a456507684dfc04b65cb2a116173fefa8b9a`，16文件上传/root暂存读回均0。`idle_execution_02.json`在停止GDM后的完整扫描中遇到`/proc/3921/stat`消失及`PROCESS_SET_CHANGED`；不能确定该PID归属。门禁拒绝，PID3887/start_ticks144649保留锁，未发任何PL命令、未启动worker。未正常退出的远端exit记录为null，不填0。
6. `parked_readback_01/`独立取回原始日志、lease及进程fd/maps/status。管理者1线程、无子进程、无XRT库/设备映射，6个fd仅终端/日志/双锁。内核只新增`rfkill: input handler enabled`信息，完整raw SHA `bb70a7d9357dd63e49b010cc9059d6a9459b6d755eaf9ef2eed97d36b522e71d`。
7. 新“仅收尾”授权后，`prepl_cleanup_01/`以pidfd验证确切PID/start_ticks/日志/lease/无硬件，再发送SIGUSR1终止纯Python等待者并确认退出；重新取得双锁，恢复GDM后归档lease。**这是受控终止，不是管理程序正常返回**。无SIGKILL/复位/重启/PL操作；helper与SSH exit0。
8. `final_readback_01/`独立复核当前状态；内核仅又增加`rfkill: input handler disabled`，无新诊断。最终raw SHA `f7e39b399f7357d4cb2ddd9abe6bed8f1358357904244fd900d0d46661518ca1`。COM5已释放、SSH均退出；临时192.168.2.2/24仍为内存连接，无默认路由/持久网络变化。

## 新代码及分域测试

主要路径均在`platform/qwen35/a10/`：

- `isolated_idle_worker.py`及`isolated_idle_trial.py`/policy/两个entry：独立native进程与持续双锁/租约，真正waitpid后才核验释放；无BO/RunStart分支。
- `accelerator_release_gate_v2.py`：完整fd/VMA扫描、已核实PS显示分类，未知扫描不通过。
- 串口准备/冷启动、固定上传/暂存、只读采集/导入、固定SSH取证及本次专用`cleanup_prepl_isolated_once.py`；不作通用绕过工具。
- 最新电脑修复`wait_prepl_quiet`：只在首次PL命令前，停止GDM后等2秒、最多4次只读观察，需连续两次完整且相同进程集合。保留全部不完整观察；权限/内核/设备占用仍拒绝。任何PL命令开始或worker存在都不可使用，计算后的严格释放门禁不变。**此修复未打包、未上板；v1/v2/v3不可重放。**

| 域 | 证据/实际命令 | 结果 |
|---|---|---|
| 契约 | `legacy_contracts.json`、`qwen35_config.json` | 各exit0，复用本轮有效证据 |
| 最新Linux PC | `idle_components_wsl_06.json`，见下方完整命令 | 73/73方法通过，exit0 |
| 较早Windows PC | `idle_components_windows_02.json` | 54方法、50过/4 POSIX跳过，exit0；不是最新73项覆盖 |
| 新bootstrap | `idle_bootstrap_pc_01.json` | 2方法，exit0 |
| 上传 | `upload_plan_03.json` | 3方法，exit0 |
| 准备/执行计划 | `candidate_stage_launch_plan_05.json` | 8计划，exit0 |
| 专用收尾PC | `prepl_cleanup_pc_01.json` | 2方法，exit0 |
| 暂存 | `user_upload_01..03.json`、`root_stage_01..03.json` | 三个独立包逐文件校验，exit0，不覆盖旧包 |
| 初次控制器 | `idle_execution_01.json` | 日志冲突，远端exit1，PL前失败 |
| 隔离控制器 | `idle_execution_02.json` | 扫描竞争、隔离等待，远端exit null，PL前失败 |
| 授权收尾/终态 | `prepl_cleanup_01/fetch_receipt.json`、`final_readback_01/fetch_receipt.json` | 各exit0 |

最新Linux命令：

```text
wsl.exe -d KV260-A-2204 --cd /mnt/c/Patientqwen/platform/qwen35/a10 /usr/bin/python3 -B -m unittest -v test_prepl_quiet test_idle_checkpoint test_ps_display_release test_isolated_idle test_xrt_worker_boundary test_minimal_gate test_kernel_log_gate test_peer_capture
```

其它精确argv、stdout/stderr与退出码在对应JSON。Linux自身fd扫描首失败、Windows旧入口fcntl失败、日志字段失败均保留，没有抹去或放宽判断。

## 资源、未决项和下一步

最终MemTotal 3,997,488KiB、MemAvailable 3,284,124KiB、CmaTotal 819,200KiB、CmaFree 810,604KiB；CMA在物理内存内，不与PSS/BO重复累加。17,768KiB RSS只是被停住的Python管理进程瞬时值，不是模型峰值/总体A53预算。新BO地址/分配峰值/同步、模型PSS、性能和能耗均未测/null。

A10仍需：审阅PC静稳修复并获一个新的空载窗口，验证真正XRT进程退出及干净释放；之后才考虑另行授权的一次计算后释放核验，最后原系统回归。历史N32不自动重放，旧20长度/1000不补跑。正常软件reboot挂起缺陷未解决，不能宣称自动回滚通过。下次必须先读当前真实boot/租约，不能重用本次执行脚本/旧PID或将仅收尾授权扩大。
