# Current irq2 boot baseline review — idle scope only

Boot `c5baeabe-273d-447e-b323-ff07dd7af201`; kernel `6.8.12-a10irq2`.
Two independent root read-only captures (`irq2_review_01.json`, `_02.json`) have identical 58,893-byte raw kernel logs, SHA256 `31a92d866823966bde73ed5d2beec35028a7f92e013e7e93aa00a9c3a2b352b7`. Exact bytes and complete extracted diagnostics are retained under `candidate_review_02/`.

Reviewed baseline contains existing startup diagnostics, not a clean-kernel claim: X.509 built-in certificate parse warning/backtrace and unsigned module taint; firmware pinctrl limitations; TPM self-test error; USB dummy regulators; framebuffer warning; near-equal SD clock request rejection; RT throttling during boot; KASLR/IMA configuration; audit suppression; and default overlay firmware-name/resets removal advisories. The watchdog lines are driver descriptions, not watchdog trips. `mtdoops:` is a driver configuration message, not `Oops:`; the original host matcher false-positive and its fix remain separately recorded.

No ZOCL/test overlay/compute was active during these captures. The only bound DRM device is the PS display (`/sys/devices/platform/axi/fd4a0000.display`, `zynqmp-display`, char 226:0, node inode 662). Display fd/VMA users are retained as separately identified observations, never blanket-exempting all DRM nodes. Current temperatures are approximately 29–31°C, not a continuous load test.

This exact historical baseline is accepted **only as a starting point for the user's single idle XRT process-lifecycle trial**. It does not approve security, TPM, pinctrl, real-time behavior, production deployment or compute. All subsequent new diagnostics remain subject to the existing action-specific kernel gate; refcount/OF errors, Oops, unknown warnings or log discontinuities stop further mutations. The launch helper must reread and match these exact bytes; any change requires a new review, not automatic adoption.

The board remains on irq2 with the original default PL until the separate one-shot launch. The PS classification revision is packaged as v2; v1 is retained unused. No additional reboot is authorized or necessary for this revision.
