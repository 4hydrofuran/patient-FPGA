"""Read-only release precondition, derived from the 20261023 peer gate.

No device opens, module/PL operations, signals, or kernel-error exemptions.
A snapshot is not an atomic exclusion mechanism: the caller must continuously
own the maintenance lease/locks and isolate other accelerator consumers.
Unknown/vanished/inaccessible process data is deliberately NOT a clean scan.
"""
import os
from pathlib import Path
import time


SCHEMA = "a10-accelerator-scan-v2"


def accelerator_path(path, cards=()):
    name = path.removesuffix(" (deleted)")
    # Include primary DRM nodes, not only render nodes. A closed fd does not
    # imply that an mmap disappeared when a native XRT library stays loaded.
    return name.startswith(("/dev/dri/", "/dev/zocl", "/dev/uio", "/dev/vfio/")) or name in cards


def mapped_accelerators(raw, cards=()):
    found = []
    for line in raw.splitlines():
        fields = line.split(None, 5)
        if len(fields) < 5:
            raise ValueError("MALFORMED_MAPS_ROW")
        if len(fields) == 6 and accelerator_path(fields[5], cards):
            found.append(line)
    return found


def start_ticks(proc):
    # comm can contain spaces and ')'; fields after the final ')' start at 3.
    return int((proc / "stat").read_text().rsplit(")", 1)[1].split()[19])


def collect(proc_root=Path("/proc"), cards=()):
    """One bounded-by-process-count observation; no retries or silent skips.

    Production use requires root, a reviewed Linux /proc, a fresh boot/lease,
    exclusive consumers and a controller deadline. No hardware access here.
    Custom device aliases must be supplied in cards; this does not establish
    that arbitrary aliases or uncooperative external consumers are impossible.
    """
    root = Path(proc_root)
    result = dict(schema=SCHEMA, scan_started_ns=time.monotonic_ns(),
                  scan_finished_ns=None, boot_id=None, boot_id_after=None,
                  scan_complete=False, device_holders=[], device_mappings=[],
                  scan_issues=[], inspected_processes=[])

    def pids():
        return sorted(p.name for p in root.iterdir() if p.name.isdecimal())

    try:
        result["boot_id"] = (root / "sys/kernel/random/boot_id").read_text().strip()
        before = pids()
        for pid in before:
            proc = root / pid
            try:
                started = start_ticks(proc)
                fds = sorted(p.name for p in (proc / "fd").iterdir())
                for fd in fds:
                    target = os.readlink(proc / "fd" / fd)
                    if accelerator_path(target, cards):
                        result["device_holders"].append(dict(pid=int(pid), fd=fd, target=target))
                for row in mapped_accelerators((proc / "maps").read_text(), cards):
                    result["device_mappings"].append(dict(pid=int(pid), map=row))
                if started != start_ticks(proc) or fds != sorted(p.name for p in (proc / "fd").iterdir()):
                    raise ValueError("PROCESS_OR_FD_TABLE_CHANGED")
                result["inspected_processes"].append(dict(pid=int(pid), start_ticks=started))
            except (OSError, ValueError, IndexError, UnicodeError) as exc:
                result["scan_issues"].append(dict(pid=int(pid), reason=type(exc).__name__ + ": " + str(exc)))
        if before != pids():
            result["scan_issues"].append(dict(reason="PROCESS_SET_CHANGED"))
        result["boot_id_after"] = (root / "sys/kernel/random/boot_id").read_text().strip()
        if not before or result["boot_id"] != result["boot_id_after"]:
            result["scan_issues"].append(dict(reason="EMPTY_PROCESS_SET_OR_BOOT_CHANGED"))
        result["scan_complete"] = not result["scan_issues"]
    except (OSError, ValueError, UnicodeError) as exc:
        result["scan_issues"].append(dict(reason=type(exc).__name__ + ": " + str(exc)))
    result["scan_finished_ns"] = time.monotonic_ns()
    return result


def require_release(snapshot, module_refcount, kernel_gate_allowed, *, boot_id):
    """Fail closed on incomplete/malformed observations. Does NOT unload."""
    if kernel_gate_allowed is not True:
        raise RuntimeError("KERNEL_GATE_BLOCKED_OR_UNKNOWN")
    if (snapshot.get("schema") != SCHEMA or snapshot.get("scan_complete") is not True or
            snapshot.get("boot_id") != boot_id or snapshot.get("boot_id_after") != boot_id):
        raise RuntimeError("PROCESS_SCAN_INCOMPLETE_OR_WRONG_BOOT")
    for key in ("scan_issues", "device_holders", "device_mappings", "inspected_processes"):
        if type(snapshot.get(key)) is not list:
            raise RuntimeError("PROCESS_SCAN_MISSING_FIELDS")
    if snapshot["scan_issues"] or not snapshot["inspected_processes"]:
        raise RuntimeError("PROCESS_SCAN_INCOMPLETE")
    if snapshot["device_holders"]:
        raise RuntimeError("ACCELERATOR_DESCRIPTOR_STILL_OPEN")
    if snapshot["device_mappings"]:
        raise RuntimeError("ACCELERATOR_VMA_STILL_MAPPED")
    if type(module_refcount) is not int or module_refcount != 0:
        raise RuntimeError("MODULE_REFERENCE_HELD_OR_UNKNOWN")

