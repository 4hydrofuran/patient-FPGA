"""One A10 job through installed XRT C ABI; no device access on import.

The input/BO contract derives from A's pinned short host. Actual output is
exported for independent PC comparison. No compiler, fallback, reset or retry.
"""
import ctypes as C
from pathlib import Path
import time
import uuid

WORDS = 4112
BO_BYTES = WORDS * 4
XCLBIN_UUID = '87b3bf55-dfd2-2b35-0a6a-55028f87deec'


class NativeAPI:
    def __init__(self):
        self.lib = C.CDLL('/usr/lib/libxrt_coreutil.so.2.18.0', use_errno=True)
        p, i, u, z, q = C.c_void_p, C.c_int, C.c_uint32, C.c_size_t, C.c_uint64
        signatures = {
            'xrtDeviceOpen': (p, [u]), 'xrtDeviceClose': (i, [p]),
            'xrtDeviceLoadXclbinFile': (i, [p, C.c_char_p]),
            'xrtDeviceGetXclbinUUID': (i, [p, p]),
            'xrtPLKernelOpenExclusive': (p, [p, p, C.c_char_p]),
            'xrtKernelClose': (i, [p]), 'xrtKernelArgGroupId': (i, [p, i]),
            'xrtBOAlloc': (p, [p, z, q, u]), 'xrtBOFree': (i, [p]),
            'xrtBOMap': (p, [p]), 'xrtBOAddress': (q, [p]),
            'xrtBOSize': (z, [p]), 'xrtBOSync': (i, [p, i, z, z]),
            'xrtRunOpen': (p, [p]), 'xrtRunClose': (i, [p]),
            # Fixed prefix only; explicit ctypes for each variadic argument.
            'xrtRunSetArg': (i, [p, i]), 'xrtRunStart': (i, [p]),
            'xrtRunState': (i, [p]),
        }
        for name, (result, args) in signatures.items():
            f = getattr(self.lib, name)
            f.restype, f.argtypes = result, args
            setattr(self, name, f)


def memory(phase):
    return dict(phase=phase, proc_status=Path('/proc/self/status').read_text(),
                smaps_rollup=Path('/proc/self/smaps_rollup').read_text(),
                meminfo=Path('/proc/meminfo').read_text(),
                explicit_bo_live_max_bytes=3*BO_BYTES,
                includes_hidden_xrt_allocations=False)


def execute_single(api, emit, checkpoint, golden, xclbin, park):
    """Keep every handle reachable until completion or indefinite quarantine."""
    device = kernel = run = None
    buffers, mapped = [], []
    in_flight = False
    begin = time.monotonic()

    def need(ok, message):
        if not ok:
            raise RuntimeError(message)

    def invoke(name, *args, handle=False):
        need(time.monotonic()-begin < 10, 'initialization soft deadline')
        emit('XRT_CALL_BEGIN', call=name)
        result = getattr(api, name)(*args)
        emit('XRT_CALL_END', call=name, result=result)
        if time.monotonic()-begin >= 10:
            park('INITIALIZATION_CALL_EXCEEDED_SOFT_DEADLINE')
        need(bool(result) if handle else result == 0, name+' failed')
        return result

    try:
        emit('MEMORY_OBSERVATION', **memory('before_device_open'))
        device = invoke('xrtDeviceOpen', 0, handle=True)
        invoke('xrtDeviceLoadXclbinFile', device, str(xclbin).encode())
        loaded_uuid = (C.c_ubyte*16)()
        invoke('xrtDeviceGetXclbinUUID', device, loaded_uuid)
        need(str(uuid.UUID(bytes=bytes(loaded_uuid))) == XCLBIN_UUID, 'loaded UUID differs')
        kernel = invoke('xrtPLKernelOpenExclusive', device, loaded_uuid,
                        b'krnl_vadd:{krnl_vadd_1}', handle=True)
        groups = [api.xrtKernelArgGroupId(kernel, n) for n in range(3)]
        need(groups == [3, 3, 3], 'metadata group differs')
        addresses = []
        for group in groups:
            buffer = invoke('xrtBOAlloc', device, BO_BYTES, 0, group, handle=True)
            buffers.append(buffer)
            address = api.xrtBOAddress(buffer)
            need(api.xrtBOSize(buffer) == BO_BYTES, 'BO size differs')
            need(0 <= address < 0x80000000 and BO_BYTES <= 0x80000000-address,
                 'BO outside pinned HP0 addressability')
            addresses.append(address)
            pointer = invoke('xrtBOMap', buffer, handle=True)
            need(pointer != C.c_void_p(-1).value, 'BO mapping failed')
            mapped.append((C.c_uint32*WORDS).from_address(pointer))
        emit('BO_CREATED', groups=groups, addresses=addresses, bytes_each=BO_BYTES,
             explicit_bo_total_bytes=3*BO_BYTES, maximum_budget_probe=False,
             loaded_xclbin_uuid=str(uuid.UUID(bytes=bytes(loaded_uuid))))
        emit('MEMORY_OBSERVATION', **memory('explicit_bos_live'))
        a, b, out = mapped
        for n in range(WORDS):
            a[n] = (0x80000000+7*8191+n*65537) & 0xffffffff if n < 32 else 0
            b[n] = (0x7fffffff-7*127+n*17) & 0xffffffff if n < 32 else 0
            out[n] = (~(a[n]+b[n])) & 0xffffffff if n < 32 else 0xdeadbeef
        emit('INPUTS_PREPARED_NOT_SUBMITTED', job=7, n=32, input_a=list(a[:32]),
             input_b=list(b[:32]), output_poison=list(out[:32]), guard_words=WORDS-32)
        sync_begin = time.monotonic()
        for buffer in buffers:
            invoke('xrtBOSync', buffer, 0, BO_BYTES, 0)
        sync_in_us = (time.monotonic()-sync_begin)*1e6
        run = invoke('xrtRunOpen', kernel, handle=True)
        for index, buffer in enumerate(buffers):
            invoke('xrtRunSetArg', run, index, C.c_void_p(buffer))
        invoke('xrtRunSetArg', run, 3, C.c_uint32(32))
        checkpoint('before_submit', None)
        emit('SINGLE_SUBMISSION_BEGIN', n=32, count=1)
        submitted = time.monotonic()
        in_flight = True  # A failed start is not proof that submission failed.
        need(api.xrtRunStart(run) == 0, 'start result unknown')
        states = []
        while True:
            if time.monotonic()-submitted >= 1:
                park('COMPUTE_SOFT_DEADLINE_NO_ABORT_NO_RELEASE')
            state = api.xrtRunState(run)
            if not states or states[-1] != state:
                states.append(state)
            if state == 4:
                break
            if state not in (1, 2, 3, 7):
                park('NON_COMPLETED_RUN_STATE_'+str(state))
            time.sleep(0.002)
        in_flight = False
        completed = time.monotonic()
        emit('POSITIVE_COMPLETION', state=4, observed_states=states,
             submit_poll_us=(completed-submitted)*1e6)
        need(api.xrtBOSync(buffers[2], 1, BO_BYTES, 0) == 0, 'output sync failed')
        readback = time.monotonic()
        actual = list(out[:32])
        mismatches = [dict(index=n, actual=actual[n], expected=golden[n])
                      for n in range(32) if actual[n] != golden[n]]
        bad_guards = [n for n in range(32, WORDS) if out[n] != 0xdeadbeef]
        result = dict(job=7, n=32, input_a=list(a[:32]), input_b=list(b[:32]),
                      actual_output=actual, independent_expected=golden,
                      mismatches=mismatches, changed_guard_indices=bad_guards,
                      guard_words_checked=WORDS-32, real_submissions=1,
                      sync_in_us=sync_in_us, sync_out_us=(readback-completed)*1e6,
                      completed_within_1s=readback-submitted < 1,
                      pass_numeric=not mismatches and not bad_guards)
        emit('ACTUAL_OUTPUT', **result)
        # Only positive completion reaches ordinary XRT handle destruction.
        for name, handle in [('xrtRunClose', run)]:
            need(getattr(api, name)(handle) == 0, name+' failed')
        run = None
        for buffer in reversed(buffers):
            need(api.xrtBOFree(buffer) == 0, 'BO close failed')
        buffers.clear()
        need(api.xrtKernelClose(kernel) == 0, 'kernel close failed')
        kernel = None
        need(api.xrtDeviceClose(device) == 0, 'device close failed')
        device = None
        emit('MEMORY_OBSERVATION', **memory('after_normal_release'))
        need(result['pass_numeric'] and result['completed_within_1s'], 'numeric/guard/deadline check failed')
        emit('SINGLE_COMPUTE_COMPLETE', real_submissions=1, n=32, pass_numeric=True)
        return result
    except Exception as error:
        if in_flight or device or kernel or run or buffers:
            park('XRT_CONTEXT_RETAINED: '+str(error))
        raise
