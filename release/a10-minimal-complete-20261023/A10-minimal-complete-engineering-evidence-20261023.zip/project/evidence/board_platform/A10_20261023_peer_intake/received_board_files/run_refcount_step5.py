"""A10 step five: one full idle lifecycle, then one N32 call and PL cleanup.

Fresh exact bundle/window only. This does not reboot or restore kernel 1036.
Reuses A's immutable management snapshots and action-scoped diagnostic gate.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import struct
import subprocess
import sys
import time
import uuid
sys.dont_write_bytecode = True
from idle_board_trial import (Trial, MACHINE, DEFAULT, CENTRAL, HASHES, RESTORE,
                              need, digest, active_handle, check_loaded, check_removed)
from minimal_gate import MinimalGate
from single_xrt_call import NativeAPI, execute_single

BOOT = '0e2f466a-87a3-4f5e-9cf4-50d6b7756832'
KERNEL = '6.8.12-a10irq2'
PACKAGE = 'a10-refcount-step5-20261022-v1'
DRIVER = Path(__file__).resolve().parent/'zocl.refcount.ko'
DRIVER_SHA = '388c45a0edefe221615d71ea948de00d0ef68190bdd8497b053dddf788f72b2c'
BOOT_FILES = {
    '/boot/firmware/image.fit': '23a0ad7516d6f67f248f952653324c18a9c7d1db31fdf27a003f021adf0ca61e',
    '/boot/firmware/boot.scr.uimg': 'f1eb9e841e100a64f59eed77bccd73396297ce93bbcb6ce4916a7b516793c685',
    '/boot/firmware/a10-candidate-irq2-20261021.fit': 'e60d7f49033ef8efbd2396fafbe94a3bc684a478d5f5e31676626d1bc5f6ae2b',
}
LIBRARIES = {
    '/usr/lib/libxrt_core.so.2.18.0': '88ad9c1c0c4aba93573436a81b09bbb06ace1d6f1b1dc5285ff987143c1d32d4',
    '/usr/lib/libxrt_coreutil.so.2.18.0': '398f44b57956d19876fc2b547689898b8be51f809822c576ca26f7813c841563',
}
XCLBIN_SHA = '9d1243508f887dfe7db76ad1f37984907fe39567bab1cb118403f7691ed98394'


class StepFive(Trial):
    boot, kernel_release, package = BOOT, KERNEL, PACKAGE
    target = Path('/lib/firmware/xilinx')/PACKAGE
    driver, driver_sha256 = DRIVER, DRIVER_SHA
    temperature_limit_mC, memory_reserve_KiB = 55000, 1048576

    def __init__(self, source, manifest_sha):
        self.source = source
        need(digest(source/'manifest.json') == manifest_sha, 'bundle manifest changed')
        manifest = json.loads((source/'manifest.json').read_text())
        need(set(p.name for p in source.iterdir()) == set(manifest['files'])|{'manifest.json'},
             'fresh bundle inventory differs; no automatic replay')
        for name, entry in manifest['files'].items():
            p = source/name
            need(p.is_file() and not p.is_symlink() and digest(p) == entry['sha256']
                 and p.stat().st_size == entry['bytes'], 'payload changed: '+name)
        self.log = (source/'lifecycle.jsonl').open('x', encoding='utf-8')
        self.manifest_sha = manifest_sha
        self.kernel_gate = MinimalGate()
        self.contract = json.loads((source/'window.json').read_text())
        baseline = (source/'baseline.raw.txt').read_bytes().decode('utf-8')
        need(digest(source/'baseline.raw.txt') == self.contract['reviewed_baseline_sha256'],
             'reviewed baseline changed')
        need(self.kernel_gate.observe_action(BOOT, baseline,
             self.contract['reviewed_baseline_sha256'], 'none')['allowed'], 'baseline rejected')
        self.compute_count = 0

    def emit(self, event, **data):
        row = dict(event=event, monotonic_s=time.monotonic(), **data)
        self.log.write(json.dumps(row)+'\n')
        self.log.flush()
        os.fsync(self.log.fileno())
        visible = {k:v for k,v in row.items() if k in
                   ('event','phase','call','result','exit_code','error','reason','n','real_submissions','pass_numeric')}
        print(json.dumps(visible), flush=True)

    def park(self, reason):
        self.emit('UNKNOWN_STATE_RETAIN_PROCESS_AND_LOCKS', reason=reason,
                  hardware_quiescence=None, automatic_cleanup=False)
        while True:
            time.sleep(30)

    def verify_irq_dt(self):
        base = Path('/sys/firmware/devicetree/base/axi')
        intc = base/'interrupt-controller@80020000'
        raw = (base/'zyxclmm_drm/interrupts-extended').read_bytes()
        parent = int.from_bytes((intc/'phandle').read_bytes(), 'big')
        cells = int.from_bytes((intc/'#interrupt-cells').read_bytes(), 'big')
        need(cells == 2 and len(raw) == 384, 'IRQ descriptor size/cells differs')
        triples = [struct.unpack('>III', raw[n:n+12]) for n in range(0, len(raw), 12)]
        need(triples == [(parent, n, 4) for n in range(32)], 'IRQ sequence/flags/parent differs')
        need(int.from_bytes((intc/'xlnx,num-intr-inputs').read_bytes(), 'big') == 32,
             'IRQ controller count differs')
        check_loaded(self.snapshot('verified_irq_topology'), PACKAGE)
        self.emit('EXACT_32_IRQ_DT_VERIFIED', raw_hex=raw.hex(), triples=triples,
                  parent=parent, cells=cells, driver_sha256=DRIVER_SHA)

    def kernel_checkpoint(self, phase, mutation):
        if phase=='before_submit':
            self.check_compute_topology(self.snapshot('verified_before_submit'),require_cu=True,allow_self=True)
        p = subprocess.run(['dmesg','--raw'], capture_output=True, timeout=3)
        need(p.returncode == 0 and not p.stderr, 'kernel log unavailable')
        raw = p.stdout.decode('utf-8')
        action, verified = 'none', False
        if phase == 'after_mutation':
            if mutation == ['insmod',str(DRIVER)]:
                action = 'insmod'
            elif mutation == ['dfx-mgr-client','-load',PACKAGE]:
                self.verify_irq_dt()
                action, verified = 'load_test', True
            elif mutation == ['dfx-mgr-client','-load',DEFAULT]:
                action = 'load_default'
        result = self.kernel_gate.observe_action(
            Path('/proc/sys/kernel/random/boot_id').read_text().strip(), raw, None, action, verified)
        self.emit('KERNEL_LOG_GATE', phase=phase, mutation=mutation, raw_log=raw, **result)
        need(result['allowed'], 'kernel gate stopped: '+result['reason'])

    def command(self, argv, state_changing=False):
        readonly = argv == ['dfx-mgr-client','-listPackage']
        write = argv in [['dfx-mgr-client','-load',PACKAGE],['dfx-mgr-client','-load',DEFAULT],
                         ['insmod',str(DRIVER)],['rmmod','zocl']]
        remove = len(argv) == 3 and argv[:2] == ['dfx-mgr-client','-remove'] and argv[2].isascii() and argv[2].isdigit()
        need((not state_changing and readonly) or (state_changing and (write or remove)),
             'outside reviewed command allowlist')
        return super().command(argv, state_changing)

    def remove(self, package):
        self.snapshot('before_remove_'+package)
        handle = active_handle(self.command(['dfx-mgr-client','-listPackage']), package)
        self.command(['dfx-mgr-client','-remove',handle], True)

    def assert_default(self, phase, initial):
        final = self.snapshot(phase)
        need(final['overlays'] == initial['overlays'] and final['module_refcount'] is None
             and not final['zocl_bound'] and not final['render_nodes'] and not final['device_holders']
             and final['fpga_state'] == 'operating' and final['vart_sha256'] == initial['vart_sha256'],
             'default restoration differs')
        active_handle(self.command(['dfx-mgr-client','-listPackage']), DEFAULT)
        return final

    def load_test(self):
        self.remove(DEFAULT)
        check_removed(self.snapshot('default_removed'), False)
        self.command(['insmod',str(DRIVER)], True)
        check_removed(self.snapshot('driver_unbound'), True)
        self.command(['dfx-mgr-client','-load',PACKAGE], True)
        check_loaded(self.snapshot('test_loaded'), PACKAGE)
        need(Path('/sys/module/zocl/srcversion').read_text().strip()=='15F2AC2306CB3CB7257CFCB','loaded module srcversion differs')

    def restore_default(self):
        self.remove(PACKAGE)
        check_removed(self.snapshot('test_removed'), True)
        self.command(['rmmod','zocl'], True)
        check_removed(self.snapshot('driver_removed'), False)
        self.command(['dfx-mgr-client','-load',DEFAULT], True)


    def service(self, action):
        need(action in ('stop','start'), 'outside approved service actions')
        self.kernel_checkpoint('before_graphical_'+action, None)
        self.emit('GRAPHICAL_SERVICE_COMMAND_BEGIN',action=action,unit='gdm.service')
        p=subprocess.Popen(['systemctl',action,'gdm.service'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:out,err=p.communicate(timeout=35)
        except subprocess.TimeoutExpired:self.park('GRAPHICAL_SERVICE_COMMAND_UNKNOWN_NO_KILL')
        self.emit('GRAPHICAL_SERVICE_COMMAND_END',action=action,exit_code=p.returncode,
                  stdout=out.decode(errors='replace'),stderr=err.decode(errors='replace'))
        need(p.returncode==0,'graphical service action failed')
        state=subprocess.run(['systemctl','is-active','gdm.service'],capture_output=True,text=True,timeout=5)
        need(state.stdout.strip()==('inactive' if action=='stop' else 'active'),'graphical service state differs')
        self.kernel_checkpoint('after_graphical_'+action,None)

    def controlled_idle_open_close(self):
        state=self.snapshot('before_idle_client_open')
        check_loaded(state,PACKAGE)
        node=Path(state['render_nodes'][0])
        need((Path('/sys/class/drm')/node.name/'device/driver/module').resolve().name=='zocl',
             'render device not owned by ZOCL')
        self.kernel_checkpoint('before_idle_client_open',None)
        self.emit('IDLE_RENDER_OPEN_BEGIN',node=str(node),compute_submissions=0)
        fd=os.open(node,os.O_RDWR|os.O_CLOEXEC)
        try:
            stat=os.fstat(fd)
            self.emit('IDLE_RENDER_OPEN_COMPLETE',node=str(node),rdev=stat.st_rdev,
                      explicit_compute_bo_allocations=0,compute_submissions=0)
        finally:
            os.close(fd)
        self.emit('IDLE_RENDER_CLOSE_COMPLETE',node=str(node))
        self.kernel_checkpoint('after_idle_client_close',None)
        check_loaded(self.snapshot('after_idle_client_close'),PACKAGE)

    def check_compute_topology(self, state, require_cu=False, allow_self=False):
        # Loading this one-CU xclbin may retain its registered CU until teardown.
        # Check that exact extra child, never waive arbitrary bindings/holders.
        details=state['zocl_binding_details']
        cus=[d for d in details if d['driver']=='cu_drv' and
             __import__('re').fullmatch(r'CU\.\d+\.auto',d['name'])]
        need(len(cus)==1 if require_cu else len(cus) in (0,1),'unexpected CU count')
        mains=[d for d in details if d['driver']=='zocl-drm' and d['name']=='axi:zyxclmm_drm']
        need(len(mains)==1 and all(Path(d['path']).parent==Path(mains[0]['path']) for d in cus),
             'CU parent differs')
        need(all(h['pid']==os.getpid() for h in state['device_holders']) if allow_self
             else not state['device_holders'],'foreign/unreleased compute holders')
        reduced=dict(state,zocl_binding_details=[d for d in details if d not in cus],
                     zocl_bound=[d['name'] for d in details if d not in cus],device_holders=[])
        check_loaded(reduced,PACKAGE)
        self.emit('COMPUTE_TOPOLOGY_VERIFIED',require_cu=require_cu,allow_self=allow_self,
                  cu_children=cus,actual_holders=state['device_holders'])

    def run(self):
        need(os.geteuid() == 0 and os.uname().machine == 'aarch64'
             and os.uname().release == KERNEL, 'wrong root/platform/kernel')
        signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT})
        self.kernel_checkpoint('preflight', None)
        initial = self.snapshot('initial')
        need(initial['overlays'] == {DEFAULT+'_image_1':'applied'} and initial['module_refcount'] is None
             and not initial['zocl_bound'] and not initial['render_nodes'] and not initial['device_holders'],
             'initial PL/owner state differs')
        for name, sha in {**BOOT_FILES,**LIBRARIES}.items():
            need(digest(name) == sha, 'pinned platform file changed: '+name)
        need(digest(DRIVER) == DRIVER_SHA, 'driver changed')
        need(not self.target.exists() and not Path('/state.txt').exists(), 'existing target/libdfx state')
        need(Path('/etc/dfx-mgrd/default_firmware').read_text().strip() == DEFAULT, 'default differs')
        for name, sha in RESTORE.items():
            need(digest(Path('/lib/firmware/xilinx')/DEFAULT/name) == sha, 'default PL changed')
        for name, sha in HASHES.items():
            need(digest(self.source/name) == sha and not os.path.lexists('/lib/firmware/'+name),
                 'test firmware differs or would overwrite')
        need(digest(self.source/'vadd.xclbin') == XCLBIN_SHA, 'xclbin changed')
        need(json.loads((self.source/'shell.json').read_text()) ==
             dict(shell_type='XRT_FLAT',num_pl_slots=1,num_aie_slots=0), 'shell differs')
        golden = json.loads((self.source/'golden.json').read_text())
        need(golden['n'] == 32 and golden['job'] == 7 and len(golden['expected']) == 32, 'golden differs')
        need(not CENTRAL.is_symlink() and CENTRAL.stat().st_uid == 0
             and not CENTRAL.stat().st_mode & 0o022, 'untrusted central directory')
        self.deploy_lock = (CENTRAL/'deployment.lock').open('a+')
        fcntl.flock(self.deploy_lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.shared_lock = Path('/run/lock/patient-qwen-linear.lock').open('a+')
        fcntl.flock(self.shared_lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        active = CENTRAL/'active'
        active.mkdir()
        lease = dict(owner='A',scope='A10_IRQ2_STEP5_IDLE_AND_ONE_N32',identity=MACHINE+':'+BOOT,
                     pid=os.getpid(),issued_unix=time.time(),expires_unix=time.time()+900,
                     token=uuid.uuid4().hex,compute_authorized=False,
                     authorization='USER_COMPLETE_STEP_FIVE_THIS_CONVERSATION',window=PACKAGE)
        def save_lease():
            with (active/'lease.json').open('w',encoding='utf-8') as f:
                json.dump(lease,f);f.flush();os.fsync(f.fileno())
        save_lease()
        self.emit('LEASE_ACQUIRED', scope=lease['scope'], identity=lease['identity'])
        self.service('stop')
        self.target.mkdir()
        for name in (*HASHES,'shell.json'):
            with (self.source/name).open('rb') as src, (self.target/name).open('xb') as dst:
                shutil.copyfileobj(src,dst)
            need(digest(self.source/name) == digest(self.target/name), 'staging differs')
        self.load_test()
        self.controlled_idle_open_close()
        self.restore_default()
        self.assert_default('idle_default_restored',initial)
        self.kernel_checkpoint('idle_complete', None)
        self.emit('FULL_IDLE_LIFECYCLE_PASS',compute_runs=0,explicit_compute_BO_allocations=0)
        lease.update(scope='A10_VADD_SHORT',compute_authorized=True,idle_lifecycle_pass=True)
        save_lease()
        self.load_test()
        check_loaded(self.snapshot('before_compute'),PACKAGE)
        need(self.compute_count == 0 and lease['expires_unix'] > time.time()+60, 'submission/lease gate')
        with (self.source/'compute_submission.json').open('x',encoding='utf-8') as f:
            json.dump(dict(count=1,n=32,job=7,boot_id=BOOT,reservation_only=True),f)
        self.compute_count += 1
        result = execute_single(NativeAPI(),self.emit,self.kernel_checkpoint,golden['expected'],
                                self.source/'vadd.xclbin',self.park)
        with (self.source/'actual_output.json').open('x',encoding='utf-8') as f:
            json.dump(result,f,indent=2)
        self.kernel_checkpoint('after_compute', None)
        self.check_compute_topology(self.snapshot('completed_no_compute_holders'))
        self.restore_default()
        final = self.assert_default('final_default_restored',initial)
        for name, sha in {**BOOT_FILES,**LIBRARIES}.items():
            need(digest(name) == sha, 'platform file changed')
        for name, sha in RESTORE.items():
            need(digest(Path('/lib/firmware/xilinx')/DEFAULT/name) == sha, 'default PL changed')
        self.kernel_checkpoint('final_readback', None)
        self.service('start')
        self.assert_default('graphical_restored_default_readback',initial)
        history = CENTRAL/'history'/PACKAGE
        need(not history.exists(), 'history destination exists')
        active.rename(history)
        self.emit('LEASE_ARCHIVED',sha256=digest(history/'lease.json'),path=str(history))
        receipt = dict(status='PASS_STEP5_IDLE_AND_ONE_N32_DEFAULT_PL_RESTORED',boot_id=BOOT,
                       kernel=KERNEL,real_submissions=1,n=32,idle_lifecycle_pass=True,
                       pass_numeric=True,manifest_sha256=self.manifest_sha,final=final,
                       lease_archive=str(history),normal_kernel_restore='NOT_TESTED_STEP6',
                       A10='NOT_PASSED_OVERALL')
        with (self.source/'receipt.json').open('x',encoding='utf-8') as f:
            json.dump(receipt,f,indent=2)
        self.emit('STEP5_COMPLETE',**receipt)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-authorized-step-five',action='store_true')
    parser.add_argument('--manifest-sha256',required=True)
    args = parser.parse_args()
    need(args.execute_authorized_step_five,'explicit step-five action required')
    trial = StepFive(Path(__file__).resolve().parent,args.manifest_sha256)
    try:
        trial.run()
    except Exception as error:
        trial.emit('STOP_NO_AUTOMATIC_RECOVERY',error=str(error),error_type=type(error).__name__)
        # Keep the owner and both locks across failed readbacks/mutations.
        if hasattr(trial,'deploy_lock'):
            trial.park('STOPPED_WINDOW_REQUIRES_REVIEW: '+str(error))
        raise
