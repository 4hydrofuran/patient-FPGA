# short34-threads2: UNBOUND deployment candidate

Prepared offline. BOARD is NOT_TESTED; no replayable compute authority is included.
Model weights, sidecar, tensor map, default platform and machine libraries remain external.
The native binary is the accepted 115d167265667f026594836760be12470876e2b001b9dc8b61773459da35efab.
The frozen gateway is derived from 40498c2388b6293d68f38907c71ffd8933a5803e.

From this directory, offline package/dependency check (never contacts devices):

```sh
python3 ordinary/fast_response_verify.py --domain PC --bundle . --suite package
```

Use a fresh extracted directory and fresh independent Owner ID for each BOARD window.
Only after separate BOARD execution authorization and accepted irq2 startup/handover:

```sh
sudo python3 ordinary/fast_response_verify.py --domain BOARD --bundle . --suite ordinary --execute-board --window-id a12-short34-threads2-pair-001
sudo python3 continuous/fast_response_verify.py --domain BOARD --bundle . --suite web --execute-board --window-id a12-short34-threads2-web-001
```

Run the second command after the first Owner has restored and independently released.
The ordinary pair has exactly 3 frozen R0/warm/hit requests; worst 4320/5000 calls, 1800 seconds.
Continuous mode has 60000 calls/14400 seconds, context 1024/output 24 and one worker.
The prefix must warm successfully before accepting input. The model must hit the bound cache.
Stop the whole continuous service from another trusted local shell:

```sh
sudo touch continuous/stop-request.json
```

Wait for in-flight completion, worker exit, original Owner restore/release receipts.
The original result-only HTTP service can remain for 30 minutes after hardware release.
Finish consultation freezes its score; it does not stop the model.

Rollback: stop and release the candidate, then use a fresh legacy70-threads2 package/directory and new Owner ID.
Never swap profiles inside a running window or reset a consumed run-v1 directory.
The package consumes its own web_gateway, adapters, prefix config and profile. Existing BOARD Python
dependencies may be reused from /home/ubuntu/patient-web-demo-20261026/.venv/lib/python3.12/site-packages.
No dependency installation, kernel change, login, reboot or flash action is performed by --help or offline checks.

Actual CPU generation (explicit external PC assets; no download):

```sh
python3 continuous/fast_response_verify.py --domain PC --bundle . --suite model --output /tmp/a12-pc-new-attempt
```

PC_DEPENDENCIES.json records local defaults; --model, --pc-binary and --pc-library-dir override them.
The 25-case model suite applies to the short profile. Legacy mode is covered by compatibility tests.
Browser timing uses performance.now and checked-answer DOM observations after two animation frames.
Backend timing uses Python monotonic_ns with nested stages. Join by session/request ID;
never subtract timestamps from these different clocks or count fixture/unchecked text as model latency.
