# KV260 Qwen3.5 A12 快速响应与核验答案缓存：无板交付 v1

日期：2026-10-27（北京时间）。先读 SUMMARY_zh-CN.md，完整文件摘要见 MANIFEST.json。

## 按用途选文件

- packages/*Deployment_VerifiedCache_Hybrid34T2*：当前推荐部署候选。解压后从 hybrid34-threads2/START_HERE.md 开始；continuous 网页命中缓存，ordinary 仍运行实时模型。
- packages/*EngineeringIncrement_Stage01_ShortPrompt*：N0～N6短提示词工程源码、测试和原始PC证据。
- packages/*EngineeringIncrement_Stage02_VerifiedCache*：C0～C5缓存工程最终源码、测试、报告、198条真实模型证明、真实浏览器逐题数据及失败修复证据。

工程增量接续现有C:/Patientqwen工程，在新的复核目录按Stage01→Stage02顺序展开，重叠源码以Stage02为准。历史证据原样保留；旧封存入口里的工作区相对路径和旧包名是历史路径，当前包的选择以本页为准。它不是全仓库、模型权重或操作系统备份。

部署包内先运行PC package检查；模型权重、匹配依赖和合法的新执行窗口仍需现有环境提供。包内BOARD命令只有另获实板授权后才能执行，当前候选UNBOUND且没有可重放授权。停止服务需等待原Owner完成/释放回执；结束问诊只冻结评分。

已实测同机真实浏览器25题，完整核验答案显示中位875.0→42.3毫秒，缓存25/25低于1秒；每条保留“已核验模型答案·缓存”标记。原生成为CPU_REFERENCE，本轮缓存不执行模型；未命中继续原模型/PL路径。该数据不是模型计算加速比或实板成绩。

独立纯实时Short34T2和Legacy70T2回退ZIP在仓库同一发布目录，与本总交付包并列。需要回退时先正常停止并释放当前窗口，再开独立新窗口。

BOARD仍NOT_TESTED；板端可见时延、真实PL未命中和硬件恢复/释放待后续实测。无模型权重、凭据、许可证正文或板端计算授权。
